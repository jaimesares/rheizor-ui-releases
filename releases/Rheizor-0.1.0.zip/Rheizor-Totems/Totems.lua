-- Tótems de chamán: barra de 4 elementos con el tótem activo, tiempo restante,
-- aviso al expirar y una columna por elemento con todos los tótems
-- (aprendidos, sin maná, en reutilización o por aprender).
--
--   Clic izquierdo en un elemento: pone el tótem elegido de ese elemento.
--   Clic derecho en un elemento:   destruye el tótem activo.
--   Clic en la columna:            pone ese tótem y lo deja como elegido.
-- También se pueden asignar teclas en Teclado > AddOns > Rheizor.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

-- totem: nombre de un tótem del elemento (teclas); totems: título del tooltip
local ELEMENTS = {
	{ key = "Earth", name = L["Tierra"], totem = L["Tótem de tierra"], totems = L["Tótems de tierra"],
	  slot = EARTH_TOTEM_SLOT or 2, color = { 0.9, 0.62, 0.25 },
	  spells = { 8071, 2484, 5730, 8075, 8143 } },
	{ key = "Fire", name = L["Fuego"], totem = L["Tótem de fuego"], totems = L["Tótems de fuego"],
	  slot = FIRE_TOTEM_SLOT or 1, color = { 1, 0.3, 0.08 },
	  spells = { 3599, 1535, 8190, 8181, 8227 } },
	{ key = "Water", name = L["Agua"], totem = L["Tótem de agua"], totems = L["Tótems de agua"],
	  slot = WATER_TOTEM_SLOT or 3, color = { 0.2, 0.6, 1 },
	  spells = { 5394, 5675, 8166, 8170, 8184, 16190 } },
	{ key = "Air", name = L["Aire"], totem = L["Tótem de aire"], totems = L["Tótems de aire"],
	  slot = AIR_TOTEM_SLOT or 4, color = { 0.7, 0.9, 1 },
	  spells = { 8177, 10595, 8512, 8835, 15107, 25908, 6495 } },
}

-- Nombres para Teclado > AddOns (ver Bindings.xml)
BINDING_HEADER_RHEIZOR = L["Rheizor · Tótems"]
for _, el in ipairs(ELEMENTS) do
	_G["BINDING_NAME_CLICK RheizorTotem" .. el.key .. ":LeftButton"] = el.totem
end

local M = R:RegisterModule("totems", {
	title = "Tótems",
	defaults = {
		enabled = true,
		locked = true,
		scale = 1,
		flyout = "hover",
		showUnknown = true,
		showNames = true,
		combatOnly = false,
		hideBlizzard = false,
		selected = {},
	},
	options = {
		{ type = "header", text = "Barra de tótems (solo chamán)" },
		{ type = "toggle", key = "enabled", name = "Activar barra de tótems",
		  desc = "Clic izquierdo en un elemento: pone su tótem elegido. Clic derecho: lo destruye. También puedes asignarles teclas en Teclado > AddOns." },

		{ type = "header", text = "Aspecto" },
		{ type = "toggle", key = "showNames", name = "Nombre bajo cada elemento" },
		{ type = "dropdown", key = "flyout", name = "Columnas de tótems",
		  desc = "Encima de cada elemento, una columna con todos sus tótems para elegir otro.",
		  values = { { "hover", "Al pasar el ratón" }, { "always", "Siempre" }, { "hidden", "Nunca" } } },
		{ type = "toggle", key = "showUnknown", name = "Incluir tótems no aprendidos",
		  desc = "Aparecen en gris en las columnas para que sepas cuáles te faltan." },

		{ type = "header", text = "Posición y tamaño" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueada, aparece un marco encima de la barra para arrastrarla." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 1.8, step = 0.05 },

		{ type = "header", text = "Comportamiento" },
		{ type = "toggle", key = "combatOnly", name = "Mostrar solo en combate",
		  desc = "Con la barra desbloqueada se muestra siempre." },
		{ type = "toggle", key = "hideBlizzard", name = "Ocultar tótems de Blizzard", reload = true,
		  desc = "Oculta los iconos de tótems que Blizzard pone bajo el retrato del jugador." },
	},
	unsupported = {
		"En combate el juego puede ocultar a los addons qué tótem tienes puesto y cuánto le queda: la barra sigue mostrando el tiempo (círculo, números y barrita), pero no puede avisar con el brillo cuando está a punto de acabar ni marcar el tótem en su columna.",
	},
})

local db
local bar
local slots = {}

local SLOT, FLY, GAP = 46, 34, 10
local WHITE = "Interface\\Buttons\\WHITE8X8"

----------------------------------------------------------------------
-- Hechizos
----------------------------------------------------------------------

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return (GetSpellInfo(id))
end

local function spellIcon(id)
	if C_Spell and C_Spell.GetSpellTexture then return C_Spell.GetSpellTexture(id) end
	return select(3, GetSpellInfo(id))
end

local function isKnown(id)
	if IsPlayerSpell and IsPlayerSpell(id) then return true end
	if IsSpellKnown and IsSpellKnown(id) then return true end
	if C_SpellBook and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(id) then return true end
	return false
end

-- Id del rango más alto que conoces (para el tooltip)
local function bestRank(id)
	local name = spellName(id)
	local info = name and C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(name)
	return info and info.spellID or id
end

local function isUsable(name)
	if C_Spell and C_Spell.IsSpellUsable then return C_Spell.IsSpellUsable(name) end
	return IsUsableSpell(name)
end

-- En combate el inicio y la duración del tiempo de reutilización son
-- secretos (no se pueden comparar ni pasar a SetCooldown desde un addon); el
-- objeto de duración sí se puede dar tal cual al marco. Sin el tiempo global.
local function setSpellCooldown(cd, name)
	if C_Spell.GetSpellCooldownDuration and cd.SetCooldownFromDurationObject then
		local ok, dur = pcall(C_Spell.GetSpellCooldownDuration, name, true)
		if ok and dur and pcall(cd.SetCooldownFromDurationObject, cd, dur, true) then return end
	end
	local ok, info = pcall(C_Spell.GetSpellCooldown, name)
	if not ok or not info then return end
	local start, duration = NS(info.startTime), NS(info.duration)
	if start and duration and duration > 1.5 then
		pcall(cd.SetCooldown, cd, start, duration)
	elseif start and duration then
		cd:Clear()
	end
end

-- Tótem puesto en un hueco cuando GetTotemInfo da valores secretos: se usa
-- el objeto de duración, que el círculo y la barrita pueden dibujar sin que
-- el addon lo lea
local function totemDuration(slot)
	if not GetTotemDuration then return nil end
	local ok, dur = pcall(GetTotemDuration, slot)
	return ok and dur or nil
end

----------------------------------------------------------------------
-- Piezas visuales
----------------------------------------------------------------------

local function decorate(btn, size, color)
	btn:SetSize(size, size)

	btn.bg = btn:CreateTexture(nil, "BACKGROUND")
	btn.bg:SetPoint("TOPLEFT", -2, 2)
	btn.bg:SetPoint("BOTTOMRIGHT", 2, -2)
	btn.bg:SetColorTexture(0, 0, 0, 0.8)

	btn.icon = btn:CreateTexture(nil, "ARTWORK")
	btn.icon:SetAllPoints()
	btn.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	btn.border = CreateFrame("Frame", nil, btn, "BackdropTemplate")
	btn.border:SetPoint("TOPLEFT", -2, 2)
	btn.border:SetPoint("BOTTOMRIGHT", 2, -2)
	btn.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 2 })
	btn.border:SetBackdropBorderColor(color[1], color[2], color[3], 1)

	btn.cd = CreateFrame("Cooldown", nil, btn, "CooldownFrameTemplate")
	btn.cd:SetAllPoints()
	btn.cd:SetDrawEdge(false)

	local hl = btn:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.18)

	btn.glow = btn:CreateTexture(nil, "OVERLAY")
	btn.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
	btn.glow:SetBlendMode("ADD")
	btn.glow:SetVertexColor(color[1], color[2], color[3], 1)
	btn.glow:SetPoint("CENTER")
	btn.glow:SetSize(size * 1.85, size * 1.85)
	btn.glow:Hide()
end

local function fontString(parent, size, layer)
	local fs = parent:CreateFontString(nil, layer or "OVERLAY")
	fs:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE")
	return fs
end

-- Destello al poner un tótem
local function addFlash(btn, color)
	local star = btn:CreateTexture(nil, "OVERLAY", nil, 7)
	star:SetTexture("Interface\\Cooldown\\star4")
	star:SetBlendMode("ADD")
	star:SetVertexColor(color[1], color[2], color[3])
	star:SetPoint("CENTER")
	star:SetSize(btn:GetWidth() * 2.2, btn:GetHeight() * 2.2)
	star:SetAlpha(0)

	local ag = star:CreateAnimationGroup()
	local scale = ag:CreateAnimation("Scale")
	scale:SetScaleFrom(0.3, 0.3)
	scale:SetScaleTo(1.3, 1.3)
	scale:SetDuration(0.45)
	local alphaIn = ag:CreateAnimation("Alpha")
	alphaIn:SetFromAlpha(0)
	alphaIn:SetToAlpha(1)
	alphaIn:SetDuration(0.1)
	local alphaOut = ag:CreateAnimation("Alpha")
	alphaOut:SetFromAlpha(1)
	alphaOut:SetToAlpha(0)
	alphaOut:SetStartDelay(0.15)
	alphaOut:SetDuration(0.35)
	btn.flash = ag
end

-- Pulso del brillo cuando al tótem le quedan pocos segundos
local function addPulse(btn)
	local ag = btn.glow:CreateAnimationGroup()
	ag:SetLooping("BOUNCE")
	local a = ag:CreateAnimation("Alpha")
	a:SetFromAlpha(1)
	a:SetToAlpha(0.15)
	a:SetDuration(0.35)
	btn.pulse = ag
end

----------------------------------------------------------------------
-- Tooltips
----------------------------------------------------------------------

local function slotTooltip(btn)
	local s = btn.slotData
	GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
	if s.active and GameTooltip.SetTotem then
		GameTooltip:SetTotem(s.el.slot)
	elseif s.spellID then
		GameTooltip:SetSpellByID(bestRank(s.spellID))
	else
		GameTooltip:SetText(s.el.totems, 1, 1, 1)
		GameTooltip:AddLine(L["Todavía no conoces ninguno."], 1, 0.3, 0.3)
	end
	GameTooltip:AddLine(" ")
	if s.spellID then
		GameTooltip:AddLine(L["|cff33ccffClic izquierdo:|r poner %s"]:format(spellName(s.spellID) or "?"), 1, 1, 1)
	end
	GameTooltip:AddLine(L["|cff33ccffClic derecho:|r destruir el tótem activo"], 1, 1, 1)
	GameTooltip:AddLine(L["Elige otro tótem en la columna de arriba."], 0.6, 0.6, 0.6)
	GameTooltip:Show()
end

local function flyTooltip(btn)
	local e = btn.entry
	if not e then return end
	GameTooltip:SetOwner(btn, "ANCHOR_RIGHT")
	GameTooltip:SetSpellByID(e.known and bestRank(e.id) or e.id)
	GameTooltip:AddLine(" ")
	if e.known then
		GameTooltip:AddLine(L["|cff33ccffClic:|r ponerlo y dejarlo como tótem de %s"]:format(btn.slotData.el.name:lower()), 1, 1, 1)
	else
		GameTooltip:AddLine(L["No aprendido todavía"], 1, 0.3, 0.3)
	end
	GameTooltip:Show()
end

local function hideTooltip() GameTooltip:Hide() end

----------------------------------------------------------------------
-- Creación de la barra
----------------------------------------------------------------------

local function createFly(s, index)
	local b = CreateFrame("Button", nil, s.col, "SecureActionButtonTemplate")
	b:RegisterForClicks("AnyUp", "AnyDown")
	decorate(b, FLY, s.el.color)
	b.border:SetBackdropBorderColor(s.el.color[1], s.el.color[2], s.el.color[3], 0.6)
	b.glow:SetSize(FLY * 1.9, FLY * 1.9)
	b:SetPoint("BOTTOM", s.col, "BOTTOM", 0, (index - 1) * (FLY + 5))
	b.slotData = s
	b:HookScript("OnClick", function(self)
		if self.entry and self.entry.known then M:Select(s, self.entry.id) end
	end)
	b:SetScript("OnEnter", flyTooltip)
	b:SetScript("OnLeave", hideTooltip)
	s.col.buttons[index] = b
	return b
end

local function createSlot(el, index)
	local s = { el = el }

	local btn = CreateFrame("Button", "RheizorTotem" .. el.key, bar, "SecureActionButtonTemplate")
	btn:RegisterForClicks("AnyUp", "AnyDown")
	btn:SetPoint("BOTTOMLEFT", bar, "BOTTOMLEFT", (index - 1) * (SLOT + GAP), 24)
	decorate(btn, SLOT, el.color)
	btn.cd:SetHideCountdownNumbers(true)
	btn:SetAttribute("type2", "destroytotem")
	btn:SetAttribute("totem-slot", el.slot)
	addFlash(btn, el.color)
	addPulse(btn)
	btn.slotData = s
	btn:SetScript("OnEnter", slotTooltip)
	btn:SetScript("OnLeave", hideTooltip)

	btn.timer = fontString(btn, 17)
	btn.timer:SetPoint("CENTER", 0, 0)

	-- Barra de duración y nombre bajo el icono
	local dur = CreateFrame("StatusBar", nil, bar)
	dur:SetStatusBarTexture(WHITE)
	dur:SetStatusBarColor(el.color[1], el.color[2], el.color[3])
	dur:SetMinMaxValues(0, 1)
	dur:SetPoint("TOPLEFT", btn, "BOTTOMLEFT", -2, -5)
	dur:SetPoint("TOPRIGHT", btn, "BOTTOMRIGHT", 2, -5)
	dur:SetHeight(4)
	dur.bg = dur:CreateTexture(nil, "BACKGROUND")
	dur.bg:SetAllPoints()
	dur.bg:SetColorTexture(0, 0, 0, 0.7)
	s.dur = dur

	s.label = fontString(bar, 9)
	s.label:SetPoint("TOP", dur, "BOTTOM", 0, -2)
	s.label:SetWidth(SLOT + GAP)
	s.label:SetWordWrap(false)

	-- Columna con todos los tótems del elemento
	local col = CreateFrame("Frame", nil, bar)
	col:SetPoint("BOTTOM", btn, "TOP", 0, 8)
	col:SetSize(FLY + 8, FLY)
	col:SetAlpha(0)
	col.buttons = {}
	s.col = col

	s.btn = btn
	return s
end

local function createBar()
	bar = CreateFrame("Frame", "RheizorTotemBar", UIParent)
	bar:SetSize(#ELEMENTS * SLOT + (#ELEMENTS - 1) * GAP, SLOT + 24)
	bar:SetMovable(true)
	bar:SetClampedToScreen(true)
	R:RegisterMovable(bar)

	for i, el in ipairs(ELEMENTS) do
		slots[i] = createSlot(el, i)
	end

	-- Marco para arrastrar cuando está desbloqueada
	local mover = CreateFrame("Frame", nil, bar, "BackdropTemplate")
	mover:SetPoint("TOPLEFT", -8, 8)
	mover:SetPoint("BOTTOMRIGHT", 8, -8)
	mover:SetFrameLevel(bar:GetFrameLevel() + 50)
	mover:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	mover:SetBackdropColor(0.1, 0.5, 0.8, 0.35)
	mover:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	mover:EnableMouse(true)
	mover:RegisterForDrag("LeftButton")
	mover.text = fontString(mover, 11)
	mover.text:SetPoint("BOTTOM", mover, "TOP", 0, 4)
	mover.text:SetText(L["|cff33ccffRheizor|r · Tótems — arrastra para mover"])
	mover:SetScript("OnDragStart", function()
		if not InCombatLockdown() then bar:StartMoving() end
	end)
	mover:SetScript("OnDragStop", function()
		bar:StopMovingOrSizing()
		bar:SetUserPlaced(false)
		local point, _, relPoint, x, y = bar:GetPoint()
		db.point = { point, relPoint, x, y }
	end)
	R:AddNudge(mover, bar)
	bar.mover = mover
end

----------------------------------------------------------------------
-- Contenido
----------------------------------------------------------------------

function M:BuildColumn(s)
	local known, unknown = {}, {}
	for _, id in ipairs(s.el.spells) do
		local entry = { id = id, name = spellName(id), known = isKnown(id) }
		if entry.name then
			table.insert(entry.known and known or unknown, entry)
		end
	end
	if db.showUnknown then
		for _, e in ipairs(unknown) do table.insert(known, e) end
	end
	s.list = known

	for i, entry in ipairs(s.list) do
		local b = s.col.buttons[i] or createFly(s, i)
		b.entry = entry
		b.icon:SetTexture(spellIcon(entry.id))
		b.icon:SetDesaturated(not entry.known)
		b.icon:SetAlpha(entry.known and 1 or 0.35)
		b:SetAttribute("type", entry.known and "spell" or nil)
		b:SetAttribute("spell", entry.known and entry.name or nil)
		b:Show()
	end
	for i = #s.list + 1, #s.col.buttons do
		s.col.buttons[i]:Hide()
		s.col.buttons[i].entry = nil
	end
	s.col:SetHeight(math.max(#s.list, 1) * (FLY + 5))
end

-- Tótem que pone el clic izquierdo del elemento
function M:UpdateSlotSpell(s)
	local id = db.selected[s.el.key]
	if not (id and isKnown(id)) then
		id = nil
		for _, e in ipairs(s.list or {}) do
			if e.known then id = e.id break end
		end
	end
	s.spellID = id
	R:RunOutOfCombat(function()
		s.btn:SetAttribute("type1", id and "spell" or nil)
		s.btn:SetAttribute("spell1", id and spellName(id) or nil)
	end)
	self:UpdateSlot(s)
end

function M:Select(s, id)
	db.selected[s.el.key] = id
	self:UpdateSlotSpell(s)
end

function M:UpdateSlot(s)
	local btn = s.btn
	local ok, have, name, start, duration, icon = pcall(GetTotemInfo, s.el.slot)
	-- En combate estos valores pueden ser secretos: no se sabe si hay tótem
	local secret = ok and issecretvalue ~= nil
		and (issecretvalue(have) or issecretvalue(start) or issecretvalue(duration)) or false
	duration = ok and NS(duration)
	local active = not secret and ok and NS(have) and duration and duration > 0 or false

	s.active = active
	s.secret = secret
	s.name = active and NS(name) or nil
	s.start = active and NS(start) or nil
	s.duration = active and duration or nil

	if active or secret then
		-- Círculo y barrita desde el objeto de duración (valen con valores secretos)
		local dur = totemDuration(s.el.slot)
		btn.cd:SetReverse(true)
		local swiped = dur and pcall(btn.cd.SetCooldownFromDurationObject, btn.cd, dur, true)
		if not swiped and active then pcall(btn.cd.SetCooldown, btn.cd, start, duration) end
		-- Sin el tiempo en claro, los números los pone el propio círculo
		btn.cd:SetHideCountdownNumbers(not secret)
		s.timerBar = dur and s.dur.SetTimerDuration and pcall(s.dur.SetTimerDuration, s.dur, dur,
			Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate or 0,
			Enum.StatusBarTimerDirection and Enum.StatusBarTimerDirection.RemainingTime or 1) or false
		s.dur:SetShown(active or s.timerBar)
		btn.icon:SetDesaturated(false)
		btn.icon:SetAlpha(1)
		btn.border:SetAlpha(1)
		btn.timer:SetText("")
		s.label:SetTextColor(s.el.color[1], s.el.color[2], s.el.color[3])
	end

	if active then
		btn.icon:SetTexture(icon)
		btn.glow:Show()
		btn.glow:SetAlpha(1)
		s.label:SetText(db.showNames and s.name or "")
		if not s.wasActive then btn.flash:Play() end
	elseif secret then
		-- El icono y el nombre secretos se pueden dibujar, pero no comprobar
		local id = s.spellID or s.el.spells[1]
		if not pcall(btn.icon.SetTexture, btn.icon, icon) then btn.icon:SetTexture(spellIcon(id)) end
		btn.glow:Hide()
		btn.pulse:Stop()
		if not (db.showNames and pcall(s.label.SetText, s.label, name)) then s.label:SetText("") end
	else
		btn.cd:SetHideCountdownNumbers(true)
		local id = s.spellID or s.el.spells[1]
		btn.icon:SetTexture(spellIcon(id))
		btn.icon:SetDesaturated(true)
		btn.icon:SetAlpha(0.45)
		btn.border:SetAlpha(0.35)
		btn.glow:Hide()
		btn.pulse:Stop()
		btn.timer:SetText("")
		btn.cd:SetReverse(false)
		if s.spellID then setSpellCooldown(btn.cd, spellName(s.spellID)) else btn.cd:Clear() end
		s.dur:Hide()
		s.label:SetText(db.showNames and s.spellID and spellName(s.spellID) or "")
		s.label:SetTextColor(0.55, 0.55, 0.55)
	end
	-- Tras un tramo secreto no se sabe qué se puso: sin destello al salir de combate
	if secret then s.wasActive = true else s.wasActive = active end

	-- Resaltar en la columna el tótem que está puesto
	for _, b in ipairs(s.col.buttons) do
		local isActive = s.name and b.entry and b.entry.name and s.name:find(b.entry.name, 1, true)
		b.glow:SetShown(isActive and true or false)
	end
end

function M:UpdateAll()
	for _, s in ipairs(slots) do self:UpdateSlot(s) end
end

function M:RebuildAll()
	R:RunOutOfCombat(function()
		for _, s in ipairs(slots) do
			M:BuildColumn(s)
			M:UpdateSlotSpell(s)
		end
		M:UpdateUsable()
		M:UpdateCooldowns()
	end)
end

-- Tinte azul si no hay maná, gris si no se puede usar
function M:UpdateUsable()
	for _, s in ipairs(slots) do
		for _, b in ipairs(s.col.buttons) do
			local e = b.entry
			if e and e.known then
				local usable, noMana = isUsable(e.name)
				if usable then
					b.icon:SetVertexColor(1, 1, 1)
				elseif noMana then
					b.icon:SetVertexColor(0.35, 0.45, 1)
				else
					b.icon:SetVertexColor(0.45, 0.45, 0.45)
				end
			end
		end
	end
end

function M:UpdateCooldowns()
	for _, s in ipairs(slots) do
		for _, b in ipairs(s.col.buttons) do
			if b.entry and b.entry.known then setSpellCooldown(b.cd, b.entry.name) else b.cd:Clear() end
		end
		if not s.active and not s.secret and s.spellID then setSpellCooldown(s.btn.cd, spellName(s.spellID)) end
	end
end

----------------------------------------------------------------------
-- Temporizadores y columnas al pasar el ratón
----------------------------------------------------------------------

local function formatTime(left)
	if left >= 60 then return string.format("%d:%02d", left / 60, left % 60) end
	if left >= 10 then return string.format("%d", left) end
	return string.format("%.1f", left)
end

local function onUpdate(_, elapsed)
	bar.throttle = (bar.throttle or 0) + elapsed
	if bar.throttle < 0.05 then return end
	local step = bar.throttle
	bar.throttle = 0

	local now = GetTime()
	for _, s in ipairs(slots) do
		local btn = s.btn
		if s.active and s.start then
			local left = s.start + s.duration - now
			if left > 0 then
				btn.timer:SetText(formatTime(left))
				if not s.timerBar then s.dur:SetValue(left / s.duration) end
				if left < 10 then
					btn.timer:SetTextColor(1, 0.25, 0.2)
					if not btn.pulse:IsPlaying() then btn.pulse:Play() end
				else
					btn.timer:SetTextColor(1, 1, 1)
					if btn.pulse:IsPlaying() then btn.pulse:Stop(); btn.glow:SetAlpha(1) end
				end
			else
				btn.timer:SetText("")
			end
		end

		-- Columna: aparece suavemente al pasar el ratón
		local target
		if db.flyout == "always" then
			target = 1
		elseif db.flyout == "hidden" then
			target = 0
		else
			-- La columna aparece también al pasar por su zona, para que nunca
			-- se pueda pulsar un botón invisible
			target = (btn:IsMouseOver() or s.col:IsMouseOver(0, -10, 0, 0)) and 1 or 0
		end
		local a = s.col:GetAlpha()
		if a ~= target then
			a = target > a and math.min(target, a + step * 8) or math.max(target, a - step * 5)
			s.col:SetAlpha(a)
		end
	end
end

----------------------------------------------------------------------
-- Posición, visibilidad y opciones
----------------------------------------------------------------------

function M:ApplyLayout()
	R:RunOutOfCombat(function()
		bar:SetScale(db.scale)
		bar:ClearAllPoints()
		local p = db.point
		if p then
			bar:SetPoint(p[1], UIParent, p[2], p[3], p[4])
		else
			bar:SetPoint("CENTER", UIParent, "CENTER", 0, -140)
		end

		local visibility = "show"
		if not db.enabled then
			visibility = "hide"
		elseif db.combatOnly and db.locked then
			visibility = "[combat] show; hide"
		end
		RegisterStateDriver(bar, "visibility", visibility)

		for _, s in ipairs(slots) do
			s.col:SetShown(db.flyout ~= "hidden")
		end
	end)
	bar.mover:SetShown(not db.locked)
end

function M:ResetPosition()
	db.point = nil
	if bar then self:ApplyLayout() end
end

function M:OnEnable()
	db = self.db
	if R:PlayerClass() ~= "SHAMAN" then return end

	R:KeepHidden({ "TotemFrame" }, function() return db.enabled and db.hideBlizzard end, L["Tótems: TotemFrame"])

	R:RunOutOfCombat(function()
		createBar()
		M:ApplyLayout()
		M:RebuildAll()
		bar:SetScript("OnUpdate", onUpdate)
	end)

	local pendingRebuild
	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_TOTEM_UPDATE")
	events:RegisterEvent("SPELLS_CHANGED")
	events:RegisterEvent("SPELL_UPDATE_COOLDOWN")
	events:RegisterEvent("SPELL_UPDATE_USABLE")
	events:RegisterUnitEvent("UNIT_POWER_UPDATE", "player")
	-- Al acabar el combate los datos dejan de ser secretos: se vuelven a leer
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	events:SetScript("OnEvent", function(_, event)
		if not bar then return end
		if event == "PLAYER_TOTEM_UPDATE" then
			M:UpdateAll()
		elseif event == "PLAYER_REGEN_ENABLED" then
			C_Timer.After(0.2, function() M:UpdateAll() end)
		elseif event == "SPELLS_CHANGED" then
			if not pendingRebuild then
				pendingRebuild = true
				C_Timer.After(0.5, function()
					pendingRebuild = nil
					M:RebuildAll()
				end)
			end
		elseif event == "SPELL_UPDATE_COOLDOWN" then
			M:UpdateCooldowns()
		else
			M:UpdateUsable()
		end
	end)
end

function M:OnOptionChanged(key, value)
	if not bar then
		if R:PlayerClass() ~= "SHAMAN" then R:Print(L["La barra de tótems solo funciona con un chamán."]) end
		return
	end
	if key == "hideBlizzard" then
		if value then
			R:KeepHidden({ "TotemFrame" }, function() return db.enabled and db.hideBlizzard end, L["Tótems: TotemFrame"])
		else
			R:NeedReload()
		end
	elseif key == "showUnknown" then
		self:RebuildAll()
	elseif key == "showNames" then
		self:UpdateAll()
	else
		self:ApplyLayout()
	end
end
