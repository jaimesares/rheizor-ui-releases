-- Medidor de amenaza al estilo Omen: una ventana con una barra por cada
-- miembro del grupo (y mascotas) con su amenaza sobre tu objetivo, ordenada
-- de más a menos, y una barra roja con lo que hace falta para quitar el agro.
--
-- El juego solo da la amenaza de tu grupo o banda. En Forever (motor 12.x)
-- los valores pueden llegar "secretos": según la documentación del cliente,
-- los de tu grupo sobre un enemigo normal o su placa no lo son, pero con
-- jefes (o midiendo el objetivo de tu objetivo) sí. Entonces las barras se
-- pintan igual (con el % respecto al tanque que da el juego), pero no se
-- pueden ordenar ni hacer cuentas, y no sale la barra de "quitar agro".

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("threat", {
	title = "Amenaza",
	defaults = {
		enabled = true,
		locked = true,
		showWhen = "group",
		width = 220,
		barHeight = 16,
		spacing = 1,
		maxBars = 10,
		texture = R.TEXTURES[2][1],
		bgAlpha = 0.5,
		fontSize = 11,
		title = true,
		growUp = false,
		valueFormat = "both",
		tankFirst = false,
		showPull = true,
		pets = true,
		classColors = true,
		targetTarget = true,
		div100 = false,
	},
	options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Activar medidor de amenaza",
		  desc = "Una ventana con la amenaza de cada miembro de tu grupo sobre tu objetivo, de más a menos." },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueado muestra datos de ejemplo y se puede arrastrar." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

		{ type = "header", text = "Aspecto" },
		{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "slider", key = "fontSize", name = "Tamaño de letra", min = 7, max = 18, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "title", name = "Título con el nombre del enemigo" },
		{ type = "toggle", key = "classColors", name = "Colores de clase" },
		{ type = "dropdown", key = "valueFormat", name = "Texto de cada barra",
		  values = { { "pct", "Porcentaje" }, { "abs", "Valor" }, { "both", "Valor y porcentaje" } },
		  desc = "El porcentaje es respecto al que tiene el agro. Si el juego da la amenaza en secreto, solo sale el porcentaje." },

		{ type = "header", text = "Tamaño" },
		{ type = "slider", key = "width", name = "Ancho", min = 120, max = 400, step = 2, format = R.fmt.int },
		{ type = "slider", key = "barHeight", name = "Alto de barra", min = 8, max = 32, step = 1, format = R.fmt.int },
		{ type = "slider", key = "spacing", name = "Separación", min = 0, max = 8, step = 1, format = R.fmt.int },
		{ type = "slider", key = "maxBars", name = "Número de barras", min = 1, max = 25, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "growUp", name = "Crecer hacia arriba",
		  desc = "La primera barra abajo y el resto por encima." },

		{ type = "header", text = "Comportamiento" },
		{ type = "dropdown", key = "showWhen", name = "Mostrar",
		  values = {
			{ "always", "Siempre que tengas un enemigo seleccionado" },
			{ "combat", "Solo en combate" },
			{ "group", "Solo en grupo o banda" },
			{ "groupcombat", "Solo en grupo y en combate" },
		  } },
		{ type = "toggle", key = "targetTarget", name = "Usar el objetivo de tu objetivo si es aliado",
		  desc = "Si seleccionas al tanque o a un sanador, muestra la amenaza sobre el enemigo al que ataca." },
		{ type = "toggle", key = "pets", name = "Incluir mascotas" },
		{ type = "toggle", key = "tankFirst", name = "El que tiene el agro, siempre arriba" },
		{ type = "toggle", key = "showPull", name = "Barra de quitar agro",
		  desc = "Barra roja con la amenaza a la que le quitarías el enemigo al tanque (110% cuerpo a cuerpo, 130% a distancia). No sale si no tienes amenaza, si ya tienes el agro o si el juego da las cifras en secreto." },

		{ type = "header", text = "Avanzado" },
		{ type = "toggle", key = "div100", name = "Dividir el valor entre 100",
		  desc = "Algunos clientes dan la amenaza multiplicada por 100. Actívalo solo si los números te salen enormes. También lo usan las placas de nombre de Rheizor." },
	},
	-- Lo que las cifras secretas impiden (se lista al final de la página)
	unsupported = {
		"Con jefes (y midiendo el objetivo de tu objetivo) el juego da la amenaza en secreto: entonces la lista no se ordena, no sale la barra de quitar agro y solo se ve el % respecto al tanque.",
	},
})

local db
local frame, mover
local bars = {}

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

local function setFont(fs, size)
	fs:SetFont(STANDARD_TEXT_FONT, size, "OUTLINE")
end

local function createBar(i)
	local bar = CreateFrame("StatusBar", nil, frame)
	bar.bg = bar:CreateTexture(nil, "BACKGROUND")
	bar.bg:SetAllPoints()
	bar.name = bar:CreateFontString(nil, "OVERLAY")
	bar.name:SetPoint("LEFT", 4, 0)
	bar.name:SetJustifyH("LEFT")
	bar.name:SetWordWrap(false)
	bar.value = bar:CreateFontString(nil, "OVERLAY")
	bar.value:SetPoint("RIGHT", -4, 0)
	bar.value:SetJustifyH("RIGHT")
	bar.name:SetPoint("RIGHT", bar.value, "LEFT", -4, 0)
	bars[i] = bar
	return bar
end

local function createFrame()
	frame = CreateFrame("Frame", "RheizorThreat", UIParent, "BackdropTemplate")
	frame:SetFrameStrata("MEDIUM")
	frame:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	frame:SetBackdropBorderColor(0, 0, 0, 1)
	frame.title = frame:CreateFontString(nil, "OVERLAY")
	frame.title:SetJustifyH("LEFT")
	frame.title:SetWordWrap(false)
	mover = R:CreateMover(frame, L["Amenaza"], db, "point", { "CENTER", "CENTER", 360, 40 })
	frame:Hide()
end

function M:ApplyStyle()
	if not frame then return end
	frame:SetWidth(db.width)
	frame:SetBackdropColor(0, 0, 0, db.bgAlpha)
	setFont(frame.title, db.fontSize)
	frame.title:ClearAllPoints()
	frame.title:SetPoint("TOPLEFT", 4, -3)
	frame.title:SetPoint("TOPRIGHT", -4, -3)
	for i = 1, db.maxBars do
		local bar = bars[i] or createBar(i)
		bar:SetStatusBarTexture(db.texture)
		bar:SetSize(db.width - 2, db.barHeight)
		bar.bg:SetTexture(db.texture)
		bar.bg:SetVertexColor(0.15, 0.15, 0.15, 0.6)
		setFont(bar.name, db.fontSize)
		setFont(bar.value, db.fontSize)
	end
	for i = db.maxBars + 1, #bars do bars[i]:Hide() end
	mover:SetShown(not db.locked)
end

function M:ResetPosition()
	db.point = nil
	if mover then mover:Place() end
end

----------------------------------------------------------------------
-- Datos
----------------------------------------------------------------------

local function groupUnits()
	local units = {}
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do
			units[#units + 1] = "raid" .. i
			if db.pets then units[#units + 1] = "raidpet" .. i end
		end
	else
		units[#units + 1] = "player"
		if db.pets then units[#units + 1] = "pet" end
		for i = 1, GetNumSubgroupMembers() do
			units[#units + 1] = "party" .. i
			if db.pets then units[#units + 1] = "partypet" .. i end
		end
	end
	return units
end

-- El enemigo del que se mide la amenaza
local function threatTarget()
	local unit = "target"
	if not UnitExists(unit) then return end
	if not NS(UnitCanAttack("player", unit)) then
		if not db.targetTarget then return end
		unit = "targettarget"
		if not UnitExists(unit) or not NS(UnitCanAttack("player", unit)) then return end
	end
	if NS(UnitIsDeadOrGhost(unit)) then return end
	return unit
end

local function isSecret(v)
	return issecretvalue and issecretvalue(v) or false
end

local function shortNumber(value)
	-- En el Classic original la API la da multiplicada por 100; en Forever parece
	-- que ya viene real. Opción por si acaso.
	if db.div100 then value = value / 100 end
	if value >= 1e6 then return string.format("%.1fM", value / 1e6) end
	if value >= 1e4 then return string.format("%.0fK", value / 1e3) end
	if value >= 1e3 then return string.format("%.1fK", value / 1e3) end
	return string.format("%d", math.floor(value + 0.5))
end

local entries = {}

-- ¿Esta unidad del grupo eres tú? En banda UnitIsUnit puede llegar secreto;
-- el GUID de los miembros del grupo no lo es
local function isMe(unit)
	if unit == "player" then return true end
	local same = NS(UnitIsUnit(unit, "player"))
	if same ~= nil then return same and true or false end
	local guid, mine = NS(UnitGUID(unit)), NS(UnitGUID("player"))
	return guid ~= nil and guid == mine
end

local function collect(mob)
	wipe(entries)
	local anySecret = false
	local pull
	for _, unit in ipairs(groupUnits()) do
		if UnitExists(unit) then
			local ok, tanking, _, scaled, raw, value = pcall(UnitDetailedThreatSituation, unit, mob)
			if ok and (isSecret(value) or (NS(value) and value > 0)) then
				local e = {
					unit = unit,
					name = NS(UnitName(unit)) or "?",
					tanking = NS(tanking),
					raw = raw,
					value = NS(value),
				}
				if not e.value then anySecret = true end
				local _, class = UnitClass(unit)
				e.class = NS(class)
				e.isPlayer = NS(UnitIsPlayer(unit))
				e.me = isMe(unit)
				-- Quitar agro: con el % "relativo" (100% = le quitas el agro) se
				-- sabe a qué amenaza llegarías tú (ya incluye el 110%/130%)
				local s = NS(scaled)
				if e.me and e.value and e.tanking == false and s and s > 0 then
					pull = e.value * 100 / s
				end
				entries[#entries + 1] = e
			end
		end
	end
	if db.showPull and pull and not anySecret then
		entries[#entries + 1] = { name = L["Quitar agro"], value = pull, pull = true }
	end
	return anySecret
end

local FAKE = {
	{ name = L["Tanque"], class = "WARRIOR", value = 12500, tanking = true },
	{ name = L["Tú"], class = "MAGE", value = 10800, me = true },
	{ name = L["Pícaro"], class = "ROGUE", value = 9500 },
	{ name = L["Sacerdote"], class = "PRIEST", value = 4200 },
	{ name = L["Cazador"], class = "HUNTER", value = 3900 },
}
local FAKE_PULL = { name = L["Quitar agro"], value = 16250, pull = true }

----------------------------------------------------------------------
-- Dibujo
----------------------------------------------------------------------

local function barColor(e)
	if e.pull then return 0.8, 0.1, 0.1 end
	if db.classColors and e.class and (e.isPlayer ~= false) then
		local c = RAID_CLASS_COLORS[e.class]
		if c then return c.r, c.g, c.b end
	end
	return 0.4, 0.6, 0.4
end

local function valueText(bar, e, pct)
	local fmt = db.valueFormat
	if e.value then
		local v = shortNumber(e.value)
		if fmt == "abs" or not pct then
			bar.value:SetText(v)
		elseif fmt == "pct" then
			bar.value:SetFormattedText("%.0f%%", pct)
		else
			bar.value:SetFormattedText("%s  %.0f%%", v, pct)
		end
	elseif e.raw ~= nil then
		-- Valor secreto: se deja al motor pintar el % respecto al tanque
		pcall(bar.value.SetFormattedText, bar.value, "%.0f%%", e.raw)
	else
		bar.value:SetText("")
	end
end

function M:Draw(list, mobName, secret)
	local shown = 0
	local top = list[1] and list[1].value
	local tankValue
	for _, e in ipairs(list) do
		if e.tanking and e.value then tankValue = e.value end
	end
	-- Largo respecto al primero de la lista (con valores secretos, respecto al tanque)
	local reference = top

	local y = db.title and (db.fontSize + 6) or 1
	frame.title:SetShown(db.title)
	frame.title:SetText(mobName and L["Amenaza: %s"]:format(mobName) or L["Amenaza"])

	for i, e in ipairs(list) do
		if i > db.maxBars then break end
		shown = i
		local bar = bars[i]
		bar:ClearAllPoints()
		local step = (i - 1) * (db.barHeight + db.spacing)
		if db.growUp then
			bar:SetPoint("BOTTOMLEFT", frame, "BOTTOMLEFT", 1, 1 + step)
		else
			bar:SetPoint("TOPLEFT", frame, "TOPLEFT", 1, -(y + step))
		end
		bar:SetStatusBarColor(barColor(e))

		local name = e.name
		if e.me then name = "» " .. name end
		if e.tanking then name = name .. " " .. L["|cffffd100(agro)|r"] end
		bar.name:SetText(name)

		local pct
		if e.value and reference and reference > 0 then
			pct = e.value / reference * 100
			bar:SetMinMaxValues(0, 1)
			bar:SetValue(math.min(e.value / reference, 1))
		elseif e.raw ~= nil then
			-- Secreto: largo según el % respecto al tanque
			pcall(bar.SetMinMaxValues, bar, 0, 100)
			pcall(bar.SetValue, bar, e.raw)
		else
			bar:SetMinMaxValues(0, 1)
			bar:SetValue(0)
		end
		-- El % siempre respecto al que tiene el agro (como Omen)
		if tankValue and e.value then pct = e.value / tankValue * 100 end
		valueText(bar, e, pct)
		bar:Show()
	end
	for i = shown + 1, #bars do bars[i]:Hide() end

	frame:SetHeight(y + math.max(shown, 1) * (db.barHeight + db.spacing))
	if secret and shown > 0 then
		frame.title:SetText((mobName and L["Amenaza: %s"]:format(mobName) or L["Amenaza"]) .. " " .. L["|cff888888(sin ordenar)|r"])
	end
end

local function sortEntries()
	table.sort(entries, function(a, b)
		local ta, tb = a.tanking == true, b.tanking == true
		if db.tankFirst and ta ~= tb then return ta end
		return (a.value or 0) > (b.value or 0)
	end)
end

local function shouldShow()
	local combat = InCombatLockdown() or NS(UnitAffectingCombat("player"))
	local group = IsInGroup()
	local w = db.showWhen
	if w == "combat" then return combat end
	if w == "group" then return group end
	if w == "groupcombat" then return group and combat end
	return true
end

function M:Update()
	if not frame then return end
	if not db.enabled then frame:Hide() return end

	-- Desbloqueado: ejemplo para colocarlo
	if not db.locked then
		wipe(entries)
		for _, e in ipairs(FAKE) do entries[#entries + 1] = e end
		if db.showPull then entries[#entries + 1] = FAKE_PULL end
		sortEntries()
		self:Draw(entries, L["Enemigo de ejemplo"])
		frame:Show()
		return
	end

	local mob = threatTarget()
	if not mob or not shouldShow() then frame:Hide() return end

	local secret = collect(mob)
	if not secret then
		sortEntries()
	elseif db.tankFirst then
		-- Sin poder comparar cifras, al menos el que tiene el agro va arriba
		for i, e in ipairs(entries) do
			if e.tanking then
				if i > 1 then table.insert(entries, 1, table.remove(entries, i)) end
				break
			end
		end
	end
	if #entries == 0 and db.showWhen ~= "always" then frame:Hide() return end
	local mobName = NS(UnitName(mob))
	-- Con un aliado seleccionado se mide el enemigo al que apunta él: se dice en el título
	if mob == "targettarget" and mobName then
		mobName = L["%s |cff888888(objetivo de %s)|r"]:format(mobName, NS(UnitName("target")) or "?")
	end
	self:Draw(entries, mobName, secret)
	frame:Show()
end

----------------------------------------------------------------------
-- Eventos (las actualizaciones se agrupan: como mucho ~6 por segundo)
----------------------------------------------------------------------

local pending = false
local function requestUpdate()
	if pending then return end
	pending = true
	C_Timer.After(0.15, function()
		pending = false
		M:Update()
	end)
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, unit)
	requestUpdate()
end)

function M:UpdateEvents()
	events:UnregisterAllEvents()
	if not db.enabled then return end
	for _, e in ipairs({ "UNIT_THREAT_LIST_UPDATE", "UNIT_THREAT_SITUATION_UPDATE", "PLAYER_TARGET_CHANGED",
		"GROUP_ROSTER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "UNIT_PET" }) do
		pcall(events.RegisterEvent, events, e)
	end
	pcall(events.RegisterUnitEvent, events, "UNIT_TARGET", "target")
end

function M:OnEnable()
	db = self.db
	-- Opción quitada ("relative"). La barra de quitar agro ha vuelto (showPull):
	-- la amenaza solo es secreta con jefes, no siempre en combate
	db.relative = nil
	createFrame()
	self:ApplyStyle()
	self:UpdateEvents()
	self:Update()
end

function M:OnOptionChanged(key)
	if key == "enabled" then self:UpdateEvents() end
	self:ApplyStyle()
	self:Update()
end
