-- Swing timer: barras de mano principal, mano izquierda y a distancia.
--
-- En Forever el registro de combate está cerrado a los addons, así que no se
-- sabe cuándo pega tu arma. El swing se estima con:
--   1. Tus hechizos: Disparo automático, varita, Golpe heroico/Rajar/
--      Magullar/Golpe de raptor (ocurren justo en el golpe) y hechizos con
--      tiempo de lanzamiento (reinician el swing).
--   2. Cronómetro según la velocidad de arma, que solo avanza cuando atacas
--      con el objetivo a tu alcance (si no, la barra espera llena y quieta).
--   3. Opcional: sincronizar con los golpes que recibe tu objetivo
--      (solo sin grupo ni mascota, para no confundirlos con los de otros).
--   4. Opcional: adelantar el golpe cuando paras un ataque (UNIT_COMBAT en
--      ti con PARRY; ese evento no dice quién pega, pero sí que has parado).

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("swing", {
	title = "Swing timer",
	defaults = {
		enabled = true,
		locked = true,
		hideIdle = true,
		showMain = true,
		showOff = true,
		showRanged = true,
		width = 220,
		height = 14,
		spacing = 3,
		texture = R.TEXTURES[2][1],
		bgAlpha = 0.6,
		border = true,
		spark = true,
		cMain = "ffd100",
		cOff = "80ffff",
		cRanged = "33ff33",
		cQueued = "ff3333",
		clipZone = true,
		showTime = true,
		showSpeed = true,
		textSize = 11,
		castReset = true,
		parryHaste = true,
		resyncTarget = true,
	},
	options = {
		{ type = "header", text = "Swing timer" },
		{ type = "toggle", key = "enabled", name = "Activar swing timer",
		  desc = "Barras que muestran cuánto falta para el siguiente golpe de tus armas." },
		{ type = "toggle", key = "showMain", name = "Barra de mano principal" },
		{ type = "toggle", key = "showOff", name = "Barra de mano izquierda", desc = "Solo aparece si llevas dos armas." },
		{ type = "toggle", key = "showRanged", name = "Barra a distancia", desc = "Disparo automático, varitas, arcos y armas arrojadizas." },

		{ type = "header", text = "Aspecto" },
		{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "border", name = "Borde" },
		{ type = "toggle", key = "spark", name = "Chispa en el borde de avance" },
		{ type = "toggle", key = "clipZone", name = "Zona de Disparo automático",
		  desc = "Marca en rojo el último medio segundo de la barra a distancia: si te mueves o lanzas algo ahí, retrasas el disparo." },
		{ type = "toggle", key = "showTime", name = "Tiempo restante" },
		{ type = "toggle", key = "showSpeed", name = "Velocidad del arma" },
		{ type = "slider", key = "textSize", name = "Tamaño del texto", min = 7, max = 20, step = 1, format = R.fmt.int },

		{ type = "header", text = "Posición y tamaño" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueado, las barras se muestran en modo demostración y puedes arrastrarlas." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "slider", key = "width", name = "Ancho", min = 80, max = 500, step = 5, format = R.fmt.int },
		{ type = "slider", key = "height", name = "Alto", min = 4, max = 40, step = 1, format = R.fmt.int },
		{ type = "slider", key = "spacing", name = "Separación", min = 0, max = 20, step = 1, format = R.fmt.int },

		{ type = "header", text = "Comportamiento" },
		{ type = "toggle", key = "hideIdle", name = "Ocultar cuando no atacas" },
		{ type = "toggle", key = "castReset", name = "Los hechizos con lanzamiento reinician el swing",
		  desc = "Como en Classic: al terminar de lanzar un hechizo con tiempo de lanzamiento, el swing empieza de cero." },
		{ type = "toggle", key = "parryHaste", name = "Adelantar el golpe al parar",
		  desc = "Como en Classic: cuando paras un ataque, tu siguiente golpe de mano principal llega antes." },
		{ type = "toggle", key = "resyncTarget", name = "Sincronizar con los golpes a tu objetivo",
		  desc = "Ajusta la barra cuando tu objetivo recibe un golpe cuerpo a cuerpo. Solo cuando vas sin grupo y sin mascota, para no confundirlo con los golpes de otros." },

		{ type = "header", text = "Colores" },
		{ type = "dropdown", key = "cMain", name = "Mano principal", values = R.COLORS },
		{ type = "dropdown", key = "cOff", name = "Mano izquierda", values = R.COLORS },
		{ type = "dropdown", key = "cRanged", name = "A distancia", values = R.COLORS },
		{ type = "dropdown", key = "cQueued", name = "Con golpe en cola", values = R.COLORS,
		  desc = "Color de la mano principal mientras tienes en cola Golpe heroico, Rajar, Magullar o Golpe de raptor." },
	},
	-- Lo que el registro de combate cerrado impide (se lista al final de la página)
	unsupported = {
		"Swing exacto golpe a golpe: el juego no dice a los addons cuándo pega tu arma, así que la barra se estima con su velocidad.",
		"Sincronizar con tus golpes en grupo o con mascota: el juego no dice a los addons de quién es cada golpe a tu objetivo.",
	},
})

local db
local container
local bars = {}
local order = { "main", "off", "ranged" }

-- Estado de cada temporizador
local timers = {
	main   = { start = nil, duration = 2, active = false },
	off    = { start = nil, duration = 2, active = false },
	ranged = { start = nil, duration = 2, active = false },
}

----------------------------------------------------------------------
-- Hechizos especiales
----------------------------------------------------------------------

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return (GetSpellInfo(id))
end

-- Habilidades "en el siguiente golpe": su éxito coincide con el golpe
local NEXT_SWING = {}
local NEXT_SWING_IDS = { 78, 845, 6807, 2973 } -- Golpe heroico, Rajar, Magullar, Golpe de raptor
-- Disparos: Disparo automático, Disparar (varita), Disparar (arco/arma), Lanzar
local RANGED = { [75] = true, [5019] = true, [3018] = true, [2764] = true }
local RANGED_NAMES = {}

local function buildSpellNames()
	for _, id in ipairs(NEXT_SWING_IDS) do
		local name = spellName(id)
		if name then NEXT_SWING[name] = true end
	end
	for id in pairs(RANGED) do
		local name = spellName(id)
		if name then RANGED_NAMES[name] = true end
	end
end

local function isQueued()
	local check = (C_Spell and C_Spell.IsCurrentSpell) or IsCurrentSpell
	if not check then return false end
	for name in pairs(NEXT_SWING) do
		if check(name) then return true end
	end
	return false
end

local function castTime(spellID)
	local info = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(spellID)
	return info and info.castTime or 0
end

----------------------------------------------------------------------
-- Temporizadores
----------------------------------------------------------------------

-- Sin arma el juego da velocidad 0: se trata como "no hay"
local function positive(v)
	v = NS(v)
	if v and v > 0 then return v end
end

local function isSecret(v)
	return issecretvalue ~= nil and issecretvalue(v)
end

-- En combate la velocidad del arma puede llegar secreta: se usa la última
-- que se pudo leer (fuera de combate). Así tampoco "desaparece" la mano
-- izquierda al empezar a atacar ya en combate.
local knownMain, knownOff, knownRanged

local function weaponSpeeds()
	local main, off = UnitAttackSpeed("player")
	if isSecret(main) or isSecret(off) then return knownMain, knownOff end
	knownMain, knownOff = positive(main), positive(off)
	return knownMain, knownOff
end

local function rangedSpeed()
	local speed = UnitRangedDamage("player")
	if isSecret(speed) then return knownRanged end
	knownRanged = positive(speed)
	return knownRanged
end

local function startSwing(key, now)
	local t = timers[key]
	now = now or GetTime()
	if key == "ranged" then
		t.duration = rangedSpeed() or t.duration
	else
		local main, off = weaponSpeeds()
		t.duration = (key == "main" and main or off) or t.duration
	end
	t.start = now
end

-- La velocidad cambió (prisa, debuffs…): se conserva la fracción recorrida
local function onSpeedChanged()
	local main, off = weaponSpeeds()
	local now = GetTime()
	for key, speed in pairs({ main = main, off = off }) do
		local t = timers[key]
		if speed and t.start and t.duration > 0 then
			local fraction = math.min((now - t.start) / t.duration, 1)
			t.duration = speed
			t.start = now - fraction * speed
		elseif speed then
			t.duration = speed
		end
	end
end

----------------------------------------------------------------------
-- Barras
----------------------------------------------------------------------

local WHITE = "Interface\\Buttons\\WHITE8X8"

local function createBar(key)
	local bar = CreateFrame("StatusBar", nil, container)
	bar:SetMinMaxValues(0, 1)
	bar.key = key

	bar.bg = bar:CreateTexture(nil, "BACKGROUND")
	bar.bg:SetAllPoints()

	bar.border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
	bar.border:SetPoint("TOPLEFT", -1, 1)
	bar.border:SetPoint("BOTTOMRIGHT", 1, -1)
	bar.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	bar.border:SetBackdropBorderColor(0, 0, 0, 1)

	bar.clip = bar:CreateTexture(nil, "ARTWORK", nil, 2)
	bar.clip:SetColorTexture(1, 0.1, 0.1, 0.45)
	bar.clip:SetPoint("TOPRIGHT")
	bar.clip:SetPoint("BOTTOMRIGHT")
	bar.clip:Hide()

	bar.spark = bar:CreateTexture(nil, "OVERLAY")
	bar.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
	bar.spark:SetBlendMode("ADD")

	bar.time = bar:CreateFontString(nil, "OVERLAY")
	bar.time:SetPoint("RIGHT", -4, 0)
	bar.speed = bar:CreateFontString(nil, "OVERLAY")
	bar.speed:SetPoint("LEFT", 4, 0)

	bar:Hide()
	bars[key] = bar
	return bar
end

function M:ApplyStyle()
	if not container then return end
	container:SetSize(db.width, db.height)
	for key, bar in pairs(bars) do
		bar:SetSize(db.width, db.height)
		bar:SetStatusBarTexture(db.texture)
		bar.bg:SetColorTexture(0, 0, 0, db.bgAlpha)
		bar.border:SetShown(db.border)
		bar.spark:SetSize(16, db.height * 2.2)
		for _, fs in ipairs({ bar.time, bar.speed }) do
			fs:SetFont(STANDARD_TEXT_FONT, db.textSize, "OUTLINE")
		end
		local colorKey = key == "main" and "cMain" or key == "off" and "cOff" or "cRanged"
		bar:SetStatusBarColor(R.HexToRGB(db[colorKey]))
	end
	container.layout = nil
end

-- Coloca una debajo de otra solo las barras visibles
local function layout(visible)
	local signature = table.concat(visible, ",")
	if container.layout == signature then return end
	container.layout = signature
	for i, key in ipairs(visible) do
		local bar = bars[key]
		bar:ClearAllPoints()
		bar:SetPoint("TOP", container, "TOP", 0, -(i - 1) * (db.height + db.spacing))
	end
end

-- ¿Está el objetivo a distancia de cuerpo a cuerpo? (nil = no se puede saber)
local function inMeleeRange()
	if not UnitExists("target") or not UnitCanAttack("player", "target") or UnitIsDeadOrGhost("target") then
		return false
	end
	local r
	if C_Spell and C_Spell.IsSpellInRange then
		r = NS(C_Spell.IsSpellInRange(6603, "target")) -- Atacar
	elseif IsSpellInRange then
		local name = spellName(6603)
		r = name and NS(IsSpellInRange(name, "target"))
	end
	if r ~= nil then return r == true or r == 1 end
	local ok, close = pcall(CheckInteractDistance, "target", 3)
	if ok and NS(close) ~= nil then return NS(close) and true or false end
	return true
end

-- Un temporizador "real": atacando o con un golpe reciente
local function isRunning(t, now)
	return t.active or (t.start ~= nil and now < t.start + t.duration + 0.4)
end

local function barVisible(key, now, demo)
	if key == "main" and not db.showMain then return false end
	if key == "off" and not db.showOff then return false end
	if key == "ranged" and not db.showRanged then return false end
	if demo then return true end

	local t = timers[key]
	if key == "off" and not select(2, weaponSpeeds()) then return false end
	if not db.hideIdle then return key ~= "ranged" or t.start ~= nil or t.active end
	return isRunning(t, now)
end

local function drawBar(bar, elapsed, duration)
	if not duration or duration <= 0 then duration = 2 end -- sin arma: velocidad 0
	local p = math.min(math.max(elapsed / duration, 0), 1)
	bar:SetValue(p)
	if db.spark and p < 1 then
		bar.spark:ClearAllPoints()
		bar.spark:SetPoint("CENTER", bar, "LEFT", p * db.width, 0)
		bar.spark:Show()
	else
		bar.spark:Hide()
	end
	bar.time:SetText(db.showTime and string.format("%.1f", math.max(duration - elapsed, 0)) or "")
	bar.speed:SetText(db.showSpeed and string.format("%.2f", duration) or "")

	if bar.key == "ranged" and db.clipZone and duration > 0.5 then
		bar.clip:SetWidth(db.width * 0.5 / duration)
		bar.clip:Show()
	else
		bar.clip:Hide()
	end
end

local throttle = 0
local function onUpdate(_, elapsed)
	throttle = throttle + elapsed
	if throttle < 0.02 then return end
	throttle = 0

	local now = GetTime()
	local demo = not db.locked
	local visible = {}

	for _, key in ipairs(order) do
		local bar = bars[key]
		local t = timers[key]

		-- Cronómetro: con el arma lista, el golpe sale en cuanto el objetivo
		-- está a tu alcance. Mientras no lo esté, la barra se queda llena y
		-- quieta. A distancia no se estima: cada disparo avisa solo.
		if key ~= "ranged" and t.active
			and (not t.start or now >= t.start + t.duration) and inMeleeRange() then
			startSwing(key, now)
		end

		if barVisible(key, now, demo) then
			table.insert(visible, key)
			if demo and not isRunning(t, now) then
				-- Desbloqueado y sin atacar: barra quieta para colocarla
				drawBar(bar, t.duration, t.duration)
			elseif t.start then
				drawBar(bar, now - t.start, t.duration)
			else
				drawBar(bar, t.duration, t.duration)
			end
			if key == "main" then
				local queued = isRunning(t, now) and isQueued()
				bar:SetStatusBarColor(R.HexToRGB(queued and db.cQueued or db.cMain))
			end
			bar:Show()
		else
			bar:Hide()
		end
	end
	layout(visible)
end

----------------------------------------------------------------------
-- Posición
----------------------------------------------------------------------

local function createContainer()
	container = CreateFrame("Frame", "RheizorSwingTimer", UIParent)
	container:SetMovable(true)
	container:SetClampedToScreen(true)
	R:RegisterMovable(container)

	local mover = CreateFrame("Frame", nil, container, "BackdropTemplate")
	mover:SetPoint("TOPLEFT", -6, 6)
	mover:SetPoint("BOTTOMRIGHT", 6, -6)
	mover:SetFrameLevel(container:GetFrameLevel() + 20)
	mover:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	mover:SetBackdropColor(0.1, 0.5, 0.8, 0.25)
	mover:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	mover:EnableMouse(true)
	mover:RegisterForDrag("LeftButton")
	mover.text = mover:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	mover.text:SetPoint("BOTTOM", mover, "TOP", 0, 3)
	mover.text:SetText(L["|cff33ccffRheizor|r · Swing timer — arrastra para mover"])
	mover:SetScript("OnDragStart", function() container:StartMoving() end)
	mover:SetScript("OnDragStop", function()
		container:StopMovingOrSizing()
		container:SetUserPlaced(false)
		local point, _, relPoint, x, y = container:GetPoint()
		db.point = { point, relPoint, x, y }
	end)
	R:AddNudge(mover, container)
	container.mover = mover

	for _, key in ipairs(order) do createBar(key) end
end

function M:ApplyLayout()
	if not container then return end
	container:ClearAllPoints()
	local p = db.point
	if p then
		container:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	else
		container:SetPoint("CENTER", UIParent, "CENTER", 0, -200)
	end
	container.mover:SetShown(not db.locked)
	-- El marco para arrastrar abarca las tres barras de la demostración
	local shown = (db.showMain and 1 or 0) + (db.showOff and 1 or 0) + (db.showRanged and 1 or 0)
	container:SetHeight(math.max(shown, 1) * (db.height + db.spacing) - db.spacing)
	container:SetShown(db.enabled)
end

function M:ResetPosition()
	db.point = nil
	self:ApplyLayout()
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

-- Golpes de tus habilidades: el daño que causan no es tu golpe blanco.
-- lastAbility = cuándo acertó la última; lastResync = el último ajuste por
-- golpe al objetivo, por si llegó antes que el aviso de la habilidad.
local lastAbility = 0
local lastResync -- { time, key, prevStart }
local ABILITY_WINDOW = 0.3

local function onSpellSucceeded(unit, _, spellID)
	spellID = NS(spellID)
	if not spellID then return end
	local name = spellName(spellID)
	if RANGED[spellID] or (name and RANGED_NAMES[name]) then
		startSwing("ranged")
	elseif name and NEXT_SWING[name] then
		-- Sustituye al golpe blanco: el swing se reinicia aquí
		startSwing("main")
	elseif castTime(spellID) == 0 then
		-- Habilidad instantánea: su golpe al objetivo no debe mover el swing
		local now = GetTime()
		lastAbility = now
		if lastResync and now - lastResync.time < ABILITY_WINDOW then
			timers[lastResync.key].start = lastResync.prevStart
		end
		lastResync = nil
	elseif db.castReset and castTime(spellID) > 0 then
		-- Solo si estás atacando: fuera de combate un casteo no debe mostrar la barra
		local now = GetTime()
		for _, key in ipairs({ "main", "off" }) do
			local t = timers[key]
			if t.active and t.start then startSwing(key, now) end
		end
	end
end

-- UNIT_COMBAT no dice quién pega, pero un golpe físico a tu objetivo casi
-- seguro es tuyo si vas solo y sin mascota. Se asigna a la mano que tocaba antes.
local function onTargetCombat(_, action, _, _, school)
	if not db.resyncTarget then return end
	if IsInGroup() or UnitExists("pet") or not timers.main.active then return end
	action, school = NS(action), NS(school)
	if not action or school ~= 1 then return end
	if action ~= "WOUND" and action ~= "MISS" and action ~= "DODGE" and action ~= "PARRY" and action ~= "BLOCK" then return end

	local now = GetTime()
	-- Es el golpe de una habilidad tuya que acaba de acertar, no el swing
	if now - lastAbility < ABILITY_WINDOW then return end
	local key = "main"
	local off = timers.off
	if off.active and off.start then
		local main = timers.main
		local mainLeft = main.start and math.abs(main.start + main.duration - now) or math.huge
		local offLeft = math.abs(off.start + off.duration - now)
		if offLeft < mainLeft then key = "off" end
	end
	-- Solo si el golpe llega cerca de cuando tocaba (evita confundir otros daños)
	local t = timers[key]
	if not t.start or math.abs(t.start + t.duration - now) < 0.4 * t.duration then
		-- Se recuerda por si el aviso de una habilidad llega justo después
		lastResync = { time = now, key = key, prevStart = t.start }
		startSwing(key, now)
	end
end

-- Parar un golpe acelera tu siguiente golpe de mano principal: si queda más
-- del 60 % del swing se adelanta un 40 % de la velocidad; si queda entre el
-- 20 % y el 60 %, se deja en el 20 %. UNIT_COMBAT en ti con PARRY = has parado.
local function onPlayerCombat(_, action)
	if not db.parryHaste or NS(action) ~= "PARRY" then return end
	local t = timers.main
	if not (t.active and t.start) then return end
	local now = GetTime()
	local left = t.start + t.duration - now
	local newLeft
	if left > 0.6 * t.duration then
		newLeft = left - 0.4 * t.duration
	elseif left > 0.2 * t.duration then
		newLeft = 0.2 * t.duration
	else
		return
	end
	t.start = t.start - (left - newLeft)
end

local handlers = {
	-- Activar el ataque no inicia nada: la barra espera quieta al primer golpe
	PLAYER_ENTER_COMBAT = function()
		timers.main.active = true
		timers.off.active = select(2, weaponSpeeds()) ~= nil
	end,
	PLAYER_LEAVE_COMBAT = function()
		timers.main.active = false
		timers.off.active = false
	end,
	START_AUTOREPEAT_SPELL = function() timers.ranged.active = true end,
	STOP_AUTOREPEAT_SPELL = function() timers.ranged.active = false end,
	UNIT_ATTACK_SPEED = onSpeedChanged,
	UNIT_SPELLCAST_SUCCEEDED = onSpellSucceeded,
}

local events = CreateFrame("Frame")
local targetEvents = CreateFrame("Frame")

function M:UpdateEvents()
	events:UnregisterAllEvents()
	targetEvents:UnregisterAllEvents()
	if not db.enabled then return end

	events:RegisterEvent("PLAYER_ENTER_COMBAT")
	events:RegisterEvent("PLAYER_LEAVE_COMBAT")
	events:RegisterEvent("START_AUTOREPEAT_SPELL")
	events:RegisterEvent("STOP_AUTOREPEAT_SPELL")
	events:RegisterUnitEvent("UNIT_ATTACK_SPEED", "player")
	events:RegisterUnitEvent("UNIT_SPELLCAST_SUCCEEDED", "player")

	-- UNIT_COMBAT: golpes a tu objetivo (sincronizar) y golpes que paras tú
	if db.resyncTarget and db.parryHaste then
		targetEvents:RegisterUnitEvent("UNIT_COMBAT", "target", "player")
	elseif db.resyncTarget then
		targetEvents:RegisterUnitEvent("UNIT_COMBAT", "target")
	elseif db.parryHaste then
		targetEvents:RegisterUnitEvent("UNIT_COMBAT", "player")
	end
end

----------------------------------------------------------------------

function M:OnEnable()
	db = self.db
	-- Opción quitada: el registro de combate está cerrado en Forever
	db.useCombatLog = nil
	buildSpellNames()

	createContainer()
	self:ApplyStyle()
	self:ApplyLayout()
	container:SetScript("OnUpdate", onUpdate)

	events:SetScript("OnEvent", function(_, event, ...) handlers[event](...) end)
	targetEvents:SetScript("OnEvent", function(_, _, unit, ...)
		if unit == "player" then onPlayerCombat(unit, ...) else onTargetCombat(unit, ...) end
	end)
	self:UpdateEvents()

	-- La velocidad inicial de las armas
	local main, off = weaponSpeeds()
	timers.main.duration = main or 2
	timers.off.duration = off or 2
	timers.ranged.duration = rangedSpeed() or 2
end

function M:OnOptionChanged(key)
	if key == "enabled" or key == "resyncTarget" or key == "parryHaste" then
		self:UpdateEvents()
	end
	self:ApplyStyle()
	self:ApplyLayout()
end
