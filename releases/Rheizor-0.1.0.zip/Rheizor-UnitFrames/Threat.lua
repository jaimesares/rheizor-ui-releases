-- Amenaza en el marco de objetivo de Rheizor: borde (completo o solo
-- esquinas), brillo suave o neón, barra de amenaza, porcentaje, color de la
-- vida, animaciones y sonido según tengas o no el agro.
--
-- Niveles según tu papel (los calcula Rheizor-Core, Tanks.lua):
--   daño/sanador: bien = sin agro, aviso = a punto de quitarlo, peligro = lo tienes
--   tanque:       bien = lo tienes seguro, aviso = te lo están quitando, peligro = no lo tienes
--   otro tanque:  el enemigo va a por otro tanque de tu grupo (si se distingue)
--
-- La amenaza del objetivo se lee por "target", que en Forever llega en claro
-- casi siempre. Con los jefes llega en secreto: no se puede saber el nivel,
-- así que solo se pintan el borde, la barra y el porcentaje con el color que
-- da el juego (sin animación, brillo ni sonido).
--
-- El brillo va por debajo del marco: su mitad interior queda tapada y solo
-- se ve lo que sale hacia fuera.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local WHITE = "Interface\\Buttons\\WHITE8X8"
local GLOW_CORNER = "Interface\\Common\\GlowBorder-Corner"
local GLOW_TOP = "Interface\\Common\\GlowBorder-Top"
local GLOW_LEFT = "Interface\\Common\\GlowBorder-Left"
local NEON = "Interface\\TutorialFrame\\UI-TutorialFrame-CalloutGlow"

local function tdb() return R.db and R.db.uf_threat end

local function off()
	local d = tdb()
	if d and not d.enabled then return L["Activa primero la amenaza en el marco."] end
end

-- disabled: apagado, o la casilla de esa parte sin marcar
local function without(key)
	return function()
		local reason = off()
		if reason then return reason end
		local d = tdb()
		if d and not d[key] then return L["Activa esa parte primero."] end
	end
end

local function cornersOnly()
	local reason = without("border")()
	if reason then return reason end
	local d = tdb()
	if d and d.borderStyle ~= "corners" then return L["Solo con «Solo las esquinas»."] end
end

local ANIMS = {
	{ "none", "Sin animación" },
	{ "pulse", "Latido suave" },
	{ "flash", "Parpadeo rápido" },
	{ "grow", "Crecer y encoger" },
}

local M = R:RegisterModule("uf_threat", {
	title = "Marco: Amenaza del objetivo",
	defaults = {
		enabled = false,
		role = "auto",
		onlyGroup = true,
		showOk = false,

		border = true,
		borderStyle = "full",
		borderPos = "outside",
		borderSize = 2,
		borderGap = 1,
		cornerLength = 12,
		borderAlpha = 1,

		glow = true,
		glowStyle = "soft",
		glowSize = 8,
		glowAlpha = 0.8,

		bar = false,
		barPos = "bottom",
		barHeight = 4,
		barGap = 2,

		health = false,

		text = true,
		textPos = "topright",
		textSize = 11,
		textColor = "level",
		textAlert = false,

		warnAnim = "pulse",
		dangerAnim = "flash",
		animTarget = "both",
		animSpeed = 1,
		sound = false,

		okColor = "33cc4d",
		warnColor = "ff9900",
		dangerColor = "ff1a1a",
		offtankColor = "3380ff",
		showOfftank = true,
		offtankAnim = "none",
	},
	options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Mostrar la amenaza en el marco de objetivo",
		  desc = "En el marco de objetivo de Rheizor (Marcos de unidad > Usar marcos de Rheizor)." },
		{ type = "dropdown", key = "role", name = "Tu papel",
		  values = {
			{ "auto", "Automático (Rheizor-Core > Tanques y amenaza)" },
			{ "dps", "Daño o sanador (evitar el agro)" },
			{ "tank", "Tanque (mantener el agro)" },
		  },
		  desc = "Automático: lo decide Rheizor-Core > Tanques y amenaza (actitud defensiva, oso, Furia recta, papel del grupo, tanque principal...). Allí también se elige quién más es tanque." },
		{ type = "toggle", key = "showOfftank", name = "Mostrar cuando lo lleva otro tanque",
		  desc = "El borde y el brillo en el color de «Lo lleva otro tanque». Cuándo se distingue: Rheizor-Core > Tanques y amenaza.", disabled = off },
		{ type = "toggle", key = "onlyGroup", name = "Solo en grupo o banda",
		  desc = "Yendo solo, lo que atacas siempre va a por ti.", disabled = off },
		{ type = "toggle", key = "showOk", name = "Mostrar también cuando todo va bien",
		  desc = "El borde y el brillo en el color de «Bien» (útil para tanques: ver que tienes el agro).", disabled = off },
		{ type = "button", name = "Probar", text = "Probar los niveles", func = function(mod) mod:Test() end,
		  desc = "Pasa por bien, aviso y peligro durante unos segundos. Necesita el marco de objetivo visible (Marcos de unidad > Modo prueba)." },

		{ type = "header", text = "Borde" },
		{ type = "toggle", key = "border", name = "Colorear el borde", disabled = off },
		{ type = "dropdown", key = "borderStyle", name = "Forma del borde", disabled = without("border"),
		  values = { { "full", "Marco completo" }, { "corners", "Solo las esquinas" } } },
		{ type = "slider", key = "cornerLength", name = "Largo de las esquinas", min = 4, max = 40, step = 1, format = R.fmt.int,
		  disabled = cornersOnly },
		{ type = "dropdown", key = "borderPos", name = "Posición del borde", disabled = without("border"),
		  values = { { "outside", "Por fuera del marco" }, { "inside", "Por dentro, sobre el borde negro" } } },
		{ type = "slider", key = "borderSize", name = "Grosor del borde", min = 1, max = 6, step = 1, format = R.fmt.int,
		  disabled = without("border") },
		{ type = "slider", key = "borderGap", name = "Separación del marco", min = 0, max = 8, step = 1, format = R.fmt.int,
		  desc = "Solo por fuera.", disabled = without("border") },
		{ type = "slider", key = "borderAlpha", name = "Opacidad del borde", min = 0.1, max = 1, step = 0.05, disabled = without("border") },

		{ type = "header", text = "Brillo" },
		{ type = "toggle", key = "glow", name = "Brillo alrededor del marco", disabled = off },
		{ type = "dropdown", key = "glowStyle", name = "Estilo del brillo", disabled = without("glow"),
		  values = { { "soft", "Suave (esquinas redondeadas)" }, { "neon", "Neón (más intenso)" } } },
		{ type = "slider", key = "glowSize", name = "Tamaño del brillo", min = 3, max = 32, step = 1, format = R.fmt.int, disabled = without("glow") },
		{ type = "slider", key = "glowAlpha", name = "Intensidad del brillo", min = 0.1, max = 1, step = 0.05, disabled = without("glow") },

		{ type = "header", text = "Barra de amenaza" },
		{ type = "toggle", key = "bar", name = "Barra de amenaza",
		  desc = "Una barra fina pegada al marco que se llena con tu porcentaje de amenaza, en el color del nivel.", disabled = off },
		{ type = "dropdown", key = "barPos", name = "Posición de la barra", disabled = without("bar"),
		  values = { { "bottom", "Debajo del marco" }, { "top", "Encima del marco" } } },
		{ type = "slider", key = "barHeight", name = "Alto de la barra", min = 2, max = 12, step = 1, format = R.fmt.int, disabled = without("bar") },
		{ type = "slider", key = "barGap", name = "Separación de la barra", min = 0, max = 10, step = 1, format = R.fmt.int, disabled = without("bar") },

		{ type = "header", text = "Porcentaje y vida" },
		{ type = "toggle", key = "text", name = "Porcentaje de amenaza", disabled = off },
		{ type = "dropdown", key = "textPos", name = "Posición del porcentaje", disabled = without("text"),
		  values = {
			{ "topright", "Arriba a la derecha" },
			{ "topleft", "Arriba a la izquierda" },
			{ "bottomright", "Abajo a la derecha" },
			{ "bottomleft", "Abajo a la izquierda" },
			{ "right", "Fuera, a la derecha" },
			{ "left", "Fuera, a la izquierda" },
			{ "center", "En el centro del marco" },
		  } },
		{ type = "slider", key = "textSize", name = "Tamaño del porcentaje", min = 8, max = 24, step = 1, format = R.fmt.int, disabled = without("text") },
		{ type = "dropdown", key = "textColor", name = "Color del porcentaje", disabled = without("text"),
		  values = { { "level", "El del nivel" }, { "white", "Blanco" } } },
		{ type = "toggle", key = "textAlert", name = "Porcentaje solo en aviso y peligro", disabled = without("text") },
		{ type = "toggle", key = "health", name = "Colorear la barra de vida",
		  desc = "En aviso y peligro la vida toma su color; el resto del tiempo, el suyo de siempre.", disabled = off },

		{ type = "header", text = "Animaciones y sonido" },
		{ type = "dropdown", key = "warnAnim", name = "Animación en aviso", values = ANIMS, disabled = off },
		{ type = "dropdown", key = "dangerAnim", name = "Animación en peligro", values = ANIMS, disabled = off },
		{ type = "dropdown", key = "offtankAnim", name = "Animación si lo lleva otro tanque", values = ANIMS, disabled = off },
		{ type = "dropdown", key = "animTarget", name = "Qué se anima", disabled = off,
		  values = { { "both", "Borde y brillo" }, { "glow", "Solo el brillo" }, { "border", "Solo el borde" } } },
		{ type = "slider", key = "animSpeed", name = "Velocidad de la animación", min = 0.5, max = 2.5, step = 0.1,
		  format = function(v) return ("×%.1f"):format(v) end, disabled = off },
		{ type = "toggle", key = "sound", name = "Sonido al pasar a peligro", disabled = off },

		{ type = "header", text = "Colores" },
		{ type = "color", key = "okColor", name = "Bien", disabled = off },
		{ type = "color", key = "warnColor", name = "Aviso", disabled = off },
		{ type = "color", key = "dangerColor", name = "Peligro", disabled = off },
		{ type = "color", key = "offtankColor", name = "Lo lleva otro tanque", disabled = off },
	},
	unsupported = {
		"Con los jefes el juego da la amenaza en secreto: solo se colorean el borde, la barra y el porcentaje con el color del juego, sin animación, brillo, sonido ni color de la vida.",
		"Solo en el marco de objetivo de Rheizor, no en el de Blizzard.",
	},
})

local db
local UF
local ind              -- lo nuestro dentro del marco de objetivo
local level, lastLevel -- "ok", "warn", "danger" o nil
local testUntil = 0
local healthTinted = false

----------------------------------------------------------------------
-- Papel y nivel
----------------------------------------------------------------------

-- Quién es tanque y el nivel lo decide Rheizor-Core (Tanks.lua): así las
-- placas y el marco dicen lo mismo del mismo enemigo
local function isTank()
	if db.role == "tank" then return true end
	if db.role == "dps" then return false end
	return R.IsPlayerTank and R:IsPlayerTank() or false
end

local function colorOf(lvl)
	return R.HexToRGB(db[lvl .. "Color"])
end

----------------------------------------------------------------------
-- Piezas
----------------------------------------------------------------------

local function tex(parent, layer, file)
	local t = parent:CreateTexture(nil, layer)
	t:SetTexture(file or WHITE)
	return t
end

-- Animación de un marco: opacidad y tamaño a la vez, de ida y vuelta
local function newAnim(frame)
	local group = frame:CreateAnimationGroup()
	group:SetLooping("BOUNCE")
	group.alpha = group:CreateAnimation("Alpha")
	group.alpha:SetFromAlpha(1)
	group.scale = group:CreateAnimation("Scale")
	group.scale:SetOrigin("CENTER", 0, 0)
	return group
end

local function build(f)
	ind = {}
	local base = f:GetFrameLevel()

	-- Borde: 4 lados o 8 trazos para las esquinas
	ind.borderFrame = CreateFrame("Frame", nil, f)
	ind.borderFrame:SetAllPoints(f)
	ind.borderFrame:SetFrameLevel(base + 7)
	ind.border = {}
	for i = 1, 8 do ind.border[i] = tex(ind.borderFrame, "OVERLAY") end
	ind.borderAnim = newAnim(ind.borderFrame)

	-- Brillo, por debajo del marco
	ind.glowFrame = CreateFrame("Frame", nil, f)
	ind.glowFrame:SetAllPoints(f)
	ind.glowFrame:SetFrameLevel(math.max(0, base - 1))
	ind.soft = {}
	for i = 1, 4 do ind.soft[i] = tex(ind.glowFrame, "BACKGROUND", GLOW_CORNER) end
	ind.soft[5] = tex(ind.glowFrame, "BACKGROUND", GLOW_TOP)
	ind.soft[6] = tex(ind.glowFrame, "BACKGROUND", GLOW_TOP)
	ind.soft[7] = tex(ind.glowFrame, "BACKGROUND", GLOW_LEFT)
	ind.soft[8] = tex(ind.glowFrame, "BACKGROUND", GLOW_LEFT)
	for _, t in ipairs(ind.soft) do
		t:SetBlendMode("ADD")
		t:SetDesaturated(true)
	end
	ind.neon = CreateFrame("Frame", nil, ind.glowFrame, "BackdropTemplate")
	ind.glowAnim = newAnim(ind.glowFrame)

	-- Barra de amenaza
	ind.bar = CreateFrame("StatusBar", nil, f)
	ind.bar:SetFrameLevel(base + 7)
	ind.bar:SetMinMaxValues(0, 100)
	ind.bar.bg = tex(ind.bar, "BACKGROUND")
	ind.bar.bg:SetAllPoints()
	ind.bar.bg:SetVertexColor(0, 0, 0, 0.7)

	-- El porcentaje, aparte: no se anima
	ind.textFrame = CreateFrame("Frame", nil, f)
	ind.textFrame:SetAllPoints(f)
	ind.textFrame:SetFrameLevel(base + 9)
	ind.text = ind.textFrame:CreateFontString(nil, "OVERLAY")
	ind.text:SetFontObject(GameFontHighlightSmall)

	ind.frame = f
end

----------------------------------------------------------------------
-- Colocación
----------------------------------------------------------------------

local TEXT_POINTS = {
	topright = { "BOTTOMRIGHT", "TOPRIGHT", -2, 2 },
	topleft = { "BOTTOMLEFT", "TOPLEFT", 2, 2 },
	bottomright = { "TOPRIGHT", "BOTTOMRIGHT", -2, -2 },
	bottomleft = { "TOPLEFT", "BOTTOMLEFT", 2, -2 },
	right = { "LEFT", "RIGHT", 6, 0 },
	left = { "RIGHT", "LEFT", -6, 0 },
	center = { "CENTER", "CENTER", 0, 0 },
}

-- Rectángulo con el lado exterior a "e" píxeles del marco (e < 0: por dentro)
local function place(t, f, p1, x1, y1, p2, x2, y2)
	t:ClearAllPoints()
	t:SetPoint(p1, f, p1, x1, y1)
	if p2 then t:SetPoint(p2, f, p2, x2, y2) end
end

local function layoutBorder(f)
	local b = db.borderSize
	local e = db.borderPos == "outside" and (db.borderGap + b) or 0
	local t = ind.border
	for _, x in ipairs(t) do x:Hide() end
	if not db.border then return e end

	if db.borderStyle == "corners" then
		local c = math.max(db.cornerLength, b + 1)
		-- Cada esquina: un trazo horizontal y uno vertical que no se pisan
		local corners = {
			{ "TOPLEFT", -1, 1 }, { "TOPRIGHT", 1, 1 }, { "BOTTOMLEFT", -1, -1 }, { "BOTTOMRIGHT", 1, -1 },
		}
		for i, c4 in ipairs(corners) do
			local point, sx, sy = c4[1], c4[2], c4[3]
			local h, v = t[i * 2 - 1], t[i * 2]
			place(h, f, point, sx * e, sy * e)
			h:SetSize(c, b)
			place(v, f, point, sx * e, sy * (e - b))
			v:SetSize(b, c - b)
			h:Show()
			v:Show()
		end
	else
		local top, bottom, left, right = t[1], t[2], t[3], t[4]
		place(top, f, "TOPLEFT", -e, e, "TOPRIGHT", e, e)
		top:SetHeight(b)
		place(bottom, f, "BOTTOMLEFT", -e, -e, "BOTTOMRIGHT", e, -e)
		bottom:SetHeight(b)
		place(left, f, "TOPLEFT", -e, e - b, "BOTTOMLEFT", -e, -e + b)
		left:SetWidth(b)
		place(right, f, "TOPRIGHT", e, e - b, "BOTTOMRIGHT", e, -e + b)
		right:SetWidth(b)
		for i = 1, 4 do t[i]:Show() end
	end
	return e
end

local function layoutGlow(f, e)
	local g = db.glowSize
	local soft, neon = ind.soft, ind.neon
	for _, t in ipairs(soft) do t:Hide() end
	neon:Hide()
	if not db.glow then return end
	-- El brillo sale desde el borde (o desde el marco sin borde)
	local o = math.max(e, 0)
	if db.glowStyle == "neon" then
		neon:ClearAllPoints()
		neon:SetPoint("TOPLEFT", f, "TOPLEFT", -o - g, o + g)
		neon:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", o + g, -o - g)
		neon:SetBackdrop({ edgeFile = NEON, edgeSize = math.max(8, g * 2), tileEdge = true })
		neon:Show()
		return
	end
	-- Suave: las piezas del resaltado de las ayudas de Blizzard, centradas
	-- en la línea del borde (la mitad de dentro la tapa el marco)
	local s = g * 2
	local tl, tr, bl, br, top, bottom, left, right = unpack(soft)
	local corners = {
		{ tl, "TOPLEFT", -1, 1, 0, 1, 0, 1 },
		{ tr, "TOPRIGHT", 1, 1, 1, 0, 0, 1 },
		{ bl, "BOTTOMLEFT", -1, -1, 0, 1, 1, 0 },
		{ br, "BOTTOMRIGHT", 1, -1, 1, 0, 1, 0 },
	}
	for _, c in ipairs(corners) do
		local t = c[1]
		t:ClearAllPoints()
		t:SetSize(s, s)
		t:SetPoint(c[2], f, c[2], c[3] * (o + g), c[4] * (o + g))
		t:SetTexCoord(c[5], c[6], c[7], c[8])
	end
	top:ClearAllPoints()
	top:SetPoint("TOPLEFT", tl, "TOPRIGHT")
	top:SetPoint("BOTTOMRIGHT", tr, "BOTTOMLEFT")
	top:SetTexCoord(0, 1, 0, 1)
	bottom:ClearAllPoints()
	bottom:SetPoint("TOPLEFT", bl, "TOPRIGHT")
	bottom:SetPoint("BOTTOMRIGHT", br, "BOTTOMLEFT")
	bottom:SetTexCoord(0, 1, 1, 0)
	left:ClearAllPoints()
	left:SetPoint("TOPLEFT", tl, "BOTTOMLEFT")
	left:SetPoint("BOTTOMRIGHT", bl, "TOPRIGHT")
	left:SetTexCoord(0, 1, 0, 1)
	right:ClearAllPoints()
	right:SetPoint("TOPLEFT", tr, "BOTTOMLEFT")
	right:SetPoint("BOTTOMRIGHT", br, "TOPRIGHT")
	right:SetTexCoord(1, 0, 0, 1)
	for _, t in ipairs(soft) do t:Show() end
end

local function layoutBar(f, e)
	local bar = ind.bar
	bar:ClearAllPoints()
	local o = math.max(e, 0)
	local y = o + db.barGap
	if db.barPos == "top" then
		bar:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 0, y)
		bar:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", 0, y)
	else
		bar:SetPoint("TOPLEFT", f, "BOTTOMLEFT", 0, -y)
		bar:SetPoint("TOPRIGHT", f, "BOTTOMRIGHT", 0, -y)
	end
	bar:SetHeight(db.barHeight)
	local u = R.db and R.db.unitframes
	bar:SetStatusBarTexture(u and u.texture or WHITE)
end

local function layoutText(f)
	local p = TEXT_POINTS[db.textPos] or TEXT_POINTS.topright
	ind.text:ClearAllPoints()
	ind.text:SetPoint(p[1], f, p[2], p[3], p[4])
	-- La letra de los marcos de Rheizor
	local u = R.db and R.db.unitframes
	local file = u and u.font or (GameFontHighlightSmall:GetFont())
	local flags = u and u.outline or "OUTLINE"
	if flags == "NONE" then flags = "" end
	if not pcall(ind.text.SetFont, ind.text, file, db.textSize, flags) then
		ind.text:SetFont((GameFontHighlightSmall:GetFont()), db.textSize, flags)
	end
	ind.text:SetShadowOffset(1, -1)
	ind.text:SetShadowColor(0, 0, 0, flags == "" and 1 or 0)
end

function M:Layout()
	if not ind then return end
	local f = ind.frame
	local e = layoutBorder(f)
	layoutGlow(f, db.border and e or 0)
	layoutBar(f, db.border and e or 0)
	layoutText(f)
end

----------------------------------------------------------------------
-- Pintar y animar
----------------------------------------------------------------------

local function paint(r, g, b)
	for _, t in ipairs(ind.border) do t:SetVertexColor(r, g, b, db.borderAlpha) end
	for _, t in ipairs(ind.soft) do t:SetVertexColor(r, g, b, db.glowAlpha) end
	ind.neon:SetBackdropBorderColor(r, g, b, db.glowAlpha)
	ind.bar:SetStatusBarColor(r, g, b)
end

local function setup(group, kind)
	group:Stop()
	if kind == "none" then return end
	local speed = db.animSpeed > 0 and db.animSpeed or 1
	if kind == "pulse" then
		group.alpha:SetToAlpha(0.25)
		group.alpha:SetDuration(0.6 / speed)
		group.scale:SetScaleFrom(1, 1)
		group.scale:SetScaleTo(1, 1)
		group.scale:SetDuration(0.6 / speed)
	elseif kind == "flash" then
		group.alpha:SetToAlpha(0)
		group.alpha:SetDuration(0.16 / speed)
		group.scale:SetScaleFrom(1, 1)
		group.scale:SetScaleTo(1, 1)
		group.scale:SetDuration(0.16 / speed)
	elseif kind == "grow" then
		group.alpha:SetToAlpha(0.6)
		group.alpha:SetDuration(0.5 / speed)
		group.scale:SetScaleFrom(1, 1)
		group.scale:SetScaleTo(1.06, 1.12)
		group.scale:SetDuration(0.5 / speed)
	end
	group:Play()
end

local function animate(kind)
	kind = kind or "none"
	local key = kind .. db.animTarget .. db.animSpeed
	if ind.animKey == key then return end
	ind.animKey = key
	setup(ind.borderAnim, (db.animTarget ~= "glow") and kind or "none")
	setup(ind.glowAnim, (db.animTarget ~= "border") and kind or "none")
end

local function animOf(lvl)
	if lvl == "warn" then return db.warnAnim end
	if lvl == "danger" then return db.dangerAnim end
	if lvl == "offtank" then return db.offtankAnim end
	return "none"
end

-- Qué se ve: borde y brillo (indicador), barra y porcentaje
local function show(indicator, bar, text)
	ind.borderFrame:SetShown(indicator and db.border)
	ind.glowFrame:SetShown(indicator and db.glow)
	ind.bar:SetShown(bar and db.bar)
	if not text then ind.text:SetText("") end
	if not indicator then animate("none") end
end

local function hide()
	show(false, false, false)
end

----------------------------------------------------------------------
-- Lectura
----------------------------------------------------------------------

local function repaintHealth()
	local f = ind and ind.frame
	if f and UF and f:IsShown() then pcall(UF.UpdateHealth, UF, f) end
end

local function setLevel(lvl)
	level = lvl
	if lvl ~= lastLevel then
		if lvl == "danger" and db.sound and GetTime() > testUntil then
			PlaySound(SOUNDKIT.RAID_WARNING or 8959, "Master")
		end
		lastLevel = lvl
		if db.health or healthTinted then repaintHealth() end
	end
end

-- Pinta un nivel conocido con su porcentaje (pct: número o nil)
local function showLevel(lvl, pct)
	setLevel(lvl)
	local r, g, b = colorOf(lvl)
	paint(r, g, b)
	local alert = lvl == "warn" or lvl == "danger"
	local indicator = alert or (lvl == "ok" and db.showOk) or (lvl == "offtank" and db.showOfftank)
	local text = db.text and pct ~= nil and (alert or not db.textAlert)
	show(indicator, true, text)
	if indicator then animate(animOf(lvl)) end
	if pct then ind.bar:SetValue(pct) end
	if text then
		ind.text:SetFormattedText("%.0f%%", pct)
		if db.textColor == "white" then ind.text:SetTextColor(1, 1, 1) else ind.text:SetTextColor(r, g, b) end
	end
end

local TEST = { { "ok", 40 }, { "warn", 95 }, { "danger", 100 }, { "offtank", 60 } }

local function update()
	if not ind then return end
	if not (db.enabled and R:IsModuleRunning(M)) then
		setLevel(nil)
		hide()
		return
	end

	-- Prueba: bien, aviso, peligro y otro tanque, 2 segundos cada uno
	local now = GetTime()
	if now < testUntil then
		local step = TEST[math.min(#TEST, math.floor((#TEST * 2 - (testUntil - now)) / 2) + 1)]
		showLevel(step[1], step[2])
		return
	end

	if (db.onlyGroup and not IsInGroup()) or not UnitExists("target") or NS(UnitIsFriend("player", "target")) then
		setLevel(nil)
		hide()
		return
	end

	local lvl, status = R:ThreatLevel("target", isTank())
	local ok, _, _, pct = pcall(UnitDetailedThreatSituation, "player", "target")
	if not ok then pct = nil end
	if lvl then
		showLevel(lvl, NS(pct))
		return
	end
	if not (issecretvalue and issecretvalue(status)) then
		setLevel(nil)
		hide()
		return
	end

	-- Secreto: el color que da el juego, sin saber el nivel
	setLevel(nil)
	animate("none")
	local okColor, r, g, b = pcall(GetThreatStatusColor, status)
	ind.glowFrame:Hide()
	ind.borderFrame:SetShown(okColor and db.border)
	ind.bar:SetShown(db.bar)
	if okColor then
		for _, t in ipairs(ind.border) do pcall(t.SetVertexColor, t, r, g, b, db.borderAlpha) end
		pcall(ind.bar.SetStatusBarColor, ind.bar, r, g, b)
	end
	pcall(ind.bar.SetValue, ind.bar, pct)
	if not (db.text and not db.textAlert and pcall(ind.text.SetFormattedText, ind.text, "%.0f%%", pct)) then
		ind.text:SetText("")
	end
	ind.text:SetTextColor(1, 1, 1)
end

----------------------------------------------------------------------

function M:Test()
	if not ind then
		R:Print(L["Hace falta el marco de objetivo de Rheizor."])
		return
	end
	if not db.enabled then
		R:Print(L["Activa primero la amenaza en el marco."])
		return
	end
	testUntil = GetTime() + #TEST * 2
end

function M:OnEnable()
	db = self.db
	UF = R.modules.unitframes
	-- El marco de objetivo lo crea Rheizor-UnitFrames al entrar: puede que aún no esté
	local f = UF and UF.byUnit and UF.byUnit.target
	if not f then
		if not self.retried then
			self.retried = true
			C_Timer.After(1, function() M:OnEnable() end)
		end
		return
	end
	if ind then return end
	build(f)
	self:Layout()
	hide()

	-- La vida en el color del nivel (después de que el marco ponga el suyo)
	hooksecurefunc(UF, "UpdateHealth", function(_, frame)
		if frame ~= f then return end
		healthTinted = false
		if db.enabled and db.health and (level == "warn" or level == "danger") then
			frame.health:SetStatusBarColor(colorOf(level))
			healthTinted = true
		end
	end)
	-- Cambiar la letra o la textura de los marcos
	hooksecurefunc(UF, "RefreshAll", function() M:Layout() end)
	-- Cambia quién es tanque (Rheizor-Core): el nivel, ya
	if R.OnTanksChanged then R:OnTanksChanged(update) end

	-- Cada poco: el porcentaje cambia sin parar y el nivel depende de la actitud
	local elapsed = 0
	local driver = CreateFrame("Frame")
	driver:SetScript("OnUpdate", function(_, e)
		elapsed = elapsed + e
		if elapsed < 0.2 then return end
		elapsed = 0
		update()
	end)
end

function M:OnOptionChanged()
	if not ind then return end
	self:Layout()
	ind.animKey = nil
	update()
	repaintHealth()
end
