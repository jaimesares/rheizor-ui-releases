-- Marcos de unidad propios, al estilo ElvUI: barras planas con borde fino,
-- retrato opcional (ninguno, 2D, 3D, icono de clase o 3D superpuesto), textos
-- y auras configurables, y posición libre arrastrando.
--
-- Jugador, objetivo, objetivo del objetivo, foco, objetivo del foco y mascota.
-- Son botones seguros: clic izquierdo selecciona, clic derecho abre el menú.
--
-- El motor 12.x puede devolver valores "secretos" (vida, auras...) en combate.
-- Las barras los aceptan tal cual; para los textos se intenta formatear y, si
-- no se puede, se deja al motor mostrar el valor como pueda.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

-- Un valor secreto no se puede ni comparar con nil: se mira esto antes
local function isSecret(v)
	return issecretvalue and issecretvalue(v) or false
end

local WHITE = "Interface\\Buttons\\WHITE8X8"
local SMOOTH = Enum and Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.ExponentialEaseOut
local SCALE100 = CurveConstants and CurveConstants.ScaleTo100
local AURA_GAP = 2

local UNITS = {
	{ unit = "player", title = "Jugador", w = 220, h = 40, power = 10, point = { "CENTER", "CENTER", -280, -160 },
	  auras = "none", nameText = false, blizz = "PlayerFrame" },
	{ unit = "target", title = "Objetivo", w = 220, h = 40, power = 10, point = { "CENTER", "CENTER", 280, -160 },
	  auras = "both", nameText = true, blizz = "TargetFrame" },
	{ unit = "targettarget", title = "Objetivo del objetivo", w = 120, h = 24, power = 0,
	  point = { "CENTER", "CENTER", 470, -160 }, auras = "none", nameText = true, poll = true, blizz = "TargetFrameToT" },
	{ unit = "focus", title = "Foco", w = 180, h = 32, power = 6, point = { "CENTER", "CENTER", -280, 60 },
	  auras = "debuffs", nameText = true, blizz = "FocusFrame" },
	{ unit = "focustarget", title = "Objetivo del foco", w = 120, h = 24, power = 0,
	  point = { "CENTER", "CENTER", -110, 60 }, auras = "none", nameText = true, poll = true, off = true, blizz = "FocusFrameToT" },
	{ unit = "pet", title = "Mascota", w = 120, h = 24, power = 6, point = { "CENTER", "CENTER", -470, -160 },
	  auras = "none", nameText = true, blizz = "PetFrame" },
}

-- Los marcos cuyo retrato va a la derecha (miran hacia el jugador)
local RIGHT_SIDE = { target = true, targettarget = true, focustarget = true }

local FONTS = {
	{ "Fonts\\FRIZQT__.TTF", "Friz Quadrata (juego)" },
	{ "Fonts\\ARIALN.TTF", "Arial Narrow" },
	{ "Fonts\\skurri.ttf", "Skurri" },
	{ "Fonts\\MORPHEUS.TTF", "Morpheus" },
}
for _, f in ipairs(R.EXTRA_FONTS or {}) do FONTS[#FONTS + 1] = { f[2], f[3] } end
local OUTLINES = { { "NONE", "Sombra" }, { "OUTLINE", "Contorno" }, { "THICKOUTLINE", "Contorno grueso" } }

local HEALTH_COLORS = { { "class", "Clase / reacción" }, { "dark", "Oscuro (estilo ElvUI)" } }
for _, c in ipairs(R.COLORS) do HEALTH_COLORS[#HEALTH_COLORS + 1] = c end

local PORTRAITS = {
	{ "none", "Sin retrato" }, { "2d", "2D" }, { "3d", "3D" },
	{ "class", "Icono de clase" }, { "overlay", "3D superpuesto en la vida" },
}
local LAYOUTS = {
	{ "nameLeft", "Nombre izquierda · vida derecha" },
	{ "hpLeft", "Vida izquierda · nombre derecha" },
	{ "center", "Nombre centrado · vida derecha" },
}
local VALUE_FORMATS = {
	{ "none", "Nada" }, { "current", "Actual" }, { "percent", "Porcentaje" },
	{ "curmax", "Actual / máximo" }, { "curpct", "Actual | porcentaje" }, { "deficit", "Lo que falta" },
}
local AURA_POS = { { "top", "Encima" }, { "bottom", "Debajo" }, { "left", "A la izquierda" }, { "right", "A la derecha" } }
local AURA_GROW = { { "right", "Hacia la derecha" }, { "left", "Hacia la izquierda" } }

----------------------------------------------------------------------
-- Módulo general
----------------------------------------------------------------------

local UF = R:RegisterModule("unitframes", {
	title = "Marcos de unidad",
	defaults = {
		enabled = true,
		hideBlizzard = true,
		locked = true,
		texture = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
		healthColor = "class",
		classBackdrop = false,
		bgAlpha = 0.7,
		border = true,
		powerColor = "power",
		smooth = true,
		healPrediction = true,
		absorbs = true,
		font ="Fonts\\FRIZQT__.TTF",
		fontSize = 12,
		outline = "OUTLINE",
		nameClass = false,
		raidIcon = true,
		leader = true,
	},
	options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Usar marcos de Rheizor", reload = true,
		  desc = "Sustituye los marcos de unidad de Blizzard por marcos al estilo ElvUI. Cada marco tiene su propia página (Marco: Jugador, Marco: Objetivo...) y sus auras van en «Auras de los marcos»." },
		{ type = "toggle", key = "hideBlizzard", name = "Ocultar los marcos de Blizzard", reload = true,
		  desc = "Solo oculta los de Blizzard que tengan su equivalente de Rheizor activado." },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueados se muestran todos con datos de ejemplo y se pueden arrastrar." },
		{ type = "button", name = "Modo prueba", text = "Mostrar / ocultar", func = function(mod) mod:ToggleTest() end,
		  desc = "Muestra todos los marcos aunque no tengas objetivo, foco o mascota." },
		{ type = "button", name = "Posiciones", text = "Restablecer", func = function(mod) mod:ResetPositions() end },

		{ type = "header", text = "Barras" },
		{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
		{ type = "toggle", key = "border", name = "Borde fino negro" },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "smooth", name = "Barras suaves", desc = "Anima los cambios de vida y recurso." },
		{ type = "toggle", key = "healPrediction", name = "Curación entrante",
		  desc = "Prolonga la barra de vida con las curaciones que se están lanzando sobre la unidad: verde claro las tuyas, verde oscuro las de otros." },
		{ type = "toggle", key = "absorbs", name = "Escudos de absorción",
		  desc = "Tramo blanco tras la vida con lo que absorben los escudos (Palabra de poder: escudo...)." },

		{ type = "header", text = "Texto" },
		{ type = "dropdown", key = "font", name = "Fuente", values = FONTS },
		{ type = "slider", key = "fontSize", name = "Tamaño de letra", min = 8, max = 20, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "outline", name = "Borde de letra", values = OUTLINES },

		{ type = "header", text = "Indicadores" },
		{ type = "toggle", key = "raidIcon", name = "Icono de banda (calavera, cruz...)" },
		{ type = "toggle", key = "leader", name = "Líder de grupo" },

		{ type = "header", text = "Colores" },
		{ type = "dropdown", key = "healthColor", name = "Color de la vida", values = HEALTH_COLORS,
		  desc = "Clase para jugadores y reacción (hostil, neutral, amistoso) para PNJ; u oscuro/un color fijo." },
		{ type = "toggle", key = "classBackdrop", name = "Fondo con color de clase",
		  desc = "La parte de vida que falta toma el color de clase/reacción. Con vida oscura queda como en ElvUI." },
		{ type = "dropdown", key = "powerColor", name = "Color del recurso",
		  values = { { "power", "Según tipo (maná, ira, energía)" }, { "class", "Color de clase" } } },
		{ type = "toggle", key = "nameClass", name = "Nombres con color de clase" },
	},
	-- Lo que no se puede hacer en WoW Forever
	unsupported = {
		"Separar la barra de maná, ira o energía de la de vida: el marco de unidad es un botón protegido del juego y sus barras no pueden ir como marcos independientes.",
		"El texto de vida «Lo que falta» no sale cuando el juego da la vida en secreto (PNJ y enemigos): no se puede restar.",
		"En combate el juego a veces no deja leer las auras de otras unidades: puede faltar alguna hasta salir de combate.",
	},
})

local gdb
local frames = {}      -- lista de marcos creados
local byUnit = {}      -- unidad -> marco
UF.byUnit = byUnit     -- (lo usa Threat.lua)
local polled = {}      -- marcos sin eventos propios (objetivo del objetivo...)
local testing = false

----------------------------------------------------------------------
-- Módulos por unidad (una página de opciones cada uno)
----------------------------------------------------------------------

local unitMods = {}

for _, conf in ipairs(UNITS) do
	-- Todas las páginas de marco con las mismas secciones y en el mismo orden
	local options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Activar este marco" },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "header", text = "Tamaño" },
		{ type = "slider", key = "width", name = "Ancho", min = 60, max = 400, step = 2, format = R.fmt.int },
		{ type = "slider", key = "height", name = "Alto", min = 14, max = 100, step = 1, format = R.fmt.int },
		{ type = "slider", key = "power", name = "Alto de la barra de recurso", min = 0, max = 40, step = 1, format = R.fmt.int,
		  desc = "Maná, ira o energía, bajo la vida. 0 = sin barra de recurso." },
		{ type = "header", text = "Retrato" },
		{ type = "dropdown", key = "portrait", name = "Retrato", values = PORTRAITS,
		  desc = "Superpuesto: el modelo 3D se ve tenue dentro de la barra de vida, como en ElvUI." },
		{ type = "header", text = "Textos" },
		{ type = "dropdown", key = "layout", name = "Distribución", values = LAYOUTS },
		{ type = "toggle", key = "nameText", name = "Mostrar nombre" },
		{ type = "slider", key = "nameLength", name = "Largo máximo del nombre", min = 0, max = 30, step = 1,
		  format = function(v) return v < 0.5 and L["Sin límite"] or R.fmt.int(v) end },
		{ type = "toggle", key = "levelText", name = "Mostrar nivel",
		  desc = "Delante del nombre (necesita «Mostrar nombre»). Coloreado por dificultad; + élite, R raro, ?? jefe." },
		{ type = "dropdown", key = "healthText", name = "Texto de vida", values = VALUE_FORMATS,
		  desc = "Si el juego da la vida en secreto (PNJ y enemigos), «Lo que falta» no sale y «Actual | porcentaje» muestra siempre los dos." },
		{ type = "dropdown", key = "powerText", name = "Texto de recurso", values = VALUE_FORMATS,
		  desc = "Solo se ve si la barra de recurso mide 8 o más de alto." },
	}
	-- Iconos que solo tienen sentido en tu propio marco
	if conf.unit == "player" then
		options[#options + 1] = { type = "header", text = "Indicadores" }
		options[#options + 1] = { type = "toggle", key = "combat", name = "Icono de combate" }
		options[#options + 1] = { type = "toggle", key = "resting", name = "Icono de descanso" }
	end

	local mod = R:RegisterModule("uf_" .. conf.unit, {
		title = L["Marco: %s"]:format(L[conf.title]),
		defaults = {
			enabled = not conf.off,
			width = conf.w, height = conf.h, power = conf.power,
			portrait = "none",
			layout = "nameLeft",
			nameText = conf.nameText, nameLength = 0, levelText = conf.unit == "target" or conf.unit == "focus",
			healthText = (conf.unit == "player" or conf.unit == "target") and "curpct" or "percent",
			powerText = (conf.unit == "player") and "current" or "none",
			combat = conf.unit == "player" or nil,
			resting = conf.unit == "player" or nil,
		},
		options = options,
	})
	mod.conf = conf
	unitMods[conf.unit] = mod

	function mod:ResetPosition()
		self.db.point = nil
		local f = byUnit[conf.unit]
		if f then R:RunOutOfCombat(function() f.mover:Place() end) end
	end

	function mod:OnOptionChanged(key)
		local f = byUnit[conf.unit]
		if not f then return end
		if key == "enabled" then UF:ApplyVisibility(f) end
		UF:Layout(f)
	end
end

----------------------------------------------------------------------
-- Auras de cada marco (sección aparte: "Auras de los marcos")
----------------------------------------------------------------------

local auraMods = {}

local function sizeFormat(v)
	return v < 0.5 and L["Ajustar al ancho"] or R.fmt.int(v)
end

-- Opciones de un bloque de auras: p = "b" (beneficios) o "d" (perjuicios).
-- Los dos bloques tienen las mismas opciones en el mismo orden.
local function auraBlockOptions(options, p, title, showName, mineLabel, mineDesc)
	local list = {
		{ type = "header", text = title },
		{ type = "toggle", key = p .. "Show", name = showName },
		{ type = "toggle", key = p .. "OnlyMine", name = mineLabel, desc = mineDesc },
		{ type = "dropdown", key = p .. "Pos", name = "Posición", values = AURA_POS },
		{ type = "dropdown", key = p .. "Grow", name = "Crecen",
		  values = AURA_GROW, desc = "Solo encima o debajo del marco. A los lados crecen hacia fuera." },
		{ type = "slider", key = p .. "Size", name = "Tamaño", min = 0, max = 60, step = 1, format = sizeFormat,
		  desc = "0 = el tamaño que haga que la fila ocupe el ancho del marco." },
		{ type = "slider", key = p .. "MineSize", name = "Tamaño de los míos", min = 0, max = 60, step = 1,
		  format = function(v) return v < 0.5 and L["Igual que el resto"] or R.fmt.int(v) end,
		  desc = "Los que has puesto tú van primero y, con otro tamaño, en su propia fila: así los ves de un vistazo." },
		{ type = "slider", key = p .. "PerRow", name = "Iconos por fila", min = 1, max = 16, step = 1, format = R.fmt.int },
		{ type = "slider", key = p .. "Rows", name = "Filas", min = 1, max = 5, step = 1, format = R.fmt.int },
		{ type = "slider", key = p .. "X", name = "Desplazamiento horizontal", min = -200, max = 200, step = 1, format = R.fmt.int },
		{ type = "slider", key = p .. "Y", name = "Desplazamiento vertical", min = -200, max = 200, step = 1, format = R.fmt.int },
	}
	for _, o in ipairs(list) do options[#options + 1] = o end
end

for _, conf in ipairs(UNITS) do
	local options = {}
	auraBlockOptions(options, "b", "Beneficios", "Mostrar beneficios", "Solo los míos",
		"Solo los beneficios que has puesto tú.")
	auraBlockOptions(options, "d", "Perjuicios", "Mostrar perjuicios", "Solo los míos",
		"Útil en el objetivo: solo los perjuicios que has puesto tú.")
	options[#options + 1] = { type = "header", text = "Iconos" }
	options[#options + 1] = { type = "toggle", key = "timer", name = "Números de tiempo restante" }
	options[#options + 1] = { type = "toggle", key = "desaturate", name = "Perjuicios ajenos en gris",
		desc = "En enemigos, los perjuicios que no son tuyos se ven sin color." }

	local isTarget = conf.unit == "target"
	local mod = R:RegisterModule("aura_" .. conf.unit, {
		title = conf.title,
		group = "Auras de los marcos",
		defaults = {
			bShow = conf.auras == "buffs" or conf.auras == "both",
			bPos = conf.unit == "player" and "bottom" or "top", bGrow = "right",
			bSize = 0, bMineSize = 0, bPerRow = 8, bRows = 1, bX = 0, bY = 0, bOnlyMine = false,
			dShow = conf.auras == "debuffs" or conf.auras == "both",
			dPos = conf.unit == "player" and "bottom" or "top", dGrow = "right",
			dSize = 0, dMineSize = isTarget and 32 or 0, dPerRow = 8, dRows = isTarget and 2 or 1,
			dX = 0, dY = 0, dOnlyMine = false,
			timer = true, desaturate = true,
		},
		options = options,
	})
	auraMods[conf.unit] = mod

	function mod:OnOptionChanged()
		local f = byUnit[conf.unit]
		if f and f:IsShown() then UF:UpdateAuras(f) end
	end
end

-- Copia los ajustes de auras que había en la página de cada marco
local function migrateAuras()
	for unit, amod in pairs(auraMods) do
		local a, u = amod.db, unitMods[unit].db
		if not a.migrated then
			a.migrated = true
			if u.auras ~= nil then
				a.bShow = u.auras == "buffs" or u.auras == "both"
				a.dShow = u.auras == "debuffs" or u.auras == "both"
				a.bPos, a.dPos = u.auraPos or a.bPos, u.auraPos or a.dPos
				a.bPerRow, a.dPerRow = u.perRow or 8, u.perRow or 8
				a.dRows = math.max((u.auraRows or 2) - 1, 1)
				a.dOnlyMine = u.onlyMine and true or false
			end
		end
		u.auras, u.auraPos, u.perRow, u.auraRows, u.onlyMine = nil, nil, nil, nil, nil
		-- La barra de recurso separada ya no existe
		u.powerDetached, u.powerWidth, u.powerPoint = nil, nil, nil
	end
	-- Los iconos de combate y descanso (solo del jugador) pasan de la página
	-- general a la del marco del jugador
	local gen, pdb = UF.db, unitMods.player.db
	for _, key in ipairs({ "combat", "resting" }) do
		if gen[key] ~= nil then
			pdb[key] = gen[key] and true or false
			gen[key] = nil
		end
	end
end

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local function short(n)
	if n >= 1e6 then return string.format("%.1fM", n / 1e6) end
	if n >= 1e4 then return string.format("%.1fk", n / 1e3) end
	return tostring(math.floor(n + 0.5))
end

local function truncate(s, n)
	if not n or n < 1 then return s end
	local count, pos = 0, 1
	for char in s:gmatch("[%z\1-\127\194-\244][\128-\191]*") do
		count = count + 1
		if count > n then return s:sub(1, pos - 1) end
		pos = pos + #char
	end
	return s
end

local hexCache = {}
local function hexColor(hex)
	local c = hexCache[hex]
	if not c then
		local r, g, b = R.HexToRGB(hex)
		c = { r = r, g = g, b = b }
		hexCache[hex] = c
	end
	return c
end

local DARK = { r = 0.31, g = 0.31, b = 0.31 }
local GRAY = { r = 0.5, g = 0.5, b = 0.5 }
local GREEN = { r = 0.1, g = 0.8, b = 0.1 }
local BLUE = { r = 0, g = 0.45, b = 1 }

local function isPlayer(unit)
	return NS(UnitIsPlayer(unit)) or (UnitTreatAsPlayerForDisplay and NS(UnitTreatAsPlayerForDisplay(unit)))
end

-- Datos de ejemplo para el modo prueba
local FAKE_CLASSES = { "WARRIOR", "MAGE", "PRIEST", "ROGUE", "HUNTER", "DRUID" }
local FAKE_AURAS = {
	"Interface\\Icons\\Spell_Holy_WordFortitude", "Interface\\Icons\\Spell_Nature_Regeneration",
	"Interface\\Icons\\Spell_Holy_PowerWordShield", "Interface\\Icons\\Spell_Shadow_ShadowWordPain",
	"Interface\\Icons\\Ability_Warrior_Sunder", "Interface\\Icons\\Spell_Frost_FrostArmor02",
}

local function fake(f)
	if (testing or not gdb.locked) and not UnitExists(f.unit) then return f.fake end
end

-- Color de identidad (clase o reacción) de la unidad
local function identityColor(f)
	local fk = fake(f)
	if fk then return RAID_CLASS_COLORS[fk.class] or GREEN end
	local unit = f.unit
	if isPlayer(unit) then
		local _, class = UnitClass(unit)
		class = NS(class)
		return (class and RAID_CLASS_COLORS[class]) or GREEN
	end
	if UnitIsTapDenied and NS(UnitIsTapDenied(unit)) then return GRAY end
	local reaction = NS(UnitReaction(unit, "player"))
	return (reaction and FACTION_BAR_COLORS and FACTION_BAR_COLORS[reaction]) or GREEN
end

local function setBar(bar, cur, max)
	pcall(bar.SetMinMaxValues, bar, 0, max)
	if gdb.smooth and SMOOTH and pcall(bar.SetValue, bar, cur, SMOOTH) then return end
	pcall(bar.SetValue, bar, cur)
end

-- Escribe cur/max en fs según el formato; con valores secretos, lo que se pueda
local function valueText(fs, fmt, cur, max, pctFunc)
	if fmt == "none" then
		fs:SetText("")
		return
	end
	local c, m = NS(cur), NS(max)
	if c and m then
		local pct = m > 0 and (c / m * 100) or 0
		if fmt == "current" then
			fs:SetText(short(c))
		elseif fmt == "percent" then
			fs:SetFormattedText("%d%%", pct + 0.5)
		elseif fmt == "curmax" then
			fs:SetText(short(c) .. " / " .. short(m))
		elseif fmt == "curpct" then
			if pct >= 99.5 or m == 0 then fs:SetText(short(c)) else fs:SetFormattedText("%s | %d%%", short(c), pct + 0.5) end
		elseif fmt == "deficit" then
			fs:SetText(m - c > 0 and ("-" .. short(m - c)) or "")
		end
		return
	end
	-- Secretos: no se puede calcular, pero el motor sí pinta los valores que da
	-- el juego (abreviados con su función y el % ya calculado por él)
	if fmt == "curpct" and pctFunc and AbbreviateNumbers then
		if pcall(function() fs:SetFormattedText("%s | %.0f%%", AbbreviateNumbers(cur), pctFunc()) end) then return end
	end
	if fmt == "curmax" and AbbreviateNumbers then
		if pcall(function() fs:SetFormattedText("%s / %s", AbbreviateNumbers(cur), AbbreviateNumbers(max)) end) then return end
	end
	if (fmt == "percent" or fmt == "curpct") and pctFunc then
		if pcall(function() fs:SetFormattedText("%.0f%%", pctFunc()) end) then return end
	end
	if fmt ~= "deficit" then
		if AbbreviateNumbers and pcall(function() fs:SetText(AbbreviateNumbers(cur)) end) then return end
		if pcall(fs.SetText, fs, cur) then return end
	end
	fs:SetText("")
end

local function setFont(fs, size)
	local outline = gdb.outline ~= "NONE" and gdb.outline or ""
	if not fs:SetFont(gdb.font, size or gdb.fontSize, outline) then
		fs:SetFont(STANDARD_TEXT_FONT, size or gdb.fontSize, outline)
	end
	if outline == "" then
		fs:SetShadowOffset(1, -1)
		fs:SetShadowColor(0, 0, 0, 1)
	else
		fs:SetShadowOffset(0, 0)
	end
end

----------------------------------------------------------------------
-- Actualizaciones
----------------------------------------------------------------------

function UF:UpdateHealth(f)
	local u, bar = f.db, f.health
	local fk = fake(f)
	local id = identityColor(f)
	local color
	if gdb.healthColor == "class" then color = id
	elseif gdb.healthColor == "dark" then color = DARK
	else color = hexColor(gdb.healthColor) end

	if fk then
		setBar(bar, fk.hp, 10000)
		valueText(f.hpText, u.healthText, fk.hp, 10000)
	else
		local unit = f.unit
		local cur, max = UnitHealth(unit), UnitHealthMax(unit)
		setBar(bar, cur, max)
		if UnitIsConnected and NS(UnitIsConnected(unit)) == false then
			color = GRAY
			f.hpText:SetText(L["Desconectado"])
		elseif NS(UnitIsDeadOrGhost(unit)) then
			f.hpText:SetText(NS(UnitIsGhost(unit)) and L["Fantasma"] or L["Muerto"])
		else
			local pctFunc = UnitHealthPercent and function() return UnitHealthPercent(unit, true, SCALE100) end
			valueText(f.hpText, u.healthText, cur, max, pctFunc)
		end
	end

	bar:SetStatusBarColor(color.r, color.g, color.b)
	local bg = gdb.classBackdrop and id or color
	local mult = gdb.classBackdrop and 0.6 or 0.25
	bar.bg:SetVertexColor(bg.r * mult, bg.g * mult, bg.b * mult, gdb.bgAlpha)
	self:UpdateHealPrediction(f)
end

-- Curación entrante y escudos: barras encadenadas tras el final de la vida.
-- Las barras hacen ellas mismas la cuenta, así que valen aunque los valores
-- vengan secretos en combate.
local function safeGet(fn, ...)
	if not fn then return end
	local ok, value = pcall(fn, ...)
	if ok then return value end
end

local function setPred(bar, value, max)
	if not isSecret(value) and value == nil then
		bar:Hide()
		return
	end
	pcall(bar.SetMinMaxValues, bar, 0, max)
	pcall(bar.SetValue, bar, value)
	bar:Show()
end

-- Con valores secretos no se puede restar "todas - las tuyas", pero el juego
-- trae una calculadora (UnitGetDetailedHealPrediction) que hace la resta ella
-- misma y da las tuyas y las de otros por separado. Devuelve true si ha podido.
local healCalc
local function predictionSplit(f, unit, max)
	if not (CreateUnitHealPredictionCalculator and UnitGetDetailedHealPrediction) then return false end
	if not healCalc then
		local ok, calc = pcall(CreateUnitHealPredictionCalculator)
		if not ok or not calc then return false end
		healCalc = calc
	end
	local ok, _, fromMe, fromOthers = pcall(function()
		UnitGetDetailedHealPrediction(unit, "player", healCalc)
		return healCalc:GetIncomingHeals()
	end)
	if not ok then return false end
	setPred(f.healMine, fromMe, max)
	setPred(f.healOther, fromOthers, max)
	return true
end

function UF:UpdateHealPrediction(f)
	local unit = f.unit
	if fake(f) or not UnitExists(unit) then
		f.healMine:Hide()
		f.healOther:Hide()
		f.absorb:Hide()
		return
	end
	local max = UnitHealthMax(unit)

	if gdb.healPrediction then
		local all = safeGet(UnitGetIncomingHeals, unit)
		local mine = safeGet(UnitGetIncomingHeals, unit, "player")
		if not (isSecret(all) or isSecret(mine)) then
			local a, m = all or 0, mine or 0
			setPred(f.healMine, m, max)
			setPred(f.healOther, math.max(0, a - m), max)
		elseif not predictionSplit(f, unit, max) then
			-- Valores secretos y sin calculadora: todo en una barra
			setPred(f.healMine, all, max)
			setPred(f.healOther, 0, max)
		end
	else
		setPred(f.healMine, 0, max)
		setPred(f.healOther, 0, max)
	end

	if gdb.absorbs then
		local absorb = safeGet(UnitGetTotalAbsorbs, unit)
		if not isSecret(absorb) and absorb == nil then absorb = 0 end
		setPred(f.absorb, absorb, max)
	else
		f.absorb:Hide()
	end
end

function UF:UpdatePower(f)
	local u, bar = f.db, f.power
	if not bar:IsShown() then return end
	local fk = fake(f)
	local color, cur, max
	if fk then
		color = PowerBarColor and PowerBarColor.MANA or BLUE
		cur, max = fk.pp, 10000
	else
		local unit = f.unit
		local index, token = UnitPowerType(unit)
		index, token = NS(index) or 0, NS(token)
		color = PowerBarColor and ((token and PowerBarColor[token]) or PowerBarColor[index]) or BLUE
		cur, max = UnitPower(unit, index), UnitPowerMax(unit, index)
		if not color.r then color = BLUE end
	end
	if gdb.powerColor == "class" then color = identityColor(f) end
	setBar(bar, cur, max)
	bar:SetStatusBarColor(color.r, color.g, color.b)
	bar.bg:SetVertexColor(color.r * 0.25, color.g * 0.25, color.b * 0.25, gdb.bgAlpha)
	local unit = f.unit
	local pctFunc = (not fk) and UnitPowerPercent and function() return UnitPowerPercent(unit, nil, true, SCALE100) end
	valueText(f.ppText, u.powerText, cur, max, pctFunc)
end

local CLASSIF = { elite = "+", rareelite = "R+", rare = "R" }

function UF:UpdateName(f)
	local u = f.db
	if not u.nameText then
		f.name:SetText("")
		return
	end
	local fk = fake(f)
	local name, level, classif
	if fk then
		name, level = fk.name, 60
	else
		name = UnitName(f.unit)
		level = NS(UnitLevel(f.unit))
		classif = NS(UnitClassification(f.unit))
	end

	local prefix = ""
	if u.levelText and level then
		local text = (level > 0 and classif ~= "worldboss") and (level .. (CLASSIF[classif] or "")) or "??"
		local c = level > 0 and GetCreatureDifficultyColor and GetCreatureDifficultyColor(level)
		c = c or (level > 0 and GetQuestDifficultyColor and GetQuestDifficultyColor(level)) or { r = 1, g = 0.1, b = 0.1 }
		prefix = string.format("|cff%02x%02x%02x%s|r ", c.r * 255, c.g * 255, c.b * 255, text)
	end

	if gdb.nameClass then
		local c = identityColor(f)
		f.name:SetTextColor(c.r, c.g, c.b)
	else
		f.name:SetTextColor(1, 1, 1)
	end

	local plain = NS(name)
	if plain then
		f.name:SetText(prefix .. truncate(plain, u.nameLength))
	elseif not pcall(f.name.SetText, f.name, name) then
		f.name:SetText(prefix)
	end
end

function UF:UpdatePortrait(f)
	local mode = f.db.portrait
	f.port:Hide()
	f.model:Hide()
	if mode == "none" then return end
	local fk = fake(f)
	local unit = fk and "player" or f.unit

	if mode == "2d" or mode == "class" then
		f.port:Show()
		local class = fk and fk.class or (isPlayer(unit) and NS(select(2, UnitClass(unit))))
		local coords = mode == "class" and class and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
		if coords then
			f.port:SetTexture("Interface\\WorldStateFrame\\ICONS-CLASSES")
			f.port:SetTexCoord(coords[1] + 0.015, coords[2] - 0.015, coords[3] + 0.015, coords[4] - 0.015)
		else
			SetPortraitTexture(f.port, unit)
			f.port:SetTexCoord(0.15, 0.85, 0.15, 0.85)
		end
		return
	end

	-- 3D (en su recuadro o superpuesto en la vida)
	f.model:Show()
	local visible = fk or (NS(UnitIsVisible(unit)) and NS(UnitIsConnected(unit)) ~= false)
	if visible then
		f.model:SetUnit(unit)
		if f.model.SetPortraitZoom then f.model:SetPortraitZoom(1) end
		if f.model.SetCamDistanceScale then f.model:SetCamDistanceScale(1) end
		f.model:SetPosition(0, 0, 0)
	else
		f.model:ClearModel()
		pcall(f.model.SetModel, f.model, "Interface\\Buttons\\TalkToMeQuestionMark.m2")
		if f.model.SetCamDistanceScale then f.model:SetCamDistanceScale(1.6) end
	end
end

function UF:UpdateIcons(f)
	local fk = fake(f)
	local unit = f.unit
	-- Icono de banda
	local index = gdb.raidIcon and (fk and 8 or NS(GetRaidTargetIndex(unit)))
	if index then
		SetRaidTargetIconTexture(f.raidIcon, index)
		f.raidIcon:Show()
	else
		f.raidIcon:Hide()
	end
	-- Líder
	f.leader:SetShown(gdb.leader and not fk and NS(UnitIsGroupLeader(unit)) and true or false)
	-- Combate y descanso (solo el jugador; sus opciones están en su página)
	local isP = unit == "player"
	f.combat:SetShown(isP and f.db.combat and (UnitAffectingCombat("player") or (fk ~= nil)) or false)
	f.resting:SetShown(isP and f.db.resting and IsResting() and not UnitAffectingCombat("player") or false)
end

----------------------------------------------------------------------
-- Auras
----------------------------------------------------------------------

local function auraOnEnter(b)
	if not b.unit then return end
	GameTooltip:SetOwner(b, "ANCHOR_BOTTOMRIGHT")
	if b.fakeName then
		GameTooltip:SetText(b.fakeName)
	elseif b.auraID and GameTooltip.SetUnitAuraByAuraInstanceID then
		GameTooltip:SetUnitAuraByAuraInstanceID(b.unit, b.auraID)
	else
		GameTooltip:SetUnitAura(b.unit, b.index, b.filter)
	end
	GameTooltip:Show()
end

local function auraButton(f, i)
	local b = f.auraButtons[i]
	if b then return b end
	b = CreateFrame("Frame", nil, f.auras, "BackdropTemplate")
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropColor(0, 0, 0, 1)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetPoint("TOPLEFT", 1, -1)
	b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
	b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
	b.cd:SetAllPoints(b.icon)
	b.cd:SetDrawEdge(false)
	b.cd:SetReverse(true)
	local top = CreateFrame("Frame", nil, b)
	top:SetAllPoints()
	top:SetFrameLevel(b.cd:GetFrameLevel() + 2)
	b.count = top:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
	b.count:SetPoint("BOTTOMRIGHT", 1, 0)
	b:EnableMouse(true)
	b:SetScript("OnEnter", auraOnEnter)
	b:SetScript("OnLeave", GameTooltip_Hide)
	f.auraButtons[i] = b
	return b
end

-- La lectura de auras está en Rheizor-Core (Auras.lua): la comparten las placas
local MAX_AURAS = R.MAX_AURAS
local getAuras = R.ReadAuras
local setAura = R.SetAuraButton

-- Auras que trae el propio evento UNIT_AURA (así lee Plater)
function UF:CacheAuras(f, info)
	f.auraCache = f.auraCache or {}
	R.CacheAuras(f.auraCache, f.unit, info)
end

function UF:DiagnoseAuras()
	R:DiagnoseAuras()
end

----------------------------------------------------------------------
-- Iconos de auras de Blizzard dentro de nuestro marco
--
-- En combate el juego no deja a ningún addon leer las auras del objetivo
-- ("Auras cannot be accessed when secret while tainted"). El marco de Blizzard
-- sí puede, porque su código no está "manchado". Así que el marco de Blizzard
-- se queda oculto pero vivo, y sus iconos de auras se mueven al nuestro.
----------------------------------------------------------------------

local auraSeq, seqCounter = setmetatable({}, { __mode = "k" }), 0
local origParent = setmetatable({}, { __mode = "k" })
local hookedBlizzard = {}   -- (en tablas propias: escribir en las de Blizzard las "mancha")
local blizzardMine = setmetatable({}, { __mode = "k" })   -- icono de Blizzard -> es tuyo

-- Iconos visibles de beneficios o perjuicios del marco de Blizzard, en el
-- orden en que aparecieron
local function blizzardAuraButtons(bf, debuff)
	local list = {}
	local pools = bf.auraPools
	if pools and pools.EnumerateActive then
		local pool = pools.GetPool and pools:GetPool(debuff and "TargetDebuffFrameTemplate" or "TargetBuffFrameTemplate")
		for b in (pool or pools):EnumerateActive() do
			if pool or ((b.Border ~= nil) == debuff) then list[#list + 1] = b end
		end
	elseif bf.GetName and bf:GetName() then
		local prefix = bf:GetName() .. (debuff and "Debuff" or "Buff")
		for i = 1, MAX_AURAS do
			local b = _G[prefix .. i]
			if not b then break end
			list[#list + 1] = b
		end
	end
	local visible = {}
	for _, b in ipairs(list) do
		if b:IsShown() then
			if not auraSeq[b] then
				seqCounter = seqCounter + 1
				auraSeq[b] = seqCounter
			end
			visible[#visible + 1] = b
		else
			auraSeq[b] = nil
		end
	end
	table.sort(visible, function(a, b) return auraSeq[a] < auraSeq[b] end)
	return visible
end

-- Ajusta el borde de color de un perjuicio de Blizzard al nuevo tamaño
local function fitBlizzardButton(b)
	local border = b.Border or (b.GetName and b:GetName() and _G[b:GetName() .. "Border"])
	if border and border.ClearAllPoints then
		border:ClearAllPoints()
		border:SetPoint("TOPLEFT", -1, 1)
		border:SetPoint("BOTTOMRIGHT", 1, -1)
	end
end

-- /rz auras: ¿encuentra iconos en el marco de Blizzard del objetivo?
local hookCalls = 0
function UF:DiagnoseBlizzard()
	local f = byUnit.target
	local bf = f and f.borrow
	if not bf then
		R:Print(L["Iconos de Blizzard: no se usan (marco de Blizzard del objetivo sin ocultar)."])
		return
	end
	local buffs, debuffs = #blizzardAuraButtons(bf, false), #blizzardAuraButtons(bf, true)
	R:Print(string.format(L["Iconos de Blizzard: %d beneficios, %d perjuicios · %s · actualizaciones: %d%s"],
		buffs, debuffs, bf.auraPools and L["grupos (auraPools)"] or L["con nombre (TargetFrameBuff1...)"],
		hookCalls, f.auraBlocked and L[" · |cffff5555lectura bloqueada en este combate|r"] or ""))
end

-- Se llama al ocultar el marco de Blizzard: tras cada actualización de sus
-- auras, las colocamos en el nuestro
-- WoW Forever: el objetivo y el foco de Blizzard ya no tienen iconos sueltos,
-- sino un contenedor de auras (TargetFrameAuraContainer) que solo se actualiza
-- mientras se ve (IsVisible). Con su marco oculto se quedaba parado y en
-- combate no había nada que prestar: las auras desaparecían al azar. Ahora
-- el contenedor pasa a nuestro marco y sigue vivo; fuera de la pantalla
-- mientras podemos leer las auras, y en su sitio cuando el juego las bloquea.
local function placeContainer(f, show)
	local c = f.blizzContainer
	if not c then return end
	pcall(function()
		c:ClearAllPoints()
		if not show then
			c:SetAlpha(0)
			c:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -5000, 5000)
			return
		end
		local a = auraMods[f.unit] and auraMods[f.unit].db
		local side = a and a.dPos or "bottom"
		local x, y = a and a.dX or 0, a and a.dY or 0
		if side == "top" then
			c:SetPoint("BOTTOMLEFT", f, "TOPLEFT", x, 3 + y)
		elseif side == "left" then
			c:SetPoint("TOPRIGHT", f, "TOPLEFT", -3 + x, y)
		elseif side == "right" then
			c:SetPoint("TOPLEFT", f, "TOPRIGHT", 3 + x, y)
		else
			c:SetPoint("TOPLEFT", f, "BOTTOMLEFT", x, -3 + y)
		end
		c:SetAlpha(1)
	end)
end

local function adoptContainer(f, bf)
	if f.blizzContainer or type(bf.GetAuraContainer) ~= "function" then return end
	local ok, c = pcall(bf.GetAuraContainer, bf)
	if not (ok and type(c) == "table" and c.SetParent) then return end
	R:RunOutOfCombat(function()
		if f.blizzContainer then return end
		if not pcall(c.SetParent, c, f.auras or f) then return end
		f.blizzContainer = c
		placeContainer(f, false)
		-- Blizzard lo vuelve a anclar a su marco (oculto) cada vez que cambia
		if type(bf.AnchorAuraContainer) == "function" then
			hooksecurefunc(bf, "AnchorAuraContainer", function()
				placeContainer(f, f.showingContainer)
			end)
		end
	end)
end

function UF:BorrowBlizzardAuras(f, bf)
	f.borrow = bf
	adoptContainer(f, bf)
	if hookedBlizzard[bf] then return end
	hookedBlizzard[bf] = true
	local function after(self)
		if self ~= nil and self ~= bf then return end
		hookCalls = hookCalls + 1
		if not (f.borrow and f:IsShown()) then return end
		-- Blizzard acaba de dar su tamaño a cada icono: los tuyos, grandes.
		-- Se apunta antes de que les pongamos el nuestro.
		local small = (SMALL_AURA_SIZE or 17) + 0.5
		for _, debuff in ipairs({ false, true }) do
			for _, b in ipairs(blizzardAuraButtons(bf, debuff)) do
				local ok, w = pcall(b.GetWidth, b)
				if ok and NS(w) then blizzardMine[b] = w > small end
			end
		end
		UF:UpdateAuras(f)
	end
	if type(bf.UpdateAuras) == "function" then
		hooksecurefunc(bf, "UpdateAuras", after)
	elseif type(TargetFrame_UpdateAuras) == "function" then
		hooksecurefunc("TargetFrame_UpdateAuras", after)
	end
end

-- Coloca una lista de iconos en un bloque (beneficios o perjuicios).
-- Los tuyos van primero y, si tienen otro tamaño, en su propia fila.
-- base = lo que ya ocupan otros bloques en ese lado. Devuelve lo que ocupa este.
local function layoutBlock(f, items, o, base)
	local side = o.pos
	local perRow, rows = o.perRow, o.rows
	local along, rowOffset, rowSize, col = 0, 0, 0, 0
	-- Filas del grupo actual: los tuyos (con su tamaño) y los demás tienen cada
	-- uno su propio límite de "Filas"; si no, con 1 fila los ajenos no cabían
	local row = 0
	local prevSize
	local used = 0

	for _, item in ipairs(items) do
		local size = item.mine and o.mineSize or o.size
		local newGroup = prevSize ~= nil and size ~= prevSize
		if newGroup or (col > 0 and col >= perRow) then
			-- Solo baja si la fila actual tiene algo (si el grupo anterior se
			-- quedó sin sitio, su última fila ya se contó)
			if col > 0 then rowOffset = rowOffset + rowSize + AURA_GAP end
			row = newGroup and 0 or row + 1
			col, along, rowSize = 0, 0, 0
		end
		prevSize = size
		if row >= rows then
			item.skip = true
		else
			local b = item.button
			b:SetSize(size, size)
			b:ClearAllPoints()
			local away = 3 + base + rowOffset
			if side == "top" then
				if o.grow == "left" then
					b:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", -along + o.x, away + o.y)
				else
					b:SetPoint("BOTTOMLEFT", f, "TOPLEFT", along + o.x, away + o.y)
				end
			elseif side == "bottom" then
				if o.grow == "left" then
					b:SetPoint("TOPRIGHT", f, "BOTTOMRIGHT", -along + o.x, -away + o.y)
				else
					b:SetPoint("TOPLEFT", f, "BOTTOMLEFT", along + o.x, -away + o.y)
				end
			elseif side == "left" then
				b:SetPoint("TOPRIGHT", f, "TOPLEFT", -away + o.x, -along + o.y)
			else
				b:SetPoint("TOPLEFT", f, "TOPRIGHT", away + o.x, -along + o.y)
			end
			if b.count then setFont(b.count, math.max(8, math.floor(size * 0.42))) end
			if b.cd and b.cd.SetHideCountdownNumbers then b.cd:SetHideCountdownNumbers(not o.timer) end
			b:Show()
			along = along + size + AURA_GAP
			col = col + 1
			rowSize = math.max(rowSize, size)
			used = used + 1
		end
	end
	if used == 0 then return 0 end
	return rowOffset + rowSize + AURA_GAP
end

-- Ajustes de un bloque ya calculados (tamaño 0 = ajustar al marco)
local function blockOptions(f, a, p)
	local o = {
		pos = a[p .. "Pos"], grow = a[p .. "Grow"], perRow = a[p .. "PerRow"], rows = a[p .. "Rows"],
		x = a[p .. "X"], y = a[p .. "Y"], onlyMine = a[p .. "OnlyMine"], timer = a.timer,
	}
	local size = a[p .. "Size"]
	if size < 1 then
		local span = (o.pos == "left" or o.pos == "right") and f:GetHeight() or f.db.width
		size = math.max(10, math.floor((span - (o.perRow - 1) * AURA_GAP) / o.perRow))
	end
	o.size = size
	local mine = a[p .. "MineSize"]
	o.mineSize = (mine and mine >= 1) and mine or size
	return o
end

function UF:UpdateAuras(f)
	local a = auraMods[f.unit] and auraMods[f.unit].db
	local used = 0          -- iconos propios usados
	local borrowed = false

	-- Los iconos de Blizzard vuelven a su marco (oculto); el reparto los recoge
	if f.borrow then
		for _, debuff in ipairs({ false, true }) do
			for _, b in ipairs(blizzardAuraButtons(f.borrow, debuff)) do
				if origParent[b] and b:GetParent() ~= origParent[b] then b:SetParent(origParent[b]) end
			end
		end
	end

	-- Bloqueadas en combate y con el contenedor de Blizzard disponible: se
	-- enseña el suyo (su código sí puede leerlas) en lugar de los nuestros
	local container = (f.blizzContainer and f.auraBlocked and InCombatLockdown() and not fake(f)) and true or false
	if container or f.showingContainer then
		f.showingContainer = container
		placeContainer(f, container)
	end

	if a and f.db.width then
		local fk = fake(f)
		local unit = f.unit
		local hostile = not fk and NS(UnitCanAttack("player", unit)) and a.desaturate
		local extent = {}   -- lado -> lo que ya ocupan los bloques anteriores

		for _, p in ipairs({ "b", "d" }) do
			if a[p .. "Show"] then
				local debuff = p == "d"
				local o = blockOptions(f, a, p)
				-- Con otro tamaño, los tuyos tienen sus propias filas: caben el doble
				local limit = o.perRow * o.rows * (o.mineSize ~= o.size and 2 or 1)
				local items = {}
				local useBlizzard = false

				-- Lectura propia: siempre (aunque en este combate algo se haya
				-- bloqueado, lo que llega con el evento UNIT_AURA sí se puede
				-- mostrar; antes se dejaba de leer y se quedaba en blanco)
				local list = {}
				if not fk and not container then
					local mineFilter = debuff and "HARMFUL|PLAYER" or "HELPFUL|PLAYER"
					local allFilters = debuff and { "HARMFUL|PLAYER", "HARMFUL" } or { "HELPFUL" }
					local mine, _, failed1 = getAuras(unit, { mineFilter }, limit, f.auraCache)
					local seen = {}
					for _, aura in ipairs(mine) do
						local id = NS(aura.auraInstanceID)
						if id then seen[id] = true end
						list[#list + 1] = { aura = aura, mine = true }
					end
					local failed2
					if not o.onlyMine then
						local all
						all, _, failed2 = getAuras(unit, allFilters, limit, f.auraCache)
						for _, aura in ipairs(all) do
							local id = NS(aura.auraInstanceID)
							if not (id and seen[id]) then list[#list + 1] = { aura = aura } end
						end
					end
					if (failed1 or failed2) and InCombatLockdown() then f.auraBlocked = true end
				end

				-- El juego las bloquea: iconos del marco de Blizzard (objetivo/foco), si tiene
				if not fk and not container and f.borrow and f.auraBlocked and InCombatLockdown() then
					local mine, rest = {}, {}
					for _, b in ipairs(blizzardAuraButtons(f.borrow, debuff)) do
						table.insert(blizzardMine[b] and mine or rest, b)
					end
					if #mine + #rest > 0 then
						useBlizzard, borrowed = true, true
						for _, b in ipairs(mine) do items[#items + 1] = { button = b, mine = true } end
						for _, b in ipairs(rest) do items[#items + 1] = { button = b } end
					end
				end

				if useBlizzard then
					-- (ya están en items)
				elseif fk then
					for i = 1, 3 do
						used = used + 1
						local b = auraButton(f, used)
						b.unit, b.fakeName = unit, L["Aura de ejemplo"]
						b.icon:SetTexture(FAKE_AURAS[(debuff and 3 or 0) + i])
						b.count:SetText(i == 2 and 3 or "")
						b.cd:SetCooldown(GetTime() - 5 * i, 30)
						b.cd:Show()
						b:SetBackdropBorderColor(debuff and 0.8 or 0, 0, 0, 1)
						b.icon:SetDesaturated(false)
						items[#items + 1] = { button = b, mine = i == 1 }
					end
				else
					-- Las leídas por nosotros: primero las tuyas, luego el resto
					for i, entry in ipairs(list) do
						if i > limit then break end
						used = used + 1
						local b = auraButton(f, used)
						local ok, err = pcall(setAura, b, unit, entry.aura, i,
							debuff and "HARMFUL" or "HELPFUL", debuff, hostile)
						if not ok then geterrorhandler()(err) end
						items[#items + 1] = { button = b, mine = entry.mine }
					end
				end

				if useBlizzard then
					for _, item in ipairs(items) do
						origParent[item.button] = origParent[item.button] or item.button:GetParent()
						item.button:SetParent(f.auras)
						fitBlizzardButton(item.button)
					end
				end

				local side = o.pos
				extent[side] = (extent[side] or 0) + layoutBlock(f, items, o, extent[side] or 0)

				-- Los que no caben: fuera
				for _, item in ipairs(items) do
					if item.skip then
						if useBlizzard and origParent[item.button] then
							item.button:SetParent(origParent[item.button])
						else
							item.button:Hide()
						end
					end
				end
			end
		end
	end
	for i = used + 1, #f.auraButtons do f.auraButtons[i]:Hide() end
end

function UF:Update(f)
	if not f or not f.db.enabled or not gdb.enabled or not f:IsShown() then return end
	self:UpdateHealth(f)
	self:UpdatePower(f)
	self:UpdateName(f)
	self:UpdatePortrait(f)
	self:UpdateIcons(f)
	self:UpdateAuras(f)
end

----------------------------------------------------------------------
-- Creación y distribución
----------------------------------------------------------------------

local UNIT_EVENTS = {
	UNIT_HEALTH = "UpdateHealth", UNIT_MAXHEALTH = "UpdateHealth", UNIT_CONNECTION = "UpdateHealth",
	UNIT_FLAGS = "UpdateHealth", UNIT_FACTION = "UpdateHealth",
	UNIT_POWER_UPDATE = "UpdatePower", UNIT_MAXPOWER = "UpdatePower", UNIT_DISPLAYPOWER = "UpdatePower",
	UNIT_NAME_UPDATE = "UpdateName", UNIT_LEVEL = "UpdateName", UNIT_CLASSIFICATION_CHANGED = "UpdateName",
	UNIT_PORTRAIT_UPDATE = "UpdatePortrait", UNIT_MODEL_CHANGED = "UpdatePortrait",
	UNIT_AURA = "UpdateAuras",
	UNIT_HEAL_PREDICTION = "UpdateHealPrediction", UNIT_ABSORB_AMOUNT_CHANGED = "UpdateHealPrediction",
}

local function onEvent(self, event, _, info)
	if event == "UNIT_AURA" then UF:CacheAuras(self, info) end
	local method = UNIT_EVENTS[event] or (event == "UNIT_POWER_FREQUENT" and "UpdatePower")
	if method then UF[method](UF, self) end
	if event == "UNIT_FACTION" then UF:UpdateName(self) end
end

local function onEnter(self)
	if not UnitExists(self.unit) then return end
	GameTooltip_SetDefaultAnchor(GameTooltip, self)
	GameTooltip:SetUnit(self.unit)
	GameTooltip:Show()
end

local function newBar(parent)
	local bar = CreateFrame("StatusBar", nil, parent)
	bar:SetMinMaxValues(0, 1)
	bar:SetValue(1)
	bar.bg = bar:CreateTexture(nil, "BACKGROUND")
	bar.bg:SetAllPoints()
	bar.bg:SetTexture(WHITE)
	return bar
end

local function createFrame(conf, index)
	local mod = unitMods[conf.unit]
	local f = CreateFrame("Button", "RheizorUF_" .. conf.unit, UIParent, "SecureUnitButtonTemplate,BackdropTemplate")
	f.unit, f.conf, f.db = conf.unit, conf, mod.db
	f.fake = {
		name = conf.unit == "player" and UnitName("player") or L[conf.title],
		class = conf.unit == "player" and R:PlayerClass() or FAKE_CLASSES[index % #FAKE_CLASSES + 1],
		hp = 5500 + index * 600, pp = 3000 + index * 900,
	}
	f:SetFrameStrata("LOW")
	f:SetAttribute("unit", conf.unit)
	f:SetAttribute("*type1", "target")
	f:SetAttribute("*type2", "togglemenu")
	f:RegisterForClicks("AnyUp")
	f:SetScript("OnEnter", onEnter)
	f:SetScript("OnLeave", GameTooltip_Hide)
	f:SetScript("OnShow", function(self) UF:Update(self) end)

	f.health = newBar(f)
	f.health:SetClipsChildren(true)   -- lo que sobrepase el 100% no se sale del marco
	f.healMine = newBar(f.health)
	f.healOther = newBar(f.health)
	f.absorb = newBar(f.health)
	for _, bar in ipairs({ f.healMine, f.healOther, f.absorb }) do
		bar.bg:Hide()
		bar:Hide()
	end
	f.power = newBar(f)
	f.portBox = CreateFrame("Frame", nil, f)
	f.portBg = f.portBox:CreateTexture(nil, "BACKGROUND")
	f.portBg:SetAllPoints()
	f.portBg:SetColorTexture(0, 0, 0, 1)
	f.port = f.portBox:CreateTexture(nil, "ARTWORK")
	f.port:SetAllPoints()
	f.model = CreateFrame("PlayerModel", nil, f.portBox)
	f.model:SetAllPoints()

	-- Capa de textos e iconos por encima de todo
	f.overlay = CreateFrame("Frame", nil, f)
	f.overlay:SetAllPoints()
	f.overlay:SetFrameLevel(f:GetFrameLevel() + 8)
	f.name = f.overlay:CreateFontString(nil, "OVERLAY")
	f.name:SetWordWrap(false)
	f.hpText = f.overlay:CreateFontString(nil, "OVERLAY")
	f.ppText = f.overlay:CreateFontString(nil, "OVERLAY")
	for _, fs in ipairs({ f.name, f.hpText, f.ppText }) do fs:SetFontObject(GameFontHighlightSmall) end
	local hl = f.overlay:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints(f.health)
	hl:SetColorTexture(1, 1, 1, 0.08)
	f.hl = hl

	f.raidIcon = f.overlay:CreateTexture(nil, "OVERLAY")
	f.raidIcon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
	f.raidIcon:SetSize(18, 18)
	f.raidIcon:SetPoint("CENTER", f, "TOP", 0, 0)
	f.leader = f.overlay:CreateTexture(nil, "OVERLAY")
	f.leader:SetTexture("Interface\\GroupFrame\\UI-Group-LeaderIcon")
	f.leader:SetSize(13, 13)
	f.leader:SetPoint("CENTER", f, "TOPLEFT", 8, 0)
	f.combat = f.overlay:CreateTexture(nil, "OVERLAY")
	f.combat:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
	f.combat:SetTexCoord(0.5, 1, 0, 0.49)
	f.combat:SetSize(20, 20)
	f.combat:SetPoint("CENTER", f.health, "CENTER", 0, 0)
	f.resting = f.overlay:CreateTexture(nil, "OVERLAY")
	f.resting:SetTexture("Interface\\CharacterFrame\\UI-StateIcon")
	f.resting:SetTexCoord(0, 0.5, 0, 0.421875)
	f.resting:SetSize(18, 18)
	f.resting:SetPoint("CENTER", f, "TOPLEFT", 24, 0)

	f.auras = CreateFrame("Frame", nil, f)
	f.auras:SetAllPoints()
	f.auras.unit = conf.unit   -- por si el tooltip de un icono prestado de Blizzard mira a su padre
	f.auraButtons = {}

	f.mover = R:CreateMover(f, L[conf.title], f.db, "point", conf.point)

	-- Eventos de su unidad (los que no tienen eventos se sondean)
	if conf.poll then
		polled[#polled + 1] = f
	else
		for event in pairs(UNIT_EVENTS) do
			if not (event == "UNIT_POWER_UPDATE" and conf.unit == "player") then
				pcall(f.RegisterUnitEvent, f, event, conf.unit)
			end
		end
		if conf.unit == "player" then pcall(f.RegisterUnitEvent, f, "UNIT_POWER_FREQUENT", "player") end
		f:SetScript("OnEvent", onEvent)
	end

	frames[#frames + 1] = f
	byUnit[conf.unit] = f
	return f
end

function UF:Layout(f)
	R:RunOutOfCombat(function()
		local u = f.db
		local B = gdb.border and 1 or 0
		f:SetSize(u.width, u.height)
		f:SetBackdrop(gdb.border and { bgFile = WHITE } or nil)
		if gdb.border then f:SetBackdropColor(0, 0, 0, 1) end

		local inner = u.height - 2 * B
		local mode = u.portrait
		local boxed = mode == "2d" or mode == "3d" or mode == "class"
		local side = RIGHT_SIDE[f.unit] and "RIGHT" or "LEFT"
		local port = boxed and inner or 0
		local left = B + ((port > 0 and side == "LEFT") and (port + B) or 0)
		local right = B + ((port > 0 and side == "RIGHT") and (port + B) or 0)
		local ph = math.max(0, math.min(u.power, inner - 6))
		local hh = inner - (ph > 0 and (ph + B) or 0)

		f.health:ClearAllPoints()
		f.health:SetPoint("TOPLEFT", left, -B)
		f.health:SetPoint("TOPRIGHT", -right, -B)
		f.health:SetHeight(hh)

		f.power:ClearAllPoints()
		f.power:SetPoint("BOTTOMLEFT", left, B)
		f.power:SetPoint("BOTTOMRIGHT", -right, B)
		f.power:SetHeight(math.max(ph, 1))
		f.power:SetShown(ph > 0)
		for _, bar in ipairs({ f.health, f.power, f.healMine, f.healOther, f.absorb }) do
			bar:SetStatusBarTexture(gdb.texture)
		end

		-- Curación y escudos, cada una empieza donde acaba la anterior
		local hw = u.width - left - right
		f.healMine:SetStatusBarColor(0, 0.9, 0.45, 0.6)
		f.healOther:SetStatusBarColor(0, 0.6, 0.3, 0.6)
		f.absorb:SetStatusBarColor(1, 1, 1, 0.45)
		local prev = f.health
		for _, bar in ipairs({ f.healMine, f.healOther, f.absorb }) do
			bar:ClearAllPoints()
			bar:SetPoint("TOPLEFT", prev:GetStatusBarTexture(), "TOPRIGHT")
			bar:SetSize(math.max(hw, 1), math.max(hh, 1))
			prev = bar
		end

		-- Retrato
		f.portBox:ClearAllPoints()
		if boxed then
			f.portBox:SetSize(port, port)
			f.portBox:SetPoint("TOP" .. side, side == "LEFT" and B or -B, -B)
			f.portBox:Show()
			f.model:SetParent(f.portBox)
			f.model:SetAllPoints(f.portBox)
			f.model:SetAlpha(1)
		elseif mode == "overlay" then
			f.portBox:Hide()
			f.model:SetParent(f.health)
			f.model:ClearAllPoints()
			f.model:SetAllPoints(f.health)
			f.model:SetFrameLevel(f.health:GetFrameLevel() + 1)
			f.model:SetAlpha(0.35)
		else
			f.portBox:Hide()
		end

		-- Textos
		for _, fs in ipairs({ f.name, f.hpText, f.ppText }) do
			setFont(fs)
			fs:ClearAllPoints()
		end
		setFont(f.ppText, math.max(8, gdb.fontSize - 2))
		local pad = 4
		if u.layout == "hpLeft" then
			f.hpText:SetPoint("LEFT", f.health, "LEFT", pad, 0)
			f.name:SetPoint("RIGHT", f.health, "RIGHT", -pad, 0)
			f.name:SetPoint("LEFT", f.hpText, "RIGHT", pad, 0)
			f.name:SetJustifyH("RIGHT")
		elseif u.layout == "center" then
			f.hpText:SetPoint("RIGHT", f.health, "RIGHT", -pad, 0)
			f.name:SetPoint("CENTER", f.health, "CENTER", 0, 0)
			f.name:SetJustifyH("CENTER")
		else
			f.hpText:SetPoint("RIGHT", f.health, "RIGHT", -pad, 0)
			f.name:SetPoint("LEFT", f.health, "LEFT", pad, 0)
			f.name:SetPoint("RIGHT", f.hpText, "LEFT", -pad, 0)
			f.name:SetJustifyH("LEFT")
		end
		f.ppText:SetPoint("RIGHT", f.power, "RIGHT", -pad, 0)
		f.ppText:SetShown(ph >= 8)

		f.mover:Place()
		UF:Update(f)
	end)
end

function UF:ApplyVisibility(f)
	R:RunOutOfCombat(function()
		local on = gdb.enabled and f.db.enabled
		local test = on and (testing or not gdb.locked)
		if f.watched then
			UnregisterUnitWatch(f)
			f.watched = false
		end
		if not on then
			f:Hide()
		elseif test then
			f:Show()
		else
			RegisterUnitWatch(f)
			f.watched = true
		end
		f.mover:SetShown(on and not gdb.locked)
		if f:IsShown() then UF:Update(f) end
	end)
end

----------------------------------------------------------------------
-- Ocultar los marcos de Blizzard (igual que oUF)
----------------------------------------------------------------------

local hiddenParent = CreateFrame("Frame")
hiddenParent:Hide()

local function killBlizzard(frame, keepEvents, keepAll)
	if type(frame) ~= "table" then return end
	pcall(function()
		-- keepAll: sigue recibiendo sus eventos (para prestarnos sus auras)
		if not keepAll then frame:UnregisterAllEvents() end
		frame:Hide()
		frame:SetParent(hiddenParent)
		for _, key in ipairs({ "healthbar", "manabar", "powerBarAlt" }) do
			local child = frame[key]
			if type(child) == "table" and child.UnregisterAllEvents then child:UnregisterAllEvents() end
		end
		for _, event in ipairs(keepEvents or {}) do frame:RegisterEvent(event) end
	end)
end

local function hideBlizzard()
	for _, conf in ipairs(UNITS) do
		if unitMods[conf.unit].db.enabled then
			local keep = conf.unit == "player" and { "PLAYER_ENTERING_WORLD", "UNIT_ENTERING_VEHICLE",
				"UNIT_ENTERED_VEHICLE", "UNIT_EXITING_VEHICLE", "UNIT_EXITED_VEHICLE" } or nil
			local bf = _G[conf.blizz]
			local borrow = (conf.unit == "target" or conf.unit == "focus") and type(bf) == "table"
			killBlizzard(bf, keep, borrow)
			if borrow and byUnit[conf.unit] then
				UF:BorrowBlizzardAuras(byUnit[conf.unit], bf)
				UF:UpdateAuras(byUnit[conf.unit])
			end
		end
	end
end

----------------------------------------------------------------------
-- API del módulo general
----------------------------------------------------------------------

function UF:ToggleTest()
	if not gdb.enabled then
		R:Print(L["Activa primero \"Usar marcos de Rheizor\"."])
		return
	end
	testing = not testing
	for _, f in ipairs(frames) do self:ApplyVisibility(f) end
	R:Print(testing and L["Modo prueba activado."] or L["Modo prueba desactivado."])
end

function UF:ResetPositions()
	for _, mod in pairs(unitMods) do mod:ResetPosition() end
end

function UF:RefreshAll()
	for _, f in ipairs(frames) do
		self:Layout(f)
		self:ApplyVisibility(f)
	end
end

function UF:OnOptionChanged(key)
	if key == "enabled" or key == "hideBlizzard" then
		R:NeedReload()
		return
	end
	self:RefreshAll()
end

function UF:OnEnable()
	gdb = self.db
	migrateAuras()
	if not gdb.enabled then return end

	for i, conf in ipairs(UNITS) do createFrame(conf, i) end
	if gdb.hideBlizzard then R:RunOutOfCombat(hideBlizzard) end

	-- Eventos generales
	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_ENTERING_WORLD")
	events:RegisterEvent("PLAYER_TARGET_CHANGED")
	events:RegisterEvent("PLAYER_FOCUS_CHANGED")
	events:RegisterEvent("RAID_TARGET_UPDATE")
	events:RegisterEvent("GROUP_ROSTER_UPDATE")
	events:RegisterEvent("PARTY_LEADER_CHANGED")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	events:RegisterEvent("PLAYER_UPDATE_RESTING")
	events:RegisterUnitEvent("UNIT_PET", "player")
	events:SetScript("OnEvent", function(_, event)
		if event == "PLAYER_ENTERING_WORLD" then
			for _, f in ipairs(frames) do UF:Update(f) end
		elseif event == "PLAYER_TARGET_CHANGED" then
			-- Otra unidad: las auras guardadas del evento ya no valen
			if byUnit.target and byUnit.target.auraCache then wipe(byUnit.target.auraCache) end
			UF:Update(byUnit.target)
			UF:Update(byUnit.targettarget)
		elseif event == "PLAYER_FOCUS_CHANGED" then
			if byUnit.focus and byUnit.focus.auraCache then wipe(byUnit.focus.auraCache) end
			UF:Update(byUnit.focus)
			UF:Update(byUnit.focustarget)
		elseif event == "UNIT_PET" then
			if byUnit.pet and byUnit.pet.auraCache then wipe(byUnit.pet.auraCache) end
			UF:Update(byUnit.pet)
		else
			for _, f in ipairs(frames) do
				if f:IsShown() and f.db.enabled then
					UF:UpdateIcons(f)
					-- Al salir de combate las auras vuelven a poder leerse
					if event == "PLAYER_REGEN_ENABLED" then
						f.auraBlocked = nil
						UF:UpdateAuras(f)
					end
				end
			end
		end
	end)

	-- Sondeo para los que no tienen eventos (5 veces por segundo)
	local acc = 0
	local driver = CreateFrame("Frame")
	driver:SetScript("OnUpdate", function(_, elapsed)
		acc = acc + elapsed
		if acc < 0.2 then return end
		acc = 0
		for _, f in ipairs(polled) do
			if f:IsShown() and f.db.enabled then
				local guid = NS(UnitGUID(f.unit))
				if guid ~= f.guid or not guid then
					f.guid = guid
					UF:Update(f)
				else
					UF:UpdateHealth(f)
					UF:UpdatePower(f)
					UF:UpdateAuras(f)
				end
			end
		end
	end)

	self:RefreshAll()
end
