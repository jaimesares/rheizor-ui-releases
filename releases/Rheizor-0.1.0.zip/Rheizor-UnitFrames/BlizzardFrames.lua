-- Aspecto de los marcos de unidad de Blizzard (jugador, objetivo, objetivo
-- del objetivo, foco y mascota), para quien no usa los marcos de Rheizor o
-- solo algunos. Antes era el addon Rheizor-Appearance (26/09/2026 se trajo
-- aquí); el módulo sigue llamándose "appearance" para conservar lo guardado
-- en los perfiles.
--
-- La posición y el tamaño de estos marcos y de los buffs/debuffs del jugador
-- los gestiona el Modo edición del juego; este módulo añade lo que no trae:
-- colores de clase/reacción, textura de barras, retrato de clase, nombres en
-- color, tamaño de las auras del objetivo/foco, escala del objetivo del
-- objetivo y ocultar detalles.
--
-- Nunca escribe variables de Blizzard (eso contaminaría su código y en 12.x
-- provoca errores con valores secretos): solo usa hooksecurefunc y métodos de
-- los propios widgets.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local FRAMES = {
	{ key = "player", unit = "player",       names = { "PlayerFrame" },                     title = "Jugador" },
	{ key = "target", unit = "target",       names = { "TargetFrame" },                     title = "Objetivo" },
	{ key = "tot",    unit = "targettarget", names = { "TargetFrameToT", "FocusFrameToT" }, title = "Objetivo del objetivo" },
	{ key = "focus",  unit = "focus",        names = { "FocusFrame" },                      title = "Foco" },
	{ key = "pet",    unit = "pet",          names = { "PetFrame" },                        title = "Mascota" },
}

local HEALTH_MODES = {
	{ "default", "Original" },
	{ "class", "Color de clase (jugadores)" },
	{ "classReaction", "Clase + reacción en PNJ" },
}
-- Tú siempre eres un jugador (la reacción no cambia nada) y la mascota nunca
-- tiene clase: cada una tiene su lista, sin opciones que no hacen nada
local HEALTH_MODES_PLAYER = {
	{ "default", "Original" },
	{ "class", "Color de clase" },
}
local HEALTH_MODES_PET = {
	{ "default", "Original" },
	{ "classReaction", "Color de reacción (verde)" },
}

local PORTRAITS = {
	{ "default", "Original" },
	{ "class", "Icono de clase (jugadores)" },
}

local TEXTURES = { { "default", "Original del juego" } }
for _, t in ipairs(R.TEXTURES) do TEXTURES[#TEXTURES + 1] = t end

-- Elementos que se pueden ocultar (rutas de 12.x y, detrás, las clásicas)
local HIDE = {
	hideHit = { "PlayerFrame.PlayerFrameContent.PlayerFrameContentMain.HitIndicator", "PlayerHitIndicator",
	            "PetHitIndicator" },
	hideRest = { "PlayerFrame.PlayerFrameContent.PlayerFrameContentContextual.PlayerRestLoop",
	             "PlayerRestIcon", "PlayerRestGlow" },
	hidePvP = { "PlayerFrame.PlayerFrameContent.PlayerFrameContentContextual.PVPIcon",
	            "PlayerFrame.PlayerFrameContent.PlayerFrameContentContextual.PrestigePortrait",
	            "PlayerFrame.PlayerFrameContent.PlayerFrameContentContextual.PrestigeBadge",
	            "TargetFrame.TargetFrameContent.TargetFrameContentContextual.PvpIcon",
	            "TargetFrame.TargetFrameContent.TargetFrameContentContextual.PrestigePortrait",
	            "TargetFrame.TargetFrameContent.TargetFrameContentContextual.PrestigeBadge",
	            "FocusFrame.TargetFrameContent.TargetFrameContentContextual.PvpIcon",
	            "FocusFrame.TargetFrameContent.TargetFrameContentContextual.PrestigePortrait",
	            "FocusFrame.TargetFrameContent.TargetFrameContentContextual.PrestigeBadge",
	            "PlayerPVPIcon", "TargetFrameTextureFramePVPIcon", "FocusFrameTextureFramePVPIcon" },
	hideNameBg = { "TargetFrame.TargetFrameContent.TargetFrameContentMain.ReputationColor",
	               "FocusFrame.TargetFrameContent.TargetFrameContentMain.ReputationColor",
	               "TargetFrameNameBackground", "FocusFrameNameBackground" },
	hideGroup = { "PlayerFrame.PlayerFrameContent.PlayerFrameContentContextual.GroupIndicator",
	              "PlayerFrameGroupIndicator" },
}

----------------------------------------------------------------------
-- Opciones
----------------------------------------------------------------------

local defaults = {
	texture = "default",
	powerTexture = true,
	totScale = 1,
	targetAuraScale = 1,
	focusAuraScale = 1,
}
for _, c in ipairs(FRAMES) do
	defaults[c.key .. "Health"] = (c.key == "player") and "class" or (c.key == "pet") and "default" or "classReaction"
	if c.key ~= "pet" then
		defaults[c.key .. "Portrait"] = "default"
		defaults[c.key .. "NameColor"] = false
	end
end
for key in pairs(HIDE) do defaults[key] = false end

local options = {
	{ type = "header", text = "Barras de vida y de recurso" },
	{ type = "dropdown", key = "texture", name = "Textura de las barras", values = TEXTURES,
	  desc = "Con una textura distinta de la original, las barras sin color de clase pasan a verde.\n\nMover los marcos, cambiar su tamaño o colocar los buffs y debuffs se hace en el Modo edición del juego (Esc > Modo edición)." },
	{ type = "toggle", key = "powerTexture", name = "Aplicar textura también a maná/energía",
	  desc = "Las barras de recurso toman el color de su tipo (maná azul, ira roja, energía amarilla...)." },
}
for _, c in ipairs(FRAMES) do
	options[#options + 1] = { type = "header", text = c.title }
	if c.key == "player" then
		options[#options + 1] = { type = "dropdown", key = "playerHealth", name = "Color de la vida", values = HEALTH_MODES_PLAYER }
	elseif c.key == "pet" then
		options[#options + 1] = { type = "dropdown", key = "petHealth", name = "Color de la vida", values = HEALTH_MODES_PET }
	else
		options[#options + 1] = { type = "dropdown", key = c.key .. "Health", name = "Color de la vida", values = HEALTH_MODES,
			desc = "Reacción: rojo hostil, amarillo neutral, verde amistoso y gris si ya lo ha tocado otro." }
	end
	if c.key ~= "pet" then
		options[#options + 1] = { type = "dropdown", key = c.key .. "Portrait", name = "Retrato", values = PORTRAITS }
		options[#options + 1] = { type = "toggle", key = c.key .. "NameColor", name = "Nombre con color de clase" }
	end
	if c.key == "target" or c.key == "focus" then
		options[#options + 1] = { type = "slider", key = c.key .. "AuraScale", name = "Tamaño de sus buffs y debuffs",
			min = 0.6, max = 1.8, step = 0.05 }
	elseif c.key == "tot" then
		options[#options + 1] = { type = "slider", key = "totScale", name = "Tamaño",
			min = 0.6, max = 1.8, step = 0.05, desc = "El Modo edición no tiene tamaño propio para este marco." }
	end
end
options[#options + 1] = { type = "header", text = "Ocultar" }
options[#options + 1] = { type = "toggle", key = "hideHit", name = "Números de daño sobre el retrato",
	desc = "Los números que aparecen encima de tu retrato y el de tu mascota al recibir daño o sanación." }
options[#options + 1] = { type = "toggle", key = "hideRest", name = "Animación de descanso (Zzz)" }
options[#options + 1] = { type = "toggle", key = "hidePvP", name = "Iconos JcJ" }
options[#options + 1] = { type = "toggle", key = "hideNameBg", name = "Fondo de color tras el nombre del objetivo/foco" }
options[#options + 1] = { type = "toggle", key = "hideGroup", name = "Indicador de grupo de banda (\"Grupo 3\")" }

local M = R:RegisterModule("appearance", {
	title = "Marcos de Blizzard",
	defaults = defaults,
	options = options,
	unsupported = {
		"Colorear la vida según lo que queda o mostrarla con tu propio formato: en combate la vida de los enemigos es un valor secreto.",
	},
})

local db
-- Los ganchos no se pueden quitar: con el addon apagado en Rheizor siguen
-- llamándose, pero dejan los marcos como los pone Blizzard
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

local confOf = {}          -- marco de Blizzard -> entrada de FRAMES
local barState = {}        -- barra -> { frame, conf, kind, orig, color, texture }
local busy = false

----------------------------------------------------------------------
-- Colores
----------------------------------------------------------------------

local function unitOf(frame, conf)
	local u = frame.unit
	if type(u) == "string" then return u end
	return conf.unit
end

local function isPlayerUnit(unit)
	return NS(UnitIsPlayer(unit)) or (UnitTreatAsPlayerForDisplay and NS(UnitTreatAsPlayerForDisplay(unit)))
end

local function classColor(unit)
	if not isPlayerUnit(unit) then return end
	local _, class = UnitClass(unit)
	local c = class and NS(class) and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
end

local function reactionColor(unit)
	if UnitIsTapDenied and NS(UnitIsTapDenied(unit)) then return 0.55, 0.55, 0.55 end
	local r = NS(UnitReaction(unit, "player"))
	local c = r and FACTION_BAR_COLORS and FACTION_BAR_COLORS[r]
	if c then return c.r, c.g, c.b end
end

local function healthColor(unit, mode)
	if mode == "class" or mode == "classReaction" then
		local r, g, b = classColor(unit)
		if r then return r, g, b end
		if mode == "classReaction" and not isPlayerUnit(unit) then return reactionColor(unit) end
	end
end

local function powerColor(unit)
	local index, token = UnitPowerType(unit)
	local colors = PowerBarColor or {}
	local c = (NS(token) and colors[token]) or (NS(index) and colors[index])
	if c and c.r then return c.r, c.g, c.b end
	return 0, 0, 1
end

local function customTexture()
	return running() and db.texture ~= "default" and db.texture or nil
end

-- Lo que queremos para una barra: color y textura (nil = lo de Blizzard)
local function wanted(bar)
	local s = barState[bar]
	if not running() then return end
	local unit = unitOf(s.frame, s.conf)
	local tex = customTexture()
	if s.kind == "power" then
		if not (tex and db.powerTexture) then return end
		if not UnitExists(unit) then return nil, tex end
		return { powerColor(unit) }, tex
	end
	local color
	if running() and UnitExists(unit) then
		local r, g, b = healthColor(unit, db[s.conf.key .. "Health"])
		if r then color = { r, g, b } end
	end
	if tex and not color then color = { 0, 0.8, 0 } end
	return color, tex
end

local function paint(bar)
	local s = barState[bar]
	if not s or busy then return end
	busy = true
	local ok, err = pcall(function()
		local color, tex = wanted(bar)
		if tex then
			bar:SetStatusBarTexture(tex)
			s.texture = true
		elseif s.texture then
			s.texture = nil
			if s.orig.tex then bar:SetStatusBarTexture(s.orig.tex) end
		end
		if color then
			if bar.SetStatusBarDesaturated then bar:SetStatusBarDesaturated(true) end
			bar:SetStatusBarColor(color[1], color[2], color[3])
			s.color = true
		elseif s.color then
			s.color = nil
			if bar.SetStatusBarDesaturated then bar:SetStatusBarDesaturated(s.orig.desat or false) end
			bar:SetStatusBarColor(s.orig.r, s.orig.g, s.orig.b)
		end
	end)
	busy = false
	if not ok then geterrorhandler()(err) end
end

----------------------------------------------------------------------
-- Localizar barras de cada marco
----------------------------------------------------------------------

local HEALTH_PATHS = {
	".PlayerFrameContent.PlayerFrameContentMain.HealthBarsContainer.HealthBar",
	".PlayerFrameContent.PlayerFrameContentMain.HealthBarArea.HealthBar",
	".TargetFrameContent.TargetFrameContentMain.HealthBarsContainer.HealthBar",
	".TargetFrameContent.TargetFrameContentMain.HealthBar",
	".HealthBar",
}
local POWER_PATHS = {
	".PlayerFrameContent.PlayerFrameContentMain.ManaBarArea.ManaBar",
	".TargetFrameContent.TargetFrameContentMain.ManaBar",
	".ManaBar",
}

local function findBar(frame, name, field, suffix, paths)
	local bar = frame[field]
	if type(bar) ~= "table" then bar = _G[name .. suffix] end
	if type(bar) ~= "table" then
		for _, p in ipairs(paths) do
			bar = R:Resolve(name .. p)
			if type(bar) == "table" then break end
		end
	end
	if type(bar) == "table" and bar.SetStatusBarColor then return bar end
end

local function trackBar(bar, frame, conf, kind)
	if not bar or barState[bar] then return end
	local t = bar:GetStatusBarTexture()
	local r, g, b = bar:GetStatusBarColor()
	barState[bar] = {
		frame = frame, conf = conf, kind = kind,
		orig = {
			r = r or 1, g = g or 1, b = b or 1,
			desat = bar.IsStatusBarDesaturated and bar:IsStatusBarDesaturated(),
			tex = t and ((t.GetAtlas and t:GetAtlas()) or t:GetTexture()),
		},
	}
	-- Si Blizzard vuelve a poner su color o textura, reaplicamos el nuestro
	hooksecurefunc(bar, "SetStatusBarColor", paint)
	hooksecurefunc(bar, "SetStatusBarTexture", paint)
	if bar.SetStatusBarDesaturated then hooksecurefunc(bar, "SetStatusBarDesaturated", paint) end
end

----------------------------------------------------------------------
-- Retrato y nombre
----------------------------------------------------------------------

local portraitState = {}

local function paintPortrait(frame, conf)
	local p = frame.portrait
	if type(p) ~= "table" or not p.SetTexCoord then return end
	local unit = unitOf(frame, conf)
	if running() and db[conf.key .. "Portrait"] == "class" and UnitExists(unit) then
		local _, class = UnitClass(unit)
		local coords = isPlayerUnit(unit) and class and NS(class) and CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]
		if coords then
			p:SetTexture("Interface\\TargetingFrame\\UI-Classes-Circles")
			p:SetTexCoord(coords[1], coords[2], coords[3], coords[4])
			portraitState[p] = true
			return
		end
	end
	if portraitState[p] then
		portraitState[p] = nil
		p:SetTexCoord(0, 1, 0, 1)
		if UnitExists(unit) then SetPortraitTexture(p, unit) end
	end
end

local nameState = {}

local function paintName(frame, conf)
	local fs = frame.name
	if type(fs) ~= "table" or not fs.SetTextColor then return end
	local unit = unitOf(frame, conf)
	if running() and db[conf.key .. "NameColor"] and UnitExists(unit) then
		local r, g, b = classColor(unit)
		if r then
			fs:SetTextColor(r, g, b)
			nameState[fs] = true
			return
		end
	end
	if nameState[fs] then
		nameState[fs] = nil
		local fo = fs:GetFontObject()
		if fo then fs:SetTextColor(fo:GetTextColor()) else fs:SetTextColor(1, 0.82, 0) end
	end
end

----------------------------------------------------------------------
-- Auras del objetivo y el foco
----------------------------------------------------------------------

local function forEachAura(frame, fn)
	local pools = frame.auraPools
	if type(pools) == "table" and pools.EnumerateActive then
		for aura in pools:EnumerateActive() do fn(aura) end
		return
	end
	local name = frame:GetName()
	if not name then return end
	for _, kind in ipairs({ "Buff", "Debuff" }) do
		local i = 1
		while _G[name .. kind .. i] do
			fn(_G[name .. kind .. i])
			i = i + 1
		end
	end
end

local function scaleAuras(frame)
	local conf = confOf[frame]
	if not conf then return end
	local scale = running() and db[conf.key .. "AuraScale"] or 1
	forEachAura(frame, function(aura)
		if aura.SetScale and not (aura.IsProtected and aura:IsProtected()) then aura:SetScale(scale) end
	end)
end

----------------------------------------------------------------------
-- Ocultar detalles (con alfa, así no hace falta /reload para volver)
----------------------------------------------------------------------

local hidden = {}   -- objeto -> clave de opción

local function hideActive(obj)
	local key = hidden[obj]
	return key and running() and db[key]
end

local function applyHide(key)
	local found = false
	for _, path in ipairs(HIDE[key]) do
		local obj = R:Resolve(path)
		if type(obj) == "table" and obj.SetAlpha then
			found = true
			if not hidden[obj] then
				hidden[obj] = key
				hooksecurefunc(obj, "SetAlpha", function(o)
					if not busy and hideActive(o) then
						busy = true
						o:SetAlpha(0)
						busy = false
					end
				end)
			end
			busy = true
			obj:SetAlpha(hideActive(obj) and 0 or 1)
			busy = false
		end
	end
	R.missing[L["Marcos de Blizzard: %s"]:format(key)] =(not found) and table.concat(HIDE[key], " / ") or nil
end

----------------------------------------------------------------------
-- Aplicar
----------------------------------------------------------------------

function M:RefreshFrame(frame)
	local conf = confOf[frame]
	if not conf then return end
	for bar, s in pairs(barState) do
		if s.frame == frame then paint(bar) end
	end
	paintPortrait(frame, conf)
	paintName(frame, conf)
end

function M:RefreshAll()
	for frame in pairs(confOf) do
		self:RefreshFrame(frame)
		if frame == TargetFrame or frame == FocusFrame then scaleAuras(frame) end
	end
	for key in pairs(HIDE) do applyHide(key) end
	R:RunOutOfCombat(function()
		local s = running() and db.totScale or 1
		for frame, conf in pairs(confOf) do
			if conf.key == "tot" then frame:SetScale(s) end
		end
	end)
end

function M:OnEnable()
	db = self.db

	-- Resto de una casilla antigua ("Activar apariencia personalizada")
	db.enabled = nil
	-- Opciones que no hacían nada: reacción para ti mismo y clase para la mascota
	if db.playerHealth == "classReaction" then db.playerHealth = "class" end
	if db.petHealth == "class" then db.petHealth = "default" end
	db.petPortrait, db.petNameColor = nil, nil

	started = true

	for _, conf in ipairs(FRAMES) do
		for _, name in ipairs(conf.names) do
			local frame = _G[name]
			if type(frame) == "table" then
				confOf[frame] = conf
				trackBar(findBar(frame, name, "healthbar", "HealthBar", HEALTH_PATHS), frame, conf, "health")
				trackBar(findBar(frame, name, "manabar", "ManaBar", POWER_PATHS), frame, conf, "power")
			else
				R.missing[L["Marcos de Blizzard: %s"]:format(L[conf.title])] = name
			end
		end
	end

	-- Blizzard actualiza el marco al cambiar de unidad; repintamos justo después
	if UnitFrame_Update then
		hooksecurefunc("UnitFrame_Update", function(frame) if confOf[frame] then M:RefreshFrame(frame) end end)
	end
	if UnitFramePortrait_Update then
		hooksecurefunc("UnitFramePortrait_Update", function(frame)
			local conf = confOf[frame]
			if conf then paintPortrait(frame, conf) end
		end)
	end
	for _, frame in ipairs({ TargetFrame, FocusFrame }) do
		if type(frame) == "table" and frame.UpdateAuras then
			hooksecurefunc(frame, "UpdateAuras", scaleAuras)
		end
	end
	if TargetFrame_UpdateAuras then hooksecurefunc("TargetFrame_UpdateAuras", scaleAuras) end

	-- Respaldo por eventos (por si los ganchos anteriores no existen en esta versión)
	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_ENTERING_WORLD")
	events:RegisterEvent("PLAYER_TARGET_CHANGED")
	events:RegisterEvent("PLAYER_FOCUS_CHANGED")
	events:RegisterUnitEvent("UNIT_PET", "player")
	events:RegisterUnitEvent("UNIT_TARGET", "target", "focus")
	events:RegisterUnitEvent("UNIT_FACTION", "target", "focus")
	events:RegisterUnitEvent("UNIT_DISPLAYPOWER", "player", "target", "focus", "pet")
	events:SetScript("OnEvent", function(_, event, unit)
		if not running() and event ~= "PLAYER_ENTERING_WORLD" then return end
		if event == "PLAYER_ENTERING_WORLD" then
			M:RefreshAll()
			return
		end
		for frame, conf in pairs(confOf) do
			local u = unitOf(frame, conf)
			if (event == "PLAYER_TARGET_CHANGED" and (conf.key == "target" or conf.key == "tot"))
				or (event == "PLAYER_FOCUS_CHANGED" and (conf.key == "focus" or conf.key == "tot"))
				or (event == "UNIT_PET" and conf.key == "pet")
				or (event == "UNIT_TARGET" and conf.key == "tot")
				or u == unit then
				M:RefreshFrame(frame)
			end
		end
	end)

	self:RefreshAll()
end

function M:OnOptionChanged()
	self:RefreshAll()
end
