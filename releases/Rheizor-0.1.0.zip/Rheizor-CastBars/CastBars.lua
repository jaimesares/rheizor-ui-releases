-- Barras de lanzamiento estilo Quartz.
--
--   Jugador: icono, nombre, tiempo, latencia (zona roja al final: puedes
--            empezar el siguiente hechizo ahí) y ticks de canalización.
--   Objetivo y foco: con los mismos colores; si el juego da los tiempos como
--            valores secretos se usa el temporizador de la propia barra.
--   GCD:     barra fina bajo la del jugador con el tiempo de reutilización global.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local SHOW_TIME = { { "remaining", "Restante — 1.2" }, { "both", "Restante / total — 1.2 / 2.5" }, { "none", "Nada" } }

-- Cada barra (jugador, objetivo, foco) tiene la misma sección: mostrarla,
-- tamaño, icono, sus extras y ocultar la de Blizzard
local function barOptions(prefix, title, hideKey, hideDesc, extra)
	local list = {
		{ type = "header", text = title },
		{ type = "toggle", key = prefix .. "Enabled", name = "Mostrar esta barra" },
		{ type = "slider", key = prefix .. "Width", name = "Ancho", min = 100, max = 500, step = 5, format = R.fmt.int },
		{ type = "slider", key = prefix .. "Height", name = "Alto", min = 8, max = 40, step = 1, format = R.fmt.int },
		{ type = "toggle", key = prefix .. "Icon", name = "Icono del hechizo" },
	}
	for _, opt in ipairs(extra or {}) do table.insert(list, opt) end
	table.insert(list, { type = "toggle", key = hideKey, name = "Ocultar la de Blizzard", reload = true, desc = hideDesc })
	return list
end

local options = {
	{ type = "header", text = "General" },
	{ type = "toggle", key = "enabled", name = "Activar barras de lanzamiento de Rheizor",
	  desc = "Barras de lanzamiento propias para ti, tu objetivo y tu foco, y una barra fina con el tiempo de reutilización global." },
	{ type = "toggle", key = "locked", name = "Bloquear posición",
	  desc = "Desbloqueadas, las barras muestran lanzamientos de ejemplo y se pueden arrastrar." },
	{ type = "button", name = "Posiciones", text = "Restablecer", func = function(mod) mod:ResetPositions() end },

	{ type = "header", text = "Aspecto" },
	{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
	{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
	{ type = "toggle", key = "border", name = "Borde" },
	{ type = "slider", key = "fontSize", name = "Tamaño de letra", min = 7, max = 20, step = 1, format = R.fmt.int },
	{ type = "dropdown", key = "showTime", name = "Texto del tiempo", values = SHOW_TIME },
}

local function add(list) for _, opt in ipairs(list) do table.insert(options, opt) end end

add(barOptions("p", "Barra del jugador", "hideBlizzPlayer", nil, {
	{ type = "toggle", key = "pLatency", name = "Mostrar latencia",
	  desc = "Zona roja al final de la barra: el tiempo que tarda el servidor en responder. Puedes pulsar el siguiente hechizo cuando la barra entra en ella." },
	{ type = "toggle", key = "pTicks", name = "Ticks de canalización",
	  desc = "Marcas en la barra en cada tick de Proyectiles Arcanos, Drenar Vida, Tortura Mental, Ventisca, etc." },
	{ type = "toggle", key = "pCraftTotal", name = "Tiempo total al fabricar varios",
	  desc = "Con «Crear todo» o varias unidades en profesiones, encima de la barra sale cuántos llevas y cuánto falta para terminarlos todos." },
}))
add(barOptions("t", "Barra del objetivo", "hideBlizzTarget",
	"Si usas el marco del objetivo de Rheizor, la de Blizzard ya se oculta junto con su marco."))
add(barOptions("f", "Barra del foco", "hideBlizzFocus",
	"Si usas el marco del foco de Rheizor, la de Blizzard ya se oculta junto con su marco."))
add({
	{ type = "header", text = "Tiempo de reutilización global (GCD)" },
	{ type = "toggle", key = "gEnabled", name = "Mostrar bajo la barra del jugador" },
	{ type = "slider", key = "gHeight", name = "Alto", min = 2, max = 16, step = 1, format = R.fmt.int },

	{ type = "header", text = "Comportamiento" },
	{ type = "toggle", key = "interrupter", name = "Decir quién ha interrumpido",
	  desc = "Al cortarse un lanzamiento pone «Interrumpido por» y el nombre de quien lo hizo.\nFunciona en tu barra; en la del objetivo y la del foco el juego casi nunca lo da (llega en secreto) y sale solo «Interrumpido»." },

	{ type = "header", text = "Colores" },
	{ type = "dropdown", key = "cCast", name = "Lanzando", values = R.COLORS },
	{ type = "dropdown", key = "cChannel", name = "Canalizando", values = R.COLORS },
	{ type = "dropdown", key = "cSuccess", name = "Completado", values = R.COLORS },
	{ type = "dropdown", key = "cFail", name = "Interrumpido / fallido", values = R.COLORS },
	{ type = "dropdown", key = "cLocked", name = "No interrumpible", values = R.COLORS },
	{ type = "dropdown", key = "cGcd", name = "GCD", values = R.COLORS },
})

local M = R:RegisterModule("castbars", {
	title = "Barras de lanzamiento",
	defaults = {
		enabled = true,
		locked = true,
		hideBlizzPlayer = true,
		hideBlizzTarget = false,
		hideBlizzFocus = false,
		pEnabled = true, pWidth = 260, pHeight = 22, pIcon = true, pLatency = true, pTicks = true, pCraftTotal = true,
		tEnabled = true, tWidth = 220, tHeight = 18, tIcon = true,
		fEnabled = false, fWidth = 200, fHeight = 16, fIcon = true,
		gEnabled = true, gHeight = 4,
		texture = R.TEXTURES[2][1],
		bgAlpha = 0.6,
		border = true,
		fontSize = 12,
		showTime = "remaining",
		interrupter = true,
		cCast = "ffd100",
		cChannel = "4080ff",
		cSuccess = "33ff33",
		cFail = "ff3333",
		cLocked = "bbbbbb",
		cGcd = "ffffff",
	},
	options = options,
	-- Lo que no se puede hacer en WoW Forever
	unsupported = {
		"Quién interrumpe a tu objetivo o a tu foco: el juego solo lo da sin secreto en tus propios lanzamientos (y los de tu mascota).",
	},
})

local db
local WHITE = "Interface\\Buttons\\WHITE8X8"
local rgb = R.HexToRGB

----------------------------------------------------------------------
-- Ticks de canalización (por nombre; se traducen con el id del rango 1)
----------------------------------------------------------------------

local CHANNEL_TICK_IDS = {
	[5143] = 5,   -- Proyectiles Arcanos
	[10] = 8,     -- Ventisca
	[689] = 5,    -- Drenar Vida
	[5138] = 5,   -- Drenar Maná
	[1120] = 5,   -- Drenar Alma
	[755] = 10,   -- Canalizar salud
	[15407] = 3,  -- Tortura Mental
	[5740] = 4,   -- Lluvia de Fuego
	[16914] = 10, -- Huracán
	[740] = 5,    -- Tranquilidad
	[1510] = 6,   -- Descarga (cazador)
	[12051] = 4,  -- Evocación
}
local CHANNEL_TICKS = {}

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return (GetSpellInfo(id))
end

----------------------------------------------------------------------
-- Barra genérica
----------------------------------------------------------------------

local castBars = {}

local function createCastBar(key, unit, label)
	local f = CreateFrame("Frame", "RheizorCastBar" .. key, UIParent)
	f.key, f.unit = key, unit
	f:SetFrameStrata("MEDIUM")

	f.icon = f:CreateTexture(nil, "ARTWORK")
	f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	f.icon:SetPoint("TOPLEFT")
	f.icon:SetPoint("BOTTOMLEFT")

	local bar = CreateFrame("StatusBar", nil, f)
	bar:SetMinMaxValues(0, 1)
	bar:SetPoint("TOPRIGHT")
	bar:SetPoint("BOTTOMRIGHT")
	f.bar = bar

	f.bg = bar:CreateTexture(nil, "BACKGROUND")
	f.bg:SetAllPoints()

	f.border = CreateFrame("Frame", nil, f, "BackdropTemplate")
	f.border:SetPoint("TOPLEFT", -1, 1)
	f.border:SetPoint("BOTTOMRIGHT", 1, -1)
	f.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	f.border:SetBackdropBorderColor(0, 0, 0, 1)

	f.latency = bar:CreateTexture(nil, "ARTWORK", nil, 2)
	f.latency:SetColorTexture(1, 0, 0, 0.45)
	f.latency:Hide()

	f.ticks = {}

	f.spark = bar:CreateTexture(nil, "OVERLAY")
	f.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
	f.spark:SetBlendMode("ADD")

	f.text = bar:CreateFontString(nil, "OVERLAY")
	f.text:SetPoint("LEFT", 5, 0)
	f.text:SetJustifyH("LEFT")
	f.text:SetWordWrap(false)
	f.time = bar:CreateFontString(nil, "OVERLAY")
	f.time:SetPoint("RIGHT", -5, 0)
	f.text:SetPoint("RIGHT", f.time, "LEFT", -4, 0)
	-- Tanda de fabricación: «3/10 · total 0:45» encima de la barra
	f.total = bar:CreateFontString(nil, "OVERLAY")
	f.total:SetPoint("BOTTOMRIGHT", f, "TOPRIGHT", 0, 3)
	f.total:Hide()

	f.mover = R:CreateMover(f, label, M.db, key .. "Point", M.defaultPoints[key])
	f:Hide()
	castBars[key] = f
	return f
end

local function setTick(f, i, fraction, width)
	local t = f.ticks[i]
	if not t then
		t = f.bar:CreateTexture(nil, "OVERLAY")
		t:SetColorTexture(1, 1, 1, 0.8)
		f.ticks[i] = t
	end
	t:SetSize(1, f.bar:GetHeight())
	t:ClearAllPoints()
	t:SetPoint("CENTER", f.bar, "LEFT", fraction * width, 0)
	t:Show()
end

local function hideTicks(f)
	for _, t in ipairs(f.ticks) do t:Hide() end
end

function M:StyleCastBar(f)
	local p = f.key
	local width, height = db[p .. "Width"], db[p .. "Height"]
	f:SetSize(width, height)
	local iconSize = db[p .. "Icon"] and height or 0
	f.icon:SetWidth(iconSize)
	f.icon:SetShown(iconSize > 0)
	f.bar:SetWidth(width - (iconSize > 0 and iconSize + 1 or 0))
	f.bar:SetStatusBarTexture(db.texture)
	f.bg:SetColorTexture(0, 0, 0, db.bgAlpha)
	f.border:SetShown(db.border)
	f.spark:SetSize(16, height * 2.2)
	f.text:SetFont(STANDARD_TEXT_FONT, db.fontSize, "OUTLINE")
	f.time:SetFont(STANDARD_TEXT_FONT, db.fontSize, "OUTLINE")
	f.total:SetFont(STANDARD_TEXT_FONT, math.max(db.fontSize - 1, 7), "OUTLINE")
	f.mover:Place()
end

----------------------------------------------------------------------
-- Lanzamientos
----------------------------------------------------------------------

local function setColor(f, key)
	f.bar:SetStatusBarColor(rgb(db[key]))
end

local function isSecret(v)
	return issecretvalue and issecretvalue(v) or false
end

-- ¿Hay valor? Sin mirar dentro si es secreto (no se puede ni comparar)
local function present(v)
	return isSecret(v) or v ~= nil
end

-- "No interrumpible" en secreto (objetivo/foco): no se puede comprobar, pero
-- el motor sí deja elegir entre dos colores según ese valor
local function setColorFromSecret(f, secretBool, keyTrue, keyFalse)
	local tex = f.bar:GetStatusBarTexture()
	if not (tex and tex.SetVertexColorFromBoolean and CreateColor) then return end
	local r1, g1, b1 = rgb(db[keyTrue])
	local r2, g2, b2 = rgb(db[keyFalse])
	pcall(tex.SetVertexColorFromBoolean, tex, secretBool, CreateColor(r1, g1, b1, 1), CreateColor(r2, g2, b2, 1))
end

-- "Interrumpido por <nombre>" a partir del GUID que trae el evento. En Forever
-- ese GUID solo llega sin secreto en tus lanzamientos (y los de tu mascota);
-- si llega secreto no se puede ni comprobar si está vacío, así que se deja.
-- Devuelve true si ha escrito el texto.
local function setInterrupter(fs, guid)
	-- (isSecret primero: un valor secreto no se puede ni comparar con nil)
	if not db.interrupter or isSecret(guid) or guid == nil or guid == "" or not UnitNameFromGUID then return false end
	local ok, name = pcall(UnitNameFromGUID, guid)
	if not ok then return false end
	local fmt = SPELL_INTERRUPTED_BY or L["Interrumpido por %s"]
	-- El nombre de un PNJ puede llegar secreto: el motor lo pinta igual
	if isSecret(name) then return (pcall(fs.SetFormattedText, fs, fmt, name)) end
	if name == nil or name == "" then return false end
	local okClass, _, class = false, nil, nil
	if UnitClassFromGUID then okClass, _, class = pcall(UnitClassFromGUID, guid) end
	local c = okClass and class and not isSecret(class) and RAID_CLASS_COLORS[class]
	if c then name = string.format("|cff%02x%02x%02x%s|r", c.r * 255, c.g * 255, c.b * 255, name) end
	fs:SetText(fmt:format(name))
	return true
end

local function castInfo(unit, channel)
	if channel then
		local name, text, texture, startMS, endMS, _, notInterruptible = UnitChannelInfo(unit)
		return name, text, texture, startMS, endMS, notInterruptible
	end
	local name, text, texture, startMS, endMS, _, _, notInterruptible = UnitCastingInfo(unit)
	return name, text, texture, startMS, endMS, notInterruptible
end

----------------------------------------------------------------------
-- Tandas de fabricación («Crear todo» / varias unidades). El juego dice
-- cuántas repeticiones quedan después del lanzamiento actual; el total se
-- estima con lo que dura cada una más la pausa medida entre una y otra.
----------------------------------------------------------------------

local function remainingRecasts()
	if not (C_TradeSkillUI and C_TradeSkillUI.GetRemainingRecasts) then return 0 end
	local ok, n = pcall(C_TradeSkillUI.GetRemainingRecasts)
	return ok and NS(n) or 0
end

local function clock(sec)
	sec = math.floor(sec + 0.5)
	if sec >= 3600 then
		return string.format("%d:%02d:%02d", math.floor(sec / 3600), math.floor(sec / 60) % 60, sec % 60)
	end
	return string.format("%d:%02d", math.floor(sec / 60), sec % 60)
end

-- f.craft = { total, left (contando el actual), gap, lastEnd }
local function trackCraft(f, channel)
	local left = (f.key == "p" and db.pCraftTotal and not channel and f.startTime) and remainingRecasts() or 0
	local c = f.craft
	-- Al último de la tanda ya no le quedan repeticiones, pero sigue siendo parte de ella
	local last = c and left == 0 and c.left == 2
	if left > 0 or last then
		if not c or left + 1 > c.left then
			c = { total = left + 1, gap = 0.3 }
			f.craft = c
		elseif c.lastEnd then
			local gap = f.startTime - c.lastEnd
			if gap > 0 and gap < 3 then c.gap = c.gap * 0.5 + gap * 0.5 end
		end
		c.left = left + 1
	else
		f.craft = nil
	end
	f.total:SetShown(f.craft ~= nil)
end

function M:StartCast(f, channel)
	local name, _, texture, startMS, endMS, notInterruptible = castInfo(f.unit, channel)
	if not present(name) then return end

	f.casting, f.channeling = not channel, channel
	f.finishing, f.demo = nil, nil
	f.icon:SetTexture(texture)
	f.text:SetText(name)
	f:SetAlpha(1)

	f.startTime, f.endTime, f.durationObj, f.hasDuration = nil, nil, nil, nil
	local s, e = NS(startMS), NS(endMS)
	if s and e then
		f.startTime, f.endTime = s / 1000, e / 1000
	else
		-- Tiempos secretos: la barra lleva su propio temporizador. Protegido por
		-- si el motor no acepta el objeto (y sin comprobarlo: puede ser secreto)
		local getDuration = channel and UnitChannelDuration or UnitCastingDuration
		if getDuration and f.bar.SetTimerDuration then
			local direction = channel and Enum.StatusBarTimerDirection.RemainingTime or Enum.StatusBarTimerDirection.ElapsedTime
			f.hasDuration = pcall(function()
				local obj = getDuration(f.unit)
				f.bar:SetTimerDuration(obj, Enum.StatusBarInterpolation.Immediate, direction)
				f.durationObj = obj
			end)
		end
	end

	local locked = NS(notInterruptible)
	local normal = channel and "cChannel" or "cCast"
	setColor(f, locked and "cLocked" or normal)
	if isSecret(notInterruptible) then setColorFromSecret(f, notInterruptible, "cLocked", normal) end

	-- Ticks de canalización
	hideTicks(f)
	local plainName = NS(name)
	if channel and f.key == "p" and db.pTicks and f.startTime and plainName and CHANNEL_TICKS[plainName] then
		local n = CHANNEL_TICKS[plainName]
		for i = 1, n - 1 do setTick(f, i, i / n, f.bar:GetWidth()) end
	end

	-- Latencia: tiempo entre pulsar el hechizo y que el servidor lo empiece
	f.latency:Hide()
	if f.key == "p" and db.pLatency and f.startTime and f.sentTime then
		local lag = math.max(GetTime() - f.sentTime, 0)
		local total = f.endTime - f.startTime
		if total > 0 and lag > 0 then
			local width = math.min(lag / total, 1) * f.bar:GetWidth()
			f.latency:ClearAllPoints()
			f.latency:SetPoint("TOP")
			f.latency:SetPoint("BOTTOM")
			f.latency:SetPoint(channel and "LEFT" or "RIGHT")
			f.latency:SetWidth(math.max(width, 1))
			f.latency:Show()
		end
	end
	f.sentTime = nil
	trackCraft(f, channel)
	f:Show()
end

function M:UpdateTimes(f, channel)
	local _, _, _, startMS, endMS = castInfo(f.unit, channel)
	local s, e = NS(startMS), NS(endMS)
	if s and e and f.startTime then f.startTime, f.endTime = s / 1000, e / 1000 end
end

-- Final del lanzamiento: destello de color y desvanecido.
-- interrupter: GUID de quien lo ha interrumpido (si el evento lo trae)
function M:Finish(f, result, text, interrupter)
	if not (f.casting or f.channeling) then return end
	f.casting, f.channeling = false, false
	f.finishing = GetTime()
	f.hasDuration, f.durationObj = nil, nil
	f.spark:Hide()
	f.latency:Hide()
	hideTicks(f)
	f.bar:SetMinMaxValues(0, 1)
	f.bar:SetValue(1)
	if result == "success" then
		setColor(f, "cSuccess")
	elseif result == "fail" then
		setColor(f, "cFail")
		if not setInterrupter(f.text, interrupter) then
			f.text:SetText(text or INTERRUPTED or L["Interrumpido"])
		end
	end
	f.time:SetText("")
	-- La tanda sigue si ha salido bien; si se corta, el juego deja de repetir
	if f.craft then
		if result == "success" then f.craft.lastEnd = GetTime() else f.craft = nil end
	end
	f.total:Hide()
end

local function formatTime(remaining, total)
	if db.showTime == "none" then return "" end
	if db.showTime == "both" and total then return string.format("%.1f / %.1f", remaining, total) end
	return string.format("%.1f", remaining)
end

-- Lanzamientos de ejemplo: el nombre sale del id del hechizo (idioma del cliente)
local DEMO = {
	p = { 2.5, false, 136048, L["Descarga de relámpagos"], 403 },
	t = { 3.0, false, 135812, L["Bola de Fuego"], 133 },
	f = { 5.0, true, 136096, L["Proyectiles Arcanos"], 5143 },
}

local function onUpdateCast(f, now)
	-- Modo demostración con las barras desbloqueadas
	if not db.locked then
		local d = DEMO[f.key]
		local p = (now % d[1]) / d[1]
		f.icon:SetTexture(d[3])
		f.text:SetText(spellName(d[5]) or d[4])
		setColor(f, d[2] and "cChannel" or "cCast")
		f.bar:SetMinMaxValues(0, 1)
		f.bar:SetValue(d[2] and 1 - p or p)
		f.time:SetText(formatTime(d[1] * (1 - p), d[1]))
		f.spark:ClearAllPoints()
		f.spark:SetPoint("CENTER", f.bar, "LEFT", (d[2] and 1 - p or p) * f.bar:GetWidth(), 0)
		f.spark:Show()
		f:SetAlpha(1)
		f:Show()
		f.demo = true
		return
	elseif f.demo then
		f.demo = nil
		f:Hide()
	end

	if f.finishing then
		local t = now - f.finishing
		if t > 0.2 then f:SetAlpha(math.max(1 - (t - 0.2) / 0.4, 0)) end
		if t > 0.6 then
			f.finishing = nil
			f:Hide()
		end
		return
	end

	if not (f.casting or f.channeling) then return end

	if f.startTime then
		local total = f.endTime - f.startTime
		local elapsed = now - f.startTime
		if now > f.endTime + 0.3 then
			-- Sin evento de final (poco habitual): se da por terminado
			M:Finish(f, f.casting and "success" or nil)
			return
		end
		local p = total > 0 and math.min(math.max(elapsed / total, 0), 1) or 1
		local value = f.channeling and (1 - p) or p
		f.bar:SetMinMaxValues(0, 1)
		f.bar:SetValue(value)
		f.spark:ClearAllPoints()
		f.spark:SetPoint("CENTER", f.bar, "LEFT", value * f.bar:GetWidth(), 0)
		f.spark:Show()
		f.time:SetText(formatTime(math.max(f.endTime - now, 0), total))
		local c = f.craft
		if c then
			local rest = math.max(f.endTime - now, 0) + (c.left - 1) * (total + c.gap)
			f.total:SetFormattedText(L["%d/%d · total %s"], c.total - c.left + 1, c.total, clock(rest))
		end
	elseif f.hasDuration then
		f.spark:Hide()
		pcall(function()
			f.time:SetFormattedText("%.1f", f.durationObj:GetRemainingDuration())
		end)
	end
end

function M:RefreshUnit(f)
	if present(UnitCastingInfo(f.unit)) then
		self:StartCast(f, false)
	elseif present(UnitChannelInfo(f.unit)) then
		self:StartCast(f, true)
	else
		f.casting, f.channeling, f.finishing = false, false, nil
		if db.locked then f:Hide() end
	end
end

----------------------------------------------------------------------
-- GCD (bajo la barra del jugador)
----------------------------------------------------------------------

local gcdBar
local gcd = { start = 0, duration = 0 }

local function createThinBar(parent)
	local bar = CreateFrame("StatusBar", nil, parent)
	bar:SetMinMaxValues(0, 1)
	bar.bg = bar:CreateTexture(nil, "BACKGROUND")
	bar.bg:SetAllPoints()
	bar.border = CreateFrame("Frame", nil, bar, "BackdropTemplate")
	bar.border:SetPoint("TOPLEFT", -1, 1)
	bar.border:SetPoint("BOTTOMRIGHT", 1, -1)
	bar.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	bar.border:SetBackdropBorderColor(0, 0, 0, 1)
	bar.spark = bar:CreateTexture(nil, "OVERLAY")
	bar.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
	bar.spark:SetBlendMode("ADD")
	bar:Hide()
	return bar
end

function M:LayoutThinBars()
	local anchor = castBars.p
	gcdBar:ClearAllPoints()
	gcdBar:SetPoint("TOPRIGHT", anchor, "BOTTOMRIGHT", 0, -3)
	gcdBar:SetSize(anchor.bar:GetWidth(), db.gHeight)
	gcdBar:SetStatusBarTexture(db.texture)
	gcdBar:SetStatusBarColor(rgb(db.cGcd))
	gcdBar.bg:SetColorTexture(0, 0, 0, db.bgAlpha)
	gcdBar.border:SetShown(db.border)
	gcdBar.spark:SetSize(10, db.gHeight * 3)
end

local function drawThin(bar, value)
	bar:SetValue(value)
	bar.spark:ClearAllPoints()
	bar.spark:SetPoint("CENTER", bar, "LEFT", value * bar:GetWidth(), 0)
end

local function updateGcd(now)
	if not db.gEnabled then gcdBar:Hide() return end
	if not db.locked then
		drawThin(gcdBar, (now % 1.5) / 1.5)
		gcdBar:Show()
		return
	end
	local left = gcd.start + gcd.duration - now
	if gcd.duration > 0 and left > 0 then
		drawThin(gcdBar, 1 - left / gcd.duration)
		gcdBar:Show()
	else
		gcdBar:Hide()
	end
end

local function onCooldownUpdate()
	local info = C_Spell and C_Spell.GetSpellCooldown and C_Spell.GetSpellCooldown(61304)
	local start, duration = info and NS(info.startTime), info and NS(info.duration)
	if start and duration and duration > 0 and duration <= 2 then
		gcd.start, gcd.duration = start, duration
	end
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local function unitHandler(event, f, ...)
	if event == "UNIT_SPELLCAST_START" then
		M:StartCast(f, false)
	elseif event == "UNIT_SPELLCAST_CHANNEL_START" then
		M:StartCast(f, true)
	elseif event == "UNIT_SPELLCAST_DELAYED" then
		M:UpdateTimes(f, false)
	elseif event == "UNIT_SPELLCAST_CHANNEL_UPDATE" then
		M:UpdateTimes(f, true)
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		if f.casting then M:Finish(f, "success") end
	elseif event == "UNIT_SPELLCAST_FAILED" then
		if f.casting then M:Finish(f, "fail", FAILED or L["Fallido"]) end
	elseif event == "UNIT_SPELLCAST_INTERRUPTED" then
		-- unit, castGUID, spellID, interruptedBy (GUID de quien lo corta)
		local _, _, _, interruptedBy = ...
		if f.casting or f.channeling then M:Finish(f, "fail", INTERRUPTED or L["Interrumpido"], interruptedBy) end
	elseif event == "UNIT_SPELLCAST_STOP" then
		if f.casting then M:Finish(f, "success") end
	elseif event == "UNIT_SPELLCAST_CHANNEL_STOP" then
		-- Si el canalizado se ha cortado, el evento trae quién (como en la barra
		-- de Blizzard); secreto no se puede mirar y se da por terminado
		local _, _, _, interruptedBy = ...
		if f.channeling then
			if not isSecret(interruptedBy) and interruptedBy ~= nil and interruptedBy ~= "" then
				M:Finish(f, "fail", INTERRUPTED or L["Interrumpido"], interruptedBy)
			else
				M:Finish(f, nil)
			end
		end
	elseif event == "UNIT_SPELLCAST_INTERRUPTIBLE" or event == "UNIT_SPELLCAST_NOT_INTERRUPTIBLE" then
		if f.casting or f.channeling then M:StartCast(f, f.channeling) end
	end
end

local CAST_EVENTS = {
	"UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED",
	"UNIT_SPELLCAST_DELAYED", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_CHANNEL_START",
	"UNIT_SPELLCAST_CHANNEL_UPDATE", "UNIT_SPELLCAST_CHANNEL_STOP",
	"UNIT_SPELLCAST_INTERRUPTIBLE", "UNIT_SPELLCAST_NOT_INTERRUPTIBLE",
}

local frames = {}

local function registerBar(f, enabled)
	local ev = frames[f.key]
	if not ev then
		ev = CreateFrame("Frame")
		ev:SetScript("OnEvent", function(_, event, ...) unitHandler(event, f, ...) end)
		frames[f.key] = ev
	end
	ev:UnregisterAllEvents()
	if not (db.enabled and enabled) then
		f.casting, f.channeling = false, false
		f:Hide()
		return
	end
	for _, event in ipairs(CAST_EVENTS) do pcall(ev.RegisterUnitEvent, ev, event, f.unit) end
end

local playerEvents = CreateFrame("Frame")
playerEvents:SetScript("OnEvent", function(_, event, ...)
	if event == "UNIT_SPELLCAST_SENT" then
		castBars.p.sentTime = GetTime()
	elseif event == "SPELL_UPDATE_COOLDOWN" then
		onCooldownUpdate()
	elseif event == "PLAYER_TARGET_CHANGED" then
		if db.tEnabled then M:RefreshUnit(castBars.t) end
	elseif event == "PLAYER_FOCUS_CHANGED" then
		if db.fEnabled then M:RefreshUnit(castBars.f) end
	end
end)

function M:UpdateEvents()
	registerBar(castBars.p, db.pEnabled)
	registerBar(castBars.t, db.tEnabled)
	registerBar(castBars.f, db.fEnabled)

	playerEvents:UnregisterAllEvents()
	if not db.enabled then return end
	playerEvents:RegisterUnitEvent("UNIT_SPELLCAST_SENT", "player")
	playerEvents:RegisterEvent("PLAYER_TARGET_CHANGED")
	pcall(playerEvents.RegisterEvent, playerEvents, "PLAYER_FOCUS_CHANGED")
	if db.gEnabled then
		playerEvents:RegisterEvent("SPELL_UPDATE_COOLDOWN")
	end
end

----------------------------------------------------------------------

M.defaultPoints = {
	p = { "CENTER", "CENTER", 0, -170 },
	t = { "CENTER", "CENTER", 0, -110 },
	f = { "CENTER", "CENTER", 0, 180 },
}

function M:ResetPositions()
	db.pPoint, db.tPoint, db.fPoint = nil, nil, nil
	self:ApplyAll()
end

function M:ApplyAll()
	for key, f in pairs(castBars) do
		self:StyleCastBar(f)
		f.mover:SetShown(not db.locked and db.enabled and db[key .. "Enabled"])
		if not db[key .. "Enabled"] or not db.enabled then f:Hide() end
	end
	self:LayoutThinBars()
end

function M:OnEnable()
	db = self.db
	for id, ticks in pairs(CHANNEL_TICK_IDS) do
		local name = spellName(id)
		if name then CHANNEL_TICKS[name] = ticks end
	end

	createCastBar("p", "player", L["Lanzamiento del jugador"])
	createCastBar("t", "target", L["Lanzamiento del objetivo"])
	createCastBar("f", "focus", L["Lanzamiento del foco"])
	gcdBar = createThinBar(castBars.p)

	-- Barras de Blizzard
	R:KeepHidden({ "PlayerCastingBarFrame", "CastingBarFrame" },
		function() return db.enabled and db.pEnabled and db.hideBlizzPlayer end, L["Lanzamiento: barra del jugador"])
	R:KeepHidden({ "TargetFrameSpellBar" },
		function() return db.enabled and db.tEnabled and db.hideBlizzTarget end, L["Lanzamiento: barra del objetivo"])
	R:KeepHidden({ "FocusFrameSpellBar" },
		function() return db.enabled and db.fEnabled and db.hideBlizzFocus end, L["Lanzamiento: barra del foco"])

	self:ApplyAll()
	self:UpdateEvents()

	-- Un único OnUpdate para todas las barras
	local driver = CreateFrame("Frame")
	driver:SetScript("OnUpdate", function()
		if not db.enabled then return end
		local now = GetTime()
		for key, f in pairs(castBars) do
			if db[key .. "Enabled"] then onUpdateCast(f, now) end
		end
		if db.pEnabled then
			updateGcd(now)
		else
			gcdBar:Hide()
		end
	end)
end

function M:OnOptionChanged(key, value)
	if key:find("^hideBlizz") then
		if value then
			local paths = { hideBlizzPlayer = { "PlayerCastingBarFrame", "CastingBarFrame" },
			                hideBlizzTarget = { "TargetFrameSpellBar" }, hideBlizzFocus = { "FocusFrameSpellBar" } }
			R:KeepHidden(paths[key], function() return db.enabled and db[key] end, L["Lanzamiento: %s"]:format(key))
		else
			R:NeedReload()
		end
		return
	end
	self:ApplyAll()
	self:UpdateEvents()
	if db.locked then
		for _, f in pairs(castBars) do self:RefreshUnit(f) end
	end
end
