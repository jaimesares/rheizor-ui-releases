-- Ventanas de Blizzard con el tema de Rheizor-Core (clásico u oscuro). Ver
-- Shared.lua para cómo se hace el tema oscuro sin tocar el código de Blizzard.

local R = Rheizor:Namespace(...)
local L = R.L
local I = R.Interface

local STYLES = {
	{ "theme", "Según el tema (Rheizor-Core > Tema)" },
	{ "classic", "Clásico de Blizzard" },
	{ "dark", "Oscuro" },
}

local M = R:RegisterModule("windows", {
	title = "Ventanas",
	defaults = {
		style = "theme",
		character = true,
		social = true,
		npc = true,
		bags = true,
		map = true,
		professions = true,
		collections = true,
		system = true,
	},
	options = {
		{ type = "header", text = "Aspecto de las ventanas de Blizzard" },
		{ type = "dropdown", key = "style", name = "Estilo", values = STYLES,
		  desc = "Oscuro: sin el marco dorado ni el fondo de piedra de Blizzard; fondo liso y borde fino con los colores de Rheizor-Core > Tema." },

		{ type = "header", text = "Qué ventanas cambia" },
		{ type = "toggle", key = "character", name = "Personaje, hechizos y talentos" },
		{ type = "toggle", key = "social", name = "Amigos y hermandad" },
		{ type = "toggle", key = "npc", name = "Mercader, correo, botín y diálogos de PNJ" },
		{ type = "toggle", key = "bags", name = "Bolsas y banco" },
		{ type = "toggle", key = "map", name = "Mapa del mundo" },
		{ type = "toggle", key = "professions", name = "Profesiones" },
		{ type = "toggle", key = "collections", name = "Colecciones, subasta, macros y probador" },
		{ type = "toggle", key = "system", name = "Menú del juego y avisos",
		  desc = "El menú de Esc y las ventanas de confirmación." },
	},
	unsupported = {
		"Los logros tienen un diseño propio que no sigue las plantillas de Blizzard: se quedan con su aspecto.",
	},
})

local db

local function style()
	local s = db and db.style or "theme"
	if s == "theme" then return R:GetTheme() end
	return s
end

local function isOn(group)
	return function()
		return db and R:IsAddonActive(M.addon) and db[group] and style() == "dark"
	end
end

local function standard(frame) return I.StandardPieces(frame) end

-- Diálogos de PNJ: además del marco, el pergamino de sus páginas (si se
-- quedara, el texto aclarado del tema oscuro se vería blanco sobre él)
local PARCHMENT = { "Bg", "Background", "SealMaterialBG", "MaterialTopLeft", "MaterialTopRight",
	"MaterialBotLeft", "MaterialBotRight" }
local function dialog(panelNames)
	return function(f)
		local extra = {}
		local function add(p)
			if type(p) == "table" and p.SetAlpha then extra[#extra + 1] = p end
		end
		local function addFrom(frame, name)
			if type(frame) ~= "table" then return end
			for _, key in ipairs(PARCHMENT) do
				add(frame[key])
				if name then add(_G[name .. key]) end
			end
		end
		addFrom(f, f:GetName())
		for _, key in ipairs({ "GreetingPanel" }) do addFrom(f[key]) end
		for _, name in ipairs(panelNames) do
			local panel = _G[name]
			addFrom(panel, name)
			I.BackgroundTextures(panel, extra)
		end
		return I.StandardPieces(f, extra)
	end
end

-- { grupo, addon de Blizzard (si carga aparte), marco, piezas(host) }
local TARGETS = {
	{ "character", nil, "CharacterFrame", function(f)
		local extra = I.BackgroundTextures(f.LeftPaneHost)
		I.BackgroundTextures(f.RightPaneHost, extra)
		return I.StandardPieces(f, extra)
	end },
	{ "character", "Blizzard_PlayerSpells", "PlayerSpellsFrame", standard },

	{ "social", nil, "FriendsFrame", standard },
	{ "social", "Blizzard_Communities", "CommunitiesFrame", standard },

	{ "npc", nil, "MerchantFrame", standard },
	{ "npc", nil, "GossipFrame", dialog({}) },
	{ "npc", nil, "QuestFrame", dialog({ "QuestFrameDetailPanel", "QuestFrameRewardPanel",
		"QuestFrameProgressPanel", "QuestFrameGreetingPanel" }) },
	{ "npc", nil, "LootFrame", standard },
	{ "npc", "Blizzard_MailFrame", "MailFrame", standard },
	{ "npc", "Blizzard_MailFrame", "OpenMailFrame", standard },

	{ "bags", nil, "ContainerFrameCombinedBags", standard },
	{ "bags", nil, "ContainerFrame1", standard },
	{ "bags", nil, "ContainerFrame2", standard },
	{ "bags", nil, "ContainerFrame3", standard },
	{ "bags", nil, "ContainerFrame4", standard },
	{ "bags", nil, "ContainerFrame5", standard },
	{ "bags", nil, "ContainerFrame6", standard },
	{ "bags", nil, "ContainerFrame7", standard },
	{ "bags", nil, "BankFrame", standard },

	-- El arte del mapa está en BorderFrame (estrato alto, encima del mapa):
	-- el fondo propio va en el propio WorldMapFrame, debajo del mapa
	{ "map", nil, "WorldMapFrame", function(f)
		local border = f.BorderFrame
		if not border then return {} end
		return I.StandardPieces(border, { border.InsetBorderTop })
	end },

	{ "professions", "Blizzard_Professions", "ProfessionsFrame", function(f)
		local extra = {}
		local page = f.CraftingPage
		if page then
			I.BackgroundTextures(page, extra)
			if page.RecipeList then
				extra[#extra + 1] = page.RecipeList.Background
				extra[#extra + 1] = page.RecipeList.BackgroundNineSlice
			end
			local form = page.SchematicForm
			if form then
				extra[#extra + 1] = form.Background
				extra[#extra + 1] = form.MinimalBackground
				extra[#extra + 1] = form.NineSlice
			end
		end
		return I.StandardPieces(f, extra)
	end },

	{ "collections", "Blizzard_Collections", "CollectionsJournal", standard },
	{ "collections", "Blizzard_AuctionHouseUI", "AuctionHouseFrame", standard },
	{ "collections", "Blizzard_MacroUI", "MacroFrame", standard },
	{ "collections", nil, "DressUpFrame", standard },

	{ "system", nil, "GameMenuFrame", function(f) return I.StandardPieces(f, { f.Border }) end },
	{ "system", nil, "StaticPopup1", function(f) return { f.BG and f.BG.Top, f.BG and f.BG.Bottom } end },
	{ "system", nil, "StaticPopup2", function(f) return { f.BG and f.BG.Top, f.BG and f.BG.Bottom } end },
	{ "system", nil, "StaticPopup3", function(f) return { f.BG and f.BG.Top, f.BG and f.BG.Bottom } end },
	{ "system", nil, "StaticPopup4", function(f) return { f.BG and f.BG.Top, f.BG and f.BG.Bottom } end },
}

-- Quita huecos (piezas que no existen en esta versión)
local function compact(list)
	local out = {}
	for i = 1, table.maxn(list) do
		local p = list[i]
		if type(p) == "table" and p.SetAlpha then out[#out + 1] = p end
	end
	return out
end

----------------------------------------------------------------------
-- Texto oscuro sobre el fondo oscuro
----------------------------------------------------------------------
-- Diálogos de PNJ, misiones y cartas escriben en marrón o negro (pensado para
-- el pergamino). Con el estilo oscuro, mientras la ventana está abierta, se
-- pasa cada texto oscuro al color que usa Blizzard sobre piedra; al volver al
-- clásico se devuelve el color original.

local DARK_TEXT = {
	{ "npc", nil, "GossipFrame" },
	{ "npc", nil, "QuestFrame" },
	{ "npc", "Blizzard_MailFrame", "OpenMailFrame" },
	{ "npc", "Blizzard_MailFrame", "MailFrame" },
}

local changed = setmetatable({}, { __mode = "k" })   -- región -> { r, g, b, fijo, ventana }

local function luminance(r, g, b)
	return 0.299 * r + 0.587 * g + 0.114 * b
end

local function near(r, g, b, c)
	return c and math.abs(r - c[1]) < 0.02 and math.abs(g - c[2]) < 0.02 and math.abs(b - c[3]) < 0.02
end

local lightText, lightTitle, parchmentTitle
local function lightColors()
	if not lightText then
		lightText, lightTitle = { 0.9, 0.9, 0.9 }, { 1, 0.82, 0 }
		if GetMaterialTextColors then
			local ok, t, ti = pcall(GetMaterialTextColors, "Stone")
			if ok and t and ti then lightText, lightTitle = t, ti end
			local ok2, _, pti = pcall(GetMaterialTextColors, "Parchment")
			if ok2 then parchmentTitle = pti end
		end
	end
	return lightText, lightTitle
end

-- Códigos |cffRRGGBB oscuros dentro del texto (títulos de misión en los diálogos)
local function lightenCodes(text)
	return (text:gsub("|c(%x%x)(%x%x)(%x%x)(%x%x)", function(a, r, g, b)
		local lr, lg, lb = tonumber(r, 16) / 255, tonumber(g, 16) / 255, tonumber(b, 16) / 255
		if luminance(lr, lg, lb) >= 0.35 then return nil end
		local t = lightColors()
		return ("|c%s%02x%02x%02x"):format(a, math.floor(t[1] * 255 + 0.5),
			math.floor(t[2] * 255 + 0.5), math.floor(t[3] * 255 + 0.5))
	end))
end

local function lighten(region, owner)
	local ok, r, g, b = pcall(region.GetTextColor, region)
	if not ok or type(r) ~= "number" then return end
	if luminance(r, g, b) < 0.35 then
		local text, title = lightColors()
		local c = near(r, g, b, parchmentTitle) and title or text
		if not changed[region] then
			changed[region] = { r, g, b, region.IsFixedColor and region:IsFixedColor(), owner }
		end
		if region.SetFixedColor then region:SetFixedColor(true) end
		region:SetTextColor(c[1], c[2], c[3])
	end
	if region.GetText and region.SetText then
		local okText, s = pcall(region.GetText, region)
		if okText and not (issecretvalue and issecretvalue(s)) and type(s) == "string" and s:find("|c", 1, true) then
			local new = lightenCodes(s)
			if new ~= s then region:SetText(new) end
		end
	end
end

local function walk(frame, owner)
	for _, region in ipairs({ frame:GetRegions() }) do
		if region:IsObjectType("FontString") and region:IsShown() then lighten(region, owner) end
	end
	for _, child in ipairs({ frame:GetChildren() }) do
		if child:IsShown() then
			if child:IsObjectType("EditBox") then lighten(child, owner) end
			walk(child, owner)
		end
	end
end

-- owner: solo los textos de esa ventana (nil = todos)
local function restoreText(owner)
	for region, c in pairs(changed) do
		if not owner or c[5] == owner then
			if region.SetFixedColor then region:SetFixedColor(c[4] and true or false) end
			region:SetTextColor(c[1], c[2], c[3])
			changed[region] = nil
		end
	end
end

local function watchText(frame, on)
	-- Los textos de las misiones (QuestInfoFrame) son los mismos que usa el
	-- registro de misiones del mapa, sobre pergamino: al cerrar, su color
	frame:HookScript("OnHide", function() restoreText(frame) end)
	local watcher = CreateFrame("Frame", nil, frame)
	local elapsed = 0.2
	-- Cada poco: Blizzard vuelve a pintar el texto al pasar de página o desplazarse
	watcher:SetScript("OnUpdate", function(_, e)
		elapsed = elapsed + e
		if elapsed < 0.15 then return end
		elapsed = 0
		if on() then walk(frame, frame) end
	end)
end

function M:OnEnable()
	db = self.db
	for _, t in ipairs(DARK_TEXT) do
		local group, addon, name = t[1], t[2], t[3]
		I.OnAddon(addon, function()
			local frame = _G[name]
			if type(frame) == "table" and frame.GetRegions then watchText(frame, isOn(group)) end
		end)
	end
	R:OnThemeChanged(function()
		if style() ~= "dark" then restoreText() end
	end)
	for _, t in ipairs(TARGETS) do
		local group, addon, name, pieces = t[1], t[2], t[3], t[4]
		I.OnAddon(addon, function()
			local frame = _G[name]
			if type(frame) ~= "table" or not frame.GetFrameLevel then return end
			local ok, list = pcall(pieces, frame)
			if not ok then
				geterrorhandler()(list)
				return
			end
			I:SkinFrame(name, frame, compact(list), isOn(group), { inset = frame.Inset })
		end)
	end
end

function M:OnOptionChanged()
	if not isOn("npc")() then restoreText() end
	I:UpdateAllSkins()
end
