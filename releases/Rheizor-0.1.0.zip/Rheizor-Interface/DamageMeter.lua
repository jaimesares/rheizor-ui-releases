-- Medidor de daño de Blizzard (el integrado del juego): activarlo, borrar los
-- datos y su aspecto (textura de las barras, letra y tema oscuro).
--
-- Tamaño, altura de las barras, estilo, números, visibilidad y transparencia
-- son ajustes del Modo edición: tocarlos desde un addon estropearía el Modo
-- edición, así que se dejan ahí. Aquí solo se cambia el aspecto con ganchos.
-- Las cifras del medidor son secretas en combate: no se leen nunca.

local R = Rheizor:Namespace(...)
local L = R.L
local I = R.Interface

local WHITE = "Interface\\Buttons\\WHITE8X8"

local STYLES = {
	{ "theme", "Según el tema (Rheizor-Core > Tema)" },
	{ "classic", "Clásico de Blizzard" },
	{ "dark", "Oscuro" },
}

local TEXTURES = (function()
	local list = { { "theme", "Según el tema" }, { "blizzard", "La del medidor de Blizzard" } }
	for _, t in ipairs(R.TEXTURES) do list[#list + 1] = { t[1], t[2] } end
	return list
end)()

local M = R:RegisterModule("damagemeter", {
	title = "Medidor de daño",
	defaults = {
		style = "theme",
		texture = "theme",
		font = "default",
		outline = "",
	},
	options = {
		{ type = "header", text = "Medidor de daño de Blizzard" },
		{ type = "toggle", cvar = "damageMeterEnabled", name = "Activar el medidor de daño",
		  desc = "El medidor que trae el juego. Tamaño, altura de las barras, estilo, números y cuándo se ve se cambian en Esc > Modo edición > Medidor de daño." },
		{ type = "toggle", cvar = "damageMeterResetOnNewInstance", name = "Borrar los datos al entrar en una mazmorra o banda" },
		{ type = "button", name = "Datos del medidor", text = "Borrar ahora",
		  desc = "Borra todos los combates guardados en el medidor.",
		  func = function(mod) mod:Reset() end },

		{ type = "header", text = "Aspecto" },
		{ type = "dropdown", key = "style", name = "Estilo de la ventana", values = STYLES,
		  desc = "Oscuro: fondo liso y borde fino con los colores de Rheizor-Core > Tema, sin la cabecera de Blizzard." },
		{ type = "dropdown", key = "texture", name = "Textura de las barras", values = TEXTURES,
		  desc = "Según el tema: plana con el tema oscuro, la de Blizzard con el clásico. Para volver a la de Blizzard hace falta /reload." },
		{ type = "dropdown", key = "font", name = "Tipo de letra", values = I.FONTS,
		  desc = "El tamaño se cambia en Esc > Modo edición > Medidor de daño." },
		{ type = "dropdown", key = "outline", name = "Contorno", values = I.OUTLINES,
		  desc = "Para ocultar el medidor hasta pasar el ratón: Rheizor-Bars > Barras." },
	},
	unsupported = {
		"Leer las cifras del medidor (para avisos o informes en el chat): en combate el juego las da en secreto a los addons.",
	},
})

local db
local entries = {}   -- barras ya enganchadas
local windows = {}

local function running()
	return db and R:IsAddonActive(M.addon)
end

local function dark()
	local s = db.style
	if s == "theme" then s = R:GetTheme() end
	return running() and s == "dark"
end

local function barTexture()
	local t = db.texture
	if t == "theme" then
		return (R:GetTheme() == "dark") and WHITE or nil
	elseif t == "blizzard" then
		return nil
	end
	return t
end

----------------------------------------------------------------------
-- Barras
----------------------------------------------------------------------

local baseFont
local fontTouched = false

local function styleEntry(entry)
	if not running() then return end
	local bar = entry.StatusBar
	if not bar then return end

	local tex = barTexture()
	if tex then
		bar:SetStatusBarTexture(tex)
		-- Blizzard solo vuelve a pintar el color si cambia: se lo ponemos
		local color = entry.statusBarColor
		local t = bar:GetStatusBarTexture()
		if color and color.GetRGB and t then t:SetVertexColor(color:GetRGB()) end
	end

	if db.font ~= "default" or db.outline ~= "" or fontTouched then
		fontTouched = true
		for _, fs in ipairs({ bar.Name, bar.Value }) do
			if fs and fs.GetFont then
				local file, size, flags = fs:GetFont()
				baseFont = baseFont or file
				file = db.font ~= "default" and db.font or baseFont
				if file and size then
					if not pcall(fs.SetFont, fs, file, size, db.outline) then
						fs:SetFont(baseFont, size, db.outline)
					end
				end
			end
		end
	end
end

local function setupEntry(entry)
	if type(entry) ~= "table" or entries[entry] then return end
	entries[entry] = true
	if entry.UpdateStyle then hooksecurefunc(entry, "UpdateStyle", styleEntry) end
	if entry.SetTextScale then hooksecurefunc(entry, "SetTextScale", styleEntry) end
	styleEntry(entry)
end

----------------------------------------------------------------------
-- Ventanas
----------------------------------------------------------------------

local function setupWindow(win, i)
	if windows[win] then return end
	windows[win] = true

	local pieces = {}
	if win.Header then pieces[#pieces + 1] = win.Header end
	local container = win.MinimizeContainer
	if container and container.Background then pieces[#pieces + 1] = container.Background end
	local skin = I:SkinFrame("DamageMeterSessionWindow" .. i, win, pieces, dark)
	-- Blizzard vuelve a poner la opacidad de su fondo
	if win.UpdateBackground and skin then
		hooksecurefunc(win, "UpdateBackground", function() I:UpdateSkin(skin) end)
	end

	if win.SetupEntry then
		hooksecurefunc(win, "SetupEntry", function(_, frame) setupEntry(frame) end)
	end
	if win.ForEachEntryFrame then pcall(win.ForEachEntryFrame, win, setupEntry) end
	setupEntry(win.LocalPlayerEntry)
end

local function scan()
	for i = 1, 3 do
		local win = _G["DamageMeterSessionWindow" .. i]
		if win then setupWindow(win, i) end
	end
end

local function restyleAll()
	for entry in pairs(entries) do styleEntry(entry) end
	-- Rheizor-Bars puede tener atenuada la cabecera («al pasar el ratón»):
	-- que el estilo oscuro guarde la cabecera visible, no la atenuada
	for win in pairs(windows) do
		if win.Header then win.Header:SetAlpha(1) end
	end
	I:UpdateAllSkins()
end

-- Para Rheizor-Bars: con el estilo oscuro la barra de la cabecera no se toca
function M:IsDark()
	return dark() and true or false
end

function M:Reset()
	if C_DamageMeter and C_DamageMeter.ResetAllCombatSessions then
		local ok = pcall(C_DamageMeter.ResetAllCombatSessions)
		if ok then R:Print(L["Datos del medidor de daño borrados."]) return end
	end
	R:Print(L["El juego no ha dejado borrar los datos: hazlo desde el menú de la ventana del medidor."])
end

function M:OnEnable()
	db = self.db
	I.OnAddon("Blizzard_DamageMeter", function()
		if not DamageMeter then
			R.missing[L["Medidor de daño"]] = "DamageMeter"
			return
		end
		if DamageMeter.SetupSessionWindow then
			hooksecurefunc(DamageMeter, "SetupSessionWindow", scan)
		end
		scan()
	end)
	R:OnThemeChanged(restyleAll)
end

function M:OnOptionChanged()
	restyleAll()
end
