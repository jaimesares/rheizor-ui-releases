-- Misiones: rastreador de objetivos (tamaño, opacidad, plegarlo solo en
-- combate o en mazmorras, letra) y nivel de las misiones en el rastreador, en
-- los diálogos de los PNJ y en el texto de la misión.
--
-- El rastreador no es un marco protegido, pero todo se hace con ganchos y
-- llamadas a sus funciones públicas: nunca se escriben campos en sus tablas.

local R = Rheizor:Namespace(...)
local L = R.L
local I = R.Interface

local COLLAPSE = {
	{ "never", "Nunca" },
	{ "combat", "En combate" },
	{ "instance", "En mazmorras y bandas" },
	{ "both", "En combate y en mazmorras o bandas" },
}

local M = R:RegisterModule("quests", {
	title = "Misiones",
	defaults = {
		scale = 1,
		alpha = 1,
		collapse = "never",
		collapsePvP = true,
		font = "default",
		fontSize = 7,     -- 7 = el del juego
		headerSize = 7,
		outline = "",
		gossipLevels = true,
		detailLevel = true,
	},
	options = {
		{ type = "header", text = "Rastreador de misiones" },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 1.5, step = 0.05,
		  desc = "La posición y la altura se cambian en Esc > Modo edición > Rastreador de objetivos." },
		{ type = "slider", key = "alpha", name = "Opacidad", min = 0.2, max = 1, step = 0.05,
		  desc = "De todo el rastreador, texto incluido. La del fondo se cambia en Esc > Modo edición." },
		{ type = "dropdown", key = "collapse", name = "Plegarlo solo", values = COLLAPSE,
		  desc = "Se pliega al entrar en combate o en una mazmorra o banda y vuelve a abrirse al salir. Si lo abres tú mientras tanto, se queda abierto." },
		{ type = "toggle", key = "collapsePvP", name = "También en campos de batalla y arenas" },

		{ type = "header", text = "Letra del rastreador" },
		{ type = "dropdown", key = "font", name = "Tipo de letra", values = I.FONTS },
		{ type = "slider", key = "fontSize", name = "Tamaño de los objetivos", min = 7, max = 20, step = 1, format = I.fmtGame,
		  desc = "Al mínimo, el del juego (Esc > Modo edición > Tamaño del texto)." },
		{ type = "slider", key = "headerSize", name = "Tamaño de los títulos", min = 7, max = 22, step = 1, format = I.fmtGame },
		{ type = "dropdown", key = "outline", name = "Contorno", values = I.OUTLINES },

		{ type = "header", text = "Nivel de las misiones" },
		{ type = "toggle", cvar = "showQuestLevel", name = "Nivel en el rastreador",
		  desc = "Pone [nivel] delante del nombre de cada misión." },
		{ type = "toggle", cvar = "showQuestDifficultyColor", name = "Color según la dificultad",
		  desc = "Gris, verde, amarillo, naranja o rojo según tu nivel, en el rastreador." },
		{ type = "toggle", key = "gossipLevels", name = "Nivel en el diálogo de los PNJ",
		  desc = "En la lista de misiones que ofrece o espera un PNJ." },
		{ type = "toggle", key = "detailLevel", name = "Nivel en el texto de la misión",
		  desc = "En el título de la misión al leerla o entregarla." },
	},
	unsupported = {
		"El registro de misiones (en el mapa) ya muestra el nivel y si es de élite: en WoW Forever lo pone el juego siempre.",
	},
})

local db
local tracker

----------------------------------------------------------------------
-- Tamaño y opacidad
----------------------------------------------------------------------

function M:ApplyLook()
	if not tracker then return end
	tracker:SetScale(db.scale)
	tracker:SetAlpha(db.alpha)
end

----------------------------------------------------------------------
-- Plegar solo
----------------------------------------------------------------------

local inCombat = false
local autoCollapsed = false   -- lo hemos plegado nosotros
local userOpened = false      -- el jugador lo ha abierto mientras tocaba plegado
local changing = false

local function wantCollapsed()
	local mode = db.collapse
	if mode == "never" then return false end
	if (mode == "combat" or mode == "both") and inCombat then return true end
	if mode == "instance" or mode == "both" then
		local inside, kind = IsInInstance()
		if inside then
			if kind == "party" or kind == "raid" or kind == "scenario" then return true end
			if db.collapsePvP and (kind == "pvp" or kind == "arena") then return true end
		end
	end
	return false
end

local function setCollapsed(on)
	changing = true
	pcall(tracker.SetCollapsed, tracker, on)
	changing = false
end

function M:UpdateCollapse()
	if not (tracker and tracker.SetCollapsed and tracker.IsCollapsed) then return end
	if wantCollapsed() then
		if not tracker:IsCollapsed() and not userOpened then
			setCollapsed(true)
			autoCollapsed = true
		end
	else
		userOpened = false
		if autoCollapsed then
			autoCollapsed = false
			if tracker:IsCollapsed() then setCollapsed(false) end
		end
	end
end

----------------------------------------------------------------------
-- Letra
----------------------------------------------------------------------

-- La de Blizzard, para volver a ella (el tamaño del Modo edición la cambia)
local base = {}
local touched = false

local function captureBase()
	for _, name in ipairs({ "ObjectiveTrackerLineFont", "ObjectiveTrackerHeaderFont" }) do
		local f = _G[name]
		if f then base[name] = { f:GetFont() } end
	end
end

local function customFont()
	return db.font ~= "default" or db.fontSize >= 8 or db.headerSize >= 8 or db.outline ~= ""
end

function M:ApplyFonts()
	if not customFont() then
		if not touched then return end
		touched = false
	else
		touched = true
	end
	for name, sizeKey in pairs({ ObjectiveTrackerLineFont = "fontSize", ObjectiveTrackerHeaderFont = "headerSize" }) do
		local f, b = _G[name], base[name]
		if f and b and b[1] then
			local file, size, flags = b[1], b[2], b[3]
			if customFont() then
				if db.font ~= "default" then file = db.font end
				if db[sizeKey] >= 8 then size = db[sizeKey] end
				if db.outline ~= "" then flags = db.outline end
			end
			if not pcall(f.SetFont, f, file, size, flags or "") then
				f:SetFont(b[1], size, flags or "")
			end
		end
	end
	if ObjectiveTrackerManager and ObjectiveTrackerManager.UpdateAll then
		pcall(ObjectiveTrackerManager.UpdateAll, ObjectiveTrackerManager)
	end
end

----------------------------------------------------------------------
-- Nivel en los diálogos
----------------------------------------------------------------------

local function withLevel(level, title)
	level = R.NotSecret(level)
	if not level or level <= 0 or not title then return title end
	return ("[%d] %s"):format(level, title)
end

-- Botones de misión del diálogo de chismes (GossipFrame)
local function gossipSetup(button, info)
	if not (db.gossipLevels and R:IsAddonActive(M.addon)) or type(info) ~= "table" then return end
	local title = withLevel(info.questLevel, info.title)
	if title == info.title then return end
	local fmt = NORMAL_QUEST_DISPLAY
	if info.isIgnored then fmt = IGNORED_QUEST_DISPLAY elseif info.isTrivial then fmt = TRIVIAL_QUEST_DISPLAY end
	button:SetFormattedText(fmt or "%s", title)
	if button.Resize then button:Resize() end
end

-- Saludo de los PNJ con varias misiones (QuestFrame)
local function greetingShow(panel)
	if not (db.gossipLevels and R:IsAddonActive(M.addon)) then return end
	local pool = panel.titleButtonPool
	if not (pool and pool.EnumerateActive) then return end
	for button in pool:EnumerateActive() do
		local id = button:GetID()
		local level
		if button.isActive == 1 then
			level = GetActiveLevel and GetActiveLevel(id)
		else
			level = GetAvailableLevel and GetAvailableLevel(id)
		end
		local text = button:GetText()
		if text and not text:find("^%[%d+%]") then
			local titled = withLevel(level, text)
			if titled ~= text then button:SetText(titled) end
		end
	end
end

-- Título de la misión al leerla, aceptarla o entregarla
local function detailShow()
	if not (db.detailLevel and R:IsAddonActive(M.addon)) then return end
	local header = QuestInfoTitleHeader
	if not (header and header:IsShown()) then return end
	local questID = GetQuestID and GetQuestID()
	if not questID or questID == 0 then return end
	local level = C_QuestLog.GetQuestDifficultyLevel and C_QuestLog.GetQuestDifficultyLevel(questID)
	local text = header:GetText()
	if text and not text:find("^%[%d+%]") then
		local titled = withLevel(level, text)
		if titled ~= text then header:SetText(titled) end
	end
end

function M:SetupDialogs()
	for _, mixin in ipairs({ GossipAvailableQuestButtonMixin, GossipActiveQuestButtonMixin }) do
		if mixin and mixin.Setup then hooksecurefunc(mixin, "Setup", gossipSetup) end
	end
	if QuestFrameGreetingPanel then QuestFrameGreetingPanel:HookScript("OnShow", greetingShow) end
	if QuestInfo_Display then hooksecurefunc("QuestInfo_Display", detailShow) end
end

----------------------------------------------------------------------

function M:OnEnable()
	db = self.db
	self:SetupDialogs()

	local function setupTracker()
		tracker = ObjectiveTrackerFrame
		if not tracker then
			R.missing[L["Misiones"]] = "ObjectiveTrackerFrame"
			return
		end
		captureBase()
		-- El tamaño del texto del Modo edición vuelve a poner la letra de Blizzard
		if ObjectiveTrackerManager and ObjectiveTrackerManager.SetTextSize then
			hooksecurefunc(ObjectiveTrackerManager, "SetTextSize", function()
				captureBase()
				if customFont() then M:ApplyFonts() end
			end)
		end
		hooksecurefunc(tracker, "SetCollapsed", function(_, collapsed)
			if changing then return end
			-- Lo ha tocado el jugador (o Blizzard): no lo volvemos a plegar
			if not collapsed and autoCollapsed then
				autoCollapsed = false
				userOpened = true
			end
		end)
		self:ApplyLook()
		if customFont() then self:ApplyFonts() end
	end
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_ObjectiveTracker", setupTracker)
	else
		setupTracker()
	end

	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	events:RegisterEvent("PLAYER_ENTERING_WORLD")
	events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
	events:RegisterEvent("CVAR_UPDATE")
	events:SetScript("OnEvent", function(_, event, cvar)
		if not R:IsAddonActive(M.addon) then return end
		if event == "PLAYER_REGEN_DISABLED" then
			inCombat = true
		elseif event == "PLAYER_REGEN_ENABLED" then
			inCombat = false
		elseif event == "CVAR_UPDATE" then
			-- El rastreador no se entera solo de estas dos
			if (cvar == "showQuestLevel" or cvar == "showQuestDifficultyColor")
				and ObjectiveTrackerManager and ObjectiveTrackerManager.UpdateAll then
				pcall(ObjectiveTrackerManager.UpdateAll, ObjectiveTrackerManager)
			end
			return
		end
		if event == "PLAYER_ENTERING_WORLD" then
			-- Blizzard prepara el rastreador justo al entrar
			C_Timer.After(0.5, function() M:ApplyLook(); M:UpdateCollapse() end)
			return
		end
		M:UpdateCollapse()
	end)
end

function M:OnOptionChanged(key)
	if key == "scale" or key == "alpha" then
		self:ApplyLook()
	elseif key == "collapse" or key == "collapsePvP" then
		self:UpdateCollapse()
	elseif key == "font" or key == "fontSize" or key == "headerSize" or key == "outline" then
		self:ApplyFonts()
	end
end
