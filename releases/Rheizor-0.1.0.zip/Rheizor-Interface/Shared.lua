-- Piezas compartidas de Rheizor-Interface: listas de letras y el "tema
-- oscuro" para ventanas de Blizzard.
--
-- El tema oscuro no toca nada de Blizzard salvo la opacidad de su arte: pone
-- a 0 el marco (NineSlice), el fondo, el retrato... y debajo pone un marco
-- propio con fondo liso y borde fino (colores de Rheizor-Core > Tema). Al
-- volver al clásico se devuelve cada pieza a la opacidad que tenía. Nada de
-- escribir campos en sus marcos ni de reemplazar funciones: solo ganchos.

local R = Rheizor:Namespace(...)
local L = R.L

local I = {}
R.Interface = I

----------------------------------------------------------------------
-- Letras
----------------------------------------------------------------------

I.FONTS = (function()
	local list = {
		{ "default", "La del juego" },
		{ "Fonts\\FRIZQT__.TTF", "Friz Quadrata" },
		{ "Fonts\\ARIALN.TTF", "Arial Narrow" },
		{ "Fonts\\skurri.ttf", "Skurri" },
		{ "Fonts\\MORPHEUS.ttf", "Morpheus" },
	}
	for _, f in ipairs(R.EXTRA_FONTS or {}) do list[#list + 1] = { f[2], f[3] } end
	return list
end)()

I.OUTLINES = {
	{ "", "Sin contorno" },
	{ "OUTLINE", "Contorno fino" },
	{ "THICKOUTLINE", "Contorno grueso" },
}

-- Deslizadores de tamaño de letra: el mínimo significa "el del juego"
function I.fmtGame(v)
	if v < 8 then return L["Del juego"] end
	return R.fmt.int(v)
end

----------------------------------------------------------------------
-- Tema oscuro para ventanas
----------------------------------------------------------------------

local WHITE = "Interface\\Buttons\\WHITE8X8"
local skins = {}   -- clave -> { host, pieces, isOn, saved, bd, inner }

local function paint(s)
	local r, g, b, a, er, eg, eb = R:ThemeColors()
	s.bd:SetBackdropColor(r, g, b, a)
	s.bd:SetBackdropBorderColor(er, eg, eb, 1)
	if s.inner then
		s.inner:SetBackdropColor(r * 0.6, g * 0.6, b * 0.6, math.min(1, a + 0.1))
		s.inner:SetBackdropBorderColor(er, eg, eb, 0.6)
	end
end

local function newBackdrop(parent, anchor)
	local bd = CreateFrame("Frame", nil, parent, "BackdropTemplate")
	bd:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, 0)
	bd:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", 0, 0)
	-- Al nivel del marco: por debajo de todo su contenido
	bd:SetFrameLevel(parent:GetFrameLevel())
	bd:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	return bd
end

function I:UpdateSkin(s)
	local on = s.isOn()
	if on then
		if not s.bd then
			s.bd = newBackdrop(s.host, s.host)
			if s.insetFrame then s.inner = newBackdrop(s.host, s.insetFrame) end
		end
		-- El marco puede cambiar de nivel (toplevel) al hacer clic
		s.bd:SetFrameLevel(s.host:GetFrameLevel())
		if s.inner then s.inner:SetFrameLevel(s.host:GetFrameLevel()) end
		paint(s)
		s.bd:Show()
		if s.inner then s.inner:Show() end
		for _, piece in ipairs(s.pieces) do
			if s.saved[piece] == nil then s.saved[piece] = piece:GetAlpha() end
			piece:SetAlpha(0)
		end
	else
		if s.bd then s.bd:Hide() end
		if s.inner then s.inner:Hide() end
		for piece, alpha in pairs(s.saved) do piece:SetAlpha(alpha) end
		wipe(s.saved)
	end
end

-- Las piezas de arte de las plantillas de Blizzard (PortraitFrameTemplate,
-- ButtonFrameTemplate, las planas de las bolsas...) que tenga el marco
local STANDARD = { "NineSlice", "Bg", "TopTileStreaks", "PortraitContainer", "TitleBg" }
function I.StandardPieces(frame, extra)
	local list = {}
	local seen = {}
	local function add(p)
		if type(p) == "table" and p.SetAlpha and not seen[p] then
			seen[p] = true
			list[#list + 1] = p
		end
	end
	for _, key in ipairs(STANDARD) do add(frame[key]) end
	local inset = frame.Inset
	if type(inset) == "table" then
		add(inset.Bg)
		add(inset.NineSlice)
	end
	for _, p in ipairs(extra or {}) do add(p) end
	return list
end

-- Texturas de fondo (capas BACKGROUND y BORDER) de un marco
function I.BackgroundTextures(frame, list)
	list = list or {}
	if type(frame) ~= "table" or not frame.GetRegions then return list end
	for _, region in ipairs({ frame:GetRegions() }) do
		if region.IsObjectType and region:IsObjectType("Texture") then
			local layer = region:GetDrawLayer()
			if layer == "BACKGROUND" or layer == "BORDER" then list[#list + 1] = region end
		end
	end
	return list
end

-- Registra una ventana. host: el marco (el fondo va debajo de su contenido);
-- pieces: lo que se hace transparente; isOn(): si toca el tema oscuro.
-- opts.inset: marco sobre el que poner un segundo fondo más oscuro.
function I:SkinFrame(key, host, pieces, isOn, opts)
	if type(host) ~= "table" or not host.GetFrameLevel then return end
	local s = skins[key]
	if not s then
		s = { host = host, pieces = pieces, isOn = isOn, saved = {} }
		s.insetFrame = opts and opts.inset
		skins[key] = s
		host:HookScript("OnShow", function() I:UpdateSkin(s) end)
	end
	self:UpdateSkin(s)
	return s
end

function I:UpdateAllSkins()
	for _, s in pairs(skins) do self:UpdateSkin(s) end
end

-- Al cambiar el tema o sus colores en Rheizor-Core
if R.OnThemeChanged then
	R:OnThemeChanged(function() I:UpdateAllSkins() end)
end

-- Espera a que cargue un addon de Blizzard (o llama ya si no hace falta)
function I.OnAddon(addon, fn)
	if not addon then return fn() end
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded(addon, fn)
	elseif C_AddOns and C_AddOns.IsAddOnLoaded(addon) then
		fn()
	end
end
