-- Apariencia del chat: letra, fondo, pestañas, caja de texto y botones.
-- Los nombres, canales, menciones y el ocultar el chat entero son de
-- Rheizor-Chat; aquí solo se cambia cómo se ve.
--
-- Sin ensuciar el chat de Blizzard: la letra se cambia con SetFont,
-- SetShadowOffset y SetSpacing de la propia ventana, que Blizzard deja
-- llamar a los addons de forma segura (ScrollingMessageFrameSecureMixin).
-- Su arte solo se oculta (Hide u opacidad 0) y el fondo liso es un marco
-- nuestro. Lo que se guarda de cada marco va en una tabla aparte.

local R = Rheizor:Namespace(...)
local L = R.L
local I = R.Interface

local function notSolid()
	local d = R.db and R.db.chatlook
	if d and (d.bg == "solid" or d.editBox == "solid") then return nil end
	return L["Solo con el fondo o la caja de texto lisos."]
end

local function notBorder()
	local reason = notSolid()
	if reason then return reason end
	local d = R.db and R.db.chatlook
	if d and not d.border then return L["Activa \"Borde fino\"."] end
end

local function fmtSpacing(v)
	if v <= 0 then return L["Del juego"] end
	return R.fmt.int(v)
end

local M = R:RegisterModule("chatlook", {
	title = "Apariencia del chat",
	defaults = {
		font = "default",
		fontSize = 7,       -- 7 = el de cada ventana
		outline = "",
		shadow = "game",
		spacing = 0,        -- 0 = el del juego
		editFont = true,
		bg = "game",
		bgColor = "000000",
		bgAlpha = 0.4,
		border = false,
		borderColor = "333333",
		tabs = "game",
		editBox = "game",
		hideButtons = false,
		hideScroll = false,
	},
	options = {
		{ type = "header", text = "Letra" },
		{ type = "dropdown", key = "font", name = "Tipo de letra", values = I.FONTS },
		{ type = "slider", key = "fontSize", name = "Tamaño de la letra", min = 7, max = 24, step = 1, format = I.fmtGame,
		  desc = "Al mínimo, el de cada ventana (clic derecho en su pestaña > Tamaño de fuente)." },
		{ type = "dropdown", key = "outline", name = "Contorno", values = I.OUTLINES },
		{ type = "dropdown", key = "shadow", name = "Sombra",
		  values = {
			{ "game", "Como el juego" },
			{ "none", "Sin sombra" },
			{ "strong", "Sombra marcada" },
		  } },
		{ type = "slider", key = "spacing", name = "Espacio entre líneas", min = 0, max = 10, step = 1, format = fmtSpacing },
		{ type = "toggle", key = "editFont", name = "La misma letra en la caja de texto" },

		{ type = "header", text = "Fondo" },
		{ type = "dropdown", key = "bg", name = "Fondo de las ventanas",
		  values = {
			{ "game", "Como el juego (se ve más al pasar el ratón)" },
			{ "solid", "Liso y siempre igual" },
			{ "none", "Sin fondo" },
		  },
		  desc = "Liso: un fondo plano con el color y la opacidad de abajo. El fondo y el marco del juego se ocultan." },
		{ type = "color", key = "bgColor", name = "Color del fondo", disabled = notSolid },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05, disabled = notSolid },
		{ type = "toggle", key = "border", name = "Borde fino", disabled = notSolid },
		{ type = "color", key = "borderColor", name = "Color del borde", disabled = notBorder },

		{ type = "header", text = "Pestañas y botones" },
		{ type = "dropdown", key = "tabs", name = "Pestañas",
		  values = {
			{ "game", "Como el juego" },
			{ "text", "Solo el texto" },
		  },
		  desc = "Solo el texto: sin el fondo de las pestañas. La elegida conserva su color y las demás salen en gris." },
		{ type = "toggle", key = "hideButtons", name = "Ocultar los botones del chat",
		  desc = "Los de al lado del chat: menú de emociones, canales, amigos y voz. Las opciones de cada ventana siguen en el clic derecho de su pestaña." },
		{ type = "toggle", key = "hideScroll", name = "Ocultar la barra de desplazamiento",
		  desc = "La rueda del ratón sigue funcionando y la flecha para bajar del todo se mantiene." },

		{ type = "header", text = "Caja de texto" },
		{ type = "dropdown", key = "editBox", name = "Aspecto de la caja de texto",
		  values = {
			{ "game", "Como el juego" },
			{ "solid", "Lisa, con los colores del fondo" },
		  },
		  desc = "Usa el color del fondo y del borde de arriba, algo más opaca para que se lea bien.\nSu posición se cambia en Rheizor-Chat." },
	},
})

local db
local WHITE = "Interface\\Buttons\\WHITE8X8"
local side = setmetatable({}, { __mode = "k" })   -- marco de Blizzard -> lo nuestro

local function data(obj)
	local s = side[obj]
	if not s then
		s = {}
		side[obj] = s
	end
	return s
end

local function running()
	return db and R:IsModuleRunning(M)
end

local function chatFrames()
	local list = {}
	for _, name in ipairs(CHAT_FRAMES or {}) do
		local frame = _G[name]
		if frame then list[#list + 1] = frame end
	end
	if #list == 0 then
		for i = 1, NUM_CHAT_WINDOWS or 10 do
			local frame = _G["ChatFrame" .. i]
			if frame then list[#list + 1] = frame end
		end
	end
	return list
end

----------------------------------------------------------------------
-- Letra
----------------------------------------------------------------------

local function customFont()
	return db.font ~= "default" or db.fontSize >= 8 or db.outline ~= "" or db.shadow ~= "game" or db.spacing > 0
end

-- El tamaño que el juego tiene guardado para la ventana (el del menú de su
-- pestaña); las ventanas temporales (susurros) no lo guardan
local function windowSize(frame, base)
	local id = frame:GetID()
	local maxId = Constants and Constants.ChatFrameConstants and Constants.ChatFrameConstants.MaxChatWindows or NUM_CHAT_WINDOWS or 10
	if FCF_GetChatWindowInfo and id and id > 0 and id <= maxId then
		local ok, _, size = pcall(FCF_GetChatWindowInfo, id)
		if ok and type(size) == "number" and size > 0 then return size end
	end
	return base
end

local function applyFont(frame)
	local s = data(frame)
	local on = running() and customFont()
	if not on and not s.fontTouched then return end
	if not s.font then
		local file, size, flags = frame:GetFont()
		if not file then return end
		local sx, sy = frame:GetShadowOffset()
		local sr, sg, sb, sa = frame:GetShadowColor()
		s.font = { file, size, flags, sx or 1, sy or -1, sr or 0, sg or 0, sb or 0, sa or 1, frame.GetSpacing and frame:GetSpacing() or 0 }
	end
	s.fontTouched = on
	local b = s.font
	local file, size, flags = b[1], windowSize(frame, b[2]), b[3]
	if on then
		if db.font ~= "default" then file = db.font end
		if db.fontSize >= 8 then size = db.fontSize end
		if db.outline ~= "" then flags = db.outline end
	end
	if not pcall(frame.SetFont, frame, file, size, flags or "") then
		pcall(frame.SetFont, frame, b[1], size, flags or "")
	end
	if on and db.shadow == "none" then
		frame:SetShadowOffset(0, 0)
	elseif on and db.shadow == "strong" then
		frame:SetShadowOffset(2, -2)
		frame:SetShadowColor(0, 0, 0, 1)
	else
		frame:SetShadowOffset(b[4], b[5])
		frame:SetShadowColor(b[6], b[7], b[8], b[9])
	end
	if frame.SetSpacing then frame:SetSpacing((on and db.spacing > 0) and db.spacing or b[10]) end
end

-- Caja de texto: el texto que escribes y el "Decir:" de delante
local function applyEditFont(editBox)
	local s = data(editBox)
	local on = running() and db.editFont and customFont()
	if not on and not s.fontTouched then return end
	s.fontTouched = on
	s.fonts = s.fonts or {}
	for _, region in ipairs({ editBox, editBox.header, editBox.headerSuffix, editBox.languageHeader }) do
		if type(region) == "table" and region.SetFont then
			local b = s.fonts[region]
			if not b then
				b = { region:GetFont() }
				s.fonts[region] = b
			end
			if b[1] then
				local file, size, flags = b[1], b[2], b[3]
				if on then
					if db.font ~= "default" then file = db.font end
					-- Del tamaño elegido, con tope: la caja mide lo que mide
					if db.fontSize >= 8 then size = math.min(db.fontSize, 20) end
					if db.outline ~= "" then flags = db.outline end
				end
				if not pcall(region.SetFont, region, file, size, flags or "") then
					pcall(region.SetFont, region, b[1], size, flags or "")
				end
			end
		end
	end
end

----------------------------------------------------------------------
-- Fondo
----------------------------------------------------------------------

local function newBackdrop(parent)
	local bd = CreateFrame("Frame", nil, parent, "BackdropTemplate")
	bd:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	return bd
end

local function paint(bd, alpha)
	local r, g, b = R.HexToRGB(db.bgColor)
	bd:SetBackdropColor(r, g, b, alpha)
	if db.border then
		local er, eg, eb = R.HexToRGB(db.borderColor)
		bd:SetBackdropBorderColor(er, eg, eb, 1)
	else
		bd:SetBackdropBorderColor(0, 0, 0, 0)
	end
end

-- Por debajo del texto: el texto va en un marco hijo de la ventana
local function below(bd, frame)
	bd:SetFrameLevel(math.max(0, frame:GetFrameLevel() - 1))
end

local function applyBackground(frame)
	local s = data(frame)
	local mode = running() and db.bg or "game"
	local name = frame:GetName()

	-- El fondo y el marco del juego (también los del lado de los botones).
	-- Blizzard solo los funde si se ven, así que ocultos se quedan ocultos
	if mode ~= "game" then
		s.hidden = s.hidden or {}
		for _, key in ipairs(CHAT_FRAME_TEXTURES or {}) do
			local t = _G[name .. key]
			if t and t.Hide and t:IsShown() then
				s.hidden[t] = true
				t:Hide()
			end
		end
	elseif s.hidden then
		for t in pairs(s.hidden) do t:Show() end
		s.hidden = nil
	end

	if mode == "solid" then
		if not s.bd then
			s.bd = newBackdrop(frame)
			local anchor = frame.Background or frame
			s.bd:SetPoint("TOPLEFT", anchor, "TOPLEFT", 0, 0)
			s.bd:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", 0, 0)
		end
		below(s.bd, frame)
		paint(s.bd, db.bgAlpha)
		s.bd:Show()
	elseif s.bd then
		s.bd:Hide()
	end
end

----------------------------------------------------------------------
-- Pestañas
----------------------------------------------------------------------

local TAB_ART = { "Left", "Middle", "Right", "ActiveLeft", "ActiveMiddle", "ActiveRight" }

local function styleTab(tab, selected)
	local s = data(tab)
	local on = running() and db.tabs == "text"
	if not on and not s.touched then return end
	s.touched = on
	for _, key in ipairs(TAB_ART) do
		local t = tab[key]
		if type(t) == "table" and t.SetAlpha then t:SetAlpha(on and 0 or 1) end
	end
	local text = tab.GetFontString and tab:GetFontString()
	if not text then return end
	if on and not selected then
		text:SetTextColor(0.55, 0.55, 0.55)
	elseif tab.selectedColorTable then
		local c = tab.selectedColorTable
		text:SetTextColor(c.r, c.g, c.b)
	else
		text:SetTextColor(NORMAL_FONT_COLOR.r, NORMAL_FONT_COLOR.g, NORMAL_FONT_COLOR.b)
	end
end

local function isSelected(frame)
	if not frame.isDocked then return true end
	return GENERAL_CHAT_DOCK and FCFDock_GetSelectedWindow and FCFDock_GetSelectedWindow(GENERAL_CHAT_DOCK) == frame
end

----------------------------------------------------------------------
-- Caja de texto
----------------------------------------------------------------------

local EDIT_ART = { "Left", "Right", "Mid" }                  -- por nombre
local EDIT_FOCUS = { "focusLeft", "focusMid", "focusRight" } -- por clave

local function styleEditBox(editBox)
	local s = data(editBox)
	local on = running() and db.editBox == "solid"
	if on or s.artTouched then
		s.artTouched = on
		local name = editBox:GetName()
		for _, key in ipairs(EDIT_ART) do
			local t = name and _G[name .. key]
			if t and t.SetAlpha then t:SetAlpha(on and 0 or 1) end
		end
		for _, key in ipairs(EDIT_FOCUS) do
			local t = editBox[key]
			if type(t) == "table" and t.SetAlpha then t:SetAlpha(on and 0 or 1) end
		end
	end
	if on then
		if not s.bd then
			s.bd = newBackdrop(editBox)
			s.bd:SetPoint("TOPLEFT", editBox, "TOPLEFT", 4, -5)
			s.bd:SetPoint("BOTTOMRIGHT", editBox, "BOTTOMRIGHT", -4, 5)
			-- Al abrirse sube de nivel (toplevel): el fondo, otra vez debajo
			local function relevel(self) if s.bd:IsShown() then below(s.bd, self) end end
			editBox:HookScript("OnShow", relevel)
			editBox:HookScript("OnEditFocusGained", relevel)
		end
		below(s.bd, editBox)
		paint(s.bd, math.max(db.bgAlpha, 0.75))
		s.bd:Show()
	elseif s.bd then
		s.bd:Hide()
	end
end

----------------------------------------------------------------------
-- Ocultar botones y barra de desplazamiento.
-- Blizzard los vuelve a mostrar a veces: se apunta lo que quiere (para
-- devolverlo al quitar la opción) y, mientras la opción siga, se ocultan.
----------------------------------------------------------------------

local BUTTONS = { "ChatFrameMenuButton", "ChatFrameChannelButton", "QuickJoinToastButton",
	"ChatFrameToggleVoiceDeafenButton", "ChatFrameToggleVoiceMuteButton", "TextToSpeechButtonFrame" }

local blockers = {}                                  -- objeto -> fn(): ¿oculto?
local wanted = setmetatable({}, { __mode = "k" })    -- objeto -> lo que quiere Blizzard
local hiding = false

local function buttonsHidden() return running() and db.hideButtons end
local function scrollHidden() return running() and db.hideScroll end

local function forceHide(obj)
	hiding = true
	obj:Hide()
	hiding = false
end

local function block(obj, isHidden)
	if type(obj) ~= "table" or not obj.Hide or blockers[obj] then return end
	blockers[obj] = isHidden
	wanted[obj] = obj:IsShown()
	hooksecurefunc(obj, "Show", function(self)
		if hiding then return end
		wanted[self] = true
		if blockers[self]() then forceHide(self) end
	end)
	hooksecurefunc(obj, "Hide", function(self)
		if not hiding then wanted[self] = false end
	end)
	hooksecurefunc(obj, "SetShown", function(self, shown)
		if hiding then return end
		wanted[self] = shown and true or false
		if shown and blockers[self]() then forceHide(self) end
	end)
end

local function updateBlocked()
	for obj, isHidden in pairs(blockers) do
		if isHidden() then
			if obj:IsShown() then forceHide(obj) end
		elseif wanted[obj] and not obj:IsShown() then
			hiding = true
			obj:Show()
			hiding = false
		end
	end
end

----------------------------------------------------------------------

function M:Apply()
	if not db then return end
	for _, frame in ipairs(chatFrames()) do
		applyFont(frame)
		applyBackground(frame)
		local name = frame:GetName()
		local tab = _G[name .. "Tab"]
		if tab then styleTab(tab, isSelected(frame)) end
		local editBox = frame.editBox or _G[name .. "EditBox"]
		if editBox then
			styleEditBox(editBox)
			applyEditFont(editBox)
		end
		if db.hideButtons then block(frame.buttonFrame, buttonsHidden) end
		if db.hideScroll then block(frame.ScrollBar, scrollHidden) end
	end
	if db.hideButtons then
		for _, name in ipairs(BUTTONS) do block(_G[name], buttonsHidden) end
	end
	updateBlocked()
	-- Sin los botones, el chat ya se puede pegar al borde de la izquierda
	if R.UpdateChatClamp then R:UpdateChatClamp() end
end

function M:OnEnable()
	db = self.db
	self:Apply()
	-- Con la interfaz ya colocada (el juego pone el tamaño de cada ventana al
	-- recibir su configuración)
	C_Timer.After(1, function() M:Apply() end)

	local events = CreateFrame("Frame")
	events:RegisterEvent("UPDATE_CHAT_WINDOWS")
	events:RegisterEvent("UPDATE_FLOATING_CHAT_WINDOWS")
	events:SetScript("OnEvent", function()
		-- Después de que Blizzard aplique lo suyo
		C_Timer.After(0, function() M:Apply() end)
	end)

	-- Cambiar el tamaño desde la pestaña, abrir un susurro en ventana nueva
	for _, fn in ipairs({ "FCF_SetChatWindowFontSize", "FCF_OpenTemporaryWindow", "FCF_OpenNewWindow" }) do
		if _G[fn] then hooksecurefunc(fn, function() M:Apply() end) end
	end
	if FCFTab_UpdateColors then
		hooksecurefunc("FCFTab_UpdateColors", function(tab, selected) styleTab(tab, selected) end)
	end
end

function M:OnOptionChanged()
	self:Apply()
end
