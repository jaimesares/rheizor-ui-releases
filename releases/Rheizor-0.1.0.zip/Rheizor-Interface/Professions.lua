-- Ventana de profesiones: tamaño, más alta (más recetas a la vista) y poder
-- moverla. Es la ProfessionsFrame de Blizzard (se carga al abrirla).
--
-- El gestor de paneles de Blizzard la recoloca y le pone escala 1 cada vez
-- que se abre o se abre otra ventana (UpdateUIPanelPositions): justo después
-- volvemos a poner lo nuestro.

local R = Rheizor:Namespace(...)
local L = R.L
local I = R.Interface

local M = R:RegisterModule("professions", {
	title = "Profesiones",
	defaults = {
		scale = 1,
		extraHeight = 0,
		movable = false,
		search = false,
		whButton = true,
		whCtrl = true,
		whTarget = "item",
		whSite = "classic",
		whSpanish = true,
	},
	options = {
		{ type = "header", text = "Ventana de profesiones" },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 1.3, step = 0.05 },
		{ type = "slider", key = "extraHeight", name = "Más alta", min = 0, max = 400, step = 20,
		  format = function(v) return v < 1 and L["Como en Blizzard"] or ("+" .. R.fmt.int(v)) end,
		  desc = "Alarga la ventana hacia abajo para ver más recetas en la lista a la vez." },
		{ type = "toggle", key = "movable", name = "Poder moverla",
		  desc = "Arrástrala desde el título. Al abrirla vuelve a donde la dejaste." },
		{ type = "button", name = "Posición", text = "Restablecer",
		  desc = "Vuelve a ponerla donde la pone Blizzard.",
		  func = function(mod) mod:ResetPosition() end },
		{ type = "toggle", key = "search", name = "Recordar la búsqueda",
		  desc = "Al volver a abrir la ventana, la lista sigue filtrada con lo último que buscaste." },

		{ type = "header", text = "Wowhead" },
		{ type = "toggle", key = "whButton", name = "Botón «Wowhead» en la receta",
		  desc = "Arriba a la derecha de la receta elegida. Muestra su enlace de Wowhead para copiarlo." },
		{ type = "toggle", key = "whCtrl", name = "Ctrl+clic en una receta de la lista",
		  desc = "Muestra el enlace de Wowhead de esa receta para copiarlo." },
		{ type = "dropdown", key = "whTarget", name = "Qué abrir",
		  values = { { "item", "El objeto que fabrica" }, { "spell", "La receta" } },
		  desc = "En la página del objeto se ve con qué se fabrica y quién lo hace. Si la receta no fabrica un objeto (encantamientos), se usa la receta." },
		{ type = "dropdown", key = "whSite", name = "Versión de Wowhead",
		  values = { { "classic", "Classic" }, { "retail", "Retail" } } },
		{ type = "toggle", key = "whSpanish", name = "Wowhead en español" },
	},
	unsupported = {
		"El coste de los materiales: el juego no da a los addons precios de la casa de subastas sin escanearla.",
		"Abrir el navegador: un addon no puede. Sale el enlace seleccionado para copiarlo con Ctrl+C.",
	},
})

local db
local frame
local BASE_HEIGHT

local function running()
	return frame and R:IsAddonActive(M.addon)
end

function M:Apply()
	if not running() or not frame:IsShown() then return end
	if not BASE_HEIGHT then BASE_HEIGHT = frame:GetHeight() end
	frame:SetScale(db.scale)
	if db.extraHeight > 0 or frame:GetHeight() ~= BASE_HEIGHT then
		frame:SetHeight(BASE_HEIGHT + db.extraHeight)
	end
	if db.movable and db.point then
		local p = db.point
		frame:ClearAllPoints()
		frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	end
end

function M:ResetPosition()
	db.point = nil
	if frame and frame:IsShown() then HideUIPanel(frame) end
	R:Print(L["Posición de la ventana de profesiones restablecida."])
end

local function savePosition()
	local point, _, relPoint, x, y = frame:GetPoint()
	if point then db.point = { point, relPoint, x, y } end
end

-- Recordar la búsqueda
local lastSearch = ""
local function searchBox()
	local page = frame and frame.CraftingPage
	return page and page.RecipeList and page.RecipeList.SearchBox
end

local function restoreSearch()
	if not (running() and db.search and lastSearch ~= "") then return end
	local box = searchBox()
	if box and box:GetText() == "" then
		box:SetText(lastSearch)   -- dispara su OnTextChanged, que filtra la lista
	end
end

----------------------------------------------------------------------
-- Wowhead: un addon no puede abrir el navegador, así que se enseña el
-- enlace ya seleccionado para copiarlo (Ctrl+C) y pegarlo
----------------------------------------------------------------------

local side = setmetatable({}, { __mode = "k" }) -- filas de la lista ya enganchadas

local function wowheadURL(recipeID)
	if db.whTarget == "item" then
		local ok, schematic = pcall(C_TradeSkillUI.GetRecipeSchematic, recipeID, false)
		local item = ok and schematic and schematic.outputItemID
		if item and item > 0 then return R.WowheadURL("item", item, db.whSite, db.whSpanish) end
	end
	return R.WowheadURL("spell", recipeID, db.whSite, db.whSpanish)
end

local function openWowhead(recipeInfo)
	if not (recipeInfo and recipeInfo.recipeID) then return end
	R:ShowCopyBox(L["Wowhead: %s"]:format(recipeInfo.name or "?"), wowheadURL(recipeInfo.recipeID))
end

-- Ctrl+clic en una fila de la lista de recetas (se engancha una vez por fila)
local function hookRow(row)
	if side[row] or not row.HookScript then return end
	side[row] = true
	row:HookScript("OnMouseDown", function(self, button)
		if not (running() and db.whCtrl and button == "LeftButton" and IsControlKeyDown()) then return end
		local ok, data = pcall(function() return self:GetElementData():GetData() end)
		if ok and data and data.recipeInfo then openWowhead(data.recipeInfo) end
	end)
end

local function setupWowhead()
	local page = frame.CraftingPage
	local form = page and page.SchematicForm
	local list = page and page.RecipeList
	if form and form.Init then
		local current
		hooksecurefunc(form, "Init", function(_, recipeInfo) current = recipeInfo end)
		local b = CreateFrame("Button", nil, form, "UIPanelButtonTemplate")
		b:SetSize(80, 20)
		b:SetPoint("TOPRIGHT", form, "TOPRIGHT", -8, -8)
		b:SetText("Wowhead")
		b:SetFrameLevel(form:GetFrameLevel() + 20)
		b:SetScript("OnClick", function() openWowhead(current) end)
		b:SetScript("OnEnter", function(self)
			GameTooltip:SetOwner(self, "ANCHOR_TOP")
			GameTooltip:AddLine(L["Ver en Wowhead"])
			GameTooltip:AddLine(L["Muestra el enlace para copiarlo y abrirlo en el navegador."], 1, 1, 1, true)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", GameTooltip_Hide)
		M.whButton = b
	end
	local box = list and list.ScrollBox
	if box then
		-- Filas ya creadas y las que se creen al desplazar la lista
		if box.ForEachFrame then box:ForEachFrame(hookRow) end
		if box.RegisterCallback and ScrollBoxListMixin and ScrollBoxListMixin.Event then
			box:RegisterCallback(ScrollBoxListMixin.Event.OnInitializedFrame, function(_, row) hookRow(row) end, M)
		end
	end
	M:UpdateWowhead()
end

function M:UpdateWowhead()
	if self.whButton then self.whButton:SetShown(running() and db.whButton) end
end

local function setup()
	frame = ProfessionsFrame
	if not frame then
		R.missing[L["Profesiones"]] = "ProfessionsFrame"
		return
	end

	-- Moverla desde el título (una zona propia, para no tapar los botones)
	frame:SetMovable(true)
	frame:SetClampedToScreen(true)
	local handle = CreateFrame("Frame", nil, frame)
	handle:SetPoint("TOPLEFT", 60, 0)
	handle:SetPoint("TOPRIGHT", -30, 0)
	handle:SetHeight(22)
	handle:SetFrameLevel(frame:GetFrameLevel() + 510)
	handle:EnableMouse(true)
	handle:RegisterForDrag("LeftButton")
	handle:SetScript("OnDragStart", function()
		if running() and db.movable then frame:StartMoving() end
	end)
	handle:SetScript("OnDragStop", function()
		frame:StopMovingOrSizing()
		frame:SetUserPlaced(false)
		if running() and db.movable then savePosition() end
	end)
	handle:SetScript("OnEnter", function(self)
		if not (running() and db.movable) then return end
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Arrastra para mover"])
		GameTooltip:Show()
	end)
	handle:SetScript("OnLeave", GameTooltip_Hide)
	M.handle = handle

	if UpdateUIPanelPositions then
		hooksecurefunc("UpdateUIPanelPositions", function()
			if frame:IsShown() then M:Apply() end
		end)
	end
	frame:HookScript("OnShow", function()
		M:Apply()
		C_Timer.After(0, function() M:Apply(); restoreSearch() end)
	end)

	local box = searchBox()
	if box then
		box:HookScript("OnTextChanged", function(self)
			if running() and db.search then lastSearch = self:GetText() or "" end
		end)
	end
	-- Blizzard la vacía al cambiar de profesión
	if EventRegistry then
		EventRegistry:RegisterCallback("Professions.ProfessionSelected", function()
			C_Timer.After(0, restoreSearch)
		end, M)
	end

	setupWowhead()
	M:Apply()
end

function M:OnEnable()
	db = self.db
	I.OnAddon("Blizzard_Professions", setup)
end

function M:OnOptionChanged(key)
	if key == "search" and not db.search then lastSearch = "" end
	self:UpdateWowhead()
	self:Apply()
end
