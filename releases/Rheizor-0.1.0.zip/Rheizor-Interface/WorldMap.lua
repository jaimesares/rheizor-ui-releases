-- Mapa del mundo: escala, posición, fondo oscuro, coordenadas, niveles de la
-- zona y transparencia al moverte. (Antes era Rheizor-WorldMap: se mantiene
-- la clave "map" para no perder la configuración.)

local R = Rheizor:Namespace(...)
local L = R.L

local M = R:RegisterModule("map", {
	title = "Mapa del mundo",
	defaults = {
		scale = 1,
		movable = false,
		noBlackout = false,
		coords = false,
		zoneLevels = true,
		fade = false,
		fadeAlpha = 0.5,
	},
	options = {
		{ type = "header", text = "Aspecto" },
		{ type = "toggle", key = "coords", name = "Mostrar coordenadas",
		  desc = "Muestra tus coordenadas y las del cursor en la parte inferior del mapa." },
		{ type = "toggle", key = "zoneLevels", name = "Niveles de la zona",
		  desc = "Arriba a la izquierda del mapa, los niveles de la zona que estás viendo, en el color de su dificultad para ti." },
		{ type = "toggle", key = "noBlackout", name = "Quitar fondo oscuro",
		  desc = "Quita el oscurecimiento de pantalla detrás del mapa maximizado y deja hacer clic a través." },

		{ type = "header", text = "Al moverte" },
		{ type = "toggle", key = "fade", name = "Transparente mientras te mueves",
		  desc = "El mapa se vuelve transparente al andar para ver por dónde vas, y vuelve a verse entero al pararte o al pasar el ratón por encima." },
		{ type = "slider", key = "fadeAlpha", name = "Opacidad al moverte", min = 0.1, max = 0.9, step = 0.05 },

		{ type = "header", text = "Tamaño y posición" },
		{ type = "slider", key = "scale", name = "Tamaño del mapa pequeño", min = 0.5, max = 1.5, step = 0.05,
		  desc = "Tamaño del mapa cuando no está maximizado. El mapa maximizado no cambia." },
		{ type = "toggle", key = "movable", name = "Mover el mapa pequeño",
		  desc = "Arrastra el mapa desde su borde para moverlo (no en combate). La posición se guarda." },
		{ type = "button", name = "Posición del mapa", text = "Restablecer",
		  desc = "Vuelve a la posición original de Blizzard.",
		  func = function(mod) mod:ResetPosition() end },
	},
	unsupported = {
		"Tus coordenadas no aparecen dentro de mazmorras y bandas: ahí el juego no da tu posición a los addons.",
		"Revelar las zonas sin explorar: el juego solo da las partes que ya has explorado, y lo demás necesita una lista de texturas de cada zona. Leatrix Maps la trae para WoW Forever.",
	},
})

-- Los ganchos no se pueden quitar: con el addon apagado en Rheizor siguen
-- llamándose, pero no hacen nada
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

local function isMaximized()
	return WorldMapFrame.IsMaximized and WorldMapFrame:IsMaximized()
end

function M:ApplyLayout()
	if not running() then return end
	local f = WorldMapFrame
	R:RunOutOfCombat(function()
		f:SetScale(isMaximized() and 1 or self.db.scale)
		if self.db.movable and self.db.point and not isMaximized() then
			local p = self.db.point
			f:ClearAllPoints()
			f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
		end
	end)

	local blackout = f.BlackoutFrame
	if blackout and (self.db.noBlackout or self.blackoutTouched) then
		self.blackoutTouched = true
		blackout:SetAlpha(self.db.noBlackout and 0 or 1)
		blackout:EnableMouse(not self.db.noBlackout)
	end
end

function M:ResetPosition()
	self.db.point = nil
	if WorldMapFrame:IsShown() then HideUIPanel(WorldMapFrame) end
	R:Print(L["Posición del mapa restablecida. Si no cambia al reabrirlo, usa /reload."])
end

function M:SetupDrag()
	local f = WorldMapFrame
	f:SetMovable(true)
	f:SetClampedToScreen(true)
	f:RegisterForDrag("LeftButton")
	f:HookScript("OnDragStart", function(frame)
		if running() and M.db.movable and not isMaximized() and not InCombatLockdown() then
			frame:StartMoving()
		end
	end)
	f:HookScript("OnDragStop", function(frame)
		frame:StopMovingOrSizing()
		if running() and M.db.movable and not isMaximized() then
			frame:SetUserPlaced(false)
			local point, _, relPoint, x, y = frame:GetPoint()
			M.db.point = { point, relPoint, x, y }
		end
	end)
end

----------------------------------------------------------------------
-- Coordenadas
----------------------------------------------------------------------

local function readPlayerCoords()
	local mapID = C_Map.GetBestMapForUnit("player")
	local pos = mapID and C_Map.GetPlayerMapPosition(mapID, "player")
	if not pos then return end
	local x, y = pos:GetXY()
	if issecretvalue and (issecretvalue(x) or issecretvalue(y)) then return end
	if x and y and (x > 0 or y > 0) then return x * 100, y * 100 end
end

function M:SetupCoords()
	local sc = WorldMapFrame.ScrollContainer
	if not sc then
		R.missing[L["Mapa del mundo: coords"]] = "WorldMapFrame.ScrollContainer"
		return
	end

	local bar = CreateFrame("Frame", nil, sc)
	bar:SetPoint("BOTTOMLEFT")
	bar:SetPoint("BOTTOMRIGHT")
	bar:SetHeight(18)
	bar:SetFrameLevel(sc:GetFrameLevel() + 100)

	local bg = bar:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(0, 0, 0, 0.5)

	bar.player = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	bar.player:SetPoint("LEFT", 10, 0)
	bar.cursor = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	bar.cursor:SetPoint("RIGHT", -10, 0)

	local elapsedSince = 1
	bar:SetScript("OnUpdate", function(_, elapsed)
		elapsedSince = elapsedSince + elapsed
		if elapsedSince < 0.1 then return end
		elapsedSince = 0

		local ok, px, py = pcall(readPlayerCoords)
		if ok and px then
			bar.player:SetFormattedText(L["Jugador: %.1f, %.1f"], px, py)
		else
			bar.player:SetText(L["Jugador: --"])
		end

		local cx, cy
		if sc:IsMouseOver() and sc.GetNormalizedCursorPosition then
			cx, cy = sc:GetNormalizedCursorPosition()
		end
		if cx and cx > 0 and cy > 0 and cx < 1 and cy < 1 then
			bar.cursor:SetFormattedText(L["Cursor: %.1f, %.1f"], cx * 100, cy * 100)
		else
			bar.cursor:SetText("")
		end
	end)

	self.coordBar = bar
	bar:SetShown(self.db.coords)
	-- Si se apaga el addon en Rheizor, la barra se esconde al abrir el mapa
	sc:HookScript("OnShow", function() bar:SetShown(running() and M.db.coords) end)
end

----------------------------------------------------------------------
-- Niveles de la zona
----------------------------------------------------------------------

function M:UpdateZoneLevels()
	local label = self.levelLabel
	if not label then return end
	local mapID = WorldMapFrame.GetMapID and WorldMapFrame:GetMapID()
	local low, high
	if running() and self.db.zoneLevels and mapID and C_Map.GetMapLevels then
		low, high = C_Map.GetMapLevels(mapID)
		low, high = R.NotSecret(low), R.NotSecret(high)
	end
	if not (low and high and high > 0) then
		label:Hide()
		return
	end
	local text = low == high and tostring(low) or (low .. "-" .. high)
	local color = GetQuestDifficultyColor and GetQuestDifficultyColor(math.floor((low + high) / 2))
	if color then
		label:SetFormattedText(L["Niveles %s"], string.format("|cff%02x%02x%02x%s|r", color.r * 255, color.g * 255, color.b * 255, text))
	else
		label:SetFormattedText(L["Niveles %s"], text)
	end
	label:Show()
end

function M:SetupZoneLevels()
	local sc = WorldMapFrame.ScrollContainer
	if not sc then return end
	local holder = CreateFrame("Frame", nil, sc)
	holder:SetAllPoints()
	holder:SetFrameLevel(sc:GetFrameLevel() + 100)
	local label = holder:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	label:SetPoint("TOPLEFT", 12, -10)
	label:SetShadowOffset(1, -1)
	label:SetShadowColor(0, 0, 0, 1)
	self.levelLabel = label
	local update = function() M:UpdateZoneLevels() end
	if WorldMapFrame.OnMapChanged then hooksecurefunc(WorldMapFrame, "OnMapChanged", update) end
	WorldMapFrame:HookScript("OnShow", update)
end

----------------------------------------------------------------------
-- Transparente al moverte. Lo hace el propio juego (PlayerMovementFrameFader,
-- el de la CVar mapFade, que siempre usa 50 %): al abrir el mapa, Blizzard lo
-- apunta y justo después lo volvemos a apuntar con nuestra opacidad.
----------------------------------------------------------------------

local function shouldFade()
	return running() and M.db.fade and not WorldMapFrame:IsMouseOver()
end

local function blizzardFade()
	return GetCVarBool("mapFade") and not WorldMapFrame:IsMouseOver()
end

function M:ApplyFade(immediate)
	local fader = PlayerMovementFrameFader
	local f = WorldMapFrame
	if not (fader and fader.AddDeferredFrame and f:IsShown()) then return end
	local add = immediate and fader.AddFrame or fader.AddDeferredFrame
	if running() and self.db.fade then
		add(f, self.db.fadeAlpha, 1, 0.5, shouldFade)
	elseif immediate then
		-- Como lo deja Blizzard
		add(f, 0.5, 1, 0.5, blizzardFade)
	end
end

function M:SetupFade()
	if not PlayerMovementFrameFader then return end
	-- Después del OnShow de Blizzard, que apunta el mapa con su opacidad
	WorldMapFrame:HookScript("OnShow", function()
		if running() and M.db.fade then M:ApplyFade() end
	end)
end

----------------------------------------------------------------------

function M:OnEnable()
	local f = WorldMapFrame
	if not f then
		R.missing[L["Mapa del mundo"]] = "WorldMapFrame"
		return
	end

	started = true
	self:SetupDrag()
	self:SetupCoords()
	self:SetupZoneLevels()
	self:SetupFade()

	local apply = function() M:ApplyLayout() end
	if f.SynchronizeDisplayState then hooksecurefunc(f, "SynchronizeDisplayState", apply) end
	if f.OnFrameSizeChanged then hooksecurefunc(f, "OnFrameSizeChanged", apply) end
	f:HookScript("OnShow", function()
		apply()
		C_Timer.After(0, apply)
	end)
	self:ApplyLayout()
end

function M:OnOptionChanged(key, value)
	if key == "coords" then
		if self.coordBar then self.coordBar:SetShown(value) end
	elseif key == "zoneLevels" then
		self:UpdateZoneLevels()
	elseif key == "fade" or key == "fadeAlpha" then
		self:ApplyFade(true)
	elseif WorldMapFrame then
		self:ApplyLayout()
	end
end
