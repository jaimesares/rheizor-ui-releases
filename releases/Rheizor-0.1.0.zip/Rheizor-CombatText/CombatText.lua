-- Texto de combate desplazable (estilo MikScrollingBattleText).
--
-- Forever usa el motor 12.x en modo restringido: el registro de combate está
-- cerrado a los addons, así que nunca se sabe quién hace cada golpe ni con
-- qué habilidad. Por eso:
--   * Zona entrante: daño y sanación que recibes tú (y tu mascota) vía
--     UNIT_COMBAT. Quién te cura sale del texto de combate de Blizzard
--     (COMBAT_TEXT_UPDATE), que sí da el nombre del sanador, aunque secreto:
--     solo se puede pintar tal cual.
--   * Los ajustes del texto de combate de Blizzard (números sobre el
--     objetivo, texto sobre tu personaje…) están todos en esta página.
--   * Zona saliente: todo el daño y la sanación que recibe tu objetivo, venga
--     de quien venga (UNIT_COMBAT); se filtra según sea enemigo o aliado.
--   * Zona de avisos: combate, experiencia, dinero, botín, reputación,
--     habilidades, nivel, vida baja, auras y procs.
-- Los valores pueden llegar "secretos": se pintan tal cual sin operarlos.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

----------------------------------------------------------------------
-- Colores y opciones
----------------------------------------------------------------------

local COLORS = R.COLORS

local FONTS = {
	{ "Fonts\\FRIZQT__.TTF", "Friz Quadrata (Blizzard)" },
	{ "Fonts\\ARIALN.TTF", "Arial Narrow" },
	{ "Fonts\\skurri.ttf", "Skurri (números de combate)" },
	{ "Fonts\\MORPHEUS.TTF", "Morpheus" },
}
for _, f in ipairs(R.EXTRA_FONTS or {}) do FONTS[#FONTS + 1] = { f[2], f[3] } end

local DIRECTIONS = { { "up", "Hacia arriba" }, { "down", "Hacia abajo" } }
local TARGET_SIDES = {
	{ "all", "Siempre" },
	{ "enemy", "Solo si es enemigo" },
	{ "friend", "Solo si es aliado" },
	{ "never", "Nunca" },
}
local ANIMATIONS = { { "arc", "En arco" }, { "straight", "Recta" } }

-- Ajustes del texto de combate de Blizzard (variables de consola del juego).
-- En el motor moderno varias se renombraron con "_v2" y, según la versión,
-- existe una, la otra o las dos: se usa la "_v2" si existe y si no la
-- clásica. En la interfaz de Blizzard de Forever solo aparecen
-- enableFloatingCombatText (sin "_v2") y varias floatingCombatText*_v2; las
-- de los números sobre el objetivo y su tamaño solo existen dentro del juego
-- (si existen), así que se comprueban al cargar. Una opción puede tocar
-- varias (tu daño y el de tu mascota) y se lee de la primera. Si no existe
-- ninguna, el gestor la muestra como "no disponible".
local function findCVar(base)
	for _, name in ipairs({ base .. "_v2", base }) do
		if C_CVar.GetCVar(name) ~= nil then return name end
	end
end

local function blizzOption(id, bases, opt)
	opt.id = id
	local list = {}
	for _, base in ipairs(bases) do
		local cvar = findCVar(base)
		if cvar then list[#list + 1] = cvar end
	end
	if #list == 0 then
		opt.cvar = bases[1]
		return opt
	end

	local function fromString(s)
		if opt.type == "toggle" then return s ~= nil and s ~= "0" end
		return tonumber(s) or opt.min
	end
	local function toString(v)
		if opt.type == "toggle" then return v and "1" or "0" end
		return string.format("%g", math.floor(v / opt.step + 0.5) * opt.step)
	end

	-- Sigue siendo una variable del juego: entra en exportar/importar
	opt.cvar, opt.exportCVar = list[1], true
	opt.get = function() return fromString(C_CVar.GetCVar(list[1])) end
	opt.set = function(value)
		local s = toString(value)
		-- R:SetCVar espera a salir de combate y avisa si el juego no lo acepta
		for _, cvar in ipairs(list) do R:SetCVar(cvar, s) end
	end
	opt.default = fromString((C_CVar.GetCVarDefault and C_CVar.GetCVarDefault(list[1])) or C_CVar.GetCVar(list[1]))
	return opt
end

local function colorOption(key, name, desc)
	return { type = "dropdown", key = key, name = name, values = COLORS, desc = desc }
end

-- Una zona: título, interruptor, sus opciones propias y al final su movimiento
local function areaOptions(prefix, title, desc, ...)
	local list = {
		{ type = "header", text = title },
		{ type = "toggle", key = prefix .. "Enabled", name = "Activar", desc = desc },
	}
	for i = 1, select("#", ...) do list[#list + 1] = (select(i, ...)) end
	list[#list + 1] = { type = "dropdown", key = prefix .. "Dir", name = "Dirección", values = DIRECTIONS }
	list[#list + 1] = { type = "dropdown", key = prefix .. "Anim", name = "Animación", values = ANIMATIONS,
		desc = "En arco: los textos se abren hacia un lado mientras suben o bajan.\nRecta: suben o bajan en línea recta." }
	return list
end

local options = {
	{ type = "header", text = "General" },
	{ type = "toggle", key = "enabled", name = "Activar texto de combate",
	  desc = "Texto de combate propio de Rheizor, en tres zonas: lo que recibes, lo que recibe tu objetivo y avisos." },
	{ type = "button", name = "Vista previa", text = "Probar",
	  desc = "Muestra textos de ejemplo en las tres zonas para ajustar posición y colores.",
	  func = function(mod) mod:Test() end },
	{ type = "toggle", key = "locked", name = "Bloquear posición",
	  desc = "Desbloqueado muestra las tres zonas con textos de ejemplo para arrastrarlas con el ratón. También se desbloquean con el modo edición de Rheizor (/rz mover)." },
	{ type = "button", name = "Posición", text = "Restablecer",
	  desc = "Vuelve a colocar las tres zonas en su sitio inicial.",
	  func = function(mod) mod:ResetPositions() end },

	{ type = "header", text = "Qué mostrar en combate" },
	{ type = "toggle", key = "showHeals", name = "Sanaciones", desc = "En la zona entrante y en la saliente." },
	{ type = "toggle", key = "showMisses", name = "Fallos, esquivas, paradas, resistencias…" },
}

local function add(list)
	for _, opt in ipairs(list) do table.insert(options, opt) end
end

add(areaOptions("in", "Zona entrante (lo que recibes)", "Daño y sanación que recibes tú.",
	{ type = "toggle", key = "inSource", name = "Quién te cura, entre paréntesis",
	  desc = "Añade el nombre de quien te cura: +2200 (Pepe). Lo da el texto de combate de Blizzard, así que necesita activado \"Texto de combate sobre tu personaje\" (abajo, en \"Texto de combate de Blizzard\"). El juego entrega ese nombre protegido: sale tal cual, sin color de clase, y también en tus propias curas.\n\nEl juego no dice quién te hace daño, solo quién te cura." },
	{ type = "toggle", key = "petIncoming", name = "Daño que recibe tu mascota", desc = "Aparece en la zona entrante marcado con [M]." },
	{ type = "toggle", key = "inMana", name = "Maná recuperado",
	  desc = "Regeneración (espíritu, mp5), pociones, Evocación, Toque de vida… El juego no dice de dónde viene: se ve cuánto sube tu maná." },
	{ type = "toggle", key = "inRegen", name = "Vida recuperada sin curas",
	  desc = "Regeneración, comer, Canibalizar, vendas… Las curas normales ya salen aparte y no se repiten." },
	{ type = "toggle", key = "inPower", name = "Energía y furia recuperadas", desc = "Con la energía sale un texto en cada tic." },
	{ type = "slider", key = "regenMin", name = "Mínimo para mostrar lo recuperado", min = 0, max = 200, step = 1, format = R.fmt.int,
	  desc = "Las subidas de maná, vida o energía más pequeñas que esto no salen. 0 = todas." }
))
add(areaOptions("out", "Zona saliente (tu objetivo)",
	"Muestra todo el daño y la sanación que recibe tu objetivo, venga de quien venga: tuyo, de tu mascota o de otros. El juego no dice a los addons quién hace cada golpe; lo que sí puedes es filtrarlo según tu objetivo sea enemigo o aliado.",
	{ type = "dropdown", key = "outDamageWho", name = "Daño que recibe tu objetivo", values = TARGET_SIDES,
	  desc = "Según tu objetivo sea un enemigo (se le puede atacar) o un aliado. Por ejemplo, solo el daño a enemigos, para no ver los golpes que recibe el tanque al que tienes seleccionado." },
	{ type = "dropdown", key = "outHealWho", name = "Sanación que recibe tu objetivo", values = TARGET_SIDES,
	  desc = "Por ejemplo, solo las curas a aliados, para no ver cómo se curan los enemigos." }
))
add(areaOptions("note", "Zona de avisos", "Combate, experiencia, dinero, botín y otros avisos de abajo.",
	{ type = "toggle", key = "nCombat", name = "Entrar y salir de combate" },
	{ type = "toggle", key = "nXP", name = "Experiencia ganada" },
	{ type = "toggle", key = "nMoney", name = "Dinero ganado" },
	{ type = "toggle", key = "nLoot", name = "Botín", desc = "Objetos que recibes, con icono y cantidad." },
	{ type = "toggle", key = "nRep", name = "Reputación" },
	{ type = "toggle", key = "nSkill", name = "Subidas de profesión y armas" },
	{ type = "toggle", key = "nLevel", name = "Subida de nivel" },
	{ type = "toggle", key = "nLowHealth", name = "Aviso de vida baja", desc = "Al bajar del 35% de vida." },
	{ type = "toggle", key = "lowHealthSound", name = "Sonido con vida baja" },
	{ type = "toggle", key = "nAuras", name = "Auras ganadas y perdidas, procs",
	  desc = "Salen del texto de combate de Blizzard: necesita activado \"Texto de combate sobre tu personaje\" (abajo, en \"Texto de combate de Blizzard\")." }
))
add({
	{ type = "header", text = "Aspecto" },
	{ type = "dropdown", key = "font", name = "Fuente", values = FONTS },
	{ type = "dropdown", key = "outline", name = "Contorno",
	  values = { { "NONE", "Sin contorno" }, { "OUTLINE", "Fino" }, { "THICKOUTLINE", "Grueso" } } },
	{ type = "slider", key = "size", name = "Tamaño de letra", min = 10, max = 40, step = 1, format = R.fmt.int },
	{ type = "slider", key = "critScale", name = "Tamaño de los críticos", min = 1, max = 2.5, step = 0.1,
	  desc = "Los críticos aparecen más grandes, con un golpe de zoom." },
	{ type = "toggle", key = "stickyCrits", name = "Críticos fijos",
	  desc = "Los críticos no se desplazan: aparecen en el centro de su zona con un golpe de zoom, se quedan quietos y se desvanecen. Si llegan varios seguidos, se apilan." },
	{ type = "slider", key = "duration", name = "Duración", min = 1, max = 5, step = 0.1, format = R.fmt.dec1 },
	{ type = "slider", key = "scrollHeight", name = "Recorrido", min = 80, max = 400, step = 10, format = R.fmt.int,
	  desc = "Distancia en píxeles que recorre cada texto." },
	{ type = "toggle", key = "abbreviate", name = "Abreviar números grandes", desc = "12500 → 12,5 K" },

	{ type = "header", text = "Colores" },
	{ type = "toggle", key = "schoolColors", name = "Colorear el daño por escuela de magia",
	  desc = "Cada escuela con su color: fuego naranja, naturaleza/venenos verde, escarcha celeste…" },
	colorOption("cPhysicalIn", "Daño físico recibido"),
	colorOption("cPhysicalOut", "Daño físico al objetivo"),
	colorOption("cNature", "Naturaleza (venenos)"),
	colorOption("cFire", "Fuego"),
	colorOption("cFrost", "Escarcha"),
	colorOption("cShadow", "Sombras"),
	colorOption("cArcane", "Arcano"),
	colorOption("cHoly", "Sagrado"),
	colorOption("cHeal", "Sanación"),
	colorOption("cMana", "Maná recuperado"),
	colorOption("cRegen", "Vida recuperada sin curas"),
	colorOption("cPower", "Energía y furia recuperadas"),
	colorOption("cMiss", "Fallos y evasiones"),

	-- Opciones del juego (no de Rheizor): todas las del texto de combate de
	-- Blizzard están aquí y solo aquí
	{ type = "header", text = "Texto de combate de Blizzard" },
	blizzOption("sct_blizzSelf", { "enableFloatingCombatText" },
		{ type = "toggle", name = "Texto de combate sobre tu personaje",
		  desc = "El texto flotante de Blizzard sobre ti: daño, sanación, reputación… Déjalo activado si usas \"Quién te cura\" o el aviso de auras y procs de Rheizor: salen de aquí." }),
	blizzOption("sct_blizzTarget",
		{ "floatingCombatTextCombatDamage", "floatingCombatTextPetMeleeDamage", "floatingCombatTextPetSpellDamage" },
		{ type = "toggle", name = "Números de daño sobre el objetivo",
		  desc = "Los números que Blizzard dibuja sobre los enemigos con el daño que les haces tú y tu mascota." }),
	blizzOption("sct_blizzHeal", { "floatingCombatTextCombatHealing" },
		{ type = "toggle", name = "Números de sanación sobre el objetivo",
		  desc = "Las curas que haces tú, dibujadas sobre quien las recibe." }),
	blizzOption("WorldTextScale", { "WorldTextScale" },
		{ type = "slider", name = "Tamaño de los números de daño",
		  min = 0.5, max = 2.5, step = 0.1, format = R.fmt.dec1,
		  desc = "Tamaño de los números que Blizzard dibuja sobre el objetivo." }),
	blizzOption("floatingCombatTextCombatDamageDirectionalScale", { "floatingCombatTextCombatDamageDirectionalScale" },
		{ type = "slider", name = "Dispersión de los números",
		  min = 0, max = 5, step = 0.5, format = R.fmt.dec1,
		  desc = "0 = los números suben rectos; valores altos los reparten en abanico." }),
})

local M = R:RegisterModule("sct", {
	title = "Texto de combate",
	defaults = {
		enabled = true,
		font = FONTS[1][1],
		outline = "OUTLINE",
		size = 18,
		critScale = 1.6,
		stickyCrits = true,
		locked = true,
		duration = 2.5,
		scrollHeight = 180,
		abbreviate = true,

		-- X/Y: posición antigua (antes de poder arrastrar), solo para el sitio por defecto
		inEnabled = true, inX = -260, inY = 20, inDir = "down", inAnim = "arc",
		outEnabled = true, outX = 260, outY = 20, outDir = "up", outAnim = "arc",
		noteEnabled = true, noteX = 0, noteY = 240, noteDir = "up", noteAnim = "straight",
		outDamageWho = "enemy",
		outHealWho = "friend",
		inSource = false,

		showHeals = true,
		showMisses = true,
		petIncoming = false,
		inMana = true,
		inRegen = true,
		inPower = false,
		regenMin = 0,
		cMana = "4080ff",
		cRegen = "80ff80",
		cPower = "ffff40",

		schoolColors = true,
		cPhysicalIn = "ff3333",
		cPhysicalOut = "ffffff",
		cNature = "00b050",
		cFire = "ff8000",
		cFrost = "80ffff",
		cShadow = "a080ff",
		cArcane = "ff80ff",
		cHoly = "ffff99",
		cHeal = "33ff33",
		cMiss = "bbbbbb",

		nCombat = true,
		nXP = true,
		nMoney = true,
		nLoot = true,
		nRep = true,
		nSkill = true,
		nLevel = true,
		nLowHealth = true,
		lowHealthSound = true,
		nAuras = false,
	},
	options = options,
	-- Lo que el juego no deja hacer a los addons (se lista al final de la página)
	unsupported = {
		"Ver solo tu daño o el de tu mascota: el juego no dice a los addons quién hace cada golpe.",
		"Ver quién le hace daño o cura a tu objetivo, o quién te hace daño a ti: el juego solo dice a los addons quién te cura a ti.",
		"Icono de la habilidad en cada golpe: el juego no dice a los addons con qué hechizo o habilidad se hizo.",
		"Color o icono de clase de quien te cura, o quitar tu nombre de tus propias curas: el juego da ese nombre protegido y solo se puede mostrar tal cual.",
	},
})

local db
local decorate   -- nombre de quien cura en los ejemplos; se define más abajo

local hexToRGB = R.HexToRGB

-- Máscara de escuela -> opción de color (la primera escuela no física)
local SCHOOLS = {
	{ 4, "cFire" }, { 16, "cFrost" }, { 8, "cNature" }, { 32, "cShadow" }, { 64, "cArcane" }, { 2, "cHoly" },
}

local function schoolColor(school, physicalKey)
	if db.schoolColors and school then
		for _, s in ipairs(SCHOOLS) do
			if bit.band(school, s[1]) ~= 0 then return db[s[2]] end
		end
	end
	return db[physicalKey]
end

----------------------------------------------------------------------
-- Zonas y animación
----------------------------------------------------------------------

local MISS_TEXT = {
	MISS = MISS or L["Fallo"],
	DODGE = DODGE or L["Esquiva"],
	PARRY = PARRY or L["Parada"],
	BLOCK = BLOCK or L["Bloqueo"],
	RESIST = RESIST or L["Resistido"],
	IMMUNE = IMMUNE or L["Inmune"],
	ABSORB = ABSORB or L["Absorbido"],
	EVADE = EVADE or L["Evadido"],
	REFLECT = REFLECT or L["Reflejado"],
	DEFLECT = DEFLECT or L["Desviado"],
}

local AREAS = {
	incoming = { prefix = "in", arc = -1, label = "Texto de combate: entrante" },
	outgoing = { prefix = "out", arc = 1, label = "Texto de combate: saliente" },
	notes    = { prefix = "note", arc = 0, label = "Texto de combate: avisos" },
}

-- Cada zona es un recuadro del alto del recorrido: los textos van de un
-- extremo al otro, y en el modo edición se arrastra el recuadro entero
local AREA_WIDTH = 220
local ARC_WIDTH = 70
local POW_TIME = 0.18
local MAX_STICKY = 4

local function setFont(fs, size)
	local flags = db.outline ~= "NONE" and db.outline or ""
	if not fs:SetFont(db.font, size, flags) then fs:SetFont(STANDARD_TEXT_FONT, size, flags) end
end

local function release(area, i)
	local line = table.remove(area.lines, i)
	line.fs:Hide()
	table.insert(area.pool, line.fs)
end

local function spawn(area, item)
	-- Críticos fijos: los anteriores se apartan un renglón para dejar sitio
	if item.sticky then
		local step = db.size * db.critScale * 1.15
		local count, oldest = 0
		for i, line in ipairs(area.lines) do
			if line.sticky then
				line.off = line.off + step
				count = count + 1
				oldest = oldest or i
			end
		end
		if count >= MAX_STICKY then release(area, oldest) end
	end

	local fs = table.remove(area.pool) or area:CreateFontString(nil, "OVERLAY")
	setFont(fs, item.crit and db.size * db.critScale or db.size)
	-- Con args, text es un formato: los valores pueden ser "secretos" (Lua no
	-- puede leerlos ni juntarlos, pero el texto en pantalla sí puede pintarlos)
	if item.args then
		fs:SetFormattedText(item.text, unpack(item.args, 1, item.args.n))
	else
		fs:SetText(item.text)
	end
	fs:SetTextColor(hexToRGB(item.color))
	fs:SetAlpha(0)
	fs:ClearAllPoints()
	fs:SetPoint("CENTER", area, "CENTER")
	fs:Show()
	table.insert(area.lines, { fs = fs, t = 0, crit = item.crit, sticky = item.sticky, off = 0 })
end

local function areaOnUpdate(area, elapsed)
	local now = GetTime()

	-- Separación mínima entre textos para que no se pisen
	if #area.queue > 0 then
		local speed = db.scrollHeight / db.duration
		local spacing = math.min(math.max(db.size * 1.15 / speed, 0.06), 0.3)
		if now - area.lastSpawn >= spacing then
			spawn(area, table.remove(area.queue, 1))
			area.lastSpawn = now
		end
	end

	local dir = db[area.prefix .. "Dir"] == "down" and -1 or 1
	local arc = db[area.prefix .. "Anim"] == "arc"
	local h = db.scrollHeight
	for i = #area.lines, 1, -1 do
		local line = area.lines[i]
		line.t = line.t + elapsed
		local p = line.t / db.duration
		local fs = line.fs
		if p >= 1 then
			release(area, i)
		else
			local x, y = 0, 0
			if line.sticky then
				y = dir * line.off
			else
				if arc then x = area.arc * ARC_WIDTH * 4 * p * (1 - p) end
				y = dir * (p - 0.5) * h
			end
			fs:ClearAllPoints()
			fs:SetPoint("CENTER", area, "CENTER", x, y)

			local alpha = 1
			if line.t < 0.08 then alpha = line.t / 0.08 elseif p > 0.75 then alpha = (1 - p) / 0.25 end
			fs:SetAlpha(alpha)

			-- Golpe de zoom de los críticos
			if line.crit and line.t < POW_TIME + 0.05 then
				local k = math.max(0, 1 - line.t / POW_TIME)
				setFont(fs, db.size * db.critScale * (1 + 0.8 * k))
			end
		end
	end

	if #area.lines == 0 and #area.queue == 0 then area:SetScript("OnUpdate", nil) end
end

local areas = {}

local function createArea(key)
	local info = AREAS[key]
	local p = info.prefix
	local area = CreateFrame("Frame", nil, UIParent)
	area:SetSize(AREA_WIDTH, db.scrollHeight)
	area:SetFrameStrata("HIGH")
	area.prefix = p
	area.arc = info.arc
	area.lines, area.pool, area.queue = {}, {}, {}
	area.lastSpawn = 0
	-- Sitio por defecto: donde empezaba el texto antes (X/Y) más medio recorrido
	local dir = db[p .. "Dir"] == "down" and -1 or 1
	area.mover = R:CreateMover(area, info.label, db, p .. "Point",
		{ "CENTER", "CENTER", db[p .. "X"], db[p .. "Y"] + dir * db.scrollHeight / 2 })
	areas[key] = area
	return area
end

-- Mete un texto en una zona sin mirar si está activada (lo usan Emit y los ejemplos)
local function push(area, text, color, crit, args)
	local item = { text = text, color = color, crit = crit, sticky = crit and db.stickyCrits, args = args }
	if item.sticky then
		spawn(area, item)
	else
		if #area.queue >= 20 then table.remove(area.queue, 1) end
		table.insert(area.queue, item)
	end
	area:SetScript("OnUpdate", areaOnUpdate)
end

----------------------------------------------------------------------
-- Ejemplos mientras las zonas están desbloqueadas
----------------------------------------------------------------------

local demoTicker, demoStep = nil, 0

-- Textos de ejemplo: { texto, color, crítico, quién cura }
local function demoLists()
	local c = db
	local function school(key, fallback) return c.schoolColors and c[key] or c[fallback] end
	local incoming = {
		{ "-1250", c.cPhysicalIn, false },
		{ "-430", school("cNature", "cPhysicalIn"), false },
		{ "-3840!", school("cFire", "cPhysicalIn"), true },
		{ "+2200", c.cHeal, false, { srcName = L["Sanadora"] } },
		{ MISS_TEXT.DODGE, c.cMiss, false },
	}
	local outgoing = {
		{ "980", c.cPhysicalOut, false },
		{ "615", school("cFrost", "cPhysicalOut"), false },
		{ "2450!", c.cPhysicalOut, true },
		{ "740", school("cShadow", "cPhysicalOut"), false },
		{ MISS_TEXT.RESIST, c.cMiss, false },
	}
	local notes = {
		{ L["+Combate"], "ff6040" },
		{ L["+%d XP"]:format(350), "c080ff" },
		{ "+" .. R.Money(12345), "ffd100" },
	}
	return incoming, outgoing, notes
end

local function demoTick()
	demoStep = demoStep + 1
	local incoming, outgoing, notes = demoLists()
	local function send(key, list)
		local e = list[(demoStep - 1) % #list + 1]
		push(areas[key], decorate(key, e[1], e[4]), e[2], e[3])
	end
	send("incoming", incoming)
	send("outgoing", outgoing)
	if demoStep % 2 == 0 then send("notes", notes) end
end

local function setDemo(on)
	if on and not demoTicker then
		demoStep = 0
		demoTicker = C_Timer.NewTicker(0.6, demoTick)
	elseif not on and demoTicker then
		demoTicker:Cancel()
		demoTicker = nil
	end
end

function M:ApplyAreas()
	for _, area in pairs(areas) do
		area:SetHeight(db.scrollHeight)
		area.mover:SetShown(not db.locked)
		if not db[area.prefix .. "Enabled"] then
			area.queue = {}
		end
	end
	setDemo(not db.locked)
end

function M:ResetPositions()
	for _, area in pairs(areas) do
		db[area.prefix .. "Point"] = nil
		area.mover:Place()
	end
end

-- Añade un texto a una zona ("incoming", "outgoing" o "notes")
-- args (opcional): { n = cuántos, ... } y entonces text es un formato
function M:Emit(key, text, color, crit, args)
	local area = areas[key]
	if not area or not db.enabled or not db[area.prefix .. "Enabled"] then return end
	-- Apagado en Rheizor sin recargar: los eventos siguen llegando, no se pinta nada
	if not R:IsAddonActive(M.addon) then return end
	push(area, text, color, crit, args)
end

----------------------------------------------------------------------
-- Daño y sanación (UNIT_COMBAT)
----------------------------------------------------------------------

-- Un valor secreto nunca es nil, pero tampoco se puede comparar: se mira antes
local function isSecret(v)
	return issecretvalue and issecretvalue(v) or false
end

local function missing(v)
	return not isSecret(v) and v == nil
end

-- AbbreviateNumbers acepta cifras secretas (SecretArguments =
-- "AllowedWhenTainted") y siempre devuelve texto, que puede ser secreto:
-- no se mira su valor, solo se pinta
local function amountText(amount)
	if db.abbreviate and AbbreviateNumbers then
		local ok, text = pcall(AbbreviateNumbers, amount)
		if ok then return text end
	end
	return amount
end

-- Solo los ejemplos traen info (las curas reales se pintan en onHealFeed)
function decorate(key, text, info)
	if info and info.srcName and key == "incoming" and db.inSource then
		text = text .. " (" .. info.srcName .. ")"
	end
	return text
end

----------------------------------------------------------------------
-- Pintar un golpe (UNIT_COMBAT)
----------------------------------------------------------------------

-- ¿Se muestra lo que recibe tu objetivo según sea enemigo o aliado?
-- (all / enemy / friend / never). UnitCanAttack no da valores secretos
-- (UnitDocumentation: sin SecretReturns); aun así, si no se puede leer, se
-- muestra.
local function sideAllowed(setting)
	if setting == "never" then return false end
	if setting ~= "enemy" and setting ~= "friend" then return true end
	local enemy = NS(UnitCanAttack("player", "target"))
	if enemy == nil then return true end
	return (enemy and "enemy" or "friend") == setting
end

-- kind: "WOUND", "HEAL", "MISS" o nil (evento secreto: solo la cifra)
-- La cifra va siempre como valor aparte del formato (%s): si llegara
-- secreta, el texto en pantalla la pinta sin que Lua la toque
local function show(key, prefix, kind, amount, school, crit, miss)
	local target = key == "outgoing"
	local physicalKey = target and "cPhysicalOut" or "cPhysicalIn"
	local fmt, color
	if kind == "WOUND" then
		if target and not sideAllowed(db.outDamageWho) then return end
		fmt = prefix .. (target and "" or "-") .. "%s" .. (crit and "!" or "")
		color = schoolColor(school, physicalKey)
	elseif kind == "HEAL" then
		if not db.showHeals or (target and not sideAllowed(db.outHealWho)) then return end
		fmt = prefix .. "+%s" .. (crit and "!" or "")
		color = db.cHeal
	elseif kind == "MISS" then
		if not db.showMisses or not MISS_TEXT[miss] then return end
		M:Emit(key, prefix .. MISS_TEXT[miss], db.cMiss, false)
		return
	else
		if (target and not sideAllowed(db.outDamageWho)) or missing(amount) then return end
		fmt, color, crit = prefix .. "%s", db[physicalKey], false
	end
	if missing(amount) then return end
	M:Emit(key, fmt, color, crit, { n = 1, amountText(amount) })
end

----------------------------------------------------------------------
-- Quién te cura: el aviso del texto de combate de Blizzard
--
-- COMBAT_TEXT_UPDATE solo trae el tipo de mensaje; los datos se piden a
-- C_CombatText.GetCurrentEventInfo(). En las curaciones el primero es el
-- nombre de quien cura y el segundo la cantidad (así lo usa Blizzard en
-- Blizzard_CombatText). Esa función tiene SecretReturns = true
-- (CombatTextDocumentation), así que para un addon los dos llegan secretos:
-- no se leen ni se comparan, se pasan tal cual al texto en pantalla. Por eso
-- no se puede saber la clase de quien cura ni si eres tú.
----------------------------------------------------------------------

local HEAL_TYPES = {   -- tipo -> crítico
	HEAL = false, HEAL_CRIT = true,
	HEAL_ABSORB = false, HEAL_CRIT_ABSORB = true,
	PERIODIC_HEAL = false, PERIODIC_HEAL_CRIT = true,
	PERIODIC_HEAL_ABSORB = false,
}

-- Cuando este aviso ya trae curaciones, UNIT_COMBAT deja de pintar las tuyas
local healFeedWorks = false
local myName

local function combatTextInfo()
	local get = (C_CombatText and C_CombatText.GetCurrentEventInfo) or GetCurrentCombatTextEventInfo
	if not get then return end
	local ok, a, b = pcall(get)
	if ok then return a, b end
end

local function onHealFeed(messageType)
	messageType = NS(messageType)
	local crit = messageType and HEAL_TYPES[messageType]
	if crit == nil then return end
	local healer, amount = combatTextInfo()
	if missing(amount) then return end
	healFeedWorks = true
	if not db.showHeals then return end

	-- Formato + valores: todo lo que viene del juego va como %s
	local fmt, args = "", { n = 0 }
	local function arg(v) args.n = args.n + 1; args[args.n] = v; return "%s" end

	fmt = "+" .. arg(amountText(amount)) .. (crit and "!" or "")

	if db.inSource and not missing(healer) then
		local name = NS(healer)
		if not name then
			-- Secreto (lo normal): se pinta tal cual, sea quien sea
			fmt = fmt .. " (" .. arg(healer) .. ")"
		elseif name ~= myName and not R.IsMyName(name) then
			-- Por si algún día llega legible: sin reino y sin tus propias curas
			fmt = fmt .. " (" .. arg(name:match("^[^%-]+") or name) .. ")"
		end
	end
	M:Emit("incoming", fmt, db.cHeal, crit, args)
end

local healFeedFrame = CreateFrame("Frame")
healFeedFrame:SetScript("OnEvent", function(_, _, messageType)
	local ok, err = pcall(onHealFeed, messageType)
	if not ok and not M.healFeedError then
		M.healFeedError = true
		geterrorhandler()(err)
	end
end)

-- Opción de Blizzard "nombres de sanadores". En Blizzard_CombatText solo
-- decide si Blizzard escribe el nombre (el dato llega igual), pero no está
-- claro si el juego lo manda sin ella: se activa por si acaso. Puede que el
-- juego no deje a los addons cambiarla: se intenta y, si no cambia, se dice
-- qué escribir.
local function ensureHealerNames()
	if M.healerHint then return end
	for _, cvar in ipairs({ "floatingCombatTextFriendlyHealers_v2", "floatingCombatTextFriendlyHealers" }) do
		local value = C_CVar.GetCVar(cvar)
		if value ~= nil then
			if value == "1" then return end
			M.healerHint = true
			pcall(C_CVar.SetCVar, cvar, "1")
			if C_CVar.GetCVar(cvar) ~= "1" then
				R:Print(L["Texto de combate: para ver quién te cura, el juego tiene que dar los nombres de los sanadores, y no deja a los addons activarlo. Escribe:"])
				R:Print("|cffffff00/console " .. cvar .. " 1|r")
			end
			return
		end
	end
end

function M:UpdateHealFeed()
	healFeedFrame:UnregisterAllEvents()
	healFeedWorks = false
	if not self.running or not db.inEnabled or not db.inSource then return end
	myName = R.PlayerFullName()
	-- El aviso informa de una sola unidad; la ventana de Blizzard la fija en
	-- ti, pero solo si está visible
	if C_CombatText and C_CombatText.SetActiveUnit then pcall(C_CombatText.SetActiveUnit, "player") end
	pcall(healFeedFrame.RegisterEvent, healFeedFrame, "COMBAT_TEXT_UPDATE")
	ensureHealerNames()
end

----------------------------------------------------------------------
-- Recuperación: maná (regeneración por espíritu y mp5, pociones,
-- Evocación, Toque de vida…) y vida que no llega como cura (regeneración
-- natural, comer, Canibalizar). Nada de esto trae UNIT_COMBAT: se mira
-- cuánto sube la barra. Lo que sube a la vez se junta en un solo texto.
----------------------------------------------------------------------

local regenFrame = CreateFrame("Frame")
local POWER_INDEX = { MANA = 0, RAGE = 1, ENERGY = 3 }
local lastPower, lastHp = {}, nil
local pendingGain = {}
-- Curas recientes (UNIT_COMBAT): esa subida de vida ya sale como cura
local healedRecently, healSecret, lastHealEvent = 0, false, 0

local function flushGain(token)
	local amount = pendingGain[token]
	pendingGain[token] = nil
	if not amount then return end
	if token == "HEALTH" then
		local secret = healSecret
		amount = amount - healedRecently
		healedRecently, healSecret = 0, false
		if secret then return end
	end
	if amount <= 0 or amount < db.regenMin then return end
	local color, suffix
	if token == "HEALTH" then
		color, suffix = db.cRegen, ""
	else
		color = token == "MANA" and db.cMana or db.cPower
		suffix = " " .. (_G[token] or token)
	end
	M:Emit("incoming", "+%s" .. suffix, color, false, { n = 1, amountText(amount) })
end

local function addGain(token, amount)
	if token == "HEALTH" and not pendingGain.HEALTH and GetTime() - lastHealEvent > 0.5 then
		healedRecently, healSecret = 0, false
	end
	if not pendingGain[token] then
		C_Timer.After(0.4, function() flushGain(token) end)
	end
	pendingGain[token] = (pendingGain[token] or 0) + amount
end

local function onPower(unit, token)
	token = NS(token)
	local index = token and POWER_INDEX[token]
	if not index then return end
	if token == "MANA" and not db.inMana then return end
	if token ~= "MANA" and not db.inPower then return end
	local value = NS(UnitPower("player", index))
	local before = lastPower[token]
	lastPower[token] = value
	if value and before and value > before and not UnitIsDeadOrGhost("player") then
		addGain(token, value - before)
	end
end

local function onRegenHealth()
	local hp = NS(UnitHealth("player"))
	local before = lastHp
	lastHp = hp
	-- Al resucitar tampoco es regeneración
	if hp and before and hp > before and not UnitIsDeadOrGhost("player") and before > 0 then
		addGain("HEALTH", hp - before)
	end
end

regenFrame:SetScript("OnEvent", function(_, event, unit, token)
	if event == "UNIT_HEALTH" then onRegenHealth() else onPower(unit, token) end
end)

function M:UpdateRegen()
	regenFrame:UnregisterAllEvents()
	wipe(lastPower)
	lastHp = nil
	if not self.running or not db.inEnabled then return end
	if db.inMana or db.inPower then
		regenFrame:RegisterUnitEvent("UNIT_POWER_UPDATE", "player")
		for token, index in pairs(POWER_INDEX) do lastPower[token] = NS(UnitPower("player", index)) end
	end
	if db.inRegen then
		regenFrame:RegisterUnitEvent("UNIT_HEALTH", "player")
		lastHp = NS(UnitHealth("player"))
	end
end

local function onUnitCombat(unit, action, flagText, amount, school)
	if unit == "player" and NS(action) == "HEAL" then
		-- Para no repetirla como regeneración
		lastHealEvent = GetTime()
		local a = NS(amount)
		if a then healedRecently = healedRecently + a else healSecret = true end
	end
	if unit == "player" and healFeedWorks and NS(action) == "HEAL" then return end
	local key, prefix = "incoming", ""
	if unit == "target" then
		if NS(UnitIsUnit("target", "player")) then return end
		key = "outgoing"
	elseif unit == "pet" then
		if not db.petIncoming then return end
		prefix = L["[M] "]
	end

	local act = NS(action)
	local crit = NS(flagText) == "CRITICAL"
	if not act then
		show(key, prefix, nil, amount)
	elseif act == "WOUND" or act == "HEAL" then
		show(key, prefix, act, amount, NS(school), crit)
	elseif MISS_TEXT[act] then
		show(key, prefix, "MISS", nil, nil, nil, act)
	end
end

----------------------------------------------------------------------
-- Avisos
----------------------------------------------------------------------

-- Convierte una cadena de Blizzard ("Recibes botín: %s.") en patrón Lua
local function toPattern(fmt)
	if not fmt then return nil end
	local p = fmt:gsub("%%%d?%$?([sd])", "\001%1")
	p = p:gsub("([%(%)%.%+%-%*%?%[%]%^%$%%])", "%%%1")
	p = p:gsub("\001s", "(.+)"):gsub("\001d", "(%%d+)")
	return "^" .. p .. "$"
end

local LOOT_PATTERNS, REP_UP, REP_DOWN, SKILL_UP

local function buildPatterns()
	LOOT_PATTERNS = {}
	for _, fmt in ipairs({ LOOT_ITEM_SELF_MULTIPLE, LOOT_ITEM_PUSHED_SELF_MULTIPLE, LOOT_ITEM_CREATED_SELF_MULTIPLE,
	                       LOOT_ITEM_SELF, LOOT_ITEM_PUSHED_SELF, LOOT_ITEM_CREATED_SELF }) do
		table.insert(LOOT_PATTERNS, toPattern(fmt))
	end
	REP_UP = toPattern(FACTION_STANDING_INCREASED)
	REP_DOWN = toPattern(FACTION_STANDING_DECREASED)
	SKILL_UP = toPattern(SKILL_RANK_UP)
end

local function onLoot(msg)
	msg = NS(msg)
	if not msg then return end
	for _, pattern in ipairs(LOOT_PATTERNS) do
		local link, count = msg:match(pattern)
		if link then
			local icon = C_Item.GetItemIconByID(link)
			local text = (icon and ("|T" .. icon .. ":0|t ") or "") .. link
			if count and tonumber(count) and tonumber(count) > 1 then text = text .. " x" .. count end
			M:Emit("notes", "+" .. text, "ffffff")
			return
		end
	end
end

local function onReputation(msg)
	msg = NS(msg)
	if not msg then return end
	local faction, amount = msg:match(REP_UP or "^$")
	if faction then
		M:Emit("notes", string.format("+%s %s", amount, faction), "8080ff")
		return
	end
	faction, amount = msg:match(REP_DOWN or "^$")
	if faction then M:Emit("notes", string.format("-%s %s", amount, faction), "ff6060") end
end

local function onSkill(msg)
	msg = NS(msg)
	if not msg then return end
	local skill, rank = msg:match(SKILL_UP or "^$")
	if skill then M:Emit("notes", string.format("%s: %s", skill, rank), "4080ff") end
end

local last = {}

local function onXP()
	local xp, max = NS(UnitXP("player")), NS(UnitXPMax("player"))
	if not xp or not max then return end
	if last.xp then
		local gain = xp - last.xp
		if gain < 0 and last.xpMax then gain = last.xpMax - last.xp + xp end
		if gain > 0 then M:Emit("notes", L["+%d XP"]:format(gain), "c080ff") end
	end
	last.xp, last.xpMax = xp, max
end

local function onMoney()
	local money = GetMoney()
	if last.money and money > last.money then
		M:Emit("notes", "+" .. R.Money(money - last.money), "ffd100")
	end
	last.money = money
end

local function onHealth()
	local hp, max = NS(UnitHealth("player")), NS(UnitHealthMax("player"))
	if not hp or not max or max == 0 then return end
	local pct = hp / max
	if pct < 0.35 and not last.lowHealth and not UnitIsDeadOrGhost("player") then
		last.lowHealth = true
		M:Emit("notes", L["¡Vida baja!"], "ff2020", true)
		if db.lowHealthSound then PlaySound(SOUNDKIT.RAID_WARNING, "Master") end
	elseif pct > 0.5 then
		last.lowHealth = nil
	end
end

-- Auras y procs del texto de combate de Blizzard: tipo -> { formato, color, crítico }
local AURA_NOTES = {
	SPELL_AURA_START = { "+%s", "ffff66" },
	SPELL_AURA_START_HARMFUL = { "+%s", "ff8080" },
	SPELL_AURA_END = { "-%s", "999999" },
	SPELL_AURA_END_HARMFUL = { "-%s", "999999" },
	SPELL_ACTIVE = { L["¡%s!"], "ffd100", true },
}

local function onCombatText(messageType)
	local note = AURA_NOTES[NS(messageType) or ""]
	if not note then return end
	-- El nombre del aura llega secreto (SecretReturns): se pasa tal cual al texto
	local data = combatTextInfo()
	if missing(data) then return end
	M:Emit("notes", note[1], note[2], note[3], { n = 1, data })
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local combatFrame = CreateFrame("Frame")   -- jugador y mascota
local targetFrame = CreateFrame("Frame")   -- objetivo
local noteFrame = CreateFrame("Frame")

local noteHandlers = {
	PLAYER_REGEN_DISABLED = function() M:Emit("notes", L["+Combate"], "ff6040") end,
	PLAYER_REGEN_ENABLED = function() M:Emit("notes", L["-Combate"], "60ff60") end,
	PLAYER_XP_UPDATE = onXP,
	PLAYER_MONEY = onMoney,
	CHAT_MSG_LOOT = onLoot,
	CHAT_MSG_COMBAT_FACTION_CHANGE = onReputation,
	CHAT_MSG_SKILL = onSkill,
	PLAYER_LEVEL_UP = function(level) M:Emit("notes", L["¡Nivel %s!"]:format(level), "ffd100", true) end,
	UNIT_HEALTH = function() onHealth() end,
	COMBAT_TEXT_UPDATE = function(messageType) onCombatText(messageType) end,
}

-- Qué opción activa cada evento: solo se escucha lo que está en uso
local NOTE_EVENTS = {
	PLAYER_REGEN_DISABLED = "nCombat",
	PLAYER_REGEN_ENABLED = "nCombat",
	PLAYER_XP_UPDATE = "nXP",
	PLAYER_MONEY = "nMoney",
	CHAT_MSG_LOOT = "nLoot",
	CHAT_MSG_COMBAT_FACTION_CHANGE = "nRep",
	CHAT_MSG_SKILL = "nSkill",
	PLAYER_LEVEL_UP = "nLevel",
	UNIT_HEALTH = "nLowHealth",
	COMBAT_TEXT_UPDATE = "nAuras",
}

-- Opciones que cambian qué eventos hay que escuchar
local NOTE_EVENTS_KEYS = { inEnabled = true, outEnabled = true, noteEnabled = true, petIncoming = true,
	inSource = true, showHeals = true, inMana = true, inRegen = true, inPower = true }
for _, key in pairs(NOTE_EVENTS) do NOTE_EVENTS_KEYS[key] = true end

function M:UpdateEvents()
	combatFrame:UnregisterAllEvents()
	targetFrame:UnregisterAllEvents()
	noteFrame:UnregisterAllEvents()
	self:UpdateHealFeed()
	self:UpdateRegen()
	if not self.running then return end

	if db.inEnabled then
		if db.petIncoming then
			combatFrame:RegisterUnitEvent("UNIT_COMBAT", "player", "pet")
		else
			combatFrame:RegisterUnitEvent("UNIT_COMBAT", "player")
		end
	end
	if db.outEnabled then
		targetFrame:RegisterUnitEvent("UNIT_COMBAT", "target")
	end
	if db.noteEnabled then
		for event, key in pairs(NOTE_EVENTS) do
			if db[key] then
				if event == "UNIT_HEALTH" then
					noteFrame:RegisterUnitEvent(event, "player")
				else
					pcall(noteFrame.RegisterEvent, noteFrame, event)
				end
			end
		end
	end

	-- Puntos de partida para calcular lo ganado
	last.xp, last.xpMax = NS(UnitXP("player")), NS(UnitXPMax("player"))
	last.money = GetMoney()
end

function M:Enable()
	if self.running then return end
	self.running = true
	combatFrame:SetScript("OnEvent", function(_, _, ...) onUnitCombat(...) end)
	targetFrame:SetScript("OnEvent", function(_, _, ...) onUnitCombat(...) end)
	noteFrame:SetScript("OnEvent", function(_, event, ...) noteHandlers[event](...) end)
	self:UpdateEvents()
end

function M:Disable()
	self.running = nil
	combatFrame:UnregisterAllEvents()
	targetFrame:UnregisterAllEvents()
	noteFrame:UnregisterAllEvents()
	self:UpdateHealFeed()
	self:UpdateRegen()
	for _, area in pairs(areas) do
		area.queue = {}
		for _, line in ipairs(area.lines) do line.fs:Hide(); table.insert(area.pool, line.fs) end
		area.lines = {}
	end
end

function M:Test()
	if not db.enabled then
		R:Print(L["Activa primero el texto de combate."])
		return
	end
	local incoming, outgoing, notes = demoLists()
	for key, list in pairs({ incoming = incoming, outgoing = outgoing, notes = notes }) do
		for _, e in ipairs(list) do self:Emit(key, decorate(key, e[1], e[4]), e[2], e[3]) end
	end
	self:Emit("notes", L["¡Vida baja!"], "ff2020", true)
end

function M:OnEnable()
	db = self.db
	-- Antes había una sola animación para todas las zonas
	if db.animation ~= nil then
		if db.animation == "straight" then db.inAnim, db.outAnim = "straight", "straight" end
		db.animation = nil
	end
	-- Antes eran casillas de sí o no
	if db.outDamage ~= nil then
		if db.outDamage == false then db.outDamageWho = "never" end
		db.outDamage = nil
	end
	if db.outHeals ~= nil then
		if db.outHeals == false then db.outHealWho = "never" end
		db.outHeals = nil
	end
	-- Opciones quitadas: necesitaban el registro de combate, cerrado en Forever
	db.outSource, db.outOnlyMine, db.spellIcon = nil, nil, nil
	-- Icono y color de clase de quien te cura: el nombre llega secreto y nunca
	-- se podía saber su clase
	db.classIcon, db.sourceClassColor = nil, nil
	buildPatterns()
	for key in pairs(AREAS) do createArea(key) end
	self:ApplyAreas()
	if db.enabled then self:Enable() end
end

function M:OnOptionChanged(key, value)
	if key == "enabled" then
		if value then self:Enable() else self:Disable() end
	elseif NOTE_EVENTS_KEYS[key] then
		self:UpdateEvents()
	else
		self:ApplyAreas()
	end
end
