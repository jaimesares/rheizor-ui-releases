-- Discos de acción al estilo OPie.
--
-- Mantén pulsada la tecla de un disco: aparece un anillo de iconos alrededor
-- del ratón. Mueve el ratón hacia uno y suelta la tecla para usarlo.
-- Funciona en combate: la elección se hace en código seguro (según el ángulo
-- entre donde pulsaste y donde sueltas) y el anillo que ves es solo visual.
--
-- Los discos se editan en su propia ventana (/rz discos): arrastra hechizos,
-- objetos, macros o monturas a los huecos.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local MAX_SLOTS = 16
local CIRCLE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local QUESTION = 134400
local atan2 = math.atan2 or math.atan

local DISC_COLORS = { { "class", "Color de clase" } }
for _, c in ipairs(R.COLORS) do table.insert(DISC_COLORS, c) end
local SHAPES = { { "circle", "Iconos redondos" }, { "square", "Iconos cuadrados" } }
local LAYOUTS = {
	{ "circle", "Círculo completo" },
	{ "half", "Semicírculo arriba" },
	{ "bottom", "Semicírculo abajo" },
	{ "fan", "Abanico arriba" },
}
-- Arco que ocupa cada distribución y hacia dónde mira su centro (0 = arriba)
local SPAN = { circle = 360, half = 180, bottom = 180, fan = 110 }
local FACING = { circle = 0, half = 0, bottom = 180, fan = 0 }

local M = R:RegisterModule("discs", {
	title = "Discos",
	defaults = {
		enabled = true,
		deadzone = 20,
		scale = 1,
		animate = true,
		backdrop = true,
		labels = true,
		centerName = true,
		pointer = true,
		cooldowns = true,
		usable = true,
	},
	options = {
		{ type = "header", text = "Discos de acción (estilo OPie)" },
		{ type = "toggle", key = "enabled", name = "Activar discos" },
		{ type = "button", name = "Discos", text = "Abrir editor",
		  desc = "Crea discos, asígnales una tecla y arrastra hechizos, objetos, macros o monturas a sus huecos. También con /rz discos.",
		  func = function(mod) mod:OpenEditor() end },

		{ type = "header", text = "Aspecto" },
		{ type = "toggle", key = "backdrop", name = "Fondo oscuro detrás del disco" },
		{ type = "toggle", key = "labels", name = "Nombres bajo los iconos" },
		{ type = "toggle", key = "centerName", name = "Nombre de lo elegido en el centro" },
		{ type = "toggle", key = "pointer", name = "Flecha hacia lo elegido" },
		{ type = "toggle", key = "cooldowns", name = "Tiempos de reutilización" },
		{ type = "toggle", key = "usable", name = "Oscurecer lo que no se puede usar",
		  desc = "Azul si te falta maná, gris si no se puede usar o no te quedan unidades." },
		{ type = "toggle", key = "animate", name = "Animación al abrir y cerrar" },

		{ type = "header", text = "Tamaño" },
		{ type = "slider", key = "scale", name = "Escala", min = 0.5, max = 2, step = 0.05,
		  desc = "Tamaño de todos los discos. El radio y el tamaño de los iconos de cada disco se cambian en el editor." },

		{ type = "header", text = "Comportamiento" },
		{ type = "slider", key = "deadzone", name = "Zona muerta central", min = 8, max = 60, step = 1, format = R.fmt.int,
		  desc = "Si sueltas la tecla sin haber alejado el ratón más que esto del centro, no se usa nada." },
	},
})

local db

----------------------------------------------------------------------
-- Dónde se guarda cada disco
----------------------------------------------------------------------
-- Compartidos: en el perfil (db.discs), los ven todos los personajes que
-- usan ese perfil. Solo de un personaje: en RheizorDB.charDiscs[personaje],
-- fuera de los perfiles (siguen con él aunque cambie de perfil).
-- «discs» es la lista de todos, primero los compartidos; su posición es el
-- número del botón seguro de cada uno.

local SCOPES = { { "profile", "Todos los personajes del perfil" }, { "char", "Solo este personaje" } }

local discs = {}

local function charDiscs()
	local store = R.store
	if type(store.charDiscs) ~= "table" then store.charDiscs = {} end
	local key = R.charKey or "?"
	if type(store.charDiscs[key]) ~= "table" then store.charDiscs[key] = {} end
	return store.charDiscs[key]
end

-- Cada disco lleva un id fijo para poder enlazarlo desde otro disco
local function ensureId(d)
	if not d.id then d.id = string.format("%x%04x", time(), math.random(0, 0xffff)) end
end

local function rebuildList()
	wipe(discs)
	for _, d in ipairs(db.discs) do discs[#discs + 1] = d end
	for _, d in ipairs(charDiscs()) do discs[#discs + 1] = d end
	for _, d in ipairs(discs) do ensureId(d) end
end

local function findDisc(id)
	if not id then return nil end
	for _, d in ipairs(discs) do
		if d.id == id then return d end
	end
end

-- La tabla donde está guardado un disco, y su posición en ella
local function ownerOf(d)
	for _, list in ipairs({ db.discs, charDiscs() }) do
		for i, other in ipairs(list) do
			if other == d then return list, i end
		end
	end
end

local function isCharDisc(d)
	return d ~= nil and ownerOf(d) == charDiscs()
end

local function indexOf(d)
	for i, other in ipairs(discs) do
		if other == d then return i end
	end
end

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local function newDisc(name)
	return {
		name = name or L["Disco"],
		key = nil,
		color = "class",
		shape = "circle",
		layout = "circle",
		radius = 90,
		size = 38,
		slots = {},
	}
end

local function discRGB(d)
	if d.color == "class" then
		local c = RAID_CLASS_COLORS[R:PlayerClass()]
		if c then return c.r, c.g, c.b end
	end
	return R.HexToRGB(d.color ~= "class" and d.color or "33ccff")
end

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return (GetSpellInfo(id))
end

local function slotName(s)
	if s.kind == "spell" or s.kind == "mount" then
		return spellName(s.id) or s.name or L["Hechizo %s"]:format(s.id)
	elseif s.kind == "item" then
		local name = C_Item and C_Item.GetItemNameByID and C_Item.GetItemNameByID(s.id)
		return name or s.name or L["Objeto %s"]:format(s.id)
	elseif s.kind == "disc" then
		local target = findDisc(s.ref)
		return target and (target.name .. " »") or L["Disco borrado"]
	end
	return s.name or s.text or "?"
end

local function slotIcon(s)
	if s.kind == "spell" or s.kind == "mount" then
		return (C_Spell and C_Spell.GetSpellTexture and C_Spell.GetSpellTexture(s.id)) or QUESTION
	elseif s.kind == "item" then
		return (C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(s.id)) or QUESTION
	elseif s.kind == "disc" then
		-- El elegido en el editor; si no, el del primer hueco del disco enlazado
		if s.icon then return s.icon end
		local target = findDisc(s.ref)
		for _, child in ipairs(target and target.slots or {}) do
			if child.kind ~= "disc" then return slotIcon(child) end
		end
		return QUESTION
	end
	return s.icon or QUESTION
end

-- Ángulo de cada hueco en grados (0 = arriba, en el sentido de las agujas del reloj)
local function sliceAngles(layout, n)
	local list = {}
	local span, facing = SPAN[layout] or 360, FACING[layout] or 0
	if span >= 360 then
		for i = 1, n do list[i] = (i - 1) * 360 / n end
	elseif n == 1 then
		list[1] = facing
	else
		local first = facing - span / 2
		for i = 1, n do list[i] = first + (i - 1) * span / (n - 1) end
	end
	return list
end

-- Distancia angular máxima para elegir un hueco (en arcos, no vale apuntar al lado vacío)
local function maxDiff(layout, n)
	local span = SPAN[layout] or 360
	if span >= 360 or n == 0 then return 180 end
	local limit = math.max(n > 1 and span / (n - 1) or 45, 35)
	-- Por encima de 90° el código seguro no limita: se iguala aquí para que coincidan
	return limit >= 90 and 180 or limit
end

local function nearest(ang, angles, limit)
	local best, bestDiff
	for i, a in ipairs(angles) do
		local diff = math.abs(ang - a) % 360
		if diff > 180 then diff = 360 - diff end
		if not bestDiff or diff < bestDiff then best, bestDiff = i, diff end
	end
	if best and bestDiff <= limit then return best end
end

-- Huecos que enlazan a otro disco: los huecos de ese disco salen en arco por
-- fuera del enlace, dentro de su sector, para que elegir por ángulo (lo único
-- que sabe el código seguro al soltar) coincida con lo que se ve.
-- Solo un nivel: lo que sea a su vez un enlace dentro del disco enlazado no sale.
local function linkedSlots(slot)
	local target = slot.kind == "disc" and findDisc(slot.ref)
	if not target then return nil end
	local list = {}
	for _, s in ipairs(target.slots) do
		if s.kind ~= "disc" then list[#list + 1] = s end
	end
	return list, target
end

-- Anchura en grados del sector de cada hueco
local function sectorWidth(layout, n)
	local span = SPAN[layout] or 360
	if span >= 360 then return 360 / math.max(n, 1) end
	if n <= 1 then return math.min(span, 90) end
	return span / (n - 1)
end

-- Ángulos del arco de hijos, su radio, la distancia desde la que se elige un
-- hijo (más cerca se queda en el enlace) y el tamaño de sus iconos
local function subLayout(d, angle, count)
	local span = math.min(sectorWidth(d.layout, #d.slots) * 0.85, 140)
	local size = d.size * 0.85
	local angles = {}
	if count == 1 then
		angles[1] = angle
	else
		for k = 1, count do angles[k] = angle - span / 2 + (k - 1) * span / (count - 1) end
	end
	-- Radio suficiente para que quepan en el arco (con tope: si son muchos se solapan)
	local needed = count > 1 and (count - 1) * (size + 6) / math.rad(span) or 0
	local radius = math.min(math.max(d.radius + d.size * 1.4, needed), d.radius + d.size * 6)
	return angles, radius, d.radius + d.size * 0.7, size
end

-- Qué hay bajo el ratón: el hueco y, si es un enlace y has pasado su umbral,
-- el hijo. Es lo mismo que calcula PRE_CLICK al soltar la tecla.
local function pickSlice(ctx, dx, dy)
	local dist2 = dx * dx + dy * dy
	if dist2 < db.deadzone * db.deadzone then return nil end
	local ang = math.deg(atan2(dx, dy))
	local best = nearest(ang, ctx.angles, ctx.limit)
	if not best then return nil, nil, ang end
	local sub = ctx.subs[best]
	local thr = sub and sub.thr * db.scale
	if thr and dist2 >= thr * thr then
		return best, nearest(ang, sub.angles, 180), ang
	end
	return best, nil, ang
end

----------------------------------------------------------------------
-- Parte segura: un botón por disco que recibe la tecla
----------------------------------------------------------------------

local header, screen
local openers = {}

-- Al pulsar se guarda dónde está el ratón; al soltar se calcula el ángulo y
-- se devuelve el "botón" s<N>, que usa los atributos *type-s<N>, *spell-s<N>…
local PRE_CLICK = [=[
	local screen = owner:GetFrameRef("screen")
	local x, y = screen:GetMousePosition()
	if down then
		self:SetAttribute("ox", x)
		self:SetAttribute("oy", y)
		return false
	end
	local ox, oy = self:GetAttribute("ox"), self:GetAttribute("oy")
	self:SetAttribute("ox", nil)
	if not (x and y and ox and oy) then return false end
	local dx = (x - ox) * screen:GetWidth()
	local dy = (y - oy) * screen:GetHeight()
	local dist2 = dx * dx + dy * dy
	local dead = self:GetAttribute("dead") or 20
	if dist2 < dead * dead then return false end
	-- El hueco más cercano en ángulo es el de mayor producto escalar con su dirección
	local best, bestDot
	for i = 1, self:GetAttribute("count") or 0 do
		local dot = dx * (self:GetAttribute("sx" .. i) or 0) + dy * (self:GetAttribute("sy" .. i) or 0)
		if not bestDot or dot > bestDot then best, bestDot = i, dot end
	end
	if not best then return false end
	local minCos = self:GetAttribute("mincos") or -1
	if minCos > 0 and (bestDot < 0 or bestDot * bestDot < minCos * minCos * dist2) then return false end
	-- Enlace a otro disco: cerca no hace nada; más lejos, el hijo más cercano en ángulo
	local sub = self:GetAttribute("sub" .. best) or 0
	if sub > 0 then
		local thr = self:GetAttribute("thr" .. best) or 0
		if dist2 < thr * thr then return false end
		local child, childDot
		for k = 1, sub do
			local dot = dx * (self:GetAttribute("sx" .. best .. "_" .. k) or 0) + dy * (self:GetAttribute("sy" .. best .. "_" .. k) or 0)
			if not childDot or dot > childDot then child, childDot = k, dot end
		end
		return "s" .. best .. "_" .. child
	end
	return "s" .. best
]=]

local function createSecure()
	header = CreateFrame("Frame", nil, UIParent, "SecureHandlerBaseTemplate")
	screen = CreateFrame("Frame", nil, UIParent, "SecureFrameTemplate")
	screen:SetAllPoints(UIParent)
	header:SetFrameRef("screen", screen)
end

local function getOpener(i)
	if openers[i] then return openers[i] end
	local b = CreateFrame("Button", "RheizorDisc" .. i, UIParent, "SecureActionButtonTemplate")
	b:SetSize(1, 1)
	b:SetPoint("TOPLEFT", UIParent, "TOPLEFT", -10, 10)
	b:EnableMouse(false)
	b:RegisterForClicks("AnyUp", "AnyDown")
	b:SetAttribute("useOnKeyDown", false)
	header:WrapScript(b, "OnClick", PRE_CLICK)
	b:HookScript("PreClick", function(_, _, down) M:OnKey(i, down) end)
	-- Atributos puestos en la última aplicación, para borrarlos en la siguiente
	b.rzAttrs = {}
	openers[i] = b
	return b
end

local function setAttr(b, name, value)
	b.rzAttrs[name] = true
	b:SetAttribute(name, value)
end

local function setAction(b, suffix, s)
	if s.kind == "spell" or s.kind == "mount" then
		setAttr(b, "*type" .. suffix, "spell")
		-- Por nombre: así se usa siempre el rango más alto que conozcas
		setAttr(b, "*spell" .. suffix, spellName(s.id) or s.id)
	elseif s.kind == "item" then
		setAttr(b, "*type" .. suffix, "item")
		setAttr(b, "*item" .. suffix, "item:" .. s.id)
	elseif s.kind == "macro" then
		setAttr(b, "*type" .. suffix, "macro")
		setAttr(b, "*macrotext" .. suffix, s.text)
	end
end

function M:ApplySecure()
	R:RunOutOfCombat(function() self:DoApplySecure() end)
end

function M:DoApplySecure()
	if not header then createSecure() end
	for _, b in pairs(openers) do
		ClearOverrideBindings(b)
		for name in pairs(b.rzAttrs) do b:SetAttribute(name, nil) end
		wipe(b.rzAttrs)
		b:SetAttribute("count", 0)
	end
	if not db.enabled then return end

	for i, d in ipairs(discs) do
		local b = getOpener(i)
		local angles = sliceAngles(d.layout, #d.slots)
		for j, s in ipairs(d.slots) do
			setAction(b, "-s" .. j, s)
			local a = math.rad(angles[j])
			setAttr(b, "sx" .. j, math.sin(a))
			setAttr(b, "sy" .. j, math.cos(a))
			-- Hijos del enlace: botones s<j>_<k>; el umbral va en píxeles de pantalla
			local children = linkedSlots(s)
			if children and #children > 0 then
				local subAngles, _, thr = subLayout(d, angles[j], #children)
				for k, c in ipairs(children) do
					setAction(b, "-s" .. j .. "_" .. k, c)
					local ca = math.rad(subAngles[k])
					setAttr(b, "sx" .. j .. "_" .. k, math.sin(ca))
					setAttr(b, "sy" .. j .. "_" .. k, math.cos(ca))
				end
				setAttr(b, "sub" .. j, #children)
				setAttr(b, "thr" .. j, thr * db.scale)
			end
		end
		b:SetAttribute("count", #d.slots)
		b:SetAttribute("dead", db.deadzone)
		b:SetAttribute("mincos", math.cos(math.rad(maxDiff(d.layout, #d.slots))))
		if d.key and d.key ~= "" then
			SetOverrideBindingClick(b, true, d.key, b:GetName(), "LeftButton")
		end
	end
end

----------------------------------------------------------------------
-- Parte visual: el anillo
----------------------------------------------------------------------

local ring
local slices, subSlices = {}, {}
-- Disco abierto: { disc, x, y, t, angles, limit, subs, key, shown, extent, closing }
-- subs[j] = { slots, disc, angles, radius, thr, size } para los huecos que enlazan a otro disco
local open

local function setShape(s, shape)
	local round = shape == "circle"
	if round ~= s.round then
		if round then
			s.icon:AddMaskTexture(s.iconMask)
			s.border:AddMaskTexture(s.borderMask)
		else
			s.icon:RemoveMaskTexture(s.iconMask)
			s.border:RemoveMaskTexture(s.borderMask)
		end
		s.round = round
	end
	s.icon:SetTexCoord(round and 0 or 0.08, round and 1 or 0.92, round and 0 or 0.08, round and 1 or 0.92)
	s.cd:SetSwipeTexture(round and CIRCLE or WHITE)
	if s.cd.SetUseCircularEdge then s.cd:SetUseCircularEdge(round) end
end

-- pool: slices (primer nivel) o subSlices (arco del enlace)
local function getSlice(i, pool)
	pool = pool or slices
	if pool[i] then return pool[i] end
	local s = CreateFrame("Frame", nil, ring)

	s.border = s:CreateTexture(nil, "BACKGROUND")
	s.border:SetTexture(WHITE)
	s.border:SetPoint("TOPLEFT", -2, 2)
	s.border:SetPoint("BOTTOMRIGHT", 2, -2)
	s.borderMask = s:CreateMaskTexture()
	s.borderMask:SetTexture(CIRCLE, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	s.borderMask:SetAllPoints(s.border)

	s.icon = s:CreateTexture(nil, "ARTWORK")
	s.icon:SetAllPoints()
	s.iconMask = s:CreateMaskTexture()
	s.iconMask:SetTexture(CIRCLE, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	s.iconMask:SetAllPoints(s.icon)

	s.cd = CreateFrame("Cooldown", nil, s, "CooldownFrameTemplate")
	s.cd:SetAllPoints(s.icon)
	s.cd:SetDrawEdge(false)
	s.cd:SetSwipeColor(0, 0, 0, 0.7)

	s.over = CreateFrame("Frame", nil, s)
	s.over:SetAllPoints()
	s.over:SetFrameLevel(s.cd:GetFrameLevel() + 2)
	s.count = s.over:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
	s.count:SetPoint("BOTTOMRIGHT", -1, 2)
	s.label = s.over:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	s.label:SetPoint("TOP", s, "BOTTOM", 0, -3)

	pool[i] = s
	return s
end

-- Tiempo de reutilización de un hechizo. En combate el inicio y la duración
-- que da C_Spell.GetSpellCooldown son secretos y SetCooldown no los acepta
-- desde un addon; el "objeto de duración" sí se puede pasar tal cual al
-- marco (es lo que hace la interfaz de Blizzard con las auras).
local function spellCooldown(cd, id)
	if C_Spell.GetSpellCooldownDuration and cd.SetCooldownFromDurationObject then
		local ok, duration = pcall(C_Spell.GetSpellCooldownDuration, id)
		if ok and duration and pcall(cd.SetCooldownFromDurationObject, cd, duration, true) then return end
	end
	if not C_Spell.GetSpellCooldown then return end
	local ok, info = pcall(C_Spell.GetSpellCooldown, id)
	if not ok or not info then return end
	-- isActive nunca es secreto; el inicio y la duración pueden serlo
	if not info.isActive then
		cd:Clear()
	elseif NS(info.startTime) and NS(info.duration) then
		pcall(cd.SetCooldown, cd, info.startTime, info.duration, NS(info.modRate) or 1)
	end
end

local function refreshSlice(s, slot)
	local usable, noMana, count = true, false, nil
	if slot.kind == "spell" or slot.kind == "mount" then
		if C_Spell and C_Spell.IsSpellUsable then
			local ok, u, nm = pcall(C_Spell.IsSpellUsable, slot.id)
			if ok then usable, noMana = NS(u), NS(nm) end
			if usable == nil then usable = true end
		end
		if db.cooldowns and C_Spell then spellCooldown(s.cd, slot.id) end
	elseif slot.kind == "item" then
		count = C_Item and C_Item.GetItemCount and NS(C_Item.GetItemCount(slot.id))
		if count == 0 then usable = false end
		if db.cooldowns and C_Container and C_Container.GetItemCooldown then
			local ok, start, duration = pcall(C_Container.GetItemCooldown, slot.id)
			start, duration = NS(start), NS(duration)
			if ok and start and duration then
				if start > 0 and duration > 0 then
					pcall(s.cd.SetCooldown, s.cd, start, duration)
				else
					s.cd:Clear()
				end
			end
		end
	end
	if not db.cooldowns then s.cd:Clear() end

	s.count:SetText(count and count > 1 and count or "")
	if db.usable and noMana then
		s.icon:SetDesaturated(false)
		s.icon:SetVertexColor(0.35, 0.45, 1)
	elseif db.usable and not usable then
		s.icon:SetDesaturated(true)
		s.icon:SetVertexColor(0.6, 0.6, 0.6)
	else
		s.icon:SetDesaturated(false)
		s.icon:SetVertexColor(1, 1, 1)
	end
end

local function styleSlice(s, chosen, dim, r, g, b)
	local scale = chosen and 1.25 or 1
	s:SetScale(scale)
	s:ClearAllPoints()
	s:SetPoint("CENTER", ring, "CENTER", s.ox / scale, s.oy / scale)
	s:SetAlpha(dim and 0.7 or 1)
	if chosen then
		s.border:SetVertexColor(math.min(r + 0.4, 1), math.min(g + 0.4, 1), math.min(b + 0.4, 1), 1)
	else
		s.border:SetVertexColor(r * 0.8, g * 0.8, b * 0.8, 0.9)
	end
end

-- Muestra el arco de hijos del enlace j (o ninguno)
local function showSub(j)
	if open.shown == j then return end
	open.shown = j
	local sub = j and open.subs[j]
	local n = sub and #sub.slots or 0
	for k = 1, n do
		local s = getSlice(k, subSlices)
		local slot = sub.slots[k]
		setShape(s, open.disc.shape)
		s:SetSize(sub.size, sub.size)
		local a = math.rad(sub.angles[k])
		s.ox, s.oy = math.sin(a) * sub.radius, math.cos(a) * sub.radius
		s.icon:SetTexture(slotIcon(slot))
		s.label:SetText(db.labels and slotName(slot) or "")
		s.label:SetWidth(sub.size * 2.2)
		s.label:SetWordWrap(false)
		s.cd:Clear()
		refreshSlice(s, slot)
		s:Show()
	end
	for k = n + 1, #subSlices do subSlices[k]:Hide() end
	-- El fondo crece para abarcar el arco mientras se ve
	local extent = open.extent
	if sub then extent = math.max(extent, (sub.radius + sub.size * 0.8 + (db.labels and 14 or 0)) * 2) end
	ring.bg:SetSize(extent, extent)
end

local function highlight(sel, child)
	local d = open.disc
	local r, g, b = discRGB(d)
	for i in ipairs(d.slots) do
		styleSlice(slices[i], i == sel, sel and i ~= sel, r, g, b)
	end
	local sub = sel and open.subs[sel]
	showSub(sub and sel or nil)
	if sub then
		local sr, sg, sb = discRGB(sub.disc)
		for k in ipairs(sub.slots) do
			styleSlice(subSlices[k], k == child, child and k ~= child, sr, sg, sb)
		end
	end
	local name
	if child then
		name = slotName(sub.slots[child])
	elseif sel then
		name = slotName(d.slots[sel])
	end
	ring.name:SetText(db.centerName and name or "")
end

local function placeRing(scale)
	ring:SetScale(scale)
	ring:ClearAllPoints()
	ring:SetPoint("CENTER", UIParent, "BOTTOMLEFT", open.x / scale, open.y / scale)
end

local function cursor()
	local scale = UIParent:GetEffectiveScale()
	local x, y = GetCursorPosition()
	return x / scale, y / scale
end

local refreshTimer = 0
local function onRingUpdate(_, elapsed)
	if not open then ring:Hide() return end
	local now = GetTime()

	if open.closing then
		local p = db.animate and (now - open.closing) / 0.15 or 1
		if p >= 1 then
			ring:Hide()
			open = nil
			return
		end
		ring:SetAlpha(1 - p)
		return
	end

	if db.animate then
		local p = math.min((now - open.t) / 0.12, 1)
		placeRing(db.scale * (0.7 + 0.3 * p))
		ring:SetAlpha(p)
	end

	local x, y = cursor()
	local sel, child, ang = pickSlice(open, x - open.x, y - open.y)
	local key = sel and (sel * 100 + (child or 0)) or false
	if key ~= open.key then
		open.key = key
		highlight(sel, child)
	end
	if db.pointer and ang and (x - open.x) ^ 2 + (y - open.y) ^ 2 >= db.deadzone ^ 2 then
		ring.arrow:SetRotation(-math.rad(ang))
		ring.arrow:Show()
	else
		ring.arrow:Hide()
	end

	refreshTimer = refreshTimer - elapsed
	if refreshTimer <= 0 then
		refreshTimer = 0.2
		for i, slot in ipairs(open.disc.slots) do refreshSlice(slices[i], slot) end
		local sub = open.shown and open.subs[open.shown]
		if sub then
			for k, slot in ipairs(sub.slots) do refreshSlice(subSlices[k], slot) end
		end
	end
end

local function createRing()
	ring = CreateFrame("Frame", "RheizorDiscRing", UIParent)
	ring:SetFrameStrata("DIALOG")
	ring:SetSize(10, 10)
	ring:Hide()

	ring.bg = ring:CreateTexture(nil, "BACKGROUND")
	ring.bg:SetPoint("CENTER")
	ring.bg:SetTexture(CIRCLE)
	ring.bg:SetVertexColor(0, 0, 0, 0.45)

	ring.dot = ring:CreateTexture(nil, "ARTWORK")
	ring.dot:SetTexture(CIRCLE)
	ring.dot:SetSize(12, 12)
	ring.dot:SetPoint("CENTER")

	ring.arrow = ring:CreateTexture(nil, "OVERLAY")
	ring.arrow:SetTexture("Interface\\Minimap\\MinimapArrow")
	ring.arrow:SetSize(30, 30)
	ring.arrow:SetPoint("CENTER")

	ring.title = ring:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	ring.title:SetPoint("BOTTOM", ring, "CENTER", 0, 12)
	ring.name = ring:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
	ring.name:SetPoint("TOP", ring, "CENTER", 0, -12)

	ring:SetScript("OnUpdate", onRingUpdate)
end

function M:ShowRing(d, x, y)
	if not ring then createRing() end
	local n = #d.slots
	open = { disc = d, x = x, y = y, t = GetTime(), angles = sliceAngles(d.layout, n), limit = maxDiff(d.layout, n), subs = {} }

	local r, g, b = discRGB(d)
	local size = d.size
	for j, slot in ipairs(d.slots) do
		local children, target = linkedSlots(slot)
		if children and #children > 0 then
			local angles, radius, thr, subSize = subLayout(d, open.angles[j], #children)
			open.subs[j] = { slots = children, disc = target, angles = angles, radius = radius, thr = thr, size = subSize }
		end
	end
	for _, s in ipairs(subSlices) do s:Hide() end
	for i, slot in ipairs(d.slots) do
		local s = getSlice(i)
		setShape(s, d.shape)
		s:SetSize(size, size)
		local a = math.rad(open.angles[i])
		s.ox, s.oy = math.sin(a) * d.radius, math.cos(a) * d.radius
		s.icon:SetTexture(slotIcon(slot))
		s.label:SetText(db.labels and slotName(slot) or "")
		s.label:SetWidth(size * 2.2)
		s.label:SetWordWrap(false)
		s.cd:Clear()
		refreshSlice(s, slot)
		s:Show()
	end
	for i = n + 1, #slices do slices[i]:Hide() end

	open.extent = (d.radius + size * 0.8 + (db.labels and 14 or 0)) * 2
	ring.bg:SetSize(open.extent, open.extent)
	ring.bg:SetShown(db.backdrop)
	ring.dot:SetVertexColor(r, g, b, 0.9)
	ring.arrow:SetVertexColor(r, g, b, 1)
	ring.arrow:Hide()
	ring.title:SetText(d.name)
	ring.title:SetTextColor(r, g, b)
	open.key = false
	highlight(nil)
	if n == 0 then ring.name:SetText(L["|cff888888Disco vacío: /rz discos|r"]) end
	placeRing(db.animate and db.scale * 0.7 or db.scale)
	ring:SetAlpha(db.animate and 0 or 1)
	refreshTimer = 0.2
	ring:Show()
end

function M:ReleaseRing(x, y)
	if not open or open.closing then return end
	local sel, child = pickSlice(open, x - open.x, y - open.y)
	local key = sel and (sel * 100 + (child or 0)) or false
	if key ~= open.key then highlight(sel, child) end
	open.closing = GetTime()
end

function M:OnKey(index, down)
	local d = discs[index]
	if not d then return end
	local x, y = cursor()
	if down then
		self:ShowRing(d, x, y)
	else
		self:ReleaseRing(x, y)
	end
end

----------------------------------------------------------------------
-- Editor
----------------------------------------------------------------------

local editor
local selDisc, selSlot = 1, nil

local function button(parent, text, width, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width, 22)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	return b
end

local function label(parent, text, template)
	local fs = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormal")
	fs:SetText(text)
	return fs
end

-- Desplegable moderno; si no existe, botón que va cambiando entre opciones
local function choice(parent, width, values, get, set)
	local ok, dd = pcall(CreateFrame, "DropdownButton", nil, parent, "WowStyle1DropdownTemplate")
	if ok and dd and dd.SetupMenu then
		dd:SetWidth(width)
		dd:SetupMenu(function(_, root)
			for _, v in ipairs(values) do
				root:CreateRadio(L[v[2]], function() return get() == v[1] end, function() set(v[1]) end, v[1])
			end
		end)
		dd.Refresh = function(self) self:GenerateMenu() end
		return dd
	end
	local b = button(parent, "", width)
	local function text()
		for _, v in ipairs(values) do if v[1] == get() then return L[v[2]] end end
		return "?"
	end
	b:SetScript("OnClick", function(self)
		local idx = 1
		for i, v in ipairs(values) do if v[1] == get() then idx = i end end
		set(values[idx % #values + 1][1])
		self:SetText(text())
	end)
	b.Refresh = function(self) self:SetText(text()) end
	return b
end

-- Valor numérico con botones - y +
local function stepper(parent, text, min, max, step, get, set)
	local f = CreateFrame("Frame", nil, parent)
	f:SetSize(220, 22)
	f.label = label(f, text, "GameFontHighlight")
	f.label:SetPoint("LEFT")
	f.value = label(f, "", "GameFontNormal")
	f.value:SetPoint("RIGHT", -30, 0)
	f.value:SetWidth(40)
	local minus = button(f, "-", 26, function() set(math.max(get() - step, min)); f:Refresh() end)
	minus:SetPoint("RIGHT", f.value, "LEFT", -4, 0)
	local plus = button(f, "+", 26, function() set(math.min(get() + step, max)); f:Refresh() end)
	plus:SetPoint("LEFT", f.value, "RIGHT", 4, 0)
	function f:Refresh() self.value:SetText(get()) end
	return f
end

local function currentDisc() return discs[selDisc] end

-- Convierte lo que haya en el cursor en un hueco
local function slotFromCursor()
	local kind, a1, a2, a3, a4 = GetCursorInfo()
	if kind == "spell" then
		-- "spell", índice del libro, tipo de libro, spellID, spellID base
		local id = type(a3) == "number" and a3 or a4
		if id then return { kind = "spell", id = id } end
	elseif kind == "item" then
		return { kind = "item", id = a1 }
	elseif kind == "macro" then
		local name, icon, body = GetMacroInfo(a1)
		if body then return { kind = "macro", name = name, icon = icon, text = body } end
	elseif kind == "mount" then
		local spellID
		if C_MountJournal and C_MountJournal.GetMountInfoByID then
			spellID = select(2, C_MountJournal.GetMountInfoByID(a1))
		end
		if not spellID and C_MountJournal and C_MountJournal.GetDisplayedMountInfo then
			spellID = select(2, C_MountJournal.GetDisplayedMountInfo(a1))
		end
		if spellID then return { kind = "mount", id = spellID } end
	end
	return nil
end

-- Texto escrito: "/..." es una macro; si no, un hechizo u objeto por nombre
local function slotFromText(text)
	text = strtrim(text or "")
	if text == "" then return nil end
	if text:sub(1, 1) == "/" then
		text = text:gsub("\\n", "\n")
		local icon = QUESTION
		local spell = text:match("/cast%s+[^%a]*([^\n;]+)") or text:match("/lanzar%s+[^%a]*([^\n;]+)")
		if spell and C_Spell and C_Spell.GetSpellTexture then
			icon = C_Spell.GetSpellTexture(strtrim(spell)) or icon
		end
		return { kind = "macro", text = text, name = text:match("^/%S+%s+([^\n]+)") or text, icon = icon }
	end
	local info = C_Spell and C_Spell.GetSpellInfo and C_Spell.GetSpellInfo(text)
	if info and info.spellID then return { kind = "spell", id = info.spellID } end
	local itemID = C_Item and C_Item.GetItemInfoInstant and C_Item.GetItemInfoInstant(text)
	if itemID then return { kind = "item", id = itemID } end
	return nil
end

function M:Changed()
	rebuildList()
	self:ApplySecure()
	if editor and editor:IsShown() then editor:Refresh() end
end

local function assignSlot(index, slot)
	local d = currentDisc()
	if not d or not slot then return end
	if index > #d.slots then
		if #d.slots >= MAX_SLOTS then return end
		index = #d.slots + 1
	end
	d.slots[index] = slot
	selSlot = index
	M:Changed()
end

local KEY_IGNORE = { LSHIFT = true, RSHIFT = true, LCTRL = true, RCTRL = true, LALT = true, RALT = true, UNKNOWN = true }
local MOUSE_KEYS = { MiddleButton = "BUTTON3", Button4 = "BUTTON4", Button5 = "BUTTON5" }

local function withModifiers(key)
	return (IsAltKeyDown() and "ALT-" or "") .. (IsControlKeyDown() and "CTRL-" or "")
		.. (IsShiftKeyDown() and "SHIFT-" or "") .. key
end

----------------------------------------------------------------------
-- Selector de icono para los huecos que enlazan a otro disco (y macros):
-- los iconos del disco enlazado, lo que arrastres encima y todos los
-- iconos de macro del juego, por páginas
----------------------------------------------------------------------

local picker
local PICK_COLS, PICK_ROWS, PICK_SIZE = 10, 7, 32
local allIcons

local function iconList()
	if allIcons then return allIcons end
	local raw = {}
	pcall(function()
		if GetLooseMacroIcons then GetLooseMacroIcons(raw) end
		if GetLooseMacroItemIcons then GetLooseMacroItemIcons(raw) end
		GetMacroIcons(raw)
		GetMacroItemIcons(raw)
	end)
	-- Vienen como id de archivo o como nombre dentro de Interface\Icons
	allIcons = {}
	for _, v in ipairs(raw) do
		allIcons[#allIcons + 1] = tonumber(v) or ("Interface\\Icons\\" .. v)
	end
	return allIcons
end

local function pickIcon(icon)
	local slot = picker.slot
	if not slot then return end
	slot.icon = icon
	-- Una macro necesita icono: «por defecto» es la interrogación
	if slot.kind == "macro" and not icon then slot.icon = QUESTION end
	picker:Hide()
	M:Changed()
end

local function iconButton(parent)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(PICK_SIZE, PICK_SIZE)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetAllPoints()
	b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
	b:SetScript("OnClick", function(self) pickIcon(self.value) end)
	return b
end

local function createPicker()
	picker = CreateFrame("Frame", "RheizorDiscIconPicker", editor, "BackdropTemplate")
	local width = PICK_COLS * (PICK_SIZE + 4) + 24
	picker:SetSize(width, 150 + PICK_ROWS * (PICK_SIZE + 4))
	picker:SetPoint("TOPLEFT", editor, "TOPRIGHT", 6, 0)
	picker:SetFrameStrata("FULLSCREEN_DIALOG")
	picker:SetFrameLevel(editor:GetFrameLevel() + 20)
	picker:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	picker:SetBackdropColor(0.05, 0.05, 0.07, 0.97)
	picker:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	picker:EnableMouse(true)
	picker:SetMovable(true)
	picker:SetClampedToScreen(true)
	picker:RegisterForDrag("LeftButton")
	picker:SetScript("OnDragStart", picker.StartMoving)
	picker:SetScript("OnDragStop", picker.StopMovingOrSizing)

	local title = label(picker, L["Icono del hueco"], "GameFontNormal")
	title:SetPoint("TOPLEFT", 12, -10)
	local close = CreateFrame("Button", nil, picker, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)

	-- Iconos del disco enlazado
	picker.fromDisc = label(picker, L["Del disco vinculado"], "GameFontHighlightSmall")
	picker.fromDisc:SetPoint("TOPLEFT", 12, -34)
	picker.discIcons = {}
	for i = 1, PICK_COLS do
		local b = iconButton(picker)
		b:SetPoint("TOPLEFT", 12 + (i - 1) * (PICK_SIZE + 4), -48)
		picker.discIcons[i] = b
	end

	-- Arrastrar algo encima: se usa su icono
	local drop = CreateFrame("Button", nil, picker, "BackdropTemplate")
	drop:SetSize(width - 24, 24)
	drop:SetPoint("TOPLEFT", 12, -88)
	drop:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	drop:SetBackdropColor(0, 0, 0, 0.5)
	drop:SetBackdropBorderColor(0.2, 0.8, 1, 0.4)
	local dropText = label(drop, L["Arrastra aquí un hechizo, objeto o macro para usar su icono"], "GameFontDisableSmall")
	dropText:SetPoint("CENTER")
	local function dropped()
		local slot = slotFromCursor()
		if slot then
			ClearCursor()
			pickIcon(slotIcon(slot))
		end
	end
	drop:SetScript("OnReceiveDrag", dropped)
	drop:SetScript("OnClick", dropped)

	-- Todos los iconos, por páginas (también con la rueda del ratón)
	picker.grid = {}
	local top = -120
	for i = 1, PICK_COLS * PICK_ROWS do
		local b = iconButton(picker)
		b:SetPoint("TOPLEFT", 12 + ((i - 1) % PICK_COLS) * (PICK_SIZE + 4), top - math.floor((i - 1) / PICK_COLS) * (PICK_SIZE + 4))
		picker.grid[i] = b
	end
	local perPage = PICK_COLS * PICK_ROWS
	local function pages() return math.max(math.ceil(#iconList() / perPage), 1) end
	local function turn(delta)
		picker.page = math.min(math.max(picker.page + delta, 1), pages())
		picker:Refresh()
	end
	picker:EnableMouseWheel(true)
	picker:SetScript("OnMouseWheel", function(_, delta) turn(-delta) end)

	local prev = button(picker, "<", 30, function() turn(-1) end)
	prev:SetPoint("BOTTOMLEFT", 12, 10)
	local nextB = button(picker, ">", 30, function() turn(1) end)
	nextB:SetPoint("LEFT", prev, "RIGHT", 4, 0)
	picker.pageText = label(picker, "", "GameFontHighlightSmall")
	picker.pageText:SetPoint("LEFT", nextB, "RIGHT", 8, 0)
	local reset = button(picker, L["Por defecto"], 100, function() pickIcon(nil) end)
	reset:SetPoint("BOTTOMRIGHT", -12, 10)

	function picker:Refresh()
		local slot = self.slot
		local children = slot and linkedSlots(slot)
		self.fromDisc:SetShown(children ~= nil)
		for i, b in ipairs(self.discIcons) do
			local child = children and children[i]
			b.value = child and slotIcon(child)
			b.icon:SetTexture(b.value)
			b:SetShown(child ~= nil)
		end
		local list = iconList()
		local first = (self.page - 1) * perPage
		for i, b in ipairs(self.grid) do
			b.value = list[first + i]
			b.icon:SetTexture(b.value)
			b:SetShown(b.value ~= nil)
		end
		self.pageText:SetText(L["Página %d / %d"]:format(self.page, pages()))
	end
end

function M:OpenIconPicker(slot)
	if not slot or not editor then return end
	if not picker then createPicker() end
	picker.slot = slot
	picker.page = 1
	picker:Show()
	picker:Refresh()
end

local function createEditor()
	editor = CreateFrame("Frame", "RheizorDiscEditor", UIParent, "BackdropTemplate")
	editor:SetSize(720, 470)
	editor:SetPoint("CENTER")
	editor:SetFrameStrata("FULLSCREEN_DIALOG")
	editor:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	editor:SetBackdropColor(0.05, 0.05, 0.07, 0.95)
	editor:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	editor:EnableMouse(true)
	editor:SetMovable(true)
	editor:SetClampedToScreen(true)
	editor:RegisterForDrag("LeftButton")
	editor:SetScript("OnDragStart", editor.StartMoving)
	editor:SetScript("OnDragStop", editor.StopMovingOrSizing)
	table.insert(UISpecialFrames, "RheizorDiscEditor")

	local title = label(editor, L["|cff33ccffRheizor|r · Discos"], "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -12)
	local close = CreateFrame("Button", nil, editor, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)

	-- Lista de discos
	local listTitle = label(editor, L["Discos"])
	listTitle:SetPoint("TOPLEFT", 14, -44)
	editor.discButtons = {}
	local add = button(editor, L["+ Nuevo"], 72, function()
		local d = newDisc(L["Disco %d"]:format(#discs + 1))
		table.insert(db.discs, d)
		rebuildList()
		selDisc, selSlot = indexOf(d) or 1, nil
		M:Changed()
	end)
	add:SetPoint("BOTTOMLEFT", 14, 14)
	local del = button(editor, L["Borrar"], 72, nil)
	del:SetPoint("LEFT", add, "RIGHT", 6, 0)
	del:SetScript("OnClick", function(self)
		if not currentDisc() then return end
		if not self.confirm then
			self.confirm = true
			self:SetText(L["¿Seguro?"])
			C_Timer.After(3, function() self.confirm = nil; self:SetText(L["Borrar"]) end)
			return
		end
		self.confirm = nil
		self:SetText(L["Borrar"])
		local gone = currentDisc()
		local list, i = ownerOf(gone)
		if list then table.remove(list, i) end
		-- Fuera también los enlaces a él desde otros discos
		for _, other in ipairs(discs) do
			for j = #other.slots, 1, -1 do
				local s = other.slots[j]
				if s.kind == "disc" and s.ref == gone.id then table.remove(other.slots, j) end
			end
		end
		selDisc, selSlot = math.max(selDisc - 1, 1), nil
		M:Changed()
	end)

	-- Rellenar el disco elegido con las profesiones de este personaje
	local prof = button(editor, L["Mis profesiones"], 150, nil)
	prof:SetPoint("BOTTOMLEFT", add, "TOPLEFT", 0, 6)
	prof:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(L["Mis profesiones"])
		GameTooltip:AddLine(L["Cambia los huecos del disco elegido por las profesiones que conoce este personaje. Mejor en un disco «Solo este personaje»."], 1, 1, 1, true)
		GameTooltip:Show()
	end)
	prof:SetScript("OnLeave", GameTooltip_Hide)
	prof:SetScript("OnClick", function(self)
		local d = currentDisc()
		if not d then return end
		if not self.confirm and #d.slots > 0 then
			self.confirm = true
			self:SetText(L["¿Seguro?"])
			C_Timer.After(3, function() self.confirm = nil; self:SetText(L["Mis profesiones"]) end)
			return
		end
		self.confirm = nil
		self:SetText(L["Mis profesiones"])
		local slots = M:ProfessionSlots()
		if #slots == 0 then
			R:Print(L["Disco «%s»: no he encontrado ninguna profesión que conozcas."]:format(d.name or "?"))
			return
		end
		d.slots, d.fill, selSlot = slots, nil, nil
		R:Print(L["Disco «%s»: %d profesiones añadidas."]:format(d.name or "?", #slots))
		M:Changed()
	end)

	local sep = editor:CreateTexture(nil, "ARTWORK")
	sep:SetColorTexture(0.2, 0.8, 1, 0.3)
	sep:SetPoint("TOPLEFT", 176, -40)
	sep:SetPoint("BOTTOMLEFT", 176, 10)
	sep:SetWidth(1)

	-- Panel del disco
	local p = CreateFrame("Frame", nil, editor)
	p:SetPoint("TOPLEFT", 190, -40)
	p:SetPoint("BOTTOMRIGHT", -14, 12)
	editor.panel = p

	local nameLabel = label(p, L["Nombre"], "GameFontHighlight")
	nameLabel:SetPoint("TOPLEFT", 0, -6)
	local name = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
	name:SetSize(170, 22)
	name:SetPoint("LEFT", nameLabel, "LEFT", 70, 0)
	name:SetAutoFocus(false)
	local function saveName(self)
		local d = currentDisc()
		if d then d.name = strtrim(self:GetText()) ~= "" and strtrim(self:GetText()) or d.name end
		self:ClearFocus()
		editor:Refresh()
	end
	name:SetScript("OnEnterPressed", saveName)
	name:SetScript("OnEditFocusLost", saveName)
	editor.name = name

	-- Tecla
	local keyLabel = label(p, L["Tecla"], "GameFontHighlight")
	keyLabel:SetPoint("TOPLEFT", 260, -6)
	local key = button(p, "", 150, nil)
	key:SetPoint("LEFT", keyLabel, "LEFT", 44, 0)
	key:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	key:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:AddLine(L["Tecla del disco"])
		GameTooltip:AddLine(L["Clic y pulsa una tecla (con Mayús/Ctrl/Alt si quieres) o un botón lateral del ratón. Clic derecho: quitar. Esc: cancelar."], 1, 1, 1, true)
		GameTooltip:AddLine(L["Mientras el disco exista, esta tecla tiene prioridad sobre tus atajos normales."], 1, 0.5, 0, true)
		GameTooltip:Show()
	end)
	key:SetScript("OnLeave", GameTooltip_Hide)
	local function stopCapture(self, value)
		self.capturing = false
		self:EnableKeyboard(false)
		local d = currentDisc()
		if d and value ~= false then d.key = value; M:Changed() else editor:Refresh() end
	end
	key:SetScript("OnClick", function(self, mouse)
		if self.capturing then
			if MOUSE_KEYS[mouse] then stopCapture(self, withModifiers(MOUSE_KEYS[mouse])) end
			return
		end
		if mouse == "RightButton" then
			local d = currentDisc()
			if d then d.key = nil; M:Changed() end
			return
		end
		self.capturing = true
		self:SetText(L["|cffffd100Pulsa una tecla...|r"])
		self:EnableKeyboard(true)
		if self.SetPropagateKeyboardInput and not InCombatLockdown() then self:SetPropagateKeyboardInput(false) end
	end)
	key:SetScript("OnKeyDown", function(self, k)
		if not self.capturing or KEY_IGNORE[k] then return end
		if k == "ESCAPE" then stopCapture(self, false) return end
		stopCapture(self, withModifiers(k))
	end)
	key:SetScript("OnMouseDown", function(self, mouse)
		if self.capturing and MOUSE_KEYS[mouse] then stopCapture(self, withModifiers(MOUSE_KEYS[mouse])) end
	end)
	editor.key = key

	-- Aspecto
	local function discGetter(field) return function() local d = currentDisc(); return d and d[field] end end
	local function discSetter(field)
		return function(v)
			local d = currentDisc()
			if d then d[field] = v; M:Changed() end
		end
	end

	local colorLabel = label(p, L["Color"], "GameFontHighlight")
	colorLabel:SetPoint("TOPLEFT", 0, -46)
	editor.color = choice(p, 160, DISC_COLORS, discGetter("color"), discSetter("color"))
	editor.color:SetPoint("LEFT", colorLabel, "LEFT", 70, 0)

	local shapeLabel = label(p, L["Forma"], "GameFontHighlight")
	shapeLabel:SetPoint("TOPLEFT", 260, -46)
	editor.shape = choice(p, 150, SHAPES, discGetter("shape"), discSetter("shape"))
	editor.shape:SetPoint("LEFT", shapeLabel, "LEFT", 44, 0)

	local layoutLabel = label(p, L["Disposición"], "GameFontHighlight")
	layoutLabel:SetPoint("TOPLEFT", 0, -80)
	editor.layout = choice(p, 160, LAYOUTS, discGetter("layout"), discSetter("layout"))
	editor.layout:SetPoint("LEFT", layoutLabel, "LEFT", 70, 0)

	-- Compartido en el perfil o solo de este personaje: se mueve de sitio
	local scopeLabel = label(p, L["Para"], "GameFontHighlight")
	scopeLabel:SetPoint("TOPLEFT", 260, -80)
	editor.scope = choice(p, 150, SCOPES,
		function() return isCharDisc(currentDisc()) and "char" or "profile" end,
		function(v)
			local d = currentDisc()
			if not d or (v == "char") == isCharDisc(d) then return end
			local list, i = ownerOf(d)
			if list then table.remove(list, i) end
			table.insert(v == "char" and charDiscs() or db.discs, d)
			rebuildList()
			selDisc = indexOf(d) or 1
			M:Changed()
		end)
	editor.scope:SetPoint("LEFT", scopeLabel, "LEFT", 44, 0)
	editor.scope:HookScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:AddLine(L["Para quién es el disco"])
		GameTooltip:AddLine(L["Todos los personajes del perfil: lo ven todos los que usan este perfil de Rheizor.\nSolo este personaje: no sale en los demás y sigue con él aunque cambie de perfil (no se incluye al exportar el perfil)."], 1, 1, 1, true)
		GameTooltip:Show()
	end)
	editor.scope:HookScript("OnLeave", GameTooltip_Hide)

	editor.radius = stepper(p, L["Radio"], 50, 220, 5, discGetter("radius"), discSetter("radius"))
	editor.radius:SetPoint("TOPLEFT", 260, -110)
	editor.size = stepper(p, L["Tamaño de icono"], 20, 72, 2, discGetter("size"), discSetter("size"))
	editor.size:SetPoint("TOPLEFT", 0, -110)

	-- Huecos
	local slotsTitle = label(p, L["Huecos"], "GameFontNormal")
	slotsTitle:SetPoint("TOPLEFT", 0, -150)
	local hint = label(p, L["Arrastra aquí hechizos, objetos, macros o monturas. Clic: elegir · Clic derecho: quitar"], "GameFontDisableSmall")
	hint:SetPoint("LEFT", slotsTitle, "RIGHT", 10, 0)

	editor.slots = {}
	for i = 1, MAX_SLOTS do
		local b = CreateFrame("Button", nil, p, "BackdropTemplate")
		b:SetSize(42, 42)
		b:SetPoint("TOPLEFT", ((i - 1) % 8) * 52, -172 - math.floor((i - 1) / 8) * 52)
		b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		b:SetBackdropColor(0, 0, 0, 0.5)
		b.icon = b:CreateTexture(nil, "ARTWORK")
		b.icon:SetPoint("TOPLEFT", 2, -2)
		b.icon:SetPoint("BOTTOMRIGHT", -2, 2)
		b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		b.plus = label(b, "+", "GameFontNormalLarge")
		b.plus:SetPoint("CENTER")
		b.num = label(b, i, "GameFontDisableSmall")
		b.num:SetPoint("TOPLEFT", 3, -2)
		b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		b:RegisterForDrag("LeftButton")
		local function drop()
			local slot = slotFromCursor()
			if slot then
				ClearCursor()
				assignSlot(i, slot)
				return true
			end
		end
		b:SetScript("OnReceiveDrag", drop)
		b:SetScript("OnClick", function(_, mouse)
			local d = currentDisc()
			if not d then return end
			if GetCursorInfo() then
				drop()
			elseif mouse == "RightButton" then
				if d.slots[i] then
					table.remove(d.slots, i)
					selSlot = nil
					M:Changed()
				end
			else
				selSlot = math.min(i, #d.slots + 1)
				editor:Refresh()
				editor.text:SetFocus()
			end
		end)
		b:SetScript("OnEnter", function(self)
			local d = currentDisc()
			local slot = d and d.slots[i]
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			if slot then
				GameTooltip:AddLine(slotName(slot))
				local kinds = { spell = L["Hechizo"], item = L["Objeto"], macro = L["Macro"], mount = L["Montura"], disc = L["Disco vinculado"] }
				GameTooltip:AddLine(kinds[slot.kind] or "", 0.6, 0.6, 0.6)
				if slot.kind == "macro" then GameTooltip:AddLine(slot.text, 1, 1, 1, true) end
				if slot.kind == "disc" then
					GameTooltip:AddLine(L["Al pasar por encima salen sus huecos en arco; aléjate un poco más para elegir uno."], 1, 1, 1, true)
				end
			else
				GameTooltip:AddLine(L["Hueco libre"])
				GameTooltip:AddLine(L["Arrastra algo aquí o haz clic para escribirlo."], 1, 1, 1, true)
			end
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", GameTooltip_Hide)
		editor.slots[i] = b
	end

	-- Edición del hueco elegido
	local textLabel = label(p, L["Hueco elegido"], "GameFontHighlight")
	textLabel:SetPoint("TOPLEFT", 0, -290)
	local text = CreateFrame("EditBox", nil, p, "InputBoxTemplate")
	text:SetSize(300, 22)
	text:SetPoint("TOPLEFT", 6, -310)
	text:SetAutoFocus(false)
	text:SetScript("OnEnterPressed", function(self)
		local slot = slotFromText(self:GetText())
		if slot then
			assignSlot(selSlot or MAX_SLOTS + 1, slot)
		else
			R:Print(L["No encuentro ese hechizo u objeto. Para una macro, empieza por / (usa \\n para separar líneas)."])
		end
		self:ClearFocus()
	end)
	text:SetScript("OnEscapePressed", text.ClearFocus)
	editor.text = text
	local textHint = label(p, L["Nombre de un hechizo u objeto, o una macro que empiece por /  ·  Intro para guardar"], "GameFontDisableSmall")
	textHint:SetPoint("TOPLEFT", 0, -338)

	local left = button(p, L["< Mover"], 90, function()
		local d = currentDisc()
		if d and selSlot and selSlot > 1 and d.slots[selSlot] then
			d.slots[selSlot], d.slots[selSlot - 1] = d.slots[selSlot - 1], d.slots[selSlot]
			selSlot = selSlot - 1
			M:Changed()
		end
	end)
	left:SetPoint("LEFT", text, "RIGHT", 10, 0)
	local right = button(p, L["Mover >"], 90, function()
		local d = currentDisc()
		if d and selSlot and d.slots[selSlot + 1] then
			d.slots[selSlot], d.slots[selSlot + 1] = d.slots[selSlot + 1], d.slots[selSlot]
			selSlot = selSlot + 1
			M:Changed()
		end
	end)
	right:SetPoint("LEFT", left, "RIGHT", 4, 0)

	-- Añadir otro disco como hueco: al pasar por encima se abre en arco
	local link = button(p, L["Vincular disco"], 150, nil)
	link:SetPoint("TOPLEFT", 0, -360)
	link:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(L["Vincular disco"])
		GameTooltip:AddLine(L["Añade otro de tus discos como un hueco más. En el anillo, al pasar por encima salen sus huecos en arco por fuera; aléjate hacia uno y suelta la tecla para usarlo. Solo un nivel: los enlaces dentro del disco vinculado no salen."], 1, 1, 1, true)
		GameTooltip:AddLine(L["Los cambios en el disco vinculado se ven en todos los que lo enlazan."], 0.6, 0.8, 1, true)
		GameTooltip:Show()
	end)
	link:SetScript("OnLeave", GameTooltip_Hide)
	link:SetScript("OnClick", function(self)
		local d = currentDisc()
		if not d or not (MenuUtil and MenuUtil.CreateContextMenu) then return end
		MenuUtil.CreateContextMenu(self, function(_, root)
			root:CreateTitle(L["Añadir como hueco"])
			local any = false
			for _, other in ipairs(discs) do
				if other ~= d then
					any = true
					local target = other
					root:CreateButton(target.name, function()
						-- Siempre al final; se coloca luego con < Mover / Mover >
						assignSlot(MAX_SLOTS + 1, { kind = "disc", ref = target.id })
					end)
				end
			end
			if not any then root:CreateTitle(L["|cff888888Crea antes otro disco con + Nuevo|r"]) end
		end)
	end)

	-- Icono del hueco elegido (enlaces a otro disco y macros)
	local iconBtn = button(p, L["Cambiar icono"], 130, function()
		local d = currentDisc()
		M:OpenIconPicker(d and selSlot and d.slots[selSlot])
	end)
	iconBtn:SetPoint("LEFT", link, "RIGHT", 6, 0)
	iconBtn:SetMotionScriptsWhileDisabled(true)
	iconBtn:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(L["Cambiar icono"])
		GameTooltip:AddLine(L["Para el hueco elegido si es un disco vinculado o una macro. Sin cambiarlo, un disco vinculado usa el icono de su primer hueco."], 1, 1, 1, true)
		GameTooltip:Show()
	end)
	iconBtn:SetScript("OnLeave", GameTooltip_Hide)
	editor.iconBtn = iconBtn

	local note = label(p, L["Uso: mantén la tecla, mueve el ratón hacia un icono y suelta. Soltar en el centro no hace nada."], "GameFontDisableSmall")
	note:SetPoint("BOTTOMLEFT", 0, 2)
	note:SetWidth(440)
	note:SetJustifyH("LEFT")

	function editor:Refresh()
		-- Lista
		for i, d in ipairs(discs) do
			local b = self.discButtons[i]
			if not b then
				b = button(self, "", 150, function() selDisc, selSlot = i, nil; self:Refresh() end)
				b:SetPoint("TOPLEFT", 14, -64 - (i - 1) * 26)
				self.discButtons[i] = b
			end
			local r, g, bl = discRGB(d)
			local keyText = d.key and (" |cff888888" .. d.key .. "|r") or ""
			-- Los de este personaje, con una marca
			local mine = isCharDisc(d) and "|cff66ccff·|r " or ""
			b:SetText((i == selDisc and "» " or "") .. mine .. string.format("|cff%02x%02x%02x%s|r", r * 255, g * 255, bl * 255, d.name) .. keyText)
			b:Show()
		end
		for i = #discs + 1, #self.discButtons do self.discButtons[i]:Hide() end

		local d = currentDisc()
		self.panel:SetShown(d ~= nil)
		if not d then return end

		self.name:SetText(d.name)
		self.key:SetText(d.key or L["|cff888888Sin asignar|r"])
		for _, c in ipairs({ self.color, self.shape, self.layout, self.scope, self.radius, self.size }) do c:Refresh() end

		local r, g, bl = discRGB(d)
		for i, b in ipairs(self.slots) do
			local slot = d.slots[i]
			local visible = i <= #d.slots + 1
			b:SetShown(visible)
			if slot then
				b.icon:SetTexture(slotIcon(slot))
				b.icon:Show()
				b.plus:Hide()
			else
				b.icon:Hide()
				b.plus:Show()
			end
			if i == selSlot then
				b:SetBackdropBorderColor(1, 1, 1, 1)
			else
				b:SetBackdropBorderColor(r, g, bl, slot and 0.9 or 0.3)
			end
		end
		local slot = selSlot and d.slots[selSlot]
		self.iconBtn:SetEnabled(slot ~= nil and (slot.kind == "disc" or slot.kind == "macro"))
		-- El selector de icono solo sigue abierto para el hueco elegido
		if picker and picker:IsShown() and picker.slot ~= slot then picker:Hide() end
		if not self.text:HasFocus() then
			if slot then
				self.text:SetText(slot.kind == "macro" and slot.text:gsub("\n", "\\n") or slotName(slot))
			else
				self.text:SetText("")
			end
		end
	end
end

function M:OpenEditor()
	if not editor then createEditor() end
	if SettingsPanel and SettingsPanel:IsShown() then HideUIPanel(SettingsPanel) end
	rebuildList()
	selDisc = math.min(selDisc, math.max(#discs, 1))
	editor:Show()
	editor:Refresh()
end

----------------------------------------------------------------------
-- Disco de profesiones: un disco con fill = "professions" se rellena al
-- entrar con las profesiones que conoce el personaje (una vez; luego se
-- edita como cualquier otro). Rangos de mayor a menor: se usa el más alto
-- que se conozca (al usarlo se lanza por el nombre, vale cualquier rango).
----------------------------------------------------------------------

local PROFESSIONS = {
	{ 11611, 3464, 3101, 2259 },   -- Alquimia
	{ 9785, 3538, 3100, 2018 },    -- Herrería
	{ 13920, 7413, 7412, 7411 },   -- Encantamiento
	{ 13262 },                     -- Desencantar
	{ 12656, 4038, 4037, 4036 },   -- Ingeniería
	{ 10662, 3811, 3104, 2108 },   -- Peletería
	{ 12180, 3910, 3909, 3908 },   -- Sastrería
	{ 2656 },                      -- Fundición (minería)
	{ 2580 },                      -- Buscar minerales
	{ 2383 },                      -- Buscar hierbas
	{ 18260, 3413, 3102, 2550 },   -- Cocina
	{ 818 },                       -- Fuego de campamento básico
	{ 10846, 7924, 3274, 3273 },   -- Primeros auxilios
	{ 18248, 7732, 7731, 7620 },   -- Pesca
}

local function knows(id)
	local checks = { IsPlayerSpell, IsSpellKnown, C_SpellBook and C_SpellBook.IsSpellKnown }
	for i = 1, 3 do
		local fn = checks[i]
		if fn then
			local ok, known = pcall(fn, id)
			if ok and known then return true end
		end
	end
	return false
end

function M:ProfessionSlots()
	local slots = {}
	for _, ranks in ipairs(PROFESSIONS) do
		for _, id in ipairs(ranks) do
			if knows(id) then
				slots[#slots + 1] = { kind = "spell", id = id }
				break
			end
		end
	end
	return slots
end

local function fillProfessionDiscs()
	local changed = false
	for _, d in ipairs(discs) do
		if d.fill == "professions" then
			local slots = M:ProfessionSlots()
			if #slots > 0 then
				d.slots, d.fill = slots, nil
				changed = true
				R:Print(L["Disco «%s»: %d profesiones añadidas."]:format(d.name or "?", #slots))
			else
				R:Print(L["Disco «%s»: no he encontrado ninguna profesión que conozcas."]:format(d.name or "?"))
			end
		end
	end
	if changed then R:RunOutOfCombat(function() M:ApplySecure() end) end
end

function M:OnEnable()
	db = self.db
	if not db.discs then
		-- Un disco de ejemplo con la piedra de hogar
		local d = newDisc(L["General"])
		d.slots[1] = { kind = "item", id = 6948 }
		db.discs = { d }
	end
	rebuildList()
	self:ApplySecure()
	-- Un momento después de entrar, cuando el libro de hechizos ya está cargado
	C_Timer.After(3, fillProfessionDiscs)
end

function M:OnOptionChanged(key)
	if key == "enabled" or key == "deadzone" or key == "scale" then
		self:ApplySecure()
	end
end
