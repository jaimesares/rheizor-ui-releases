-- Rheizor-CC: tus aturdimientos y demás controles con el tiempo que les queda.
--
--   · Los tuyos: al lanzar el hechizo (UNIT_SPELLCAST_SENT / SUCCEEDED, que
--     con tus hechizos no llegan en secreto) se pone un temporizador con la
--     duración que tiene ese hechizo (Golpe en los riñones según los puntos
--     de combo), recortada por los rendimientos decrecientes si toca.
--   · Si el juego deja leer los perjuicios del objetivo, se corrige con el
--     tiempo real, se quitan los que se rompen antes (Gubia, Porrazo...) y
--     se marcan los resistidos. También salen los de otros jugadores.
--   · Rendimientos decrecientes (DR) del objetivo por categoría: ½, ¼,
--     inmune, y cuánto falta para que se reinicien (18 s).
--   · Los controles que sufres tú (C_LossOfControl), en un icono grande.
--
-- Sin registro de combate en WoW Forever: lo de otros jugadores y los
-- controles rotos solo se ven cuando el juego deja leer las auras.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

----------------------------------------------------------------------
-- Hechizos: id -> { categoría, duración } (Classic)
----------------------------------------------------------------------

-- Categorías de rendimientos decrecientes (aproximadas a Classic)
local CATS = {
	{ "stun", "Aturdimientos", "ff4040" },
	{ "kidney", "Golpe en los riñones", "ff8000" },
	{ "rstun", "Aturdimientos por azar", "ff6666" },
	{ "incap", "Incapacitaciones (Gubia, Porrazo, Polimorfia)", "ffd100" },
	{ "blind", "Ceguera", "c0c0c0" },
	{ "fear", "Miedos", "b366ff" },
	{ "sleep", "Sueños", "66ccff" },
	{ "horror", "Horror", "9966cc" },
}
local CAT_INDEX = {}
for i, c in ipairs(CATS) do CAT_INDEX[c[1]] = i end

local SPELLS = {}
local function add(cat, dur, ...)
	for _, id in ipairs({ ... }) do SPELLS[id] = { cat = cat, dur = dur } end
end
local function addRanks(cat, list)
	for id, dur in pairs(list) do SPELLS[id] = { cat = cat, dur = dur } end
end

-- Pícaro
add("stun", 4, 1833)                                             -- Golpe bajo
SPELLS[408] = { cat = "kidney", dur = 5, perPoint = 0 }            -- Golpe en los riñones (1)
SPELLS[8643] = { cat = "kidney", dur = 6, perPoint = 1 }           -- Golpe en los riñones (2)
add("incap", 4, 1776, 1777, 8629, 11285, 11286)                    -- Gubia
addRanks("incap", { [6770] = 25, [2070] = 35, [11297] = 45 })      -- Porrazo
add("blind", 10, 2094)                                             -- Ceguera
-- Guerrero
add("stun", 3, 20253, 20614, 20615)                                -- Interceptar
add("stun", 5, 12809)                                              -- Conmoción
add("rstun", 1, 7922)                                              -- Cargar
add("rstun", 3, 5530)                                              -- Aturdir con maza
add("fear", 8, 5246)                                               -- Grito intimidatorio
-- Paladín
addRanks("stun", { [853] = 3, [5588] = 4, [5589] = 5, [10308] = 6 }) -- Martillo de justicia
add("incap", 6, 20066)                                             -- Arrepentimiento
-- Druida
addRanks("stun", { [5211] = 2, [6798] = 3, [8983] = 4 })           -- Azote
add("stun", 2, 9005, 9823, 9827)                                   -- Abalanzarse
addRanks("sleep", { [2637] = 20, [18657] = 30, [18658] = 40 })     -- Hibernar
-- Cazador
add("incap", 4, 19503)                                             -- Disparo de dispersión
add("stun", 3, 24394)                                              -- Intimidación
add("sleep", 12, 19386, 24132, 24133)                              -- Picadura de dracoleón
addRanks("fear", { [1513] = 10, [14326] = 15, [14327] = 20 })      -- Asustar bestia
-- Mago
addRanks("incap", { [118] = 20, [12824] = 30, [12825] = 40, [12826] = 50, [28271] = 50, [28272] = 50 }) -- Polimorfia
add("rstun", 2, 12355)                                             -- Impacto
-- Sacerdote
add("fear", 8, 8122, 8124, 10888, 10890)                           -- Alarido psíquico
add("rstun", 3, 15269)                                             -- Apagón
-- Brujo
addRanks("fear", { [5782] = 10, [6213] = 15, [6215] = 20 })        -- Miedo
addRanks("fear", { [5484] = 10, [17928] = 15 })                    -- Aullido de terror
add("fear", 15, 6358)                                              -- Seducción
add("horror", 3, 6789, 17925, 17926)                               -- Espiral de la muerte
-- Raciales
add("stun", 2, 20549)                                              -- Pisotón de guerra

local DR_MULT = { 1, 0.5, 0.25, 0 }
local DR_RESET = 18

----------------------------------------------------------------------
-- Opciones
----------------------------------------------------------------------

local STYLES = { { "bars", "Barras" }, { "icons", "Iconos" } }
local GROW = {
	{ "down", "Hacia abajo" }, { "up", "Hacia arriba" },
	{ "right", "Hacia la derecha" }, { "left", "Hacia la izquierda" },
}
local SOUNDS = {
	{ "none", "Ninguno" },
	{ "alert", "Alerta de banda" },
	{ "ready", "Comprobación de listos" },
	{ "whisper", "Susurro" },
	{ "click", "Clic" },
	{ "map", "Ping del mapa" },
}
local SOUND_IDS = {
	alert = function() return SOUNDKIT.RAID_WARNING end,
	ready = function() return SOUNDKIT.READY_CHECK end,
	whisper = function() return SOUNDKIT.TELL_MESSAGE end,
	click = function() return SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON end,
	map = function() return SOUNDKIT.MAP_PING end,
}

local defaults = {
	locked = true,
	mine = true,
	others = true,
	onlyTarget = false,
	otherTargetAlpha = 0.6,
	style = "bars",
	grow = "down",
	width = 200,
	height = 20,
	iconSize = 36,
	spacing = 3,
	texture = R.TEXTURES[2][1],
	bgAlpha = 0.6,
	border = true,
	textSize = 11,
	showSpell = true,
	showTarget = true,
	decimals = 3,
	othersAlpha = 0.75,
	warnAt = 1.5,
	warnFlash = true,
	warnSound = "none",
	endSound = "none",
	breakSound = "none",
	dr = true,
	drPlayersOnly = true,
	drSize = 28,
	selfShow = true,
	selfSize = 56,
	selfSound = "none",
}
for _, c in ipairs(CATS) do defaults["color_" .. c[1]] = c[3] end

local options = {
	{ type = "header", text = "Controles" },
	{ type = "toggle", key = "locked", name = "Bloquear posición",
	  desc = "Desbloqueado se ven ejemplos y se pueden arrastrar los tres marcos (controles, rendimientos decrecientes y los que sufres tú). También con /rz mover." },
	{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
	{ type = "button", name = "Probar", text = "Probar",
	  desc = "Pone unos controles de ejemplo durante unos segundos.", func = function(mod) mod:Test() end },

	{ type = "header", text = "Qué controles" },
	{ type = "toggle", key = "mine", name = "Los tuyos" },
	{ type = "toggle", key = "others", name = "Los de otros jugadores en tu objetivo o foco",
	  desc = "Solo cuando el juego deja leer los perjuicios del objetivo (en combate a veces los oculta)." },
	{ type = "toggle", key = "onlyTarget", name = "Solo los de tu objetivo actual",
	  desc = "Si no, también los de otros enemigos (por ejemplo, el que tienes con Porrazo mientras pegas a otro)." },
	{ type = "slider", key = "otherTargetAlpha", name = "Opacidad de los de otros enemigos", min = 0.2, max = 1, step = 0.05,
	  desc = "Los controles de enemigos que no son tu objetivo actual." },
	{ type = "slider", key = "othersAlpha", name = "Opacidad de los de otros jugadores", min = 0.2, max = 1, step = 0.05 },

	{ type = "header", text = "Aspecto" },
	{ type = "dropdown", key = "style", name = "Estilo", values = STYLES },
	{ type = "dropdown", key = "grow", name = "Crecen", values = GROW },
	{ type = "slider", key = "width", name = "Ancho de las barras", min = 80, max = 400, step = 5, format = R.fmt.int },
	{ type = "slider", key = "height", name = "Alto de las barras", min = 10, max = 40, step = 1, format = R.fmt.int },
	{ type = "slider", key = "iconSize", name = "Tamaño de los iconos", min = 16, max = 80, step = 1, format = R.fmt.int },
	{ type = "slider", key = "spacing", name = "Separación", min = 0, max = 20, step = 1, format = R.fmt.int },
	{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
	{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
	{ type = "toggle", key = "border", name = "Borde" },
	{ type = "slider", key = "textSize", name = "Tamaño del texto", min = 7, max = 24, step = 1, format = R.fmt.int },
	{ type = "toggle", key = "showSpell", name = "Nombre del hechizo" },
	{ type = "toggle", key = "showTarget", name = "Nombre del enemigo" },
	{ type = "slider", key = "decimals", name = "Décimas por debajo de", min = 0, max = 10, step = 0.5,
	  format = function(v) return v == 0 and L["Nunca"] or string.format("%g s", v) end },

	{ type = "header", text = "Colores por tipo" },
}
for _, c in ipairs(CATS) do
	options[#options + 1] = { type = "color", key = "color_" .. c[1], name = c[2] }
end
for _, o in ipairs({
	{ type = "header", text = "Avisos" },
	{ type = "slider", key = "warnAt", name = "Avisar cuando falten", min = 0, max = 5, step = 0.5,
	  format = function(v) return v == 0 and L["No avisar"] or string.format("%g s", v) end,
	  desc = "Para volver a controlar a tiempo. Solo con los tuyos." },
	{ type = "toggle", key = "warnFlash", name = "Parpadear al avisar" },
	{ type = "dropdown", key = "warnSound", name = "Sonido al avisar", values = SOUNDS },
	{ type = "dropdown", key = "endSound", name = "Sonido al acabar", values = SOUNDS },
	{ type = "dropdown", key = "breakSound", name = "Sonido si se rompe antes o lo resisten", values = SOUNDS,
	  desc = "Solo se sabe si el juego deja leer los perjuicios del objetivo." },

	{ type = "header", text = "Rendimientos decrecientes" },
	{ type = "toggle", key = "dr", name = "Mostrar los del objetivo",
	  desc = "Cada vez que controlas al mismo enemigo con la misma categoría dura la mitad, luego un cuarto y luego es inmune, hasta 18 s después del último. Los tuyos también se acortan con esto." },
	{ type = "toggle", key = "drPlayersOnly", name = "Solo contra jugadores",
	  desc = "En Classic los PNJ no tienen rendimientos decrecientes (salvo algunos jefes)." },
	{ type = "slider", key = "drSize", name = "Tamaño", min = 16, max = 60, step = 1, format = R.fmt.int },

	{ type = "header", text = "Controles sobre ti" },
	{ type = "toggle", key = "selfShow", name = "Mostrar los que sufres tú",
	  desc = "Aturdido, con miedo, silenciado... con el tiempo que te queda." },
	{ type = "slider", key = "selfSize", name = "Tamaño", min = 24, max = 120, step = 2, format = R.fmt.int },
	{ type = "dropdown", key = "selfSound", name = "Sonido", values = SOUNDS },
	{ type = "toggle", cvar = "lossOfControl", optional = true, name = "Aviso de Blizzard al perder el control",
	  desc = "El que Blizzard pone en el centro de la pantalla. Puedes quitarlo si usas este." },
}) do options[#options + 1] = o end

local M = R:RegisterModule("cc", {
	title = "Controles",
	defaults = defaults,
	options = options,
	unsupported = {
		"Sin registro de combate: los controles de otros jugadores, los que se rompen antes de tiempo y los resistidos solo se ven cuando el juego deja leer los perjuicios del objetivo.",
		"Las duraciones de los tuyos son las del hechizo: los talentos que las alargan (Gubia mejorada...) se corrigen solo si el juego deja leer el perjuicio.",
	},
})

----------------------------------------------------------------------
-- Estado
----------------------------------------------------------------------

local WHITE = "Interface\\Buttons\\WHITE8X8"
local db
local timers = {}      -- clave (guid:hechizo) -> temporizador
local drs = {}         -- guid -> categoría -> { count, reset, icon }
local pending = {}     -- castGUID -> datos del lanzamiento
local lastPending
local testing = false
local holder, drFrame, selfFrame

local function call(fn, ...)
	if not fn then return end
	local ok, a, b, c, d = pcall(fn, ...)
	if ok then return a, b, c, d end
end

local function playSound(key)
	local get = SOUND_IDS[key]
	local id = get and get()
	if id then PlaySound(id, "Master") end
end

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return call(C_Spell.GetSpellName, id) end
	return (call(GetSpellInfo, id))
end

local function spellIcon(id)
	if C_Spell and C_Spell.GetSpellTexture then return call(C_Spell.GetSpellTexture, id) end
	return select(3, call(GetSpellInfo, id))
end

local function catColor(cat)
	return R.HexToRGB(db["color_" .. cat] or "ffffff")
end

local function targetGUID()
	return NS(call(UnitGUID, "target"))
end

----------------------------------------------------------------------
-- Rendimientos decrecientes
----------------------------------------------------------------------

local function drUses(isPlayer)
	return isPlayer or not db.drPlayersOnly
end

-- Multiplicador que toca ahora (sin apuntarlo)
local function drMult(guid, cat, now)
	local d = drs[guid] and drs[guid][cat]
	if not d or now >= d.reset then return 1 end
	return DR_MULT[math.min(d.count + 1, #DR_MULT)]
end

local function drApply(guid, cat, exp, icon, now)
	drs[guid] = drs[guid] or {}
	local d = drs[guid][cat]
	if not d or now >= d.reset then
		d = { count = 0 }
		drs[guid][cat] = d
	end
	d.count = math.min(d.count + 1, #DR_MULT - 1)
	d.reset = exp + DR_RESET
	d.icon = icon
end

----------------------------------------------------------------------
-- Temporizadores
----------------------------------------------------------------------

local function key(guid, spell) return tostring(guid) .. ":" .. spell end

-- Uno nuevo. Devuelve el temporizador
local function start(guid, name, isPlayer, spell, dur, mine, estimated, exp)
	local info = SPELLS[spell]
	local now = GetTime()
	local t = {
		guid = guid, name = name, isPlayer = isPlayer, spell = spell, cat = info.cat,
		mine = mine, estimated = estimated, start = now, icon = spellIcon(spell),
		spellName = spellName(spell) or "?",
	}
	if exp then
		t.exp, t.dur = exp, dur
	else
		local mult = drUses(isPlayer) and drMult(guid, info.cat, now) or 1
		t.dur = dur * mult
		t.exp = now + t.dur
		t.immune = mult == 0
	end
	if drUses(isPlayer) then drApply(guid, info.cat, t.exp, t.icon, now) end
	if t.immune then
		t.ended, t.endText, t.exp = now, L["Inmune"], now
	end
	timers[key(guid, spell)] = t
	return t
end

local function finish(t, text, sound)
	if t.ended then return end
	t.ended = GetTime()
	t.endText = text
	if sound and t.mine then playSound(sound) end
	-- Se ha roto antes: los rendimientos decrecientes cuentan desde ahora
	local d = drs[t.guid] and drs[t.guid][t.cat]
	if d and t.exp > t.ended then d.reset = t.ended + DR_RESET end
end

----------------------------------------------------------------------
-- Tus lanzamientos
----------------------------------------------------------------------

-- De quién es un nombre (el objetivo del lanzamiento solo viene por nombre)
local function unitByName(name)
	for _, u in ipairs({ "target", "mouseover", "focus" }) do
		if UnitExists(u) and NS(call(UnitName, u)) == name then return u end
	end
end

local function comboPoints()
	return NS(call(GetComboPoints, "player", "target")) or NS(call(UnitPower, "player", 14))
end

local function onSent(target, castGUID, spell)
	if not SPELLS[spell] then return end
	target = NS(target)
	local unit = target and unitByName(target) or "target"
	local p = {
		spell = spell,
		name = target or NS(call(UnitName, unit)) or "?",
		guid = NS(call(UnitGUID, unit)) or ("name:" .. tostring(target)),
		isPlayer = NS(call(UnitIsPlayer, unit)) and true or false,
		cp = comboPoints(),
	}
	castGUID = NS(castGUID)
	if castGUID then pending[castGUID] = p end
	lastPending = p
end

local function onSucceeded(castGUID, spell)
	local info = SPELLS[spell]
	if not info or not db.mine then return end
	castGUID = NS(castGUID)
	local p = (castGUID and pending[castGUID]) or (lastPending and lastPending.spell == spell and lastPending)
	if castGUID then pending[castGUID] = nil end
	lastPending = nil
	if not p then
		local guid = targetGUID()
		if not guid then return end
		p = { spell = spell, guid = guid, name = NS(call(UnitName, "target")) or "?",
			isPlayer = NS(call(UnitIsPlayer, "target")) and true or false, cp = comboPoints() }
	end
	local dur, estimated = info.dur, false
	if info.perPoint then
		-- Golpe en los riñones: un segundo por punto (+1 en el rango 2)
		if p.cp and p.cp > 0 then
			dur = p.cp + info.perPoint
		else
			estimated = true
		end
	end
	local t = start(p.guid, p.name, p.isPlayer, spell, dur, true, estimated)
	t.checkAt = GetTime() + 0.4
end

----------------------------------------------------------------------
-- Perjuicios del objetivo y del foco
----------------------------------------------------------------------

local caches = { target = {}, focus = {} }

local function scan(unit, info)
	if not UnitExists(unit) then return end
	local guid = NS(call(UnitGUID, unit))
	if not guid then return end
	R.CacheAuras(caches[unit], unit, info)
	local list, _, failed = R.ReadAuras(unit, { "HARMFUL" }, R.MAX_AURAS or 40, caches[unit])
	local reliable = not failed
	local seen = {}
	local now = GetTime()
	for _, aura in ipairs(list) do
		local spell = NS(aura.spellId)
		if spell == nil then reliable = false end
		local sp = spell and SPELLS[spell]
		if sp then
			local mine = NS(aura.isFromPlayerOrPlayerPet)
			local k = key(guid, spell)
			local t = timers[k]
			local dur, exp = NS(aura.duration), NS(aura.expirationTime)
			if not (dur and exp and dur > 0) then dur, exp = nil, nil end
			if t and not t.ended then
				seen[k] = true
				t.seenAura = true
				-- El tiempo real (talentos, rendimientos decrecientes del servidor)
				if exp then t.exp, t.dur, t.estimated = exp, dur, false end
			elseif (mine == false and db.others) or (mine and db.mine and not t) then
				if not (t and t.ended and now - t.ended < 1) then
					local name = NS(call(UnitName, unit)) or "?"
					local isPlayer = NS(call(UnitIsPlayer, unit)) and true or false
					local nt = start(guid, name, isPlayer, spell, dur or sp.dur, mine and true or false, exp == nil,
						exp or (now + sp.dur))
					nt.seenAura = true
					seen[k] = true
				end
			end
		end
	end
	if not reliable then return end
	-- Lo que ya no está: roto antes de tiempo, o resistido si nunca llegó a verse
	for k, t in pairs(timers) do
		if t.guid == guid and not t.ended and not seen[k] and t.exp - now > 0.3 then
			if t.seenAura then
				finish(t, L["Roto"], db.breakSound)
			elseif t.mine and t.checkAt and now >= t.checkAt then
				finish(t, L["Resistido"], db.breakSound)
			end
		end
	end
end

----------------------------------------------------------------------
-- Dibujo de los temporizadores
----------------------------------------------------------------------

local rows = {}

local function fmtTime(s)
	if s <= 0 then return "0" end
	if db.decimals > 0 and s < db.decimals then return string.format("%.1f", s) end
	if s >= 60 then return string.format("%d:%02d", math.floor(s / 60), math.floor(s % 60)) end
	return string.format("%d", math.ceil(s))
end

local function newRow()
	local f = CreateFrame("Frame", nil, holder)
	f.icon = f:CreateTexture(nil, "ARTWORK")
	f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	f.bar = CreateFrame("StatusBar", nil, f)
	f.bar.bg = f.bar:CreateTexture(nil, "BACKGROUND")
	f.bar.bg:SetAllPoints()
	f.bar.bg:SetColorTexture(0, 0, 0, 1)
	f.cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
	f.cd:SetAllPoints(f.icon)
	f.cd:SetDrawEdge(false)
	f.cd:SetHideCountdownNumbers(true)
	f.border = CreateFrame("Frame", nil, f, "BackdropTemplate")
	f.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	f.border:SetBackdropBorderColor(0, 0, 0, 1)
	f.over = CreateFrame("Frame", nil, f)
	f.over:SetAllPoints()
	f.over:SetFrameLevel(f.cd:GetFrameLevel() + 3)
	f.name = f.over:CreateFontString(nil, "OVERLAY")
	f.name:SetJustifyH("LEFT")
	f.name:SetWordWrap(false)
	f.time = f.over:CreateFontString(nil, "OVERLAY")
	f.flash = f.over:CreateTexture(nil, "OVERLAY")
	f.flash:SetAllPoints(f)
	f.flash:SetColorTexture(1, 1, 1)
	f.flash:SetBlendMode("ADD")
	f.flash:SetAlpha(0)
	return f
end

local function styleRow(f)
	local font = STANDARD_TEXT_FONT
	f.name:SetFont(font, db.textSize, "OUTLINE")
	f.time:SetFont(font, db.textSize + (db.style == "icons" and 3 or 0), "OUTLINE")
	f.name:ClearAllPoints()
	f.time:ClearAllPoints()
	f.icon:ClearAllPoints()
	f.border:ClearAllPoints()
	if db.style == "icons" then
		local s = db.iconSize
		f:SetSize(s, s)
		f.icon:SetAllPoints()
		f.bar:Hide()
		f.cd:Show()
		f.border:SetPoint("TOPLEFT", -1, 1)
		f.border:SetPoint("BOTTOMRIGHT", 1, -1)
		f.time:SetPoint("CENTER", f, "CENTER", 0, 0)
		f.name:SetPoint("TOP", f, "BOTTOM", 0, -2)
		f.name:SetJustifyH("CENTER")
		f.name:SetWidth(s * 2)
	else
		local h = db.height
		f:SetSize(db.width, h)
		f.icon:SetPoint("TOPLEFT")
		f.icon:SetSize(h, h)
		f.bar:Show()
		f.cd:Hide()
		f.bar:ClearAllPoints()
		f.bar:SetPoint("TOPLEFT", f.icon, "TOPRIGHT", 1, 0)
		f.bar:SetPoint("BOTTOMRIGHT")
		pcall(f.bar.SetStatusBarTexture, f.bar, db.texture)
		f.bar.bg:SetAlpha(db.bgAlpha)
		f.border:SetPoint("TOPLEFT", -1, 1)
		f.border:SetPoint("BOTTOMRIGHT", 1, -1)
		f.time:SetPoint("RIGHT", f, "RIGHT", -4, 0)
		f.name:SetPoint("LEFT", f.bar, "LEFT", 4, 0)
		f.name:SetPoint("RIGHT", f.time, "LEFT", -4, 0)
		f.name:SetJustifyH("LEFT")
		f.name:SetWidth(0)
	end
	f.border:SetShown(db.border)
end

local function rowLabel(t)
	local parts = {}
	if db.showSpell then parts[#parts + 1] = t.spellName end
	if db.showTarget and t.name then parts[#parts + 1] = "|cffcccccc" .. t.name .. "|r" end
	if db.style == "icons" and #parts > 1 then return parts[#parts] end
	return table.concat(parts, " · ")
end

local function sorted()
	local list = {}
	local now = GetTime()
	local tg = targetGUID()
	for k, t in pairs(timers) do
		-- Acabados: se ven un momento con su texto (Roto, Resistido...)
		local gone = (t.ended and now - t.ended > 1.2) or (not t.ended and now > t.exp + 0.2)
		if gone then
			if not t.ended and t.mine and not t.test then playSound(db.endSound) end
			timers[k] = nil
		elseif not db.onlyTarget or t.guid == tg or testing then
			list[#list + 1] = t
		end
	end
	table.sort(list, function(a, b)
		if (a.guid == tg) ~= (b.guid == tg) then return a.guid == tg end
		return a.exp < b.exp
	end)
	return list, tg
end

local function placeRow(f, i)
	local gap = db.spacing
	f:ClearAllPoints()
	local w, h = f:GetWidth(), f:GetHeight()
	if db.style == "icons" and db.showTarget then h = h + db.textSize + 4 end
	local n = i - 1
	if db.grow == "up" then f:SetPoint("BOTTOMLEFT", holder, "BOTTOMLEFT", 0, n * (h + gap))
	elseif db.grow == "right" then f:SetPoint("TOPLEFT", holder, "TOPLEFT", n * (w + gap), 0)
	elseif db.grow == "left" then f:SetPoint("TOPRIGHT", holder, "TOPRIGHT", -n * (w + gap), 0)
	else f:SetPoint("TOPLEFT", holder, "TOPLEFT", 0, -n * (h + gap)) end
end

local function drawTimers()
	local list, tg = sorted()
	local now = GetTime()
	for i, t in ipairs(list) do
		local f = rows[i]
		if not f then
			f = newRow()
			rows[i] = f
			styleRow(f)
		end
		if f.drawn ~= t then
			f.drawn = t
			f.warnT = 0
			f.icon:SetTexture(t.icon)
			local r, g, b = catColor(t.cat)
			f.bar:SetStatusBarColor(r, g, b)
			f.border:SetBackdropBorderColor(db.style == "icons" and r or 0, db.style == "icons" and g or 0, db.style == "icons" and b or 0, 1)
			f.drawnExp = nil
		end
		-- El tiempo puede corregirse al leer el perjuicio
		if f.drawnExp ~= t.exp then
			f.drawnExp = t.exp
			if db.style == "icons" and t.dur and t.dur > 0 then f.cd:SetCooldown(t.exp - t.dur, t.dur) end
		end
		placeRow(f, i)
		local left = t.exp - now
		if t.ended then
			f.time:SetText("")
			f.name:SetText("|cffff5555" .. (t.endText or "") .. "|r" .. (db.style == "bars" and (" · " .. t.spellName) or ""))
			f.bar:SetValue(0)
			f.cd:Clear()
		else
			f.bar:SetMinMaxValues(0, math.max(t.dur or 1, 0.01))
			f.bar:SetValue(math.max(left, 0))
			f.time:SetText((t.estimated and "~" or "") .. fmtTime(left))
			f.name:SetText(rowLabel(t))
			-- Aviso: queda poco para volver a controlarlo
			if t.mine and db.warnAt > 0 and left <= db.warnAt and not t.warned and not testing then
				t.warned = true
				playSound(db.warnSound)
				f.warnT = 0.6
			end
		end
		local alpha = 1
		if not t.mine then alpha = alpha * db.othersAlpha end
		if tg and t.guid ~= tg and not testing then alpha = alpha * db.otherTargetAlpha end
		f:SetAlpha(alpha)
		f:Show()
	end
	for i = #list + 1, #rows do
		rows[i]:Hide()
		rows[i].drawn = nil
	end
	return #list
end

----------------------------------------------------------------------
-- Rendimientos decrecientes del objetivo
----------------------------------------------------------------------

local drIcons = {}

local function drIcon(i)
	local f = drIcons[i]
	if f then return f end
	f = CreateFrame("Frame", nil, drFrame, "BackdropTemplate")
	f:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	f.icon = f:CreateTexture(nil, "ARTWORK")
	f.icon:SetPoint("TOPLEFT", 1, -1)
	f.icon:SetPoint("BOTTOMRIGHT", -1, 1)
	f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	f.cd = CreateFrame("Cooldown", nil, f, "CooldownFrameTemplate")
	f.cd:SetAllPoints(f.icon)
	f.cd:SetDrawEdge(false)
	f.cd:SetReverse(true)
	f.cd:SetHideCountdownNumbers(true)
	f.over = CreateFrame("Frame", nil, f)
	f.over:SetAllPoints()
	f.over:SetFrameLevel(f.cd:GetFrameLevel() + 2)
	f.text = f.over:CreateFontString(nil, "OVERLAY")
	f.text:SetPoint("BOTTOM", f, "BOTTOM", 0, 1)
	drIcons[i] = f
	return f
end

local DR_TEXT = { "|cff33ff33½|r", "|cffffd100¼|r", "|cffff3333" }

local function drawDR()
	local shown = 0
	if db.dr then
		local guid = testing and "test:1" or targetGUID()
		local isPlayer = testing or NS(call(UnitIsPlayer, "target"))
		local list = guid and drs[guid]
		local now = GetTime()
		if list and (isPlayer or not db.drPlayersOnly) then
			for i, c in ipairs(CATS) do
				local d = list[c[1]]
				if d and now < d.reset and d.count > 0 then
					shown = shown + 1
					local f = drIcon(shown)
					local s = db.drSize
					f:SetSize(s, s)
					f:ClearAllPoints()
					f:SetPoint("LEFT", drFrame, "LEFT", (shown - 1) * (s + 3), 0)
					f.icon:SetTexture(d.icon)
					f.text:SetFont(STANDARD_TEXT_FONT, math.max(9, s * 0.42), "OUTLINE")
					local n = math.min(d.count, 3)
					f.text:SetText(n >= 3 and (DR_TEXT[3] .. L["Inm."] .. "|r") or DR_TEXT[n])
					local r, g, b = catColor(c[1])
					f:SetBackdropBorderColor(r, g, b, 1)
					if f.reset ~= d.reset then
						f.reset = d.reset
						f.cd:SetCooldown(d.reset - DR_RESET, DR_RESET)
					end
					f:Show()
				end
			end
		end
	end
	for i = shown + 1, #drIcons do drIcons[i]:Hide() end
	drFrame:SetShown(shown > 0 or not db.locked)
	drFrame:SetSize(math.max(shown, 3) * (db.drSize + 3), db.drSize)
end

----------------------------------------------------------------------
-- Controles sobre ti
----------------------------------------------------------------------

local LOC = C_LossOfControl
local selfShown

local function lossOfControl()
	if not LOC then return end
	local n = NS(call(LOC.GetActiveLossOfControlDataCount)) or 0
	local best
	for i = 1, n do
		local d = call(LOC.GetActiveLossOfControlData, i)
		if type(d) == "table" then
			local dt = NS(d.displayType)
			if dt ~= 0 then
				local prio = NS(d.priority) or 0
				if not best or prio > (NS(best.priority) or 0) then best = d end
			end
		end
	end
	return best
end

local function drawSelf()
	local d = db.selfShow and (testing and { test = true } or lossOfControl())
	if not d then
		selfFrame:SetShown(not db.locked)
		if db.locked then selfShown = nil end
		if not db.locked then
			selfFrame.icon:SetTexture(spellIcon(1833))
			selfFrame.text:SetText(L["Aturdido"])
			selfFrame.time:SetText("")
		end
		return
	end
	local s = db.selfSize
	selfFrame:SetSize(s, s)
	selfFrame.time:SetFont(STANDARD_TEXT_FONT, math.max(10, s * 0.4), "OUTLINE")
	selfFrame.text:SetFont(STANDARD_TEXT_FONT, math.max(9, s * 0.22), "OUTLINE")
	if d.test then
		selfFrame.icon:SetTexture(spellIcon(1833))
		selfFrame.text:SetText(L["Aturdido"])
		selfFrame.time:SetText("3")
	else
		pcall(selfFrame.icon.SetTexture, selfFrame.icon, d.iconTexture)
		pcall(selfFrame.text.SetText, selfFrame.text, d.displayText or "")
		local left = NS(d.timeRemaining)
		selfFrame.time:SetText(left and fmtTime(left) or "")
		local start, dur = NS(d.startTime), NS(d.duration)
		local id = NS(d.spellID) or 0
		if selfShown ~= id then
			selfShown = id
			playSound(db.selfSound)
			if start and dur and dur > 0 then selfFrame.cd:SetCooldown(start, dur) else selfFrame.cd:Clear() end
		end
	end
	selfFrame:Show()
end

----------------------------------------------------------------------
-- Bucle
----------------------------------------------------------------------

local function onUpdate(_, elapsed)
	local n = drawTimers()
	holder:SetShown(n > 0 or not db.locked)
	for _, f in ipairs(rows) do
		if f:IsShown() and f.warnT and f.warnT > 0 then
			f.warnT = math.max(0, f.warnT - elapsed)
			f.flash:SetAlpha(db.warnFlash and (0.5 * math.abs(math.sin(f.warnT * math.pi * 3))) or 0)
		else
			f.flash:SetAlpha(0)
		end
	end
	drawDR()
	drawSelf()
end

-- Un marco que siempre está (el de los temporizadores se oculta)
local ticker = CreateFrame("Frame")

function M:Refresh()
	if not holder then return end
	for _, f in ipairs(rows) do styleRow(f); f.drawn = nil end
	local w = db.style == "icons" and db.iconSize or db.width
	local h = db.style == "icons" and db.iconSize or db.height
	holder:SetSize(w, h)
	for _, m in ipairs({ holder.mover, drFrame.mover, selfFrame.mover }) do
		m:Place()
		m:SetShown(not db.locked)
	end
	-- Desbloqueado: ejemplos para ver dónde queda
	if not db.locked and not testing then self:Test(true) end
end

function M:ResetPosition()
	db.point, db.drPoint, db.selfPoint = nil, nil, nil
	self:Refresh()
end

local testToken = 0
function M:Test(whileUnlocked)
	if not holder then return end
	testToken = testToken + 1
	local token = testToken
	testing = true
	local now = GetTime()
	local function fake(spell, left, mine, name, guid, isPlayer)
		local info = SPELLS[spell]
		local t = {
			guid = guid, name = name, isPlayer = isPlayer, spell = spell, cat = info.cat, mine = mine,
			start = now, dur = info.dur, exp = now + left, icon = spellIcon(spell), spellName = spellName(spell) or "?",
			warned = true, test = true,
		}
		timers["test:" .. spell] = t
	end
	fake(1833, 4, true, L["Enemigo"], "test:1", true)
	fake(11297, 30, true, L["Otro enemigo"], "test:2", false)
	fake(5782, 8, false, L["Enemigo"], "test:1", true)
	drs["test:1"] = {
		stun = { count = 1, reset = now + 15, icon = spellIcon(1833) },
		kidney = { count = 2, reset = now + 10, icon = spellIcon(408) },
		fear = { count = 3, reset = now + 18, icon = spellIcon(5782) },
	}
	local function stop()
		if token ~= testToken then return end
		if whileUnlocked and not db.locked then
			C_Timer.After(5, stop)
			M:Test(true)
			return
		end
		testing = false
		for k, t in pairs(timers) do if t.test then timers[k] = nil end end
		drs["test:1"] = nil
	end
	C_Timer.After(whileUnlocked and 5 or 8, stop)
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, unit, a, b, c)
	if event == "UNIT_SPELLCAST_SENT" then
		-- unidad, objetivo (nombre), castGUID, spellID
		local spell = NS(c)
		if spell then onSent(a, b, spell) end
	elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
		local spell = NS(b)
		if spell then onSucceeded(a, spell) end
	elseif event == "UNIT_AURA" then
		if unit == "target" or unit == "focus" then scan(unit, a) end
	elseif event == "PLAYER_TARGET_CHANGED" then
		scan("target")
	elseif event == "PLAYER_FOCUS_CHANGED" then
		scan("focus")
	elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" then
		local id = NS(a)
		if id then pending[id] = nil end
	end
end)

function M:OnEnable()
	db = self.db
	if holder then return end
	holder = CreateFrame("Frame", "RheizorCC", UIParent)
	holder:SetFrameStrata("MEDIUM")
	holder:SetSize(200, 20)
	holder.mover = R:CreateMover(holder, "Controles", db, "point", { "CENTER", "CENTER", 0, -220 })

	drFrame = CreateFrame("Frame", "RheizorCCDR", UIParent)
	drFrame:SetSize(100, 28)
	drFrame.mover = R:CreateMover(drFrame, "Rendimientos decrecientes", db, "drPoint", { "CENTER", "CENTER", 180, -120 })

	selfFrame = CreateFrame("Frame", "RheizorCCSelf", UIParent, "BackdropTemplate")
	selfFrame:SetSize(56, 56)
	selfFrame:SetFrameStrata("HIGH")
	selfFrame:SetBackdrop({ edgeFile = WHITE, edgeSize = 2 })
	selfFrame:SetBackdropBorderColor(1, 0.2, 0.2, 1)
	selfFrame.icon = selfFrame:CreateTexture(nil, "ARTWORK")
	selfFrame.icon:SetPoint("TOPLEFT", 2, -2)
	selfFrame.icon:SetPoint("BOTTOMRIGHT", -2, 2)
	selfFrame.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	selfFrame.cd = CreateFrame("Cooldown", nil, selfFrame, "CooldownFrameTemplate")
	selfFrame.cd:SetAllPoints(selfFrame.icon)
	selfFrame.cd:SetHideCountdownNumbers(true)
	local over = CreateFrame("Frame", nil, selfFrame)
	over:SetAllPoints()
	over:SetFrameLevel(selfFrame.cd:GetFrameLevel() + 2)
	selfFrame.time = over:CreateFontString(nil, "OVERLAY")
	selfFrame.time:SetPoint("CENTER")
	selfFrame.text = over:CreateFontString(nil, "OVERLAY")
	selfFrame.text:SetPoint("TOP", selfFrame, "BOTTOM", 0, -3)
	selfFrame:Hide()
	selfFrame.mover = R:CreateMover(selfFrame, "Controles sobre ti", db, "selfPoint", { "CENTER", "CENTER", 0, 120 })

	for _, e in ipairs({ "PLAYER_TARGET_CHANGED", "PLAYER_FOCUS_CHANGED" }) do pcall(events.RegisterEvent, events, e) end
	pcall(events.RegisterUnitEvent, events, "UNIT_AURA", "target", "focus")
	for _, e in ipairs({ "UNIT_SPELLCAST_SENT", "UNIT_SPELLCAST_SUCCEEDED", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED" }) do
		pcall(events.RegisterUnitEvent, events, e, "player")
	end
	ticker:SetScript("OnUpdate", onUpdate)
	self:Refresh()
end

function M:OnOptionChanged()
	self:Refresh()
end
