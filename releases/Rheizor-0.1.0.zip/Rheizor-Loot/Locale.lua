-- Traducciones de Rheizor-Loot: clave = texto en español
Rheizor:AddTranslations("en", {
	-- Módulo y opciones
	["Botín"] = "Loot",
	["Tiradas (Necesidad / Codicia / Desencantar)"] = "Rolls (Need / Greed / Disenchant)",
	["Usar mi posición"] = "Use my position",
	["Coloca las ventanas de tirada donde pongas su marco de ejemplo. Se activa solo al arrastrar el marco (con \"Desbloquear para mover\" o /rz mover)."] = "Places the roll windows wherever you put their sample frame. It turns on by itself when you drag the frame (with \"Unlock to move\" or /rz move).",
	["La de Blizzard: lo que diga la opción del juego \"Abrir el botín bajo el ratón\" (Opciones > Controles).\nBajo el ratón: siempre junto al cursor.\nMi posición: donde dejes su marco de ejemplo; se elige sola al arrastrar el marco.\n\nBajo el ratón y Mi posición cambian esa opción del juego por ti."] = "Blizzard default: whatever the game's \"Open loot window at mouse\" option says (Options > Controls).\nUnder mouse: always next to the cursor.\nMy position: wherever you leave its sample frame; picked automatically when you drag the frame.\n\nUnder mouse and My position change that game option for you.",
	["Botín: las tiradas saldrán donde has dejado su marco."] = "Loot: rolls will appear where you left their frame.",
	["Botín: la ventana de botín se abrirá donde has dejado su marco."] = "Loot: the loot window will open where you left its frame.",
	["Botín: el juego no deja a los addons cambiar «Abrir el botín bajo el ratón». Escribe en el chat: %s"] = "Loot: the game doesn't let addons change \"Open loot window at mouse\". Type in chat: %s",
	["Tamaño"] = "Size",
	["Ventana de botín"] = "Loot window",
	["Posición"] = "Position",
	["La de Blizzard"] = "Blizzard default",
	["Bajo el ratón"] = "Under mouse",
	["Mi posición"] = "My position",
	["Colocar"] = "Placement",
	["Desbloquear para mover"] = "Unlock to move",
	["Muestra marcos de ejemplo que puedes arrastrar. Desactívalo al terminar."] = "Shows sample frames you can drag. Turn it off when you're done.",
	["Posiciones"] = "Positions",
	["Restablecer"] = "Reset",
	["Vuelve a colocar los marcos de ejemplo en su sitio inicial."] = "Moves the sample frames back to their default spots.",

	-- Marcos de ejemplo
	["|cff33ccffRheizor|r · %s — arrastra para mover"] = "|cff33ccffRheizor|r · %s — drag to move",
	["Tiradas"] = "Rolls",
	["|cff0070ddEspada de ejemplo|r"] = "|cff0070ddSample Sword|r",
	["Necesidad · Codicia · Desencantar"] = "Need · Greed · Disenchant",
	["|cffffffff12 plata|r"] = "|cffffffff12 silver|r",
	["|cff1eff00Bolsa de ejemplo|r"] = "|cff1eff00Sample Bag|r",
	["|cffffffffPan de ejemplo|r"] = "|cffffffffSample Bread|r",

	-- Diagnóstico (/rz debug)
	["Botín: tiradas"] = "Loot: rolls",
	["Botín: ventana"] = "Loot: window",
})
