-- Botín: posición y tamaño de las ventanas de tirada (Necesidad/Codicia/
-- Desencantar) y de la ventana de botín al despojar.
--
-- Las tiradas viven dentro de GroupLootContainer, que Blizzard recoloca
-- junto con las alertas. Se engancha su SetPoint para devolverlo siempre a
-- la posición elegida.

local R = Rheizor:Namespace(...)
local L = R.L

local M = R:RegisterModule("loot", {
	title = "Botín",
	defaults = {
		rollMove = false,
		rollScale = 1,
		lootMode = "blizzard",
		lootScale = 1,
		unlocked = false,
	},
	options = {
		{ type = "header", text = "Tiradas (Necesidad / Codicia / Desencantar)" },
		{ type = "toggle", key = "rollMove", name = "Usar mi posición",
		  desc = "Coloca las ventanas de tirada donde pongas su marco de ejemplo. Se activa solo al arrastrar el marco (con \"Desbloquear para mover\" o /rz mover)." },
		{ type = "slider", key = "rollScale", name = "Tamaño", min = 0.6, max = 1.6, step = 0.05 },

		{ type = "header", text = "Ventana de botín" },
		{ type = "dropdown", key = "lootMode", name = "Posición",
		  values = {
			{ "blizzard", "La de Blizzard" },
			{ "mouse", "Bajo el ratón" },
			{ "fixed", "Mi posición" },
		  },
		  desc = "La de Blizzard: lo que diga la opción del juego \"Abrir el botín bajo el ratón\" (Opciones > Controles).\nBajo el ratón: siempre junto al cursor.\nMi posición: donde dejes su marco de ejemplo; se elige sola al arrastrar el marco.\n\nBajo el ratón y Mi posición cambian esa opción del juego por ti." },
		{ type = "slider", key = "lootScale", name = "Tamaño", min = 0.6, max = 1.6, step = 0.05 },

		{ type = "header", text = "Colocar" },
		{ type = "toggle", key = "unlocked", name = "Desbloquear para mover",
		  desc = "Muestra marcos de ejemplo que puedes arrastrar. Desactívalo al terminar." },
		{ type = "button", name = "Posiciones", text = "Restablecer",
		  desc = "Vuelve a colocar los marcos de ejemplo en su sitio inicial.",
		  func = function(mod) mod:ResetPositions() end },
	},
})

local db
local rollAnchor, lootAnchor

local DEFAULT_ROLL = { "BOTTOM", "BOTTOM", 0, 260 }
local DEFAULT_LOOT = { "TOPLEFT", "TOPLEFT", 60, -180 }

----------------------------------------------------------------------
-- Marcos de ejemplo (arrastrables)
----------------------------------------------------------------------

local function createAnchor(key, label, width, height)
	local f = CreateFrame("Frame", "RheizorLootAnchor" .. key, UIParent, "BackdropTemplate")
	f:SetSize(width, height)
	f:SetFrameStrata("DIALOG")
	f:SetMovable(true)
	f:SetClampedToScreen(true)
	R:RegisterMovable(f)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	f:SetBackdropColor(0.1, 0.5, 0.8, 0.35)
	f:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)

	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.label:SetPoint("BOTTOM", f, "TOP", 0, 4)
	f.label:SetText(string.format(L["|cff33ccffRheizor|r · %s — arrastra para mover"], label))

	f.key = key
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		self:SetUserPlaced(false)
		local point, _, relPoint, x, y = self:GetPoint()
		db[self.key .. "Point"] = { point, relPoint, x, y }
		-- Si lo mueves es que lo quieres ahí: se activa la posición propia
		if self.key == "roll" and not db.rollMove then
			db.rollMove = true
			R:Print(L["Botín: las tiradas saldrán donde has dejado su marco."])
		elseif self.key == "loot" and db.lootMode ~= "fixed" then
			db.lootMode = "fixed"
			R:Print(L["Botín: la ventana de botín se abrirá donde has dejado su marco."])
		end
		M:Apply()
	end)
	R:AddNudge(f)
	f:Hide()
	return f
end

-- Dibujo de una tirada de ejemplo
local function decorateRoll(f)
	local icon = f:CreateTexture(nil, "ARTWORK")
	icon:SetTexture("Interface\\Icons\\INV_Sword_39")
	icon:SetSize(38, 38)
	icon:SetPoint("LEFT", 10, 0)

	local name = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	name:SetPoint("LEFT", icon, "RIGHT", 8, 6)
	name:SetText(L["|cff0070ddEspada de ejemplo|r"])

	local hint = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	hint:SetPoint("TOPLEFT", name, "BOTTOMLEFT", 0, -3)
	hint:SetText(L["Necesidad · Codicia · Desencantar"])

	local x = -10
	for _, tex in ipairs({ "UI-GroupLoot-DE-Up", "UI-GroupLoot-Coin-Up", "UI-GroupLoot-Dice-Up" }) do
		local b = f:CreateTexture(nil, "ARTWORK")
		b:SetTexture("Interface\\Buttons\\" .. tex)
		b:SetSize(26, 26)
		b:SetPoint("RIGHT", x, 0)
		x = x - 28
	end
end

-- Dibujo de una ventana de botín de ejemplo
local function decorateLoot(f)
	local items = {
		{ "Interface\\Icons\\INV_Misc_Coin_01", L["|cffffffff12 plata|r"] },
		{ "Interface\\Icons\\INV_Misc_Bag_07", L["|cff1eff00Bolsa de ejemplo|r"] },
		{ "Interface\\Icons\\INV_Misc_Food_15", L["|cffffffffPan de ejemplo|r"] },
	}
	for i, item in ipairs(items) do
		local icon = f:CreateTexture(nil, "ARTWORK")
		icon:SetTexture(item[1])
		icon:SetSize(30, 30)
		icon:SetPoint("TOPLEFT", 10, -10 - (i - 1) * 38)
		local text = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		text:SetPoint("LEFT", icon, "RIGHT", 8, 0)
		text:SetText(item[2])
	end
end

local function placeAnchor(f, saved, default)
	local p = saved or default
	f:ClearAllPoints()
	f:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

----------------------------------------------------------------------
-- Aplicar posiciones
----------------------------------------------------------------------

local placingRoll, placingLoot

-- Los ganchos de Blizzard no se pueden quitar: si se apaga el addon en
-- Rheizor, siguen llamándose pero no hacen nada. (No se usa
-- R:IsModuleRunning: durante el propio OnEnable aún da false)
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

local function placeRoll()
	if placingRoll or not db.rollMove or not GroupLootContainer or not running() then return end
	placingRoll = true
	GroupLootContainer:ClearAllPoints()
	GroupLootContainer:SetPoint("BOTTOM", rollAnchor, "BOTTOM")
	placingRoll = nil
end

local function placeLoot()
	if placingLoot or db.lootMode ~= "fixed" or not LootFrame or not running() then return end
	placingLoot = true
	LootFrame:ClearAllPoints()
	LootFrame:SetPoint("TOPLEFT", lootAnchor, "TOPLEFT")
	placingLoot = nil
end

-- "Abrir el botín bajo el ratón". Algunas CVars no las puede cambiar un addon
-- (el juego lo ignora sin avisar): se comprueba y, si no ha cambiado, se
-- explica cómo hacerlo a mano
local warnedCVar
local function setLootUnderMouse(value)
	if C_CVar.GetCVar("lootUnderMouse") == value then return end
	R:RunOutOfCombat(function()
		C_CVar.SetCVar("lootUnderMouse", value)
		if C_CVar.GetCVar("lootUnderMouse") ~= value and not warnedCVar then
			warnedCVar = true
			R:Print(string.format(L["Botín: el juego no deja a los addons cambiar «Abrir el botín bajo el ratón». Escribe en el chat: %s"],
				"|cffffff00/console lootUnderMouse " .. value .. "|r"))
		end
	end)
end

function M:Apply()
	placeAnchor(rollAnchor, db.rollPoint, DEFAULT_ROLL)
	placeAnchor(lootAnchor, db.lootPoint, DEFAULT_LOOT)
	rollAnchor:SetShown(db.unlocked)
	lootAnchor:SetShown(db.unlocked)

	if GroupLootContainer then
		GroupLootContainer:SetScale(db.rollScale)
		rollAnchor:SetScale(db.rollScale)
		if db.rollMove then
			placeRoll()
		elseif AlertFrame and AlertFrame.UpdateAnchors then
			AlertFrame:UpdateAnchors()
		end
	end
	if LootFrame then
		LootFrame:SetScale(db.lootScale)
		lootAnchor:SetScale(db.lootScale)
		placeLoot()
	end
	-- La opción del juego "abrir bajo el ratón" manda sobre la posición: se
	-- ajusta a lo elegido (con "La de Blizzard" no se toca)
	if db.lootMode == "mouse" then
		setLootUnderMouse("1")
	elseif db.lootMode == "fixed" then
		setLootUnderMouse("0")
	end
end

function M:ResetPositions()
	db.rollPoint, db.lootPoint = nil, nil
	self:Apply()
end

----------------------------------------------------------------------

function M:OnEnable()
	db = self.db
	started = true

	rollAnchor = createAnchor("roll", L["Tiradas"], 290, 64)
	decorateRoll(rollAnchor)
	lootAnchor = createAnchor("loot", L["Ventana de botín"], 200, 124)
	decorateLoot(lootAnchor)

	if GroupLootContainer then
		hooksecurefunc(GroupLootContainer, "SetPoint", placeRoll)
		GroupLootContainer:HookScript("OnShow", placeRoll)
	else
		R.missing[L["Botín: tiradas"]] = "GroupLootContainer"
	end

	if LootFrame then
		hooksecurefunc(LootFrame, "SetPoint", placeLoot)
		LootFrame:HookScript("OnShow", function()
			placeLoot()
			C_Timer.After(0, placeLoot)
		end)
	else
		R.missing[L["Botín: ventana"]] = "LootFrame"
	end

	self:Apply()
end

function M:OnOptionChanged()
	self:Apply()
end
