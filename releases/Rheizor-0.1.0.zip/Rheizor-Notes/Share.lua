-- Ventana «Compartir» del editor de notas: con quién se comparte una nota
-- y quién puede editarla. La sincronización está en Sync.lua.
--   Autor (o nota aún sin compartir): toda la hermandad (con o sin rango
--   mínimo) y/o miembros sueltos, cada uno con o sin permiso para editar.
--   Quien la recibe: ve de quién es y con quién está, y puede salirse
--   quedándose una copia.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local M = ns.M

local W, H = 440, 540
local ROW_H = 22
local WHITE = "Interface\\Buttons\\WHITE8X8"

local win, list, rows, searchBox, guildCheck, guildEditCheck, rankDrop, infoText, statusText
local saveButton, stopButton, headerEdit
local noteId, work, filter = nil, nil, ""

local function ui() return ns.ui end

local function note() return noteId and M:FindNote(noteId) end

local function setStatus(text, r, g, b)
	statusText:SetText(text or "")
	statusText:SetTextColor(r or 1, g or 1, b or 1)
end

local function classColor(class)
	local c = class and (C_ClassColor and C_ClassColor.GetClassColor(class) or (RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]))
	if c then return c.r, c.g, c.b end
	return 1, 1, 1
end

local function check(parent, text, onClick)
	local c = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
	c:SetSize(22, 22)
	c.label = parent:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	c.label:SetPoint("LEFT", c, "RIGHT", 2, 0)
	c.label:SetText(text or "")
	c:SetScript("OnClick", onClick)
	return c
end

----------------------------------------------------------------------
-- Lista de miembros
----------------------------------------------------------------------

local function editable()
	local n = note()
	return n and (not n.shared or M:IsNoteAuthor(n))
end

local function rankValues()
	local names, count = ns.RankNames()
	local values = { { "all", "Todos los rangos" } }
	for i = 0, count - 1 do
		values[#values + 1] = { i, L["Hasta %s"]:format(names[i] or tostring(i + 1)) }
	end
	return values
end

local function row(i)
	local r = rows[i]
	if r then return r end
	r = CreateFrame("Frame", nil, list.child)
	r:SetHeight(ROW_H)
	r:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	r:SetPoint("RIGHT", list.child, "RIGHT")
	r:EnableMouse(true)
	local hl = r:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	r.share = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
	r.share:SetSize(20, 20)
	r.share:SetPoint("LEFT", 4, 0)
	r.edit = CreateFrame("CheckButton", nil, r, "UICheckButtonTemplate")
	r.edit:SetSize(20, 20)
	r.edit:SetPoint("RIGHT", -8, 0)
	r.dot = r:CreateTexture(nil, "ARTWORK")
	r.dot:SetSize(8, 8)
	r.dot:SetPoint("LEFT", r.share, "RIGHT", 4, 0)
	r.dot:SetTexture(WHITE)
	r.rank = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	r.rank:SetPoint("RIGHT", r.edit, "LEFT", -10, 0)
	r.rank:SetWidth(100)
	r.rank:SetJustifyH("RIGHT")
	r.rank:SetWordWrap(false)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", r.dot, "RIGHT", 6, 0)
	r.name:SetPoint("RIGHT", r.rank, "LEFT", -4, 0)
	r.name:SetJustifyH("LEFT")
	r.name:SetWordWrap(false)
	r.share:SetScript("OnClick", function(self)
		if not work then return end
		if self:GetChecked() then
			work.members[r.key] = { name = r.fullName, edit = false }
		else
			work.members[r.key] = nil
		end
		ns.RefreshShare()
	end)
	r.edit:SetScript("OnClick", function(self)
		if not work then return end
		local m = work.members[r.key]
		if not m then
			m = { name = r.fullName, edit = false }
			work.members[r.key] = m
		end
		m.edit = self:GetChecked() and true or false
		ns.RefreshShare()
	end)
	rows[i] = r
	return r
end

local function entries()
	local out, inRoster = {}, {}
	for _, e in ipairs(ns.Roster()) do
		inRoster[e.key] = true
		out[#out + 1] = e
	end
	-- Arriba, los que están en la nota pero ya no en la hermandad
	if work then
		for k, m in pairs(work.members) do
			if not inRoster[k] then table.insert(out, 1, { key = k, name = m.name or k, online = false, gone = true }) end
		end
	end
	if filter ~= "" then
		local f, kept = filter:lower(), {}
		for _, e in ipairs(out) do
			if e.name:lower():find(f, 1, true) then kept[#kept + 1] = e end
		end
		out = kept
	end
	return out
end

local function drawRows()
	local canChange = editable()
	local names = ns.RankNames()
	local all = entries()
	for i, e in ipairs(all) do
		local r = row(i)
		r.key, r.fullName = e.key, e.name
		local m = work and work.members[e.key]
		local byGuild = work and work.guild and (work.minRank == nil or (e.rank ~= nil and e.rank <= work.minRank))
		r.share:SetChecked(m ~= nil or byGuild)
		r.share:SetEnabled(canChange and not byGuild)
		r.edit:SetChecked((m and m.edit) or (byGuild and work.guildEdit) or false)
		r.edit:SetEnabled(canChange and not (byGuild and work.guildEdit))
		r.name:SetText(R.NameKey(e.name) or e.name)
		if e.online then
			r.name:SetTextColor(classColor(e.class))
			r.dot:SetVertexColor(0.2, 1, 0.2)
		else
			r.name:SetTextColor(0.55, 0.55, 0.55)
			r.dot:SetVertexColor(0.35, 0.35, 0.35)
		end
		r.rank:SetText(e.gone and L["Fuera de la hermandad"] or (e.rank and names[e.rank]) or "")
		r:Show()
	end
	for i = #all + 1, #rows do rows[i]:Hide() end
	list.child:SetHeight(math.max(1, #all * ROW_H))
	if list.UpdateBar then list:UpdateBar() end
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

function ns.RefreshShare()
	if not win or not win:IsShown() then return end
	local n = note()
	if not n then
		win:Hide()
		return
	end
	local author = editable()
	win.title:SetText(L["Compartir: %s"]:format(n.title ~= "" and n.title or L["Nota"]))

	local s = n.shared
	if not IsInGuild() then
		infoText:SetText(L["Tienes que estar en una hermandad para compartir notas."])
	elseif not s then
		infoText:SetText(L["Elige con quién. Les llega al pulsar «Compartir» si están conectados; si no, al entrar al juego mientras alguien con la nota está conectado. Todos necesitan Rheizor Notas."])
	elseif author then
		infoText:SetText(L["Eres el autor: tú decides quién la ve y quién la edita. Si quitas a alguien, se queda una copia solo suya."])
	else
		infoText:SetText(L["De %s. Solo el autor cambia con quién se comparte.\n%s"]:format(R.NameKey(s.author) or s.author,
			M:CanEditNote(n) and L["Puedes editarla."] or L["Solo lectura."]))
	end

	guildCheck:SetChecked(work.guild)
	guildCheck:SetEnabled(author and IsInGuild())
	guildEditCheck:SetChecked(work.guildEdit)
	guildEditCheck:SetEnabled(author and work.guild)
	rankDrop:SetValues(rankValues(), work.minRank == nil and "all" or work.minRank, function(v)
		work.minRank = v ~= "all" and v or nil
		ns.RefreshShare()
	end)
	rankDrop:EnableMouse(author and work.guild)
	rankDrop:SetAlpha((author and work.guild) and 1 or 0.5)

	saveButton:SetShown(author and IsInGuild())
	saveButton:SetText(s and L["Guardar"] or L["Compartir"])
	stopButton:SetShown(s ~= nil)
	stopButton:SetText(author and L["Dejar de compartir"] or L["Salir (me quedo una copia)"])
	if stopButton.armed then stopButton:SetText(L["|cffff5555¿Seguro? Pulsa otra vez|r"]) end
	drawRows()
end

local function loadWork()
	local n = note()
	local s = n and n.shared
	work = {
		members = s and R.DeepCopy(s.members) or {},
		guild = s and s.guild or false,
		guildEdit = s and s.guildEdit or false,
		minRank = s and s.minRank,
	}
end

local function create()
	local U = ui()
	win = CreateFrame("Frame", "RheizorNotesShare", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	win:RegisterForDrag("LeftButton")
	win:SetScript("OnDragStart", win.StartMoving)
	win:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		self:SetUserPlaced(false)
	end)
	U.backdrop(win, 0.96)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorNotesShare")

	win.title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	win.title:SetPoint("TOPLEFT", 14, -10)
	win.title:SetPoint("RIGHT", -34, 0)
	win.title:SetJustifyH("LEFT")
	win.title:SetWordWrap(false)
	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() win:Hide() end)

	infoText = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	infoText:SetPoint("TOPLEFT", 14, -36)
	infoText:SetPoint("RIGHT", -14, 0)
	infoText:SetJustifyH("LEFT")
	infoText:SetSpacing(2)

	guildCheck = check(win, L["Toda la hermandad"], function(self)
		work.guild = self:GetChecked() and true or false
		if not work.guild then work.guildEdit, work.minRank = false, nil end
		ns.RefreshShare()
	end)
	guildCheck:SetPoint("TOPLEFT", 10, -84)
	guildEditCheck = check(win, L["Pueden editarla"], function(self)
		work.guildEdit = self:GetChecked() and true or false
		ns.RefreshShare()
	end)
	guildEditCheck:SetPoint("LEFT", guildCheck, "LEFT", 190, 0)

	local rankLabel = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	rankLabel:SetPoint("TOPLEFT", 16, -116)
	rankLabel:SetText(L["Rangos"])
	rankDrop = U.dropdown(win, 220)
	rankDrop:SetPoint("LEFT", rankLabel, "LEFT", 90, 0)
	rankDrop:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Rangos"], 1, 1, 1)
		GameTooltip:AddLine(L["Con «Hasta Oficial», la ven los oficiales y los rangos por encima. Los miembros que marques abajo la ven igualmente."], nil, nil, nil, true)
		GameTooltip:Show()
	end)
	rankDrop:SetScript("OnLeave", GameTooltip_Hide)

	searchBox = U.inputBox(win, 200, 40)
	searchBox:SetPoint("TOPLEFT", 12, -146)
	local hint = searchBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("LEFT", 6, 0)
	hint:SetText(L["Buscar…"])
	searchBox:SetScript("OnTextChanged", function(self)
		filter = strtrim(self:GetText() or "")
		hint:SetShown(self:GetText() == "" and not self:HasFocus())
		drawRows()
	end)
	searchBox:HookScript("OnEditFocusGained", function() hint:Hide() end)
	searchBox:HookScript("OnEditFocusLost", function(self) hint:SetShown(self:GetText() == "") end)

	headerEdit = win:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	headerEdit:SetPoint("TOPRIGHT", -18, -152)
	headerEdit:SetText(L["Edita"])

	local box = CreateFrame("Frame", nil, win, "BackdropTemplate")
	box:SetPoint("TOPLEFT", 10, -172)
	box:SetPoint("BOTTOMRIGHT", -10, 60)
	U.backdrop(box, 0.45)
	box:SetBackdropBorderColor(1, 1, 1, 0.08)
	list = U.scroll(box)
	list:SetPoint("TOPLEFT", 2, -2)
	list:SetPoint("BOTTOMRIGHT", -4, 2)
	list.child:SetSize(W - 34, 1)
	rows = {}

	saveButton = U.button(win, L["Compartir"], 130, 24)
	saveButton:SetPoint("BOTTOMLEFT", 12, 28)
	saveButton:SetScript("OnClick", function()
		local n = note()
		if not n or not work then return end
		if not n.shared and not work.guild and not next(work.members) then
			setStatus(L["Marca «Toda la hermandad» o a alguien de la lista."], 1, 0.33, 0.33)
			return
		end
		if M:SetSharing(n, work) then
			loadWork()
			setStatus(L["Hecho. A los conectados les llega ahora; al resto, cuando entren al juego."], 0.2, 1, 0.2)
			if M.RefreshEditor then M:RefreshEditor() end
		else
			setStatus(L["No se ha podido compartir."], 1, 0.33, 0.33)
		end
		ns.RefreshShare()
	end)

	stopButton = U.button(win, L["Dejar de compartir"], 200, 24)
	stopButton:SetPoint("BOTTOMRIGHT", -12, 28)
	stopButton:SetScript("OnClick", function(self)
		local n = note()
		if not n or not n.shared then return end
		if not self.armed then
			self.armed = true
			ns.RefreshShare()
			return
		end
		self.armed = false
		local author = M:IsNoteAuthor(n)
		M:StopSharing(n)
		loadWork()
		setStatus(author and L["Ya no se comparte. A cada uno le queda una copia."]
			or L["Ya no la recibes. Te queda como nota tuya."], 0.2, 1, 0.2)
		if M.RefreshEditor then M:RefreshEditor() end
		ns.RefreshShare()
	end)
	stopButton:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(self:GetText(), 1, 1, 1)
		local n = note()
		if n and M:IsNoteAuthor(n) then
			GameTooltip:AddLine(L["La nota sigue siendo tuya y a cada miembro le queda una copia que ya no se actualiza."], nil, nil, nil, true)
		else
			GameTooltip:AddLine(L["Te quedas la nota tal como está ahora, como nota solo tuya, y dejas de recibir cambios."], nil, nil, nil, true)
		end
		GameTooltip:Show()
	end)
	stopButton:SetScript("OnLeave", GameTooltip_Hide)

	statusText = win:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	statusText:SetPoint("BOTTOMLEFT", 14, 10)
	statusText:SetPoint("RIGHT", -14, 0)
	statusText:SetJustifyH("LEFT")
	statusText:SetWordWrap(false)

	win:SetScript("OnHide", function()
		stopButton.armed = false
		searchBox:ClearFocus()
	end)

	ns.OnRoster(function()
		if win:IsShown() and work then drawRows() end
	end)
end

-- Abre la ventana para esa nota, al lado del editor
function ns.OpenShare(id, anchor)
	if not win then create() end
	noteId = id
	filter = ""
	searchBox:SetText("")
	stopButton.armed = false
	loadWork()
	setStatus("")
	win:ClearAllPoints()
	if anchor and anchor:IsShown() then
		win:SetPoint("TOPLEFT", anchor, "TOPRIGHT", 6, 0)
	else
		win:SetPoint("CENTER")
	end
	win:Show()
	ns.RequestRoster()
	ns.RefreshShare()
end
