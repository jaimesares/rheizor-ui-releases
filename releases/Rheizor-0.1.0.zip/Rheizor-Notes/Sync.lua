-- Notas compartidas con miembros de la hermandad.
--
-- No hay servidor: las notas van de jugador a jugador con mensajes de addon
-- (invisibles en el chat), así que solo se sincronizan entre quienes están
-- conectados a la vez.
--
--   · Al entrar, cada uno avisa a la hermandad de qué notas compartidas tiene
--     y en qué versión (H). Quien tenga una más nueva se la manda (N); quien
--     vaya por detrás la pide (Q). A quien ya no está en una nota se le avisa
--     (X) y se queda una copia solo suya.
--   · Al editar, la nota se manda a los miembros conectados (por susurro, o
--     por el canal de hermandad si es para toda la hermandad).
--   · Solo se aceptan cambios de quien puede editar la nota, según tu copia.
--     Quién la ve y quién la edita solo lo cambia el autor.
--   · Se comparte el título, el texto y la lista de deseos. Dónde se ve, cuándo
--     y su aspecto son de cada uno.
--   · Si dos la cambian sin estar conectados a la vez gana la versión más
--     reciente, y quien pierde la suya se queda con ella como nota aparte.
--
-- La nota guarda en note.shared lo que se sincroniza; note.mine (la creó esta
-- cuenta) y note.shareSent (la versión actual ya salió) son solo locales.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret
local M = ns.M

local PREFIX = "RZNotes"
local CHUNK = 220
local MAX_CHUNKS = 200
local MAX_TITLE = 200
local MAX_TEXT = 30000
local MAX_WISH = 100
local MAX_MEMBERS = 500
local HIST = 30

local store
local roster, rosterLoaded = {}, false   -- [clave] = { name, rank, online, class }
local helloSeen = {}                     -- [clave] = { [uid] = versión que anunció }
local pending, pendingOrder = {}, {}     -- ofertas por aceptar
local lastReply = {}                     -- [uid .. clave] = GetTime()

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local function nameKey(name) return name and R.NameKey(name) end
local function myKey() return nameKey(R.PlayerFullName()) end

local CHARS = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
local function randomID(n)
	local t = {}
	for i = 1, n do
		local r = math.random(1, #CHARS)
		t[i] = CHARS:sub(r, r)
	end
	return table.concat(t)
end

local function now() return GetServerTime and GetServerTime() or time() end

local function isAuthor(s, k) return type(s.authors) == "table" and s.authors[k] == true end

local function inGuildShare(s, k)
	if not s.guild then return false end
	if s.minRank == nil then return true end
	local r = roster[k]
	return r ~= nil and r.rank ~= nil and r.rank <= s.minRank
end

local function isMember(s, k)
	return isAuthor(s, k) or s.members[k] ~= nil or inGuildShare(s, k)
end

local function canEdit(s, k)
	if isAuthor(s, k) then return true end
	local m = s.members[k]
	if m and m.edit then return true end
	return (s.guildEdit and inGuildShare(s, k)) and true or false
end

-- ¿La versión a es más nueva que la b?
local function newer(a, b)
	if a.rev ~= b.rev then return a.rev > b.rev end
	if (a.time or 0) ~= (b.time or 0) then return (a.time or 0) > (b.time or 0) end
	return (a.vid or "") > (b.vid or "")
end

local function inHist(s, vid)
	for _, v in ipairs(s.hist) do
		if v == vid then return true end
	end
	return false
end

local function findUid(uid)
	for _, n in ipairs(M:GetNotes()) do
		if n.shared and n.shared.uid == uid then return n end
	end
end

local function isMyChar(name)
	local k = nameKey(name)
	return k ~= nil and store and store.myChars and store.myChars[k] == true
end

local function authorOnline(s)
	for k in pairs(s.authors) do
		local r = roster[k]
		if r and r.online then return true end
	end
	return false
end

local function titleOf(note)
	return note.title ~= "" and note.title or L["Nota"]
end

----------------------------------------------------------------------
-- Lista de la hermandad
----------------------------------------------------------------------

local function requestRoster()
	if not IsInGuild() then return end
	if C_GuildInfo and C_GuildInfo.GuildRoster then
		pcall(C_GuildInfo.GuildRoster)
	elseif GuildRoster then
		pcall(GuildRoster)
	end
end

local function readRoster()
	if not IsInGuild() then
		wipe(roster)
		rosterLoaded = false
		return
	end
	local n = GetNumGuildMembers()
	n = NS(n)
	if not n or n == 0 then return end
	wipe(roster)
	for i = 1, n do
		local name, _, rank, _, _, _, _, _, online, _, class = GetGuildRosterInfo(i)
		name = NS(name)
		if type(name) == "string" and name ~= "" then
			roster[nameKey(name)] = {
				name = name,
				rank = NS(rank),
				online = NS(online) and true or false,
				class = NS(class),
			}
		end
	end
	rosterLoaded = true
end

-- Para la ventana de compartir: miembros ordenados (conectados primero)
function ns.Roster()
	local list, me = {}, myKey()
	for k, r in pairs(roster) do
		if k ~= me then list[#list + 1] = { key = k, name = r.name, rank = r.rank, online = r.online, class = r.class } end
	end
	table.sort(list, function(a, b)
		if a.online ~= b.online then return a.online end
		return a.name < b.name
	end)
	return list
end

function ns.RosterLoaded() return rosterLoaded end
function ns.RequestRoster() requestRoster() end

function ns.RankNames()
	local out = {}
	local n = GuildControlGetNumRanks and NS(GuildControlGetNumRanks()) or 0
	for i = 1, n or 0 do
		out[i - 1] = NS(GuildControlGetRankName(i)) or tostring(i)
	end
	return out, (n or 0)
end

----------------------------------------------------------------------
-- Envío: trozos de 220 caracteres, a un ritmo que el juego permita
----------------------------------------------------------------------

local function pack(msg)
	local raw = R.Serialize(msg)
	if not raw then return end
	local z = R.Compress and R.Compress(raw)
	if z and #z < #raw then return "Z" .. R.Encode64(z) end
	return "P" .. R.Encode64(raw)
end

local function decode(data)
	local kind = data:sub(1, 1)
	local raw = R.Decode64(data:sub(2))
	if kind == "Z" then
		raw = R.Decompress and R.Decompress(raw)
	elseif kind ~= "P" then
		return
	end
	if type(raw) ~= "string" or #raw > 300000 then return end
	local msg = R.Deserialize(raw)
	if type(msg) == "table" then return msg end
end

local queue, tokens, lastRefill, pausedUntil = {}, 8, 0, 0
local ticker

local function lockdown()
	return C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() == true
end

local function pump()
	local t = GetTime()
	tokens = math.min(8, tokens + (t - lastRefill))
	lastRefill = t
	-- En combates de jefe el juego puede bloquear los mensajes: se espera
	while #queue > 0 and tokens >= 1 and t >= pausedUntil and not lockdown() do
		local m = table.remove(queue, 1)
		local ok, res = pcall(C_ChatInfo.SendAddonMessage, PREFIX, m[1], m[2], m[3])
		local failed = not ok or res == false
		if type(res) == "number" and Enum and Enum.SendAddonMessageResult then
			failed = res ~= Enum.SendAddonMessageResult.Success
		end
		if failed then
			m.tries = (m.tries or 0) + 1
			if m.tries < 5 then table.insert(queue, 1, m) end
			pausedUntil = t + 2
			break
		end
		tokens = tokens - 1
	end
	if #queue == 0 and ticker then
		ticker:Cancel()
		ticker = nil
	end
end

-- tag: una versión nueva de la misma nota para el mismo destino quita de la
-- cola la anterior que aún no ha salido
local function sendPacked(data, chan, target, tag)
	local n = math.ceil(#data / CHUNK)
	if n > MAX_CHUNKS then return false end
	if tag then
		tag = tag .. "\1" .. chan .. "\1" .. (target or "")
		for i = #queue, 1, -1 do
			if queue[i].tag == tag then table.remove(queue, i) end
		end
	end
	local id = randomID(3)
	for i = 1, n do
		queue[#queue + 1] = { id .. ":" .. i .. ":" .. n .. ":" .. data:sub((i - 1) * CHUNK + 1, i * CHUNK), chan, target, tag = tag }
	end
	if not ticker then ticker = C_Timer.NewTicker(0.2, pump) end
	return true
end

local function send(msg, chan, target, tag)
	if chan == "GUILD" and not IsInGuild() then return false end
	local data = pack(msg)
	return data and sendPacked(data, chan, target, tag) or false
end

----------------------------------------------------------------------
-- Nota <-> mensaje
----------------------------------------------------------------------

local function noteMsg(note)
	local s = note.shared
	local wish = {}
	for i, w in ipairs(note.wish) do wish[i] = { id = w.id, want = w.want, name = w.name } end
	return {
		t = "N", uid = s.uid, rev = s.rev, vid = s.vid, time = s.time, by = s.by, hist = s.hist,
		mrev = s.mrev, author = s.author, authors = s.authors, members = s.members,
		guild = s.guild, guildEdit = s.guildEdit, minRank = s.minRank,
		title = note.title, text = note.text, wish = wish,
	}
end

local function str(v, max)
	if type(v) ~= "string" then return nil end
	if #v > max then v = v:sub(1, max) end
	return v
end

-- Lo que llega no puede traer códigos de la interfaz (enlaces, colores):
-- cada | suelto pasa a || y se ve tal cual
local function plain(s)
	if not s then return s end
	s = s:gsub("%z", ""):gsub("\1", "")
	return (s:gsub("||", "\1"):gsub("|", "||"):gsub("\1", "||"))
end

-- Estado y contenido de un mensaje N, comprobados; nil si no vale
local function readNote(m)
	if type(m.uid) ~= "string" or #m.uid > 40 or m.uid == "" then return end
	local s = {
		uid = m.uid,
		rev = tonumber(m.rev), mrev = tonumber(m.mrev), time = tonumber(m.time) or 0,
		vid = str(m.vid, 20), by = str(m.by, 80) or "?", author = str(m.author, 80) or "?",
		guild = m.guild == true, guildEdit = m.guildEdit == true, minRank = tonumber(m.minRank),
		authors = {}, members = {}, hist = {},
	}
	if not s.rev or not s.mrev or not s.vid then return end
	local n = 0
	if type(m.authors) == "table" then
		for k, v in pairs(m.authors) do
			if type(k) == "string" and #k <= 80 and v == true then
				n = n + 1
				if n > 20 then break end
				s.authors[k] = true
			end
		end
	end
	if not next(s.authors) then return end
	n = 0
	if type(m.members) == "table" then
		for k, v in pairs(m.members) do
			if type(k) == "string" and #k <= 80 and type(v) == "table" then
				n = n + 1
				if n > MAX_MEMBERS then break end
				s.members[k] = { name = str(v.name, 80) or k, edit = v.edit == true }
			end
		end
	end
	if type(m.hist) == "table" then
		for i = 1, math.min(#m.hist, HIST) do
			local v = str(m.hist[i], 20)
			if v then s.hist[#s.hist + 1] = v end
		end
	end
	local c = {
		title = plain(str(m.title, MAX_TITLE)) or "",
		text = plain(str(m.text, MAX_TEXT)) or "",
		wish = {},
	}
	if type(m.wish) == "table" then
		for i = 1, math.min(#m.wish, MAX_WISH) do
			local w = m.wish[i]
			local id = type(w) == "table" and tonumber(w.id)
			if id and id > 0 and id == math.floor(id) then
				c.wish[#c.wish + 1] = {
					id = id,
					want = math.max(1, math.min(9999, math.floor(tonumber(w.want) or 1))),
					name = plain(str(w.name, 100)),
				}
			end
		end
	end
	return s, c
end

local function applyMembers(dst, s)
	dst.mrev, dst.author, dst.authors, dst.members = s.mrev, s.author, s.authors, s.members
	dst.guild, dst.guildEdit, dst.minRank = s.guild, s.guildEdit, s.minRank
end

local function applyContent(note, s, c)
	local d = note.shared
	d.rev, d.vid, d.time, d.by, d.hist = s.rev, s.vid, s.time, s.by, s.hist
	note.title, note.text = c.title, c.text
	-- Se conserva lo que ya se había avisado de los deseos que siguen
	local done = {}
	for _, w in ipairs(c.wish) do done[w.id] = note.wishDone[w.id] end
	note.wish, note.wishDone = c.wish, done
	note.shareSent = true
end

----------------------------------------------------------------------
-- Mandar notas
----------------------------------------------------------------------

local function sendNoteTo(note, target)
	if send(noteMsg(note), "WHISPER", target, note.shared.uid) then note.shareSent = true end
end

-- Como mucho una respuesta cada 20 s por nota y persona
local function mayReply(uid, k)
	local id, t = uid .. "\1" .. k, GetTime()
	if lastReply[id] and t - lastReply[id] < 20 then return false end
	lastReply[id] = t
	return true
end

-- A los miembros conectados; con toda la hermandad (sin rango), por su canal
local function push(note)
	local s = note.shared
	if not IsInGuild() then return false end
	if s.guild and not s.minRank then
		if send(noteMsg(note), "GUILD", nil, s.uid) then note.shareSent = true end
		return true
	end
	local me, data, sent = myKey(), nil, false
	for k, r in pairs(roster) do
		if r.online and k ~= me and isMember(s, k) then
			data = data or pack(noteMsg(note))
			if data and sendPacked(data, "WHISPER", r.name, s.uid) then sent = true end
		end
	end
	if sent then note.shareSent = true end
	return sent
end

local function sendRevoke(uid, chan, target)
	send({ t = "X", uid = uid }, chan, target)
end

local pushTimers = {}
local function schedulePush(note, delay)
	local uid = note.shared.uid
	if pushTimers[uid] then pushTimers[uid]:Cancel() end
	pushTimers[uid] = C_Timer.NewTimer(delay or 3, function()
		pushTimers[uid] = nil
		local n = findUid(uid)
		if n and n.shared and R:IsModuleRunning(M) then push(n) end
	end)
end

----------------------------------------------------------------------
-- Pasar a nota propia (te han quitado o te sales)
----------------------------------------------------------------------

local function toLocal(note, why)
	note.shared, note.mine, note.shareSent = nil, nil, nil
	if why then R:Print(why:format(titleOf(note))) end
	M:Refresh()
	if M.RefreshEditor then M:RefreshEditor() end
	if ns.RefreshShare then ns.RefreshShare() end
end

----------------------------------------------------------------------
-- Ofertas: la primera vez que alguien te comparte una nota
----------------------------------------------------------------------

local showNextOffer

local function acceptOffer(uid)
	local p = pending[uid]
	pending[uid] = nil
	if not p or findUid(uid) then return end
	local s, c = p.s, p.c
	local note = M:AddNote({ title = c.title, text = c.text, wish = c.wish, shared = s })
	note.shareSent = true
	R:Print(L["Nota compartida «%s» añadida. Está en /rznotas."]:format(titleOf(note)))
	if M.RefreshEditor then M:RefreshEditor() end
end

local function declineOffer(uid)
	pending[uid] = nil
	store.declined[uid] = now()
end

StaticPopupDialogs.RHEIZOR_NOTES_SHARE = {
	text = L["%s quiere compartir contigo la nota «%s».\n\nSe verá en tus notas y se actualizará cuando alguien la cambie."],
	button1 = L["Aceptar"],
	button2 = L["Rechazar"],
	OnAccept = function(_, data) acceptOffer(data) end,
	OnCancel = function(_, data) declineOffer(data) end,
	-- Si se cerró sin contestar (otra ventana la echó), vuelve a la cola
	OnHide = function(self)
		local uid = self and self.data
		C_Timer.After(0.3, function()
			if uid and pending[uid] then pendingOrder[#pendingOrder + 1] = uid end
			showNextOffer()
		end)
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = false,
	preferredIndex = 3,
}

function showNextOffer()
	if StaticPopup_Visible and StaticPopup_Visible("RHEIZOR_NOTES_SHARE") then return end
	while #pendingOrder > 0 do
		local uid = table.remove(pendingOrder, 1)
		local p = pending[uid]
		if p and not findUid(uid) then
			StaticPopup_Show("RHEIZOR_NOTES_SHARE", p.from, p.c.title ~= "" and p.c.title or L["Nota"], uid)
			return
		end
		pending[uid] = nil
	end
end

local function offer(s, c, sender)
	if not pending[s.uid] then pendingOrder[#pendingOrder + 1] = s.uid end
	pending[s.uid] = { s = s, c = c, from = R.NameKey(sender) or sender }
	showNextOffer()
end

----------------------------------------------------------------------
-- Mensajes recibidos
----------------------------------------------------------------------

-- Tu versión se pierde: se queda como nota aparte
local function keepMine(note)
	local copy = M:DuplicateNote(note.id)
	if copy then
		copy.title = L["%s (tu versión)"]:format(titleOf(note))
		R:Print(L["«%s» cambió también en otro sitio y gana la versión más reciente. La tuya está en la nota «%s»."]:format(titleOf(note), copy.title))
	end
end

local function onNote(m, sender, sk)
	local s, c = readNote(m)
	if not s then return end
	local me = myKey()
	local note = findUid(s.uid)
	if not note then
		if store.declined[s.uid] or store.tombs[s.uid] then return end
		if not isMember(s, me) or not canEdit(s, sk) then return end
		offer(s, c, sender)
		return
	end

	local mine = note.shared
	-- Solo de quien puede editarla según tu copia
	if not canEdit(mine, sk) then return end
	local changed = false
	if s.mrev > mine.mrev then
		applyMembers(mine, s)
		changed = true
	end
	if newer(s, mine) then
		if mine.vid ~= s.vid and not inHist(s, mine.vid) and isMyChar(mine.by) then keepMine(note) end
		applyContent(note, s, c)
		changed = true
		if M.OnRemoteUpdate then M:OnRemoteUpdate(note, s.by) end
	elseif (newer(mine, s) or mine.mrev > s.mrev) and isMember(mine, sk) and mayReply(s.uid, sk) then
		-- Va por detrás: se le manda la tuya
		sendNoteTo(note, sender)
	end
	-- ¿Sigue en ella alguno de tus personajes? (la nota es de toda la cuenta).
	-- Con la hermandad por rangos hace falta la lista para saberlo.
	local still = isMember(mine, me)
	for k in pairs(store.myChars) do still = still or isMember(mine, k) end
	if not still and not note.mine and (rosterLoaded or not mine.guild) then
		toLocal(note, L["Ya no estás en la nota compartida «%s»: te queda una copia solo tuya."])
		return
	end
	if changed then
		M:RenderNote(note.id)
		M:UpdateVisibility()
	end
end

local function onRevoke(m, sk)
	local note = type(m.uid) == "string" and findUid(m.uid)
	if not note or note.mine then return end
	if not canEdit(note.shared, sk) then return end
	toLocal(note, L["Ya no estás en la nota compartida «%s»: te queda una copia solo tuya."])
end

-- ¿Contesto yo? El autor si está; si no, quien pueda editarla
local function responder(s)
	local me = myKey()
	if not canEdit(s, me) then return false end
	if isAuthor(s, me) or not authorOnline(s) then return true end
	-- El autor está conectado: contesta él, salvo que vaya por detrás de ti
	for k in pairs(s.authors) do
		local v = helloSeen[k] and helloSeen[k][s.uid]
		if v and not (newer(s, v) or s.mrev > v.mrev) then return false end
	end
	return true
end

local function onHello(m, sender, sk)
	local seen = {}
	if type(m.have) == "table" then
		for uid, v in pairs(m.have) do
			if type(uid) == "string" and type(v) == "table" then
				seen[uid] = { rev = tonumber(v[1]) or 0, mrev = tonumber(v[2]) or 0, vid = tostring(v[3] or ""), time = tonumber(v[4]) or 0 }
			end
		end
	end
	helloSeen[sk] = seen
	local no = {}
	if type(m.no) == "table" then
		for _, uid in ipairs(m.no) do
			if type(uid) == "string" then no[uid] = true end
		end
	end

	local me, want = myKey(), {}
	for _, note in ipairs(M:GetNotes()) do
		local s = note.shared
		if s and isMember(s, me) then
			local theirs = seen[s.uid]
			if isMember(s, sk) then
				if not theirs then
					-- No la tiene: se la ofrece quien contesta
					if not no[s.uid] and responder(s) and mayReply(s.uid, sk) then sendNoteTo(note, sender) end
				else
					if (newer(s, theirs) or s.mrev > theirs.mrev) and responder(s) and mayReply(s.uid, sk) then
						sendNoteTo(note, sender)
					end
					if (newer(theirs, s) or theirs.mrev > s.mrev) and canEdit(s, sk) then want[#want + 1] = s.uid end
				end
			elseif theirs and responder(s) and mayReply(s.uid, sk) then
				-- La tiene pero ya no está en ella
				sendRevoke(s.uid, "WHISPER", sender)
			end
		end
	end
	-- Notas que dejaste de compartir o borraste siendo el autor
	for uid in pairs(seen) do
		if store.tombs[uid] and mayReply(uid, sk) then sendRevoke(uid, "WHISPER", sender) end
	end
	if #want > 0 then send({ t = "Q", uids = want }, "WHISPER", sender) end
end

local function onRequest(m, sender, sk)
	if type(m.uids) ~= "table" then return end
	for i = 1, math.min(#m.uids, 50) do
		local note = type(m.uids[i]) == "string" and findUid(m.uids[i])
		if note and isMember(note.shared, sk) and mayReply(note.shared.uid, sk) then sendNoteTo(note, sender) end
	end
end

local function handle(m, sender)
	local sk = nameKey(sender)
	if not sk then return end
	if m.t == "N" then
		onNote(m, sender, sk)
	elseif m.t == "H" then
		onHello(m, sender, sk)
	elseif m.t == "Q" then
		onRequest(m, sender, sk)
	elseif m.t == "X" then
		onRevoke(m, sk)
	end
end

-- Trozos a medio llegar: [remitente:id] = { n, got, parts, time }
local partial, partialCount = {}, 0

local function prunePartial()
	local t = GetTime()
	for k, p in pairs(partial) do
		if t - p.time > 120 then
			partial[k] = nil
			partialCount = partialCount - 1
		end
	end
end

local function onAddonMessage(prefix, text, _, sender)
	if prefix ~= PREFIX or not R:IsModuleRunning(M) then return end
	text, sender = NS(text), NS(sender)
	if type(text) ~= "string" or type(sender) ~= "string" or R.IsMyName(sender) then return end
	local id, i, n, body = text:match("^(%w+):(%d+):(%d+):(.*)$")
	i, n = tonumber(i), tonumber(n)
	if not id or not i or not n or n > MAX_CHUNKS or i < 1 or i > n then return end
	local k = sender .. ":" .. id
	local p = partial[k]
	if not p then
		if partialCount > 100 then prunePartial() end
		if partialCount > 100 then return end
		p = { n = n, got = 0, parts = {}, time = GetTime() }
		partial[k] = p
		partialCount = partialCount + 1
	end
	if p.n ~= n or p.parts[i] then return end
	p.parts[i] = body
	p.got = p.got + 1
	if p.got < n then return end
	partial[k] = nil
	partialCount = partialCount - 1
	local msg = decode(table.concat(p.parts))
	if msg then
		local ok, err = pcall(handle, msg, sender)
		if not ok then geterrorhandler()(err) end
	end
end

----------------------------------------------------------------------
-- Aviso al entrar
----------------------------------------------------------------------

local function sendHello()
	if not IsInGuild() or not R:IsModuleRunning(M) then return end
	local me, have = myKey(), {}
	for _, n in ipairs(M:GetNotes()) do
		local s = n.shared
		if s and isMember(s, me) then have[s.uid] = { s.rev, s.mrev, s.vid, s.time } end
	end
	local no = {}
	for uid in pairs(store.declined) do
		no[#no + 1] = uid
		if #no >= 100 then break end
	end
	send({ t = "H", have = have, no = no }, "GUILD")
end

----------------------------------------------------------------------
-- Lo que usan Notes.lua, el editor y la ventana de compartir
----------------------------------------------------------------------

function M:IsShared(note) return note and note.shared ~= nil end

function M:CanEditNote(note)
	if not note or not note.shared then return true end
	return note.mine or canEdit(note.shared, myKey())
end

function M:IsNoteAuthor(note)
	return note and note.shared and (note.mine or isAuthor(note.shared, myKey())) and true or false
end

-- Texto corto para el editor
function M:ShareStatus(note)
	local s = note and note.shared
	if not s then return L["Solo tuya"] end
	if self:IsNoteAuthor(note) then
		local n = 0
		for _ in pairs(s.members) do n = n + 1 end
		if s.guild then return L["Compartida con la hermandad"] end
		return L["Compartida con %d"]:format(n)
	end
	if canEdit(s, myKey()) then return L["De %s · puedes editarla"]:format(R.NameKey(s.author) or s.author) end
	return L["De %s · solo lectura"]:format(R.NameKey(s.author) or s.author)
end

-- Al cambiar el título, el texto, una casilla o la lista de deseos
function M:NoteEdited(note)
	local s = note and note.shared
	if not s or not self:CanEditNote(note) then return end
	if note.shareSent ~= false then
		-- La versión anterior ya salió: esta es otra
		table.insert(s.hist, 1, s.vid)
		for i = #s.hist, HIST + 1, -1 do s.hist[i] = nil end
		s.rev = s.rev + 1
		s.vid = randomID(8)
		note.shareSent = false
	end
	s.time = now()
	s.by = R.PlayerFullName()
	schedulePush(note, 3)
end

-- Compartir o cambiar con quién (solo el autor).
-- cfg = { members = { [clave] = { name, edit } }, guild, guildEdit, minRank }
function M:SetSharing(note, cfg)
	local me = myKey()
	local s = note.shared
	local before = s and R.DeepCopy(s)
	if s and not self:IsNoteAuthor(note) then return false end
	if not IsInGuild() then return false end
	if not s then
		s = {
			uid = randomID(12), rev = 1, vid = randomID(8), time = now(), by = R.PlayerFullName(),
			author = R.PlayerFullName(), authors = { [me] = true }, hist = {}, mrev = 0, members = {},
		}
		note.shared, note.mine, note.shareSent = s, true, false
	end
	s.authors[me] = true
	s.members = R.DeepCopy(cfg.members or {})
	for k in pairs(s.authors) do s.members[k] = nil end
	s.guild = cfg.guild and true or false
	s.guildEdit = s.guild and cfg.guildEdit and true or false
	s.minRank = s.guild and tonumber(cfg.minRank) or nil
	s.mrev = s.mrev + 1
	store.tombs[s.uid] = nil
	-- A quien ya no está (y está conectado) se le avisa ahora; al resto, al entrar
	if before then
		for k, r in pairs(roster) do
			if r.online and k ~= me and isMember(before, k) and not isMember(s, k) then
				sendRevoke(s.uid, "WHISPER", r.name)
			end
		end
	end
	push(note)
	self:Refresh()
	return true
end

-- Autor: deja de compartirla con todos (a cada uno le queda una copia).
-- Miembro: sale de ella y se queda la nota como propia.
function M:StopSharing(note)
	local s = note and note.shared
	if not s then return end
	if self:IsNoteAuthor(note) then
		if s.guild and not s.minRank then
			sendRevoke(s.uid, "GUILD")
		else
			local me = myKey()
			for k, r in pairs(roster) do
				if r.online and k ~= me and isMember(s, k) then sendRevoke(s.uid, "WHISPER", r.name) end
			end
		end
		store.tombs[s.uid] = now()
		toLocal(note)
	else
		store.declined[s.uid] = now()
		toLocal(note)
	end
end

-- Borrar una nota compartida es lo mismo que dejarla (Notes.lua lo llama
-- antes de quitarla)
function M:OnSharedDeleted(note)
	local s = note.shared
	if self:IsNoteAuthor(note) then
		self:StopSharing(note)
	else
		store.declined[s.uid] = now()
	end
end

----------------------------------------------------------------------
-- Arranque y eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
local helloSent = false
local rosterListeners = {}
function ns.OnRoster(fn) rosterListeners[#rosterListeners + 1] = fn end

events:SetScript("OnEvent", function(_, event, ...)
	if event == "CHAT_MSG_ADDON" then
		onAddonMessage(...)
	elseif event == "GUILD_ROSTER_UPDATE" or event == "PLAYER_GUILD_UPDATE" then
		readRoster()
		for _, fn in ipairs(rosterListeners) do pcall(fn) end
		if rosterLoaded and not helloSent and R:IsModuleRunning(M) then
			helloSent = true
			C_Timer.After(3 + math.random() * 3, sendHello)
		end
	end
end)

local function prune(t, days)
	local limit = now() - days * 86400
	for k, v in pairs(t) do
		if type(v) ~= "number" or v < limit then t[k] = nil end
	end
end

function M:SyncEnable(db)
	store = db
	if type(store.declined) ~= "table" then store.declined = {} end
	if type(store.tombs) ~= "table" then store.tombs = {} end
	if type(store.myChars) ~= "table" then store.myChars = {} end
	prune(store.declined, 180)
	prune(store.tombs, 90)

	local me = myKey()
	if me then store.myChars[me] = true end
	-- Tus otros personajes también son autores de tus notas
	for _, n in ipairs(store.notes) do
		local s = n.shared
		if type(s) == "table" and n.mine and me and not isAuthor(s, me) then
			s.authors[me] = true
			s.members[me] = nil
			s.mrev = s.mrev + 1
			n.shareSent = false
		end
	end

	if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
		C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
	end
	for _, e in ipairs({ "CHAT_MSG_ADDON", "GUILD_ROSTER_UPDATE", "PLAYER_GUILD_UPDATE" }) do
		pcall(events.RegisterEvent, events, e)
	end
	requestRoster()
	-- La lista de la hermandad dice quién está conectado
	if not self.rosterTicker then self.rosterTicker = C_Timer.NewTicker(60, requestRoster) end
end
