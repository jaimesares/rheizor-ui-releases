-- Rheizor-Notes: Markdown sencillo para las notas.
--
-- Cada línea del texto es un bloque (no se juntan líneas como en el
-- Markdown estricto: en una nota es más natural que cada línea sea una):
--   # Título  ## Subtítulo  ### Apartado
--   - lista  * lista  + lista   (con espacios delante, sublista)
--   1. lista numerada
--   - [ ] casilla   - [x] casilla marcada   (se marcan con un clic)
--   > cita
--   ---   línea separadora
--   ```   bloque de código (hasta el siguiente ```)
-- Dentro de una línea:
--   **negrita**  *cursiva*  _cursiva_  ~~tachado~~  ==resaltado==  `código`
--   [texto](https://…)          enlace (clic: se puede copiar)
--   {item:12345}  {spell:12345} objeto o hechizo con icono y tooltip
--   {rt1}…{rt8}, {star} {skull}…  marcas de banda
--   {icon:Interface\Icons\…}     cualquier icono del juego
-- Los enlaces que se pegan con Mayús + clic se guardan como {item:…}.
--
-- Los colores de negrita, cursiva… no pueden cambiar la letra (una línea
-- de texto de WoW tiene una sola fuente), así que se marcan con color.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local NS = R.NotSecret

local MD = {}
ns.md = MD

MD.COLORS = {
	bold = "ffd100",
	italic = "8fd0ff",
	code = "ff9966",
	strike = "808080",
	mark = "66ff66",
	link = "66bbff",
}

----------------------------------------------------------------------
-- Iconos, marcas de banda, objetos y hechizos
----------------------------------------------------------------------

local MARKERS = {
	star = 1, circle = 2, diamond = 3, triangle = 4, moon = 5, square = 6, cross = 7, x = 7, skull = 8,
	estrella = 1, circulo = 2, ["círculo"] = 2, rombo = 3, diamante = 3, triangulo = 4, ["triángulo"] = 4,
	luna = 5, cuadrado = 6, cruz = 7, calavera = 8,
}

local function icon(path, size)
	if not path then return "" end
	return ("|T%s:%d:%d|t"):format(tostring(path), size or 0, size or 0)
end

local function marker(n, size)
	return icon("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. n, size)
end

-- Algún objeto aún no está en la caché: se vuelve a dibujar al llegar
MD.waiting = false

function MD.ItemInfo(id)
	local name, link, quality
	if C_Item and C_Item.GetItemInfo then
		local ok, n, l, q = pcall(C_Item.GetItemInfo, id)
		if ok then name, link, quality = NS(n), NS(l), NS(q) end
	elseif GetItemInfo then
		local ok, n, l, q = pcall(GetItemInfo, id)
		if ok then name, link, quality = NS(n), NS(l), NS(q) end
	end
	local tex
	local fn = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
	if fn then
		local ok, t = pcall(fn, id)
		tex = ok and NS(t) or nil
	end
	if not name then
		MD.waiting = true
		if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
	end
	return name, link, quality, tex
end

function MD.SpellInfo(id)
	local name, tex
	if C_Spell and C_Spell.GetSpellName then
		local ok, n = pcall(C_Spell.GetSpellName, id)
		name = ok and NS(n) or nil
		local ok2, t = pcall(C_Spell.GetSpellTexture, id)
		tex = ok2 and NS(t) or nil
	elseif GetSpellInfo then
		local ok, n, _, t = pcall(GetSpellInfo, id)
		if ok then name, tex = NS(n), NS(t) end
	end
	return name, tex
end

local function itemToken(id, size)
	id = tonumber(id)
	if not id then return end
	local name, link, _, tex = MD.ItemInfo(id)
	if link then return icon(tex, size) .. link end
	return icon(tex, size) .. "|cff9d9d9d|Hitem:" .. id .. "|h[" .. (name or ("item:" .. id)) .. "]|h|r"
end

local function spellToken(id, size)
	id = tonumber(id)
	if not id then return end
	local name, tex = MD.SpellInfo(id)
	return icon(tex, size) .. "|cff71d5ff|Hspell:" .. id .. ":0|h[" .. (name or ("spell:" .. id)) .. "]|h|r"
end

-- {algo} → icono o enlace; lo que no se reconoce se deja tal cual
local function token(body, size)
	local kind, arg = body:match("^(%a+):(.+)$")
	kind = kind and kind:lower()
	if kind == "item" or kind == "objeto" then return itemToken(arg, size) end
	if kind == "spell" or kind == "hechizo" then return spellToken(arg, size) end
	if kind == "icon" or kind == "icono" then return icon(arg, size) end
	local lower = body:lower()
	local n = lower:match("^rt(%d)$")
	if n and tonumber(n) >= 1 and tonumber(n) <= 8 then return marker(n, size) end
	if MARKERS[lower] then return marker(MARKERS[lower], size) end
end

----------------------------------------------------------------------
-- Formato dentro de una línea
----------------------------------------------------------------------

local function colored(hex, text)
	return "|cff" .. hex .. text .. "|r"
end

-- urls: tabla donde se guardan los enlaces (el texto del enlace de WoW no
-- puede llevar todos los caracteres de una dirección)
function MD.Inline(text, size, urls)
	local C = MD.COLORS
	local saved = {}
	local function keep(s)
		saved[#saved + 1] = s
		return "\001" .. #saved .. "\002"
	end
	-- `código`: lo de dentro no se interpreta
	text = text:gsub("`([^`]+)`", function(s) return keep(colored(C.code, s)) end)
	-- Enlaces de chat pegados tal cual: no se tocan
	text = text:gsub("|c[^|]*|H.-|h.-|h|r", keep)
	text = text:gsub("|H.-|h.-|h", keep)
	-- {item:…}, {spell:…}, {rt1}, {skull}…
	text = text:gsub("{([^{}]+)}", function(body)
		local r = token(body, size)
		return r and keep(r) or nil
	end)
	-- [texto](dirección)
	text = text:gsub("%[([^%]]+)%]%(([^%)%s]+)%)", function(label, url)
		local id = "0"
		if urls then
			urls[#urls + 1] = url
			id = tostring(#urls)
		end
		return keep("|cff" .. C.link .. "|Hrznotes:url:" .. id .. "|h" .. label .. "|h|r")
	end)
	text = text:gsub("%*%*(.-)%*%*", function(s) return colored(C.bold, s) end)
	text = text:gsub("__(.-)__", function(s) return colored(C.bold, s) end)
	text = text:gsub("~~(.-)~~", function(s) return colored(C.strike, s) end)
	text = text:gsub("==(.-)==", function(s) return colored(C.mark, s) end)
	text = text:gsub("%*([^%*%s][^%*]-)%*", function(s) return colored(C.italic, s) end)
	text = text:gsub("^_([^_]+)_", function(s) return colored(C.italic, s) end)
	text = text:gsub("([%s%(])_([^_]+)_", function(pre, s) return pre .. colored(C.italic, s) end)
	-- Lo guardado vuelve a su sitio (puede haber guardados dentro de guardados)
	for _ = 1, 3 do
		local n
		text, n = text:gsub("\001(%d+)\002", function(i) return saved[tonumber(i)] end)
		if n == 0 then break end
	end
	return text
end

----------------------------------------------------------------------
-- Bloques: una tabla por línea
--   { kind = "h1"|"h2"|"h3"|"p"|"bullet"|"number"|"check"|"quote"|"hr"|
--            "code"|"blank", text, level, number, checked, line }
-- line es el número de línea en el texto original (para marcar casillas)
----------------------------------------------------------------------

function MD.Parse(text)
	local blocks = {}
	local inCode = false
	local n = 0
	text = (text or ""):gsub("\r\n", "\n"):gsub("\t", "  ")
	for line in (text .. "\n"):gmatch("(.-)\n") do
		n = n + 1
		local b
		if line:match("^%s*```") then
			inCode = not inCode
		elseif inCode then
			b = { kind = "code", text = line }
		elseif line:match("^%s*$") then
			b = { kind = "blank" }
		else
			local hashes, rest = line:match("^%s*(#+)%s+(.*)$")
			if hashes then
				b = { kind = "h" .. math.min(#hashes, 3), text = rest }
			elseif line:match("^%s*([-*_])%s*%1%s*%1[-*_%s]*$") then
				b = { kind = "hr" }
			else
				local quote = line:match("^%s*>%s?(.*)$")
				if quote then
					b = { kind = "quote", text = quote }
				else
					local sp, mark, rest2 = line:match("^(%s*)[-*+]%s+%[([ xX])%]%s*(.*)$")
					if sp then
						b = { kind = "check", text = rest2, checked = mark ~= " ", level = math.floor(#sp / 2) }
					else
						local sp2, rest3 = line:match("^(%s*)[-*+]%s+(.*)$")
						if sp2 then
							b = { kind = "bullet", text = rest3, level = math.floor(#sp2 / 2) }
						else
							local sp3, num, rest4 = line:match("^(%s*)(%d+)[%.%)]%s+(.*)$")
							if sp3 then
								b = { kind = "number", text = rest4, number = num, level = math.floor(#sp3 / 2) }
							else
								b = { kind = "p", text = line }
							end
						end
					end
				end
			end
		end
		if b then
			b.line = n
			-- Varias líneas vacías seguidas cuentan como una
			if not (b.kind == "blank" and (#blocks == 0 or blocks[#blocks].kind == "blank")) then
				blocks[#blocks + 1] = b
			end
		end
	end
	while #blocks > 0 and blocks[#blocks].kind == "blank" do blocks[#blocks] = nil end
	return blocks
end

-- Marca o desmarca la casilla de la línea indicada; devuelve el texto nuevo
function MD.ToggleCheck(text, lineNumber)
	local out, n = {}, 0
	for line in ((text or ""):gsub("\r\n", "\n") .. "\n"):gmatch("(.-)\n") do
		n = n + 1
		if n == lineNumber then
			line = line:gsub("^(%s*[-*+]%s+%[)([ xX])(%])", function(a, mark, c)
				return a .. (mark == " " and "x" or " ") .. c
			end, 1)
		end
		out[#out + 1] = line
	end
	return table.concat(out, "\n")
end

-- Desmarca todas las casillas
function MD.ClearChecks(text)
	local out = {}
	for line in ((text or ""):gsub("\r\n", "\n") .. "\n"):gmatch("(.-)\n") do
		out[#out + 1] = (line:gsub("^(%s*[-*+]%s+%[)[xX](%])", "%1 %2", 1))
	end
	return table.concat(out, "\n")
end

-- Ayuda para el editor
MD.HELP = {
	{ "# Título / ## Subtítulo / ### Apartado", "Títulos" },
	{ "- elemento   (2 espacios delante: sublista)", "Lista" },
	{ "1. elemento", "Lista numerada" },
	{ "- [ ] tarea   - [x] hecha", "Casillas (clic para marcar)" },
	{ "> texto", "Cita" },
	{ "---", "Línea separadora" },
	{ "``` … ```", "Bloque de código" },
	{ "**negrita**  *cursiva*  ~~tachado~~  ==resaltado==  `código`", "Formato" },
	{ "[texto](https://…)", "Enlace" },
	{ "{item:13468}  {spell:2825}", "Objeto o hechizo (o Mayús + clic en uno)" },
	{ "{rt1}…{rt8}  {star} {skull}…", "Marcas de banda" },
}
