-- Rheizor-Notes: notas en pantalla escritas en Markdown (Markdown.lua).
--
-- Cada nota decide cuándo se ve (siempre, sin grupo, en grupo, en banda,
-- en mazmorras, en ciertas zonas, con o sin combate, en qué personajes) y
-- puede llevar una lista de deseos: objetos y cuántos quieres, con lo que
-- tienes en bolsas, banco y (con Rheizor Personajes) tus otros personajes.
--
-- Las notas se guardan en RheizorNotesDB, compartido por toda la cuenta y
-- aparte de los perfiles: cambiar de perfil no las borra. Las opciones
-- generales (bloquear, tooltip…) sí van en el perfil.
--
-- Una nota puede compartirse con miembros de la hermandad (Sync.lua y la
-- ventana de Share.lua): su título, texto y lista de deseos se sincronizan.
--
-- Nada de esto es protegido: las notas se muestran y ocultan también en
-- combate. Los valores que el juego pueda dar "secretos" en combate (zona,
-- instancia) se leen con R.NotSecret y, si no se pueden leer, se mantiene
-- el último estado conocido.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret
local MD = ns.md

local WHITE = "Interface\\Buttons\\WHITE8X8"
local ACCENT = "33ccff"
local PAD = 6

----------------------------------------------------------------------
-- Listas de valores (las traduce RegisterModule o el editor)
----------------------------------------------------------------------

ns.FONTS = {
	{ "default", "Fuente del juego" },
	{ "arialn", "Arial Narrow" },
	{ "friz", "Friz Quadrata" },
	{ "skurri", "Skurri" },
	{ "morpheus", "Morpheus" },
}

local FONT_FILES = {
	arialn = "Fonts\\ARIALN.TTF",
	friz = "Fonts\\FRIZQT__.TTF",
	skurri = "Fonts\\skurri.ttf",
	morpheus = "Fonts\\MORPHEUS.TTF",
}
for _, f in ipairs(R.EXTRA_FONTS or {}) do
	ns.FONTS[#ns.FONTS + 1] = { f[1], f[3] }
	FONT_FILES[f[1]] = f[2]
end

ns.GROUPS = {
	{ "always", "Siempre" },
	{ "solo", "Solo sin grupo" },
	{ "party", "En grupo (no en banda)" },
	{ "raid", "En banda" },
	{ "group", "En grupo o en banda" },
}

ns.INSTANCES = {
	{ "any", "En cualquier sitio" },
	{ "world", "Fuera de instancias" },
	{ "dungeon", "En mazmorras" },
	{ "raid", "En instancias de banda" },
	{ "pvp", "En campos de batalla y arenas" },
	{ "instance", "En cualquier instancia" },
}

ns.COMBAT = {
	{ "any", "Con y sin combate" },
	{ "hide", "Ocultar en combate" },
	{ "only", "Solo en combate" },
}

function ns.ValueText(values, value)
	for _, v in ipairs(values) do
		if v[1] == value then return L[v[2]] end
	end
	return tostring(value or "")
end

function ns.SetFont(fs, key, size, flags)
	local ok, set = pcall(fs.SetFont, fs, FONT_FILES[key] or STANDARD_TEXT_FONT, size or 12, flags or "")
	if not ok or not set then pcall(fs.SetFont, fs, STANDARD_TEXT_FONT, size or 12, flags or "") end
	fs:SetShadowColor(0, 0, 0, 1)
	fs:SetShadowOffset(1, -1)
end

----------------------------------------------------------------------
-- Módulo
----------------------------------------------------------------------

local M = R:RegisterModule("notes", {
	title = "Notas",
	defaults = {
		locked = true,
		hideAll = false,
		interactive = true,
		tooltip = true,
		sound = true,
		stackAll = false,
		accordion = false,
		stackHeader = true,
		stackWidth = true,
		grow = "down",
		stackGap = 4,
		combatCollapse = false,
		idleAlpha = 1,
	},
	options = {
		{ type = "header", text = "Notas" },
		{ type = "button", name = "Editor de notas", text = "Abrir",
		  desc = "Crear, escribir y borrar notas, elegir cuándo se ve cada una y su lista de deseos. También con /rznotas o /rz notas.",
		  func = function(mod) mod:ToggleEditor() end },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueadas se ven todas las notas activas, cada una con un recuadro para arrastrarla." },
		{ type = "toggle", key = "hideAll", name = "Ocultar todas las notas",
		  desc = "Sin borrarlas ni cambiar sus reglas. También con /rznotas ocultar y /rznotas mostrar." },
		{ type = "toggle", key = "interactive", name = "Se puede hacer clic en las notas",
		  desc = "Marcar casillas, ver el tooltip de objetos y hechizos, plegar la nota con un clic en su título (clic derecho: editarla) y desplazarla con la rueda. Desactivado, los clics atraviesan las notas." },
		{ type = "toggle", key = "combatCollapse", name = "Plegar las notas en combate",
		  desc = "Mientras dura el combate solo se ve su título; al salir vuelven como estaban. Solo en las notas con barra de título." },
		{ type = "slider", key = "idleAlpha", name = "Opacidad sin el ratón encima", min = 0.1, max = 1, step = 0.05,
		  desc = "100% = siempre igual. Por debajo, las notas se atenúan hasta que pasas el ratón por encima." },

		{ type = "header", text = "Grupos de notas" },
		{ type = "toggle", key = "stackAll", name = "Juntar todas las notas en una columna",
		  desc = "Las notas sin grupo van juntas en el grupo «Notas».\nCada nota puede tener además su propio grupo (en el editor, «Grupo de notas»): las del mismo grupo van una debajo de otra, en el orden de la lista, y se mueven juntas." },
		{ type = "toggle", key = "accordion", name = "Modo acordeón",
		  desc = "Al desplegar una nota se pliegan las demás de su grupo: solo queda una abierta." },
		{ type = "toggle", key = "stackHeader", name = "Barra con el nombre del grupo",
		  desc = "Clic: plegar o desplegar el grupo entero. Clic derecho: abrir el editor." },
		{ type = "toggle", key = "stackWidth", name = "Mismo ancho en todo el grupo",
		  desc = "Todas con el ancho de la más ancha." },
		{ type = "dropdown", key = "grow", name = "Los grupos crecen",
		  values = { { "down", "Hacia abajo" }, { "up", "Hacia arriba" } } },
		{ type = "slider", key = "stackGap", name = "Separación entre notas del grupo", min = 0, max = 30, step = 1, format = R.fmt.int },

		{ type = "header", text = "Lista de deseos" },
		{ type = "toggle", key = "tooltip", name = "En el tooltip de los objetos",
		  desc = "Al pasar el ratón por un objeto que está en una lista de deseos: cuántos tienes y cuántos quieres." },
		{ type = "toggle", key = "sound", name = "Sonido al completar un deseo" },
	},
})
ns.M = M

local db            -- opciones (perfil)
local store         -- RheizorNotesDB
local frames = {}   -- [id] = marco de la nota
local editorOpen, editorSelected = false, nil
local primed = false  -- las bolsas ya se han leído: se puede avisar de deseos cumplidos

local NOTE_DEFAULTS = {
	title = "",
	text = "",
	enabled = true,
	owner = nil,            -- nil: todos los personajes; si no, la clave del personaje
	group = "always",
	instance = "any",
	zones = "",
	combat = "any",
	hideMounted = false,
	collapsed = false,
	stack = "",             -- grupo de notas: las del mismo nombre van juntas
	showTitle = true,
	width = 260,
	maxHeight = 0,          -- 0: todo lo que ocupe
	scale = 1,
	fontSize = 12,
	font = "default",
	textColor = "ffffff",
	bgAlpha = 0.55,
	border = true,
	wish = {},              -- { { id = 13468, want = 20, name = "…" }, … }
	wishBank = true,
	wishAlts = false,
	wishAlert = true,
	wishHideDone = false,
	wishDone = {},          -- [id] = true: ya se avisó de que está completo
}

local function fill(note)
	for k, v in pairs(NOTE_DEFAULTS) do
		if note[k] == nil then note[k] = R.DeepCopy(v) end
	end
	return note
end

function M:GetNotes()
	return store and store.notes or {}
end

function M:FindNote(id)
	for _, n in ipairs(self:GetNotes()) do
		if n.id == id then return n end
	end
end

local function defaultPoint(k)
	k = (k or 0) % 8
	return { "TOPLEFT", "TOPLEFT", 60 + k * 24, -200 - k * 24 }
end

function M:NewNote()
	local id = store.nextID
	store.nextID = id + 1
	local note = fill({ id = id })
	note.title = L["Nota %d"]:format(id)
	note.text = "## " .. note.title .. "\n- [ ] " .. L["Primera tarea"] .. "\n- [ ] " .. L["Segunda tarea"]
	note.point = defaultPoint(#store.notes)
	table.insert(store.notes, note)
	self:Refresh()
	return note
end

-- Nota nueva con estos campos (una nota compartida que llega, Sync.lua)
function M:AddNote(fields)
	local note = fill(R.DeepCopy(fields))
	note.id = store.nextID
	store.nextID = note.id + 1
	note.point = defaultPoint(#store.notes)
	table.insert(store.notes, note)
	self:Refresh()
	return note
end

function M:DuplicateNote(id)
	local src = self:FindNote(id)
	if not src then return end
	local note = R.DeepCopy(src)
	note.id = store.nextID
	store.nextID = note.id + 1
	note.title = L["%s (copia)"]:format(src.title ~= "" and src.title or "?")
	note.wishDone = {}
	-- La copia es solo tuya
	note.shared, note.mine, note.shareSent = nil, nil, nil
	local p = src.point or defaultPoint(0)
	note.point = { p[1], p[2], (p[3] or 0) + 24, (p[4] or 0) - 24 }
	table.insert(store.notes, note)
	self:Refresh()
	return note
end

function M:DeleteNote(id)
	for i, n in ipairs(store.notes) do
		if n.id == id then
			if n.shared and self.OnSharedDeleted then self:OnSharedDeleted(n) end
			table.remove(store.notes, i)
			break
		end
	end
	local f = frames[id]
	if f then
		f:Hide()
		f.note = nil
	end
	self:Refresh()
end

function M:MoveNote(id, delta)
	local list = store.notes
	for i, n in ipairs(list) do
		if n.id == id then
			local j = i + delta
			if j >= 1 and j <= #list then list[i], list[j] = list[j], list[i] end
			break
		end
	end
end

----------------------------------------------------------------------
-- ¿Se ve ahora?
----------------------------------------------------------------------

local state = { combat = false, instance = "none", mounted = false }
ns.state = state

local function readState()
	local c = NS(UnitAffectingCombat("player"))
	if c ~= nil then state.combat = c and true or false end
	if InCombatLockdown() then state.combat = true end
	local ok, inInstance, kind = pcall(IsInInstance)
	if ok then
		inInstance, kind = NS(inInstance), NS(kind)
		if inInstance ~= nil then state.instance = inInstance and (kind or "none") or "none" end
	end
	local m = IsMounted and NS(IsMounted())
	if m ~= nil then state.mounted = m and true or false end
end

local function groupOK(rule)
	if rule == "always" then return true end
	local raid = IsInRaid() and true or false
	local party = (not raid) and IsInGroup() and true or false
	if rule == "solo" then return not raid and not party end
	if rule == "party" then return party end
	if rule == "raid" then return raid end
	if rule == "group" then return raid or party end
	return true
end

local function instanceOK(rule)
	local k = state.instance
	if rule == "any" then return true end
	if rule == "world" then return k == "none" end
	if rule == "dungeon" then return k == "party" or k == "scenario" end
	if rule == "raid" then return k == "raid" end
	if rule == "pvp" then return k == "pvp" or k == "arena" end
	if rule == "instance" then return k ~= "none" end
	return true
end

-- Nombres de la zona actual (zona, subzona, instancia), en minúsculas
local zoneNames = {}
local function readZones()
	local names = {}
	for _, fn in ipairs({ GetRealZoneText, GetZoneText, GetSubZoneText, GetMinimapZoneText }) do
		if fn then
			local ok, z = pcall(fn)
			z = ok and NS(z) or nil
			if type(z) == "string" and z ~= "" then names[#names + 1] = z:lower() end
		end
	end
	if GetInstanceInfo then
		local ok, z = pcall(GetInstanceInfo)
		z = ok and NS(z) or nil
		if type(z) == "string" and z ~= "" then names[#names + 1] = z:lower() end
	end
	-- Si no se ha podido leer nada (valores secretos), se queda lo anterior
	if #names > 0 then zoneNames = names end
end

-- Zonas separadas por comas; vale una parte del nombre ("núcleo" encaja
-- con "Núcleo de Magma")
local function zonesOK(zones)
	if not zones or not zones:find("%S") then return true end
	for part in zones:gmatch("[^,;\n]+") do
		local t = strtrim(part):lower()
		if t ~= "" then
			for _, name in ipairs(zoneNames) do
				if name:find(t, 1, true) then return true end
			end
		end
	end
	return false
end

function ns.CurrentZone()
	readZones()
	local ok, z = pcall(GetRealZoneText)
	return ok and NS(z) or zoneNames[1]
end

local function ownerOK(note)
	return note.owner == nil or note.owner == R.charKey
end

-- Cumple sus reglas (sin tener en cuenta el editor ni el desbloqueo)
function M:RulesOK(note)
	if not note.enabled or not ownerOK(note) then return false end
	if not groupOK(note.group) then return false end
	if not instanceOK(note.instance) then return false end
	if not zonesOK(note.zones) then return false end
	if note.combat == "hide" and state.combat then return false end
	if note.combat == "only" and not state.combat then return false end
	if note.hideMounted and state.mounted then return false end
	return true
end

function M:ShouldShow(note)
	-- Con el editor abierto o las notas desbloqueadas se ven todas las activas
	if editorOpen and note.id == editorSelected then return true end
	if editorOpen or not db.locked then return note.enabled and ownerOK(note) end
	if db.hideAll then return false end
	return self:RulesOK(note)
end

----------------------------------------------------------------------
-- Grupos de notas: las del mismo grupo van en una columna que se mueve
-- entera. Su posición y si están plegados van en RheizorNotesDB.stacks.
----------------------------------------------------------------------

-- Grupo de una nota ("" = el grupo común con «Juntar todas»), o nil
function ns.StackKey(note)
	local s = type(note.stack) == "string" and strtrim(note.stack) or ""
	if s ~= "" then return s end
	if db and db.stackAll then return "" end
end

local function stackData(key)
	if type(store.stacks) ~= "table" then store.stacks = {} end
	local d = store.stacks[key]
	if type(d) ~= "table" then
		d = {}
		store.stacks[key] = d
	end
	return d
end

local function stackName(key)
	return key ~= "" and key or L["Notas"]
end

-- Nombres de los grupos que existen, para el editor
function M:GetStackNames()
	local names, seen = {}, {}
	for _, n in ipairs(self:GetNotes()) do
		local s = type(n.stack) == "string" and strtrim(n.stack) or ""
		if s ~= "" and not seen[s] then
			seen[s] = true
			names[#names + 1] = s
		end
	end
	table.sort(names)
	return names
end

-- Grupo entero plegado con su barra (con el editor abierto se ve todo)
function M:StackCollapsed(key)
	if not key or not db.stackHeader or editorOpen then return false end
	return stackData(key).collapsed and true or false
end

-- Se ve su marco: cumple las reglas y su grupo no está plegado
function M:Visible(note)
	return self:ShouldShow(note) and not self:StackCollapsed(ns.StackKey(note))
end

----------------------------------------------------------------------
-- Lista de deseos: cuántos tienes
----------------------------------------------------------------------

local function altCount(id)
	local chars = type(RheizorCharsDB) == "table" and RheizorCharsDB.chars
	if type(chars) ~= "table" then return 0 end
	local realm = GetRealmName()
	local mine = R.PlayerFullName() .. " - " .. realm
	local total = 0
	for key, c in pairs(chars) do
		if key ~= mine and type(c) == "table" and c.realm == realm then
			for _, place in ipairs({ "bags", "bank", "mail", "equipped" }) do
				local n = type(c[place]) == "table" and c[place][id]
				if type(n) == "number" then total = total + n end
			end
		end
	end
	return total
end

-- Total, de este personaje, de los demás
function ns.Count(note, id)
	local n
	local bank = note.wishBank and true or false
	if C_Item and C_Item.GetItemCount then
		local ok, c = pcall(C_Item.GetItemCount, id, bank, false, bank, bank)
		n = ok and NS(c) or nil
	elseif GetItemCount then
		local ok, c = pcall(GetItemCount, id, bank)
		n = ok and NS(c) or nil
	end
	n = tonumber(n) or 0
	local alts = note.wishAlts and altCount(id) or 0
	return n + alts, n, alts
end

function ns.HasCharacters()
	return type(RheizorCharsDB) == "table" and type(RheizorCharsDB.chars) == "table"
end

local function wishSummary(note)
	local done, total = 0, 0
	for _, w in ipairs(note.wish) do
		total = total + 1
		if ns.Count(note, w.id) >= (w.want or 1) then done = done + 1 end
	end
	return done, total
end

local function itemLink(id, fallback)
	local name, link = MD.ItemInfo(id)
	return link or ("[" .. (name or fallback or ("item:" .. id)) .. "]")
end

local function alertDone(note, w, have)
	R:Print(L["Lista de deseos (%s): ya tienes %s %d/%d."]:format(note.title ~= "" and note.title or "?",
		itemLink(w.id, w.name), have, w.want or 1))
	if UIErrorsFrame then
		UIErrorsFrame:AddMessage(L["Deseo cumplido: %s"]:format(itemLink(w.id, w.name)), 0.2, 1, 0.2)
	end
	if db.sound and PlaySound then
		local kit = SOUNDKIT and (SOUNDKIT.IG_QUEST_LIST_COMPLETE or SOUNDKIT.READY_CHECK)
		if kit then pcall(PlaySound, kit) end
	end
end

-- Comprueba los deseos cumplidos (y avisa de los nuevos)
local function checkWishes()
	if not primed then return end
	for _, note in ipairs(M:GetNotes()) do
		if ownerOK(note) and #note.wish > 0 then
			for _, w in ipairs(note.wish) do
				local have = ns.Count(note, w.id)
				if have >= (w.want or 1) then
					if not note.wishDone[w.id] then
						note.wishDone[w.id] = true
						if note.wishAlert and note.enabled then alertDone(note, w, have) end
					end
				else
					note.wishDone[w.id] = nil
				end
			end
		end
	end
end

----------------------------------------------------------------------
-- Tooltip de los objetos
----------------------------------------------------------------------

local ownTooltip = false

local function addWishLines(tooltip, id)
	if ownTooltip or not db or not db.tooltip or not R:IsModuleRunning(M) or not tooltip.AddLine then return end
	for _, note in ipairs(M:GetNotes()) do
		if ownerOK(note) then
			for _, w in ipairs(note.wish) do
				if w.id == id then
					local have = ns.Count(note, id)
					local want = w.want or 1
					local color = have >= want and "33ff33" or "ffd100"
					tooltip:AddLine(L["Lista de deseos (%s): %s"]:format(note.title ~= "" and note.title or "?",
						"|cff" .. color .. have .. "/" .. want .. "|r"), 0.2, 0.8, 1)
				end
			end
		end
	end
end

local function hookTooltips()
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
			local id = data and NS(data.id)
			if type(id) == "number" then addWishLines(tooltip, id) end
		end)
	end
end

----------------------------------------------------------------------
-- Enlaces dentro de las notas
----------------------------------------------------------------------

local function insertInChat(link)
	if ChatFrameUtil and ChatFrameUtil.InsertLink then
		return ChatFrameUtil.InsertLink(link)
	elseif ChatEdit_InsertLink then
		return ChatEdit_InsertLink(link)
	end
end
ns.InsertInChat = insertInChat

local function onHyperlinkEnter(self, link)
	local f = self.owner
	GameTooltip:SetOwner(self, "ANCHOR_CURSOR")
	local url = link:match("^rznotes:url:(%d+)$")
	if url then
		GameTooltip:SetText(f.urls and f.urls[tonumber(url)] or "?", 0.4, 0.73, 1, 1, true)
		GameTooltip:AddLine(L["Clic: copiar la dirección"], 0.7, 0.7, 0.7)
	else
		ownTooltip = true
		pcall(GameTooltip.SetHyperlink, GameTooltip, link)
		ownTooltip = false
	end
	GameTooltip:Show()
end

local function onHyperlinkClick(self, link, text, button)
	local f = self.owner
	local url = link:match("^rznotes:url:(%d+)$")
	if url then
		if R.ShowText then R:ShowText(L["Enlace"], f.urls and f.urls[tonumber(url)] or "") end
		return
	end
	if IsModifiedClick and IsModifiedClick("CHATLINK") then
		insertInChat(text)
		return
	end
	if SetItemRef then pcall(SetItemRef, link, text, button, self) end
end

----------------------------------------------------------------------
-- Marco de una nota
----------------------------------------------------------------------

local function hex(h)
	return R.HexToRGB(h or "ffffff")
end

local function onWheel(self, delta)
	local f = self.owner
	local maxScroll = f.maxScroll or 0
	if maxScroll <= 0 then return end
	local v = self:GetVerticalScroll() - delta * (f.note and f.note.fontSize or 12) * 3
	self:SetVerticalScroll(math.max(0, math.min(maxScroll, v)))
end

local function createFrame(note)
	local f = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
	f:SetFrameStrata("LOW")
	f:SetClampedToScreen(true)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f.lines, f.wishRows = {}, {}

	local title = CreateFrame("Button", nil, f)
	title:SetPoint("TOPLEFT", 1, -1)
	title:SetPoint("TOPRIGHT", -1, -1)
	title:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	title.bg = title:CreateTexture(nil, "BACKGROUND")
	title.bg:SetAllPoints()
	title.bg:SetColorTexture(0.2, 0.8, 1, 0.12)
	title.text = title:CreateFontString(nil, "OVERLAY")
	title.text:SetPoint("LEFT", PAD, 0)
	title.text:SetPoint("RIGHT", -18, 0)
	title.text:SetJustifyH("LEFT")
	title.text:SetWordWrap(false)
	title.arrow = title:CreateFontString(nil, "OVERLAY")
	title.arrow:SetPoint("RIGHT", -PAD, 0)
	title:SetScript("OnClick", function(_, button)
		local n = f.note
		if not n then return end
		if button == "RightButton" then
			M:OpenEditorAt(n.id)
		else
			n.collapsed = not n.collapsed
			-- Acordeón: al abrir una, se pliegan las demás de su grupo
			local key = ns.StackKey(n)
			if not n.collapsed and db.accordion and key then
				for _, o in ipairs(M:GetNotes()) do
					if o ~= n and not o.collapsed and o.showTitle and ns.StackKey(o) == key then
						o.collapsed = true
						M:RenderNote(o.id)
					end
				end
			end
			M:RenderNote(n.id)
		end
	end)
	title:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(f.note and f.note.title or "", 1, 1, 1)
		GameTooltip:AddLine(L["Clic: plegar o desplegar · Clic derecho: editar"], 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	title:SetScript("OnLeave", GameTooltip_Hide)
	f.title = title

	local scroll = CreateFrame("ScrollFrame", nil, f)
	scroll.owner = f
	scroll:SetScript("OnMouseWheel", onWheel)
	f.scroll = scroll
	local content = CreateFrame("Frame", nil, scroll)
	content.owner = f
	content:SetSize(1, 1)
	scroll:SetScrollChild(content)
	if content.SetHyperlinksEnabled then content:SetHyperlinksEnabled(true) end
	content:SetScript("OnHyperlinkEnter", onHyperlinkEnter)
	content:SetScript("OnHyperlinkLeave", GameTooltip_Hide)
	content:SetScript("OnHyperlinkClick", onHyperlinkClick)
	f.content = content

	f.mover = R:CreateMover(f, note.title ~= "" and note.title or L["Nota"], note, "point", defaultPoint(0))
	f.mover.configure = function() if f.note then M:OpenEditorAt(f.note.id) end end
	-- Se guarda por la esquina de arriba a la izquierda: al crecer, la nota
	-- baja en vez de moverse hacia arriba
	f.mover:HookScript("OnDragStop", function()
		local n, left, top = f.note, f:GetLeft(), f:GetTop()
		if n and left and top then
			n.point = { "TOPLEFT", "BOTTOMLEFT", math.floor(left + 0.5), math.floor(top + 0.5) }
			f.mover:Place()
		end
	end)
	return f
end

-- Elementos de una línea: texto, texto de delante (viñeta, número), textura
-- (separador, barra de cita, fondo de código) y casilla
local function getLine(f, i)
	local ln = f.lines[i]
	if not ln then
		ln = {}
		ln.fs = f.content:CreateFontString(nil, "OVERLAY")
		ln.fs:SetJustifyH("LEFT")
		ln.fs:SetWordWrap(true)
		if ln.fs.SetNonSpaceWrap then ln.fs:SetNonSpaceWrap(true) end
		ln.lead = f.content:CreateFontString(nil, "OVERLAY")
		ln.lead:SetJustifyH("RIGHT")
		ln.tex = f.content:CreateTexture(nil, "BACKGROUND")
		f.lines[i] = ln
	end
	ln.fs:Hide()
	ln.lead:Hide()
	ln.tex:Hide()
	if ln.check then ln.check:Hide() end
	return ln
end

local function getCheck(f, ln)
	if ln.check then return ln.check end
	local c = CreateFrame("Button", nil, f.content)
	c.box = c:CreateTexture(nil, "ARTWORK")
	c.box:SetAllPoints()
	c.box:SetTexture("Interface\\Buttons\\UI-CheckBox-Up")
	c.mark = c:CreateTexture(nil, "OVERLAY")
	c.mark:SetAllPoints()
	c.mark:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
	local hl = c:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetTexture("Interface\\Buttons\\UI-CheckBox-Highlight")
	hl:SetBlendMode("ADD")
	c:SetScript("OnClick", function(self)
		local n = f.note
		if not n or not self.line or not M:CanEditNote(n) then return end
		n.text = MD.ToggleCheck(n.text, self.line)
		M:RenderNote(n.id)
		if M.OnNoteTextChanged then M:OnNoteTextChanged(n.id) end
		M:NoteEdited(n)
	end)
	ln.check = c
	return c
end

local HEADINGS = {
	h1 = { add = 8, color = ACCENT, before = 6 },
	h2 = { add = 5, color = "ffd100", before = 5 },
	h3 = { add = 2, color = "ffffff", before = 4 },
}

local function setText(ln, note, size, x, y, width, text, r, g, b)
	local fs = ln.fs
	ns.SetFont(fs, note.font, size)
	fs:SetTextColor(r, g, b)
	fs:ClearAllPoints()
	fs:SetPoint("TOPLEFT", x, -y)
	fs:SetWidth(math.max(10, width - x))
	fs:SetText(text)
	fs:Show()
	return math.max(fs:GetStringHeight() or size, size)
end

local function drawBlock(f, ln, b, note, y, width)
	local size = note.fontSize
	local r, g, bl = hex(note.textColor)
	local kind = b.kind
	local interactive = db.interactive
	local inline = function(text) return MD.Inline(text or "", size, f.urls) end

	if kind == "blank" then
		return y + math.floor(size * 0.6 + 0.5)
	elseif kind == "hr" then
		ln.tex:SetColorTexture(1, 1, 1, 0.25)
		ln.tex:ClearAllPoints()
		ln.tex:SetPoint("TOPLEFT", 0, -(y + 5))
		ln.tex:SetSize(width, 1)
		ln.tex:Show()
		return y + 11
	elseif HEADINGS[kind] then
		local h = HEADINGS[kind]
		if y > 0 then y = y + h.before end
		local hr, hg, hb = hex(h.color)
		local height = setText(ln, note, size + h.add, 0, y, width, inline(b.text), hr, hg, hb)
		if kind == "h1" then
			ln.tex:SetColorTexture(hr, hg, hb, 0.35)
			ln.tex:ClearAllPoints()
			ln.tex:SetPoint("TOPLEFT", 0, -(y + height + 2))
			ln.tex:SetSize(width, 1)
			ln.tex:Show()
			return y + height + 6
		end
		return y + height + 3
	elseif kind == "quote" then
		local height = setText(ln, note, size, 9, y, width, inline(b.text), 0.72, 0.72, 0.72)
		ln.tex:SetColorTexture(0.2, 0.8, 1, 0.8)
		ln.tex:ClearAllPoints()
		ln.tex:SetPoint("TOPLEFT", 1, -y)
		ln.tex:SetSize(2, height)
		ln.tex:Show()
		return y + height + 2
	elseif kind == "code" then
		local cr, cg, cb = hex(MD.COLORS.code)
		local text = b.text ~= "" and b.text or " "
		local height = setText(ln, note, size - 1, 4, y + 1, width - 4, text, cr, cg, cb)
		ln.tex:SetColorTexture(0, 0, 0, 0.4)
		ln.tex:ClearAllPoints()
		ln.tex:SetPoint("TOPLEFT", 0, -y)
		ln.tex:SetSize(width, height + 2)
		ln.tex:Show()
		return y + height + 2
	elseif kind == "bullet" or kind == "number" then
		local indent = (b.level or 0) * 14
		local lead = ln.lead
		ns.SetFont(lead, note.font, size)
		lead:SetTextColor(0.2, 0.8, 1)
		lead:SetText(kind == "bullet" and ((b.level or 0) > 0 and "–" or "•") or (b.number .. "."))
		local leadW = kind == "bullet" and 10 or math.max(14, math.ceil(lead:GetStringWidth() or 12))
		lead:SetWidth(leadW)
		lead:ClearAllPoints()
		lead:SetPoint("TOPLEFT", indent, -y)
		lead:Show()
		-- "•" puede no existir en alguna fuente: con la del juego siempre sale
		local height = setText(ln, note, size, indent + leadW + 4, y, width, inline(b.text), r, g, bl)
		return y + height + 2
	elseif kind == "check" then
		local indent = (b.level or 0) * 14
		local box = size + 2
		local c = getCheck(f, ln)
		c.line = b.line
		c:SetSize(box, box)
		c:ClearAllPoints()
		c:SetPoint("TOPLEFT", indent - 2, -(y - 2))
		c.mark:SetShown(b.checked)
		c:EnableMouse(interactive and M:CanEditNote(note))
		c:Show()
		local text = inline(b.text)
		local height
		if b.checked then
			height = setText(ln, note, size, indent + box + 2, y, width, text, 0.5, 0.5, 0.5)
		else
			height = setText(ln, note, size, indent + box + 2, y, width, text, r, g, bl)
		end
		return y + math.max(height, box - 2) + 3
	end
	-- Párrafo
	local height = setText(ln, note, size, 0, y, width, inline(b.text), r, g, bl)
	return y + height + 2
end

-- Filas de la lista de deseos
local function wishRow(f, i)
	local row = f.wishRows[i]
	if row then return row end
	row = CreateFrame("Button", nil, f.content)
	row:RegisterForClicks("LeftButtonUp")
	row.fill = row:CreateTexture(nil, "BACKGROUND")
	row.fill:SetPoint("TOPLEFT")
	row.fill:SetPoint("BOTTOMLEFT")
	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetPoint("LEFT", 2, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	row.count = row:CreateFontString(nil, "OVERLAY")
	row.count:SetPoint("RIGHT", -3, 0)
	row.count:SetJustifyH("RIGHT")
	row.name = row:CreateFontString(nil, "OVERLAY")
	row.name:SetPoint("LEFT", row.icon, "RIGHT", 5, 0)
	row.name:SetPoint("RIGHT", row.count, "LEFT", -4, 0)
	row.name:SetJustifyH("LEFT")
	row.name:SetWordWrap(false)
	row:SetScript("OnEnter", function(self)
		local n, w = f.note, self.wish
		if not n or not w then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		ownTooltip = true
		pcall(GameTooltip.SetItemByID, GameTooltip, w.id)
		ownTooltip = false
		local total, mine, alts = ns.Count(n, w.id)
		GameTooltip:AddLine(" ")
		GameTooltip:AddDoubleLine(L["Tienes"], total .. " / " .. (w.want or 1), 1, 0.82, 0, 1, 1, 1)
		if n.wishAlts then
			GameTooltip:AddDoubleLine(L["Este personaje"], mine, 0.7, 0.7, 0.7, 1, 1, 1)
			GameTooltip:AddDoubleLine(L["Tus otros personajes"], alts, 0.7, 0.7, 0.7, 1, 1, 1)
		end
		local left = (w.want or 1) - total
		if left > 0 then GameTooltip:AddLine(L["Te faltan %d"]:format(left), 1, 0.4, 0.4) end
		GameTooltip:AddLine(L["Mayús + clic: enlazar en el chat"], 0.5, 0.5, 0.5)
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	row:SetScript("OnClick", function(self)
		if self.wish and IsModifiedClick and IsModifiedClick("CHATLINK") then
			insertInChat(itemLink(self.wish.id, self.wish.name))
		end
	end)
	f.wishRows[i] = row
	return row
end

local function drawWish(f, note, y, width)
	local used = 0
	local header = f.wishHeader
	if not header then
		header = f.content:CreateFontString(nil, "OVERLAY")
		header:SetJustifyH("LEFT")
		f.wishHeader = header
		f.wishLine = f.content:CreateTexture(nil, "BACKGROUND")
	end
	header:Hide()
	f.wishLine:Hide()
	if #note.wish > 0 then
		local size = note.fontSize
		if y > 0 then y = y + 6 end
		local done, total = wishSummary(note)
		ns.SetFont(header, note.font, size)
		header:SetTextColor(0.2, 0.8, 1)
		header:ClearAllPoints()
		header:SetPoint("TOPLEFT", 0, -y)
		header:SetWidth(width)
		header:SetText(L["Lista de deseos"] .. "  |cff" .. (done == total and "33ff33" or "aaaaaa") .. done .. "/" .. total .. "|r")
		header:Show()
		y = y + (header:GetStringHeight() or size) + 1
		f.wishLine:SetColorTexture(0.2, 0.8, 1, 0.35)
		f.wishLine:ClearAllPoints()
		f.wishLine:SetPoint("TOPLEFT", 0, -y)
		f.wishLine:SetSize(width, 1)
		f.wishLine:Show()
		y = y + 4
		local rowH = size + 8
		local shown = 0
		for _, w in ipairs(note.wish) do
			local have = ns.Count(note, w.id)
			local want = w.want or 1
			local complete = have >= want
			if not (complete and note.wishHideDone) then
				used = used + 1
				local row = wishRow(f, used)
				row.wish = w
				row:ClearAllPoints()
				row:SetPoint("TOPLEFT", 0, -y)
				row:SetSize(width, rowH)
				row:EnableMouse(db.interactive)
				local name, _, quality, tex = MD.ItemInfo(w.id)
				if name and name ~= w.name then w.name = name end
				row.icon:SetTexture(tex or 134400)
				row.icon:SetSize(rowH - 4, rowH - 4)
				ns.SetFont(row.name, note.font, size)
				ns.SetFont(row.count, note.font, size)
				local qr, qg, qb = 1, 1, 1
				if quality and C_Item and C_Item.GetItemQualityColor then
					local ok, cr, cg, cb = pcall(C_Item.GetItemQualityColor, quality)
					if ok and cr then qr, qg, qb = cr, cg, cb end
				elseif quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality] then
					local c = ITEM_QUALITY_COLORS[quality]
					qr, qg, qb = c.r, c.g, c.b
				end
				row.name:SetText(name or w.name or ("item:" .. w.id))
				row.name:SetTextColor(qr, qg, qb)
				row.count:SetText(have .. "/" .. want)
				if complete then
					row.count:SetTextColor(0.2, 1, 0.2)
					row.fill:SetColorTexture(0.2, 1, 0.2, 0.18)
				else
					row.count:SetTextColor(1, 1, 1)
					row.fill:SetColorTexture(0.2, 0.8, 1, 0.18)
				end
				local frac = math.max(0, math.min(1, have / math.max(1, want)))
				row.fill:SetWidth(math.max(0.01, width * frac))
				row.fill:SetShown(frac > 0)
				row:Show()
				y = y + rowH + 1
				shown = shown + 1
			end
		end
		if shown == 0 then
			used = used + 1
			local row = wishRow(f, used)
			row.wish = nil
			row:ClearAllPoints()
			row:SetPoint("TOPLEFT", 0, -y)
			row:SetSize(width, rowH)
			row.icon:SetTexture(nil)
			row.icon:SetSize(1, rowH - 4)
			row.fill:Hide()
			ns.SetFont(row.name, note.font, size)
			row.name:SetText(L["¡Todo conseguido!"])
			row.name:SetTextColor(0.2, 1, 0.2)
			row.count:SetText("")
			row:EnableMouse(false)
			row:Show()
			y = y + rowH
		end
	end
	for i = used + 1, #f.wishRows do f.wishRows[i]:Hide() end
	return y
end

local function titleText(note)
	local t = note.title ~= "" and note.title or L["Nota"]
	if #note.wish > 0 then
		local done, total = wishSummary(note)
		t = t .. "  |cff" .. (done == total and "33ff33" or "aaaaaa") .. done .. "/" .. total .. "|r"
	end
	return t
end

local function render(f, note)
	f.note = note
	local size = note.fontSize
	-- En un grupo la coloca el grupo (LayoutStacks), que también puede
	-- igualar su ancho
	local key = ns.StackKey(note)
	if not key then
		f.stackWidth = nil
		if f:GetParent() ~= UIParent then f:SetParent(UIParent) end
	end
	local width = (key and f.stackWidth) or note.width
	local inner = width - PAD * 2

	-- Tamaño: se mantiene la esquina de arriba a la izquierda
	if not key and f.appliedScale and f.appliedScale ~= note.scale then
		local left, top = f:GetLeft(), f:GetTop()
		if left and top then
			local k = f.appliedScale / note.scale
			note.point = { "TOPLEFT", "BOTTOMLEFT", math.floor(left * k + 0.5), math.floor(top * k + 0.5) }
		end
	end
	f:SetScale(note.scale)
	f.appliedScale = note.scale
	if not key then f.mover:Place() end
	f.mover.text:SetText("|cff33ccffRheizor|r · " .. (note.title ~= "" and note.title or L["Nota"]))
	f.mover:SetShown(not db.locked and not key)

	f:SetWidth(width)
	f:SetBackdropColor(0.03, 0.03, 0.05, note.bgAlpha)
	if note.border then
		f:SetBackdropBorderColor(0.2, 0.8, 1, 0.45)
	else
		f:SetBackdropBorderColor(0, 0, 0, 0)
	end

	-- "Plegar en combate" no cambia la nota: al salir queda como estaba
	local combatFold = db.combatCollapse and state.combat and not editorOpen

	-- Título
	local th = 0
	local title = f.title
	if note.showTitle then
		th = size + 8
		title:SetHeight(th)
		ns.SetFont(title.text, note.font, size)
		ns.SetFont(title.arrow, note.font, size)
		title.text:SetTextColor(1, 1, 1)
		title.text:SetText(titleText(note))
		title.arrow:SetText((note.collapsed or combatFold) and "+" or "-")
		title.arrow:SetTextColor(0.2, 0.8, 1)
		title.arrow:SetShown(db.interactive)
		title:EnableMouse(db.interactive)
		title:Show()
	else
		title:Hide()
	end
	local collapsed = (note.collapsed or combatFold) and note.showTitle

	-- Contenido
	f.urls = {}
	f.content:SetWidth(inner)
	local y = 0
	local used = 0
	if not collapsed then
		for _, b in ipairs(MD.Parse(note.text)) do
			used = used + 1
			y = drawBlock(f, getLine(f, used), b, note, y, inner)
		end
		y = drawWish(f, note, y, inner)
	else
		for _, row in ipairs(f.wishRows) do row:Hide() end
		if f.wishHeader then f.wishHeader:Hide() f.wishLine:Hide() end
	end
	for i = used + 1, #f.lines do getLine(f, i) end
	f.content:SetHeight(math.max(1, y))
	f.content:EnableMouse(db.interactive)

	local body = y
	if note.maxHeight and note.maxHeight > 0 then body = math.min(y, note.maxHeight) end
	f.maxScroll = math.max(0, y - body)
	f.scroll:EnableMouseWheel(db.interactive and f.maxScroll > 0)
	if f.scroll:GetVerticalScroll() > f.maxScroll then f.scroll:SetVerticalScroll(f.maxScroll) end

	f.scroll:ClearAllPoints()
	if collapsed or body <= 0 then
		f.scroll:Hide()
		f:SetHeight(th > 0 and th + 2 or PAD * 2)
	else
		f.scroll:SetPoint("TOPLEFT", PAD, -(th + PAD))
		f.scroll:SetPoint("TOPRIGHT", -PAD, -(th + PAD))
		f.scroll:SetHeight(body)
		f.scroll:Show()
		f:SetHeight(th + body + PAD * 2 + (th > 0 and 1 or 0))
	end
end

----------------------------------------------------------------------
-- Contenedor de un grupo: barra con su nombre (opcional) y sus notas
-- una detrás de otra
----------------------------------------------------------------------

local stacks = {}   -- [grupo] = contenedor

local function createStack(key, index)
	local c = CreateFrame("Frame", nil, UIParent)
	c:SetFrameStrata("LOW")
	c:SetSize(100, 20)
	c.key = key

	local h = CreateFrame("Button", nil, c, "BackdropTemplate")
	h:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	h:SetBackdropColor(0.03, 0.03, 0.05, 0.8)
	h:SetBackdropBorderColor(0.2, 0.8, 1, 0.45)
	h:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	h.text = h:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	h.text:SetPoint("LEFT", PAD, 0)
	h.text:SetPoint("RIGHT", -18, 0)
	h.text:SetJustifyH("LEFT")
	h.text:SetWordWrap(false)
	h.arrow = h:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	h.arrow:SetPoint("RIGHT", -PAD, 0)
	h:SetScript("OnClick", function(_, button)
		if button == "RightButton" then
			M:ToggleEditor()
			return
		end
		local d = stackData(c.key)
		d.collapsed = (not d.collapsed) or nil
		M:UpdateVisibility()
	end)
	h:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(stackName(c.key), 1, 1, 1)
		GameTooltip:AddLine(L["Clic: plegar o desplegar el grupo · Clic derecho: editor"], 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	h:SetScript("OnLeave", GameTooltip_Hide)
	c.header = h

	local k = (index or 0) % 8
	c.mover = R:CreateMover(c, stackName(key), stackData(key), "point", { "TOPLEFT", "TOPLEFT", 80 + k * 24, -160 - k * 24 })
	c.mover.configure = function()
		if R.OpenModuleOptions then R:OpenModuleOptions(M) end
	end
	-- Se guarda por la esquina desde la que crece
	c.mover:HookScript("OnDragStop", function()
		local d = stackData(c.key)
		local left, top, bottom = c:GetLeft(), c:GetTop(), c:GetBottom()
		if not left then return end
		if db.grow == "up" then
			d.point = { "BOTTOMLEFT", "BOTTOMLEFT", math.floor(left + 0.5), math.floor(bottom + 0.5) }
		else
			d.point = { "TOPLEFT", "BOTTOMLEFT", math.floor(left + 0.5), math.floor(top + 0.5) }
		end
		c.mover:Place()
	end)
	return c
end

function M:LayoutStacks()
	if not store or not R:IsModuleRunning(self) then return end
	local members, order = {}, {}
	for _, note in ipairs(self:GetNotes()) do
		local key = ns.StackKey(note)
		if key and self:ShouldShow(note) then
			if not members[key] then
				members[key] = {}
				order[#order + 1] = key
			end
			table.insert(members[key], note)
		end
	end
	for key, c in pairs(stacks) do
		if not members[key] then c:Hide() end
	end

	local up = db.grow == "up"
	local gap = tonumber(db.stackGap) or 4
	local HEADER_H = 18
	local count = 0
	for _ in pairs(stacks) do count = count + 1 end
	for _, key in ipairs(order) do
		local c = stacks[key]
		if not c then
			c = createStack(key, count)
			stacks[key] = c
			count = count + 1
		end
		local list = members[key]
		-- Ancho común (en píxeles de pantalla: cada nota puede tener otra escala)
		local width = 0
		for _, n in ipairs(list) do width = math.max(width, n.width * n.scale) end

		c.mover:Place()
		c:Show()
		local prev, total = nil, 0
		local h = c.header
		if db.stackHeader then
			local collapsed = self:StackCollapsed(key)
			h:SetSize(width, HEADER_H)
			h:ClearAllPoints()
			if up then h:SetPoint("BOTTOMLEFT", c, "BOTTOMLEFT", 0, 0) else h:SetPoint("TOPLEFT", c, "TOPLEFT", 0, 0) end
			h.text:SetText(stackName(key) .. "  |cffaaaaaa" .. #list .. "|r")
			h.arrow:SetText(collapsed and "+" or "-")
			h.arrow:SetTextColor(0.2, 0.8, 1)
			h:EnableMouse(db.interactive)
			h:Show()
			prev, total = h, HEADER_H
		else
			h:Hide()
		end
		for _, n in ipairs(list) do
			local f = frames[n.id]
			if f and f:IsShown() then
				local w = db.stackWidth and math.floor(width / n.scale + 0.5) or nil
				if f.stackWidth ~= w then
					f.stackWidth = w
					render(f, n)
				end
				if f:GetParent() ~= c then
					f:SetParent(c)
					f:SetAlpha(1)
				end
				f:ClearAllPoints()
				local space = prev and gap or 0
				if up then
					if prev then f:SetPoint("BOTTOMLEFT", prev, "TOPLEFT", 0, space) else f:SetPoint("BOTTOMLEFT", c, "BOTTOMLEFT", 0, 0) end
				else
					if prev then f:SetPoint("TOPLEFT", prev, "BOTTOMLEFT", 0, -space) else f:SetPoint("TOPLEFT", c, "TOPLEFT", 0, 0) end
				end
				total = total + (space + f:GetHeight()) * n.scale
				prev = f
			end
		end
		c:SetSize(math.max(width, 20), math.max(total, 10))
		c.mover.text:SetText("|cff33ccffRheizor|r · " .. stackName(key))
		c.mover:SetShown(not db.locked)
	end
end

----------------------------------------------------------------------
-- Atenuar sin el ratón encima
----------------------------------------------------------------------

local idleTicker

local function updateIdle()
	if not db or not R:IsModuleRunning(M) then return end
	local a = tonumber(db.idleAlpha) or 1
	local full = a >= 1 or editorOpen or not db.locked
	for _, f in pairs(frames) do
		if f:IsShown() and f:GetParent() == UIParent then
			f:SetAlpha((full or f:IsMouseOver()) and 1 or a)
		end
	end
	for _, c in pairs(stacks) do
		if c:IsShown() then c:SetAlpha((full or c:IsMouseOver()) and 1 or a) end
	end
end

function M:UpdateIdle()
	local need = (tonumber(db.idleAlpha) or 1) < 1
	if need and not idleTicker then
		idleTicker = C_Timer.NewTicker(0.15, updateIdle)
	elseif not need and idleTicker then
		idleTicker:Cancel()
		idleTicker = nil
	end
	updateIdle()
end

function M:RenderNote(id)
	if not R:IsModuleRunning(self) then return end
	local note = self:FindNote(id)
	if not note then return end
	local f = frames[id]
	if not self:Visible(note) then
		if f then f:Hide() end
		self:LayoutStacks()
		return
	end
	if not f then
		f = createFrame(note)
		frames[id] = f
	end
	-- La tabla de la nota puede ser otra (tras importar o duplicar)
	if f.note ~= note then
		f.note = note
	end
	render(f, note)
	f:Show()
	self:LayoutStacks()
end

-- Vuelve a mirar las reglas de todas (sin redibujar las que no cambian)
function M:UpdateVisibility()
	if not R:IsModuleRunning(self) then return end
	for _, note in ipairs(self:GetNotes()) do
		local f = frames[note.id]
		local want = self:Visible(note)
		if want and not (f and f:IsShown()) then
			self:RenderNote(note.id)
		elseif not want and f and f:IsShown() then
			f:Hide()
		end
	end
	-- Marcos de notas borradas
	for id, f in pairs(frames) do
		if not self:FindNote(id) then f:Hide() end
	end
	self:LayoutStacks()
	updateIdle()
	if self.RefreshEditorList then self:RefreshEditorList() end
end

function M:Refresh()
	if not R:IsModuleRunning(self) then return end
	MD.waiting = false
	for _, note in ipairs(self:GetNotes()) do self:RenderNote(note.id) end
	for id, f in pairs(frames) do
		if not self:FindNote(id) then f:Hide() end
	end
	self:LayoutStacks()
	self:UpdateIdle()
	if self.RefreshEditorList then self:RefreshEditorList() end
end

-- Redibujo con un pequeño retraso (mientras se escribe en el editor)
local queued = {}
function M:QueueRender(id)
	if queued[id] then return end
	queued[id] = true
	C_Timer.After(0.15, function()
		queued[id] = nil
		M:RenderNote(id)
	end)
end

-- Solo las notas con lista de deseos (al cambiar las bolsas)
local countsQueued = false
function M:UpdateCounts()
	if countsQueued then return end
	countsQueued = true
	C_Timer.After(0.3, function()
		countsQueued = false
		if not R:IsModuleRunning(M) then return end
		checkWishes()
		for _, note in ipairs(M:GetNotes()) do
			if #note.wish > 0 then
				local f = frames[note.id]
				if f and f:IsShown() then render(f, note) end
			end
		end
		M:LayoutStacks()
		if M.RefreshEditorWish then M:RefreshEditorWish() end
	end)
end

function M:SetEditorOpen(open, selected)
	editorOpen = open and true or false
	editorSelected = selected
	self:UpdateVisibility()
end

function M:SetEditorSelected(id)
	editorSelected = id
	if editorOpen then self:UpdateVisibility() end
end

function M:IsShownNow(note)
	local f = frames[note.id]
	return f and f:IsShown() and true or false
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
local itemRefresh = false
events:SetScript("OnEvent", function(_, event)
	if not R:IsModuleRunning(M) then return end
	if event == "PLAYER_REGEN_DISABLED" or event == "PLAYER_REGEN_ENABLED" then
		state.combat = event == "PLAYER_REGEN_DISABLED"
		if not state.combat then readState() end
		-- Plegar en combate: hay que redibujarlas todas
		if db.combatCollapse then
			M:Refresh()
			return
		end
	elseif event == "BAG_UPDATE_DELAYED" or event == "PLAYERBANKSLOTS_CHANGED" or event == "BANKFRAME_OPENED"
		or event == "BANKFRAME_CLOSED" or event == "PLAYERREAGENTBANKSLOTS_CHANGED" then
		M:UpdateCounts()
		return
	elseif event == "GET_ITEM_INFO_RECEIVED" then
		-- Nombres e iconos de objetos que aún no estaban en la caché
		if MD.waiting and not itemRefresh then
			itemRefresh = true
			C_Timer.After(0.5, function()
				itemRefresh = false
				M:Refresh()
			end)
		end
		return
	else
		readState()
		readZones()
	end
	M:UpdateVisibility()
end)

local EVENTS = {
	"PLAYER_ENTERING_WORLD", "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA",
	"GROUP_ROSTER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_MOUNT_DISPLAY_CHANGED",
	"BAG_UPDATE_DELAYED", "PLAYERBANKSLOTS_CHANGED", "PLAYERREAGENTBANKSLOTS_CHANGED",
	"BANKFRAME_OPENED", "BANKFRAME_CLOSED", "GET_ITEM_INFO_RECEIVED",
}

local function exampleNote()
	local note = fill({ id = store.nextID })
	store.nextID = store.nextID + 1
	note.title = L["Ejemplo"]
	note.text = table.concat({
		"# " .. L["Notas de Rheizor"],
		L["Escribe en **Markdown**: *cursiva*, ==resaltado==, `código`."],
		"",
		"## " .. L["Tareas"],
		"- [x] " .. L["Instalar Rheizor Notas"],
		"- [ ] " .. L["Hacer clic en una casilla para marcarla"],
		"",
		"> " .. L["Clic derecho en el título: editar. /rznotas abre el editor."],
		"{rt1} {rt2} {rt3} {rt4} {rt5} {rt6} {rt7} {rt8}",
	}, "\n")
	note.point = defaultPoint(0)
	table.insert(store.notes, note)
end

function M:OnEnable()
	db = self.db
	RheizorNotesDB = type(RheizorNotesDB) == "table" and RheizorNotesDB or {}
	store = RheizorNotesDB
	if type(store.notes) ~= "table" then store.notes = {} end
	store.nextID = tonumber(store.nextID) or 1
	for _, n in ipairs(store.notes) do
		fill(n)
		if n.id >= store.nextID then store.nextID = n.id + 1 end
	end
	if not store.seeded then
		store.seeded = true
		if #store.notes == 0 then exampleNote() end
	end
	for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
	hookTooltips()
	readState()
	readZones()
	self:Refresh()
	self:SyncEnable(store)
	-- Al entrar las bolsas pueden no estar leídas aún: los avisos de deseos
	-- cumplidos empiezan un poco después
	C_Timer.After(5, function()
		primed = true
		checkWishes()
		if R:IsModuleRunning(M) then M:Refresh() end
	end)
end

function M:OnOptionChanged()
	self:Refresh()
end

----------------------------------------------------------------------
-- Comandos: /rznotas, /rznotes y /rz notas
----------------------------------------------------------------------

local function command(msg)
	msg = strtrim(msg or ""):lower()
	R:RunModuleAction(M, function(m)
		if msg == "ocultar" or msg == "hide" then
			db.hideAll = true
			m:Refresh()
			R:Print(L["Notas ocultas. /rznotas mostrar para volver a verlas."])
		elseif msg == "mostrar" or msg == "show" then
			db.hideAll = false
			m:Refresh()
		elseif msg == "alternar" or msg == "toggle" then
			db.hideAll = not db.hideAll
			m:Refresh()
		else
			m:ToggleEditor()
		end
	end)
end

SLASH_RHEIZORNOTES1 = "/rznotas"
SLASH_RHEIZORNOTES2 = "/rznotes"
SlashCmdList.RHEIZORNOTES = command

do
	local original = SlashCmdList.RHEIZOR
	if original then
		SlashCmdList.RHEIZOR = function(msg)
			local word, rest = strtrim(msg or ""):match("^(%S+)%s*(.*)$")
			word = word and word:lower()
			if word == "notas" or word == "notes" or word == "nota" or word == "note" then
				command(rest)
			else
				original(msg)
			end
		end
	end
end
