-- Editor de notas (/rznotas, /rz notas o el botón de las opciones):
--   Izquierda: las notas (activar, crear, duplicar, borrar).
--   Centro:    título, texto en Markdown y lista de deseos.
--   Derecha:   cuándo se ve, aspecto y opciones de la lista de deseos.
-- Mientras está abierto se ven todas las notas activas (y siempre la
-- elegida) y los cambios se ven en pantalla al escribir.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret
local M = ns.M
local MD = ns.md
local UI = R.UI or {}

local W, H = 900, 600
local LIST_W, MID_W, SET_W = 180, 400, 280
local ROW_H = 26
local EDIT_H = 230
local WHITE = "Interface\\Buttons\\WHITE8X8"

local win, noteList, wishList, settings
local noteRows, wishRows, controls = {}, {}, {}
local selected
local armed = false
local titleBox, textBox, textScroll, itemBox, qtyBox, statusText, deleteButton, dupButton
local wishCount

local function backdrop(f, alpha)
	if UI.SetBackdrop then return UI.SetBackdrop(f, alpha) end
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.05, 0.05, 0.07, alpha or 0.95)
	f:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
end

local function setStatus(text, r, g, b)
	statusText:SetText(text or "")
	statusText:SetTextColor(r or 1, g or 1, b or 1)
end

local function button(parent, text, width, height)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width or 100, height or 22)
	b:SetText(text)
	return b
end

local function scroll(parent)
	local sf
	if UI.MakeScroll then
		sf = UI.MakeScroll(parent)
	else
		sf = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
		sf.child = CreateFrame("Frame", nil, sf)
		sf:SetScrollChild(sf.child)
	end
	return sf
end

local function inputBox(parent, width, letters)
	local e = CreateFrame("EditBox", nil, parent, "BackdropTemplate")
	e:SetSize(width, 22)
	e:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	e:SetBackdropColor(0, 0, 0, 0.6)
	e:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	e:SetFontObject(GameFontHighlightSmall)
	e:SetTextInsets(6, 6, 0, 0)
	e:SetAutoFocus(false)
	if letters then e:SetMaxLetters(letters) end
	e:SetScript("OnEscapePressed", e.ClearFocus)
	return e
end

local function dropdown(parent, width)
	local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
	b:SetSize(width, 22)
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropColor(0, 0, 0, 0.6)
	b:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	b.text:SetPoint("LEFT", 6, 0)
	b.text:SetPoint("RIGHT", -18, 0)
	b.text:SetJustifyH("LEFT")
	b.text:SetWordWrap(false)
	local arrow = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	arrow:SetPoint("RIGHT", -6, 0)
	arrow:SetText("v")
	function b:SetValues(values, current, onPick)
		self.values, self.current, self.onPick = values, current, onPick
		self.text:SetText(ns.ValueText(values, current))
	end
	b:SetScript("OnClick", function(self)
		if not self.values then return end
		local shown = {}
		for i, v in ipairs(self.values) do shown[i] = { v[1], L[v[2]] } end
		if UI.OpenPopup then
			UI.OpenPopup(self, shown, self.current, self.onPick)
		else
			local nextIndex = 1
			for i, v in ipairs(shown) do
				if v[1] == self.current then nextIndex = i % #shown + 1 end
			end
			self.onPick(shown[nextIndex][1])
		end
	end)
	return b
end

-- Para la ventana de compartir (Share.lua)
ns.ui = { button = button, scroll = scroll, inputBox = inputBox, dropdown = dropdown, backdrop = backdrop }

local function current()
	return selected and M:FindNote(selected)
end

-- Nota compartida en la que no puedes escribir
local function readOnly(note)
	if note and not M:CanEditNote(note) then
		setStatus(L["Solo lectura: quien la comparte no te deja editarla."], 1, 0.5, 0.3)
		return true
	end
	return false
end

----------------------------------------------------------------------
-- Columna izquierda: notas
----------------------------------------------------------------------

local selectNote   -- más abajo

local function noteRow(i)
	local row = noteRows[i]
	if row then return row end
	row = CreateFrame("Button", nil, noteList.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", noteList.child, "RIGHT")
	row.sel = row:CreateTexture(nil, "BACKGROUND")
	row.sel:SetAllPoints()
	row.sel:SetColorTexture(0.2, 0.8, 1, 0.22)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(0.2, 0.8, 1, 0.12)
	row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
	row.check:SetSize(20, 20)
	row.check:SetPoint("LEFT", 2, 0)
	row.check:SetScript("OnClick", function(self)
		local note = M:FindNote(row.id)
		if not note then return end
		note.enabled = self:GetChecked() and true or false
		M:UpdateVisibility()
		M:RefreshEditor()
	end)
	row.check:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(L["Nota activa"], 1, 1, 1)
		GameTooltip:AddLine(L["Desactivada no se ve nunca, pero no se borra."], nil, nil, nil, true)
		GameTooltip:Show()
	end)
	row.check:SetScript("OnLeave", GameTooltip_Hide)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.text:SetPoint("LEFT", row.check, "RIGHT", 2, 0)
	row.text:SetPoint("RIGHT", -4, 0)
	row.text:SetJustifyH("LEFT")
	row.text:SetWordWrap(false)
	row:SetScript("OnClick", function(self) selectNote(self.id) end)
	row:SetScript("OnEnter", function(self)
		local note = M:FindNote(self.id)
		if not note then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(note.title ~= "" and note.title or L["Nota"], 1, 1, 1)
		if note.shared then
			GameTooltip:AddLine(M:ShareStatus(note), 0.2, 0.8, 1)
			if note.shared.by then
				GameTooltip:AddLine(L["Último cambio: %s"]:format(R.NameKey(note.shared.by) or note.shared.by), 0.7, 0.7, 0.7)
			end
		end
		if not note.enabled then
			GameTooltip:AddLine(L["Desactivada"], 0.6, 0.6, 0.6)
		elseif note.owner and note.owner ~= R.charKey then
			GameTooltip:AddLine(L["Solo para %s"]:format(note.owner), 0.6, 0.6, 0.6)
		elseif M:RulesOK(note) then
			GameTooltip:AddLine(L["Con sus reglas, ahora se ve."], 0.2, 1, 0.2)
		else
			GameTooltip:AddLine(L["Con sus reglas, ahora no se ve."], 1, 0.5, 0.3)
		end
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	noteRows[i] = row
	return row
end

local function drawNotes()
	local list = M:GetNotes()
	for i, note in ipairs(list) do
		local row = noteRow(i)
		row.id = note.id
		row.check:SetChecked(note.enabled)
		local name = note.title ~= "" and note.title or L["Nota"]
		local dot
		if not note.enabled or (note.owner and note.owner ~= R.charKey) then
			dot = "|cff555555"
		elseif M:RulesOK(note) then
			dot = "|cff33ff33"
		else
			dot = "|cffff8040"
		end
		local tag = note.shared and "|cff33ccff@|r " or ""
		row.text:SetText(dot .. "•|r " .. tag .. name)
		row.sel:SetShown(note.id == selected)
		row:Show()
	end
	for i = #list + 1, #noteRows do noteRows[i]:Hide() end
	noteList.child:SetHeight(math.max(1, #list * ROW_H))
	if noteList.UpdateBar then noteList:UpdateBar() end
	deleteButton:SetEnabled(selected ~= nil)
	dupButton:SetEnabled(selected ~= nil)
	deleteButton:SetText(armed and L["|cffff5555¿Seguro? Pulsa otra vez|r"] or L["Borrar"])
end

----------------------------------------------------------------------
-- Centro: texto
----------------------------------------------------------------------

local function drawText()
	local note = current()
	titleBox:SetShown(note ~= nil)
	textScroll:SetShown(note ~= nil)
	if not note then return end
	local editable = M:CanEditNote(note)
	for _, box in ipairs({ titleBox, textBox }) do
		if not editable and box:HasFocus() then box:ClearFocus() end
		if box.SetEnabled then box:SetEnabled(editable) end
		box:SetTextColor(editable and 1 or 0.6, editable and 1 or 0.6, editable and 1 or 0.6)
	end
	if not titleBox:HasFocus() then titleBox:SetText(note.title or "") end
	if not textBox:HasFocus() then textBox:SetText(note.text or "") end
end

-- La nota cambió desde fuera (una casilla marcada en pantalla)
function M:OnNoteTextChanged(id)
	if win and win:IsShown() and id == selected and not textBox:HasFocus() then
		local note = current()
		if note then textBox:SetText(note.text or "") end
	end
end

-- Llegó una versión nueva de una nota compartida (Sync.lua): se pone
-- aunque la estés escribiendo, sin mover el cursor
function M:OnRemoteUpdate(note, by)
	if not win or not win:IsShown() or note.id ~= selected then return end
	for _, pair in ipairs({ { titleBox, note.title }, { textBox, note.text } }) do
		local box, text = pair[1], pair[2] or ""
		if box:GetText() ~= text then
			local pos = box:HasFocus() and box:GetCursorPosition()
			box:SetText(text)
			if pos then box:SetCursorPosition(math.min(pos, #text)) end
		end
	end
	setStatus(L["Actualizada por %s"]:format(R.NameKey(by) or by or "?"), 0.2, 0.8, 1)
	self:RefreshEditor()
end

local function insertInText(s)
	local note = current()
	if readOnly(note) then return end
	textBox:Insert(s)
	if note then
		note.text = textBox:GetText()
		M:QueueRender(note.id)
		M:NoteEdited(note)
	end
end

----------------------------------------------------------------------
-- Centro: lista de deseos
----------------------------------------------------------------------

local onWishDrop   -- más abajo

local function changedWish()
	local note = current()
	if not note then return end
	M:RenderNote(note.id)
	M:RefreshEditorWish()
	M:NoteEdited(note)
end

local function wishRow(i)
	local row = wishRows[i]
	if row then return row end
	row = CreateFrame("Frame", nil, wishList.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", wishList.child, "RIGHT")
	row:EnableMouse(true)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetSize(20, 20)
	row.icon:SetPoint("LEFT", 4, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	local function small(text, onClick)
		local b = button(row, text, 22, 20)
		b:SetScript("OnClick", onClick)
		return b
	end
	local function step(dir)
		local note = current()
		local w = note and note.wish[row.index]
		if not w or readOnly(note) then return end
		w.want = math.max(1, math.min(9999, (w.want or 1) + dir * (IsShiftKeyDown() and 10 or 1)))
		note.wishDone[w.id] = nil
		changedWish()
	end
	row.del = small("x", function()
		local note = current()
		if not note or readOnly(note) then return end
		local w = table.remove(note.wish, row.index)
		if w then note.wishDone[w.id] = nil end
		changedWish()
	end)
	row.del:SetPoint("RIGHT", -2, 0)
	row.plus = small("+", function() step(1) end)
	row.plus:SetPoint("RIGHT", row.del, "LEFT", -6, 0)
	row.want = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.want:SetWidth(36)
	row.want:SetPoint("RIGHT", row.plus, "LEFT", -2, 0)
	row.minus = small("-", function() step(-1) end)
	row.minus:SetPoint("RIGHT", row.want, "LEFT", -2, 0)
	row.have = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.have:SetWidth(50)
	row.have:SetJustifyH("RIGHT")
	row.have:SetPoint("RIGHT", row.minus, "LEFT", -4, 0)
	row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.name:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
	row.name:SetPoint("RIGHT", row.have, "LEFT", -4, 0)
	row.name:SetJustifyH("LEFT")
	row.name:SetWordWrap(false)
	row:SetScript("OnEnter", function(self)
		local note = current()
		local w = note and note.wish[self.index]
		if not w then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		pcall(GameTooltip.SetItemByID, GameTooltip, w.id)
		GameTooltip:AddLine(L["Mayús + clic en - o + cambia de 10 en 10."], 0.5, 0.5, 0.5)
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	row:SetScript("OnReceiveDrag", function() onWishDrop() end)
	wishRows[i] = row
	return row
end

local function drawWish()
	local note = current()
	local list = note and note.wish or {}
	for i, w in ipairs(list) do
		local row = wishRow(i)
		row.index = i
		local name, _, _, tex = MD.ItemInfo(w.id)
		if name then w.name = name end
		row.icon:SetTexture(tex or 134400)
		row.name:SetText(name or w.name or ("item:" .. w.id))
		local have = ns.Count(note, w.id)
		local want = w.want or 1
		row.have:SetText((have >= want and "|cff33ff33" or "|cffaaaaaa") .. have .. "|r /")
		row.want:SetText(want)
		row:Show()
	end
	for i = #list + 1, #wishRows do wishRows[i]:Hide() end
	wishList.child:SetHeight(math.max(1, #list * ROW_H))
	if wishList.UpdateBar then wishList:UpdateBar() end
	if note and #list > 0 then
		local done = 0
		for _, w in ipairs(list) do
			if ns.Count(note, w.id) >= (w.want or 1) then done = done + 1 end
		end
		wishCount:SetText(done .. "/" .. #list)
	else
		wishCount:SetText("")
	end
end

function M:RefreshEditorWish()
	if win and win:IsShown() then drawWish() end
end

-- "20 Loto negro", "Loto negro x20", un número, un enlace…
local function parseWish(text, qtyText)
	text = strtrim(text or "")
	if text == "" then return nil, L["Escribe un objeto: su número, su nombre o Mayús + clic en él."] end
	local qty = tonumber(qtyText or "")
	local id = tonumber(text) or tonumber(text:match("item:(%d+)") or "")
	if not id then
		local n, rest = text:match("^(%d+)%s*[xX]?%s+(.+)$")
		if not n then rest, n = text:match("^(.-)%s*[xX]%s*(%d+)$") end
		if n then
			qty = qty or tonumber(n)
			text = strtrim(rest)
		end
		id = tonumber(text) or tonumber(text:match("item:(%d+)") or "")
	end
	if not id and C_Item and C_Item.GetItemInfoInstant then
		local ok, found = pcall(C_Item.GetItemInfoInstant, text)
		id = ok and NS(found) or nil
	elseif not id and GetItemInfoInstant then
		local ok, found = pcall(GetItemInfoInstant, text)
		id = ok and NS(found) or nil
	end
	if type(id) ~= "number" then
		return nil, L["No se encuentra ese objeto: prueba con su número o con Mayús + clic en él."]
	end
	return id, math.max(1, math.floor(qty or 1))
end

local function addWish(id, qty)
	local note = current()
	if not note then
		setStatus(L["Crea o elige antes una nota."], 1, 0.33, 0.33)
		return
	end
	if readOnly(note) then return end
	for _, w in ipairs(note.wish) do
		if w.id == id then
			w.want = qty
			note.wishDone[id] = nil
			setStatus(L["Actualizado: %s"]:format(w.name or ("item:" .. id)), 0.2, 1, 0.2)
			changedWish()
			return
		end
	end
	local name = MD.ItemInfo(id)
	table.insert(note.wish, { id = id, want = qty, name = name })
	setStatus(L["Añadido: %s"]:format(name or ("item:" .. id)), 0.2, 1, 0.2)
	changedWish()
end

local function onAddWish()
	local id, qty = parseWish(itemBox:GetText(), qtyBox:GetText())
	if id then
		addWish(id, qty)
		itemBox:SetText("")
		qtyBox:SetText("")
		itemBox:ClearFocus()
		qtyBox:ClearFocus()
	else
		setStatus(qty, 1, 0.33, 0.33)
	end
end

function onWishDrop()
	local kind, id = GetCursorInfo()
	id = NS(id)
	if kind == "item" and type(id) == "number" then
		addWish(id, tonumber(qtyBox:GetText() or "") or 1)
	elseif kind then
		setStatus(L["Aquí solo se pueden soltar objetos."], 1, 0.33, 0.33)
	end
	ClearCursor()
end

----------------------------------------------------------------------
-- Derecha: ajustes de la nota
----------------------------------------------------------------------

local function pct(v) return string.format("%d%%", v * 100 + 0.5) end
local function int(v) return string.format("%d", v) end

local function ownerValues(note)
	local values = {
		{ "all", "Todos tus personajes" },
		{ "me", "Solo este personaje" },
	}
	if note.owner and note.owner ~= R.charKey then
		values[#values + 1] = { "other", L["Solo %s"]:format(note.owner) }
	end
	return values
end

local function ownerValue(note)
	if not note.owner then return "all" end
	if note.owner == R.charKey then return "me" end
	return "other"
end

local SETTINGS = {
	{ kind = "header", text = "Nota" },
	{ kind = "share" },
	{ kind = "check", key = "enabled", name = "Nota activa" },
	{ kind = "choice", key = "owner", name = "Personajes", values = "owner" },
	{ kind = "stack", key = "stack", name = "Grupo de notas" },
	{ kind = "header", text = "Cuándo se ve" },
	{ kind = "choice", key = "group", name = "Grupo", values = ns.GROUPS },
	{ kind = "choice", key = "instance", name = "Dónde", values = ns.INSTANCES },
	{ kind = "zones", key = "zones", name = "Solo en estas zonas" },
	{ kind = "choice", key = "combat", name = "Combate", values = ns.COMBAT },
	{ kind = "check", key = "hideMounted", name = "Ocultar al ir montado" },
	{ kind = "header", text = "Aspecto" },
	{ kind = "check", key = "showTitle", name = "Barra de título (plegar y desplegar)" },
	{ kind = "check", key = "border", name = "Borde" },
	{ kind = "num", key = "width", name = "Ancho", min = 120, max = 900, step = 10, fmt = int },
	{ kind = "num", key = "maxHeight", name = "Alto máximo", min = 0, max = 1200, step = 10,
	  fmt = function(v) return v == 0 and L["Sin límite"] or string.format("%d", v) end },
	{ kind = "num", key = "fontSize", name = "Tamaño de la letra", min = 8, max = 30, step = 1, fmt = int },
	{ kind = "choice", key = "font", name = "Fuente", values = ns.FONTS },
	{ kind = "choice", key = "textColor", name = "Color del texto", values = R.COLORS },
	{ kind = "num", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05, fmt = pct },
	{ kind = "num", key = "scale", name = "Escala", min = 0.5, max = 2, step = 0.05, fmt = pct },
	{ kind = "header", text = "Lista de deseos" },
	{ kind = "check", key = "wishBank", name = "Contar lo que tienes en el banco" },
	{ kind = "check", key = "wishAlts", name = "Contar tus otros personajes", needsChars = true },
	{ kind = "check", key = "wishAlert", name = "Avisar al conseguir cada objeto" },
	{ kind = "check", key = "wishHideDone", name = "Ocultar lo ya conseguido" },
	{ kind = "header", text = "Posición" },
	{ kind = "action", name = "Volver a colocarla en el centro", text = "Restablecer",
	  func = function(note)
		note.point = { "TOPLEFT", "CENTER", -math.floor(note.width / 2), 100 }
	  end },
}

local function setValue(key, value)
	local note = current()
	if not note then return end
	if key == "owner" then
		if value == "all" then note.owner = nil
		elseif value == "me" then note.owner = R.charKey end
	else
		note[key] = value
	end
	M:RenderNote(note.id)
	M:UpdateVisibility()
	M:RefreshEditor()
end

local function makeControls(parent)
	local y = 0
	local labelW = 110
	for _, s in ipairs(SETTINGS) do
		local kind = s.kind
		local c = CreateFrame("Frame", nil, parent)
		if kind == "header" then
			c:SetHeight(24)
			c.text = c:CreateFontString(nil, "OVERLAY", "GameFontNormal")
			c.text:SetPoint("BOTTOMLEFT", 2, 3)
			c.text:SetText(L[s.text])
			local line = c:CreateTexture(nil, "ARTWORK")
			line:SetColorTexture(0.2, 0.8, 1, 0.3)
			line:SetHeight(1)
			line:SetPoint("BOTTOMLEFT", 0, 0)
			line:SetPoint("BOTTOMRIGHT", 0, 0)
		elseif kind == "choice" then
			c:SetHeight(ROW_H)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetWidth(labelW - 6)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.drop = dropdown(c, SET_W - labelW - 26)
			c.drop:SetPoint("LEFT", labelW, 0)
			function c:Refresh(note)
				if s.values == "owner" then
					self.drop:SetValues(ownerValues(note), ownerValue(note), function(v) setValue("owner", v) end)
				else
					self.drop:SetValues(s.values, note[s.key], function(v) setValue(s.key, v) end)
				end
			end
		elseif kind == "num" then
			c:SetHeight(ROW_H)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetWidth(labelW - 6)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			local minus = button(c, "-", 24, 20)
			minus:SetPoint("LEFT", labelW, 0)
			c.value = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
			c.value:SetPoint("LEFT", minus, "RIGHT", 4, 0)
			c.value:SetWidth(64)
			local plus = button(c, "+", 24, 20)
			plus:SetPoint("LEFT", c.value, "RIGHT", 4, 0)
			local function step(dir)
				local note = current()
				if not note then return end
				local v = (note[s.key] or 0) + s.step * (IsShiftKeyDown() and 10 or 1) * dir
				v = math.max(s.min, math.min(s.max, v))
				v = math.floor(v / s.step + 0.5) * s.step
				setValue(s.key, v)
			end
			minus:SetScript("OnClick", function() step(-1) end)
			plus:SetScript("OnClick", function() step(1) end)
			function c:Refresh(note)
				self.value:SetText(s.fmt(note[s.key] or 0))
			end
		elseif kind == "check" then
			c:SetHeight(ROW_H - 2)
			c.check = CreateFrame("CheckButton", nil, c, "UICheckButtonTemplate")
			c.check:SetSize(22, 22)
			c.check:SetPoint("LEFT", 0, 0)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", c.check, "RIGHT", 4, 0)
			c.label:SetPoint("RIGHT", 0, 0)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.check:SetScript("OnClick", function(self) setValue(s.key, self:GetChecked() and true or false) end)
			if s.needsChars then
				c.check:SetScript("OnEnter", function(self)
					GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
					GameTooltip:SetText(L[s.name], 1, 1, 1)
					GameTooltip:AddLine(L["Con lo que Rheizor Personajes recuerda de cada uno (bolsas, banco, buzón y equipado), del mismo reino. Cada personaje se actualiza al entrar con él."], nil, nil, nil, true)
					if not ns.HasCharacters() then
						GameTooltip:AddLine(L["Necesita el addon Rheizor Personajes activado."], 1, 0.4, 0.4, true)
					end
					GameTooltip:Show()
				end)
				c.check:SetScript("OnLeave", GameTooltip_Hide)
			end
			function c:Refresh(note)
				self.check:SetChecked(note[s.key] and true or false)
			end
		elseif kind == "zones" then
			c:SetHeight(ROW_H * 2 + 4)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("TOPLEFT", 2, -5)
			c.label:SetText(L[s.name])
			c.add = button(c, L["+ Zona actual"], 100, 20)
			c.add:SetPoint("TOPRIGHT", -2, -1)
			c.box = inputBox(c, SET_W - 30, 400)
			c.box:SetPoint("TOPLEFT", 0, -ROW_H)
			c.box:SetPoint("RIGHT", c, "RIGHT", -2, 0)
			local function save(self)
				local note = current()
				if note and self:GetText() ~= note.zones then setValue("zones", self:GetText()) end
			end
			c.box:SetScript("OnEnterPressed", function(self) save(self) self:ClearFocus() end)
			c.box:SetScript("OnEditFocusLost", save)
			c.box:SetScript("OnEnter", function(self)
				GameTooltip:SetOwner(self, "ANCHOR_TOP")
				GameTooltip:SetText(L[s.name], 1, 1, 1)
				GameTooltip:AddLine(L["Separadas por comas. Vale el nombre de la zona, de la subzona o de la instancia, o una parte (\"magma\" encaja con \"Núcleo de Magma\"). Vacío: en todas."], nil, nil, nil, true)
				GameTooltip:Show()
			end)
			c.box:SetScript("OnLeave", GameTooltip_Hide)
			c.add:SetScript("OnClick", function()
				local note = current()
				local zone = ns.CurrentZone()
				if not note or not zone then return end
				local text = strtrim(note.zones or "")
				for part in text:gmatch("[^,;\n]+") do
					if strtrim(part):lower() == zone:lower() then return end
				end
				setValue("zones", text == "" and zone or (text .. ", " .. zone))
			end)
			function c:Refresh(note)
				if not self.box:HasFocus() then self.box:SetText(note.zones or "") end
			end
		elseif kind == "stack" then
			-- Un grupo que ya existe (desplegable) o uno nuevo (escribiendo)
			c:SetHeight(ROW_H * 2 + 4)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("TOPLEFT", 2, -7)
			c.label:SetWidth(labelW - 6)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.drop = dropdown(c, SET_W - labelW - 26)
			c.drop:SetPoint("TOPLEFT", labelW, -2)
			c.box = inputBox(c, SET_W - 30, 40)
			c.box:SetPoint("TOPLEFT", 0, -ROW_H - 2)
			c.box:SetPoint("RIGHT", c, "RIGHT", -2, 0)
			c.hint = c.box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
			c.hint:SetPoint("LEFT", 6, 0)
			c.hint:SetText(L["Nuevo grupo…"])
			local function updateHint()
				c.hint:SetShown(c.box:GetText() == "" and not c.box:HasFocus())
			end
			c.box:HookScript("OnTextChanged", updateHint)
			c.box:HookScript("OnEditFocusGained", updateHint)
			local function save(self)
				local note = current()
				local text = strtrim(self:GetText() or "")
				if note and text ~= "" and text ~= note.stack then
					setValue("stack", text)
					self:SetText("")
				end
				updateHint()
			end
			c.box:SetScript("OnEnterPressed", function(self) save(self) self:ClearFocus() end)
			c.box:SetScript("OnEditFocusLost", save)
			c.box:SetScript("OnEnter", function(self)
				GameTooltip:SetOwner(self, "ANCHOR_TOP")
				GameTooltip:SetText(L["Nuevo grupo"], 1, 1, 1)
				GameTooltip:AddLine(L["Escribe un nombre y pulsa Enter. Las notas con el mismo grupo van una debajo de otra, en el orden de la lista, y se mueven juntas. El modo acordeón y el resto de opciones de grupos están en las opciones de Notas."], nil, nil, nil, true)
				GameTooltip:Show()
			end)
			c.box:SetScript("OnLeave", GameTooltip_Hide)
			function c:Refresh(note)
				local values = { { "", "Sin grupo" } }
				for _, name in ipairs(M:GetStackNames()) do values[#values + 1] = { name, name } end
				self.drop:SetValues(values, strtrim(note.stack or ""), function(v) setValue("stack", v) end)
			end
		elseif kind == "share" then
			-- Con quién se comparte (la ventana está en Share.lua)
			c:SetHeight(ROW_H + 2)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetPoint("RIGHT", -104, 0)
			c.label:SetJustifyH("LEFT")
			c.label:SetWordWrap(false)
			c.button = button(c, L["Compartir…"], 96, 22)
			c.button:SetPoint("RIGHT", -2, 0)
			c.button:SetScript("OnClick", function()
				local note = current()
				if note and ns.OpenShare then ns.OpenShare(note.id, win) end
			end)
			function c:Refresh(note)
				self.label:SetText((note.shared and "|cff33ccff" or "|cffaaaaaa") .. M:ShareStatus(note) .. "|r")
			end
		elseif kind == "action" then
			c:SetHeight(ROW_H + 2)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetPoint("RIGHT", -104, 0)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.button = button(c, L[s.text], 96, 22)
			c.button:SetPoint("RIGHT", -2, 0)
			c.button:SetScript("OnClick", function()
				local note = current()
				if not note then return end
				s.func(note)
				M:RenderNote(note.id)
			end)
		end
		c:SetPoint("TOPLEFT", 0, -y)
		c:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
		y = y + c:GetHeight()
		controls[#controls + 1] = c
	end
	return y
end

local function drawSettings()
	local note = current()
	settings:SetShown(note ~= nil)
	if not note then return end
	for _, c in ipairs(controls) do
		if c.Refresh then c:Refresh(note) end
	end
end

----------------------------------------------------------------------
-- Enlaces con Mayús + clic mientras se escribe aquí
----------------------------------------------------------------------

local lastLink, lastTime
local function onInsertLink(link)
	if not win or not win:IsShown() or type(link) ~= "string" then return end
	-- Puede llegar dos veces (función nueva y la antigua que la llama)
	local now = GetTime()
	if link == lastLink and now == lastTime then return end
	lastLink, lastTime = link, now
	if textBox:HasFocus() then
		local item = link:match("|Hitem:(%d+)")
		local spell = link:match("|Hspell:(%d+)")
		if item then
			insertInText("{item:" .. item .. "}")
		elseif spell then
			insertInText("{spell:" .. spell .. "}")
		else
			insertInText(link)
		end
	elseif itemBox:HasFocus() then
		local item = link:match("|Hitem:(%d+)")
		if item then
			local id = tonumber(item)
			addWish(id, tonumber(qtyBox:GetText() or "") or 1)
			itemBox:SetText("")
		end
	end
end

local hooked = false
local function hookLinks()
	if hooked then return end
	hooked = true
	if ChatFrameUtil and ChatFrameUtil.InsertLink then
		hooksecurefunc(ChatFrameUtil, "InsertLink", onInsertLink)
	end
	if ChatEdit_InsertLink then
		hooksecurefunc("ChatEdit_InsertLink", onInsertLink)
	end
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

function M:RefreshEditorList()
	if win and win:IsShown() then drawNotes() end
end

function M:RefreshEditor()
	if not win or not win:IsShown() then return end
	if selected and not current() then selected = nil end
	drawNotes()
	drawText()
	drawWish()
	drawSettings()
end

function selectNote(id)
	-- Lo que se estaba escribiendo ya está guardado (se guarda al teclear)
	titleBox:ClearFocus()
	textBox:ClearFocus()
	selected = id
	armed = false
	setStatus("")
	if textScroll.SetVerticalScroll then textScroll:SetVerticalScroll(0) end
	M:SetEditorSelected(id)
	M:RefreshEditor()
end

local function column(x, width, title)
	local f = CreateFrame("Frame", nil, win, "BackdropTemplate")
	f:SetPoint("TOPLEFT", x, -58)
	f:SetPoint("BOTTOMLEFT", x, 12)
	f:SetWidth(width)
	backdrop(f, 0.45)
	f:SetBackdropBorderColor(1, 1, 1, 0.08)
	local t = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	t:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 2, 4)
	t:SetText(title)
	return f
end

local function helpTooltip(owner)
	GameTooltip:SetOwner(owner, "ANCHOR_RIGHT")
	GameTooltip:SetText(L["Formato (Markdown)"], 1, 1, 1)
	for _, h in ipairs(MD.HELP) do
		GameTooltip:AddDoubleLine("|cffffd100" .. L[h[1]] .. "|r", L[h[2]], 1, 1, 1, 0.8, 0.8, 0.8)
	end
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine(L["Mayús + clic en un objeto o hechizo mientras escribes lo añade. También puedes soltarlo encima del texto."], 0.6, 0.6, 0.6, true)
	GameTooltip:Show()
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorNotesEditor", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	backdrop(win, 0.94)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorNotesEditor")   -- se cierra con Esc

	local drag = CreateFrame("Frame", nil, win)
	drag:SetPoint("TOPLEFT")
	drag:SetPoint("TOPRIGHT", -30, 0)
	drag:SetHeight(30)
	drag:EnableMouse(true)
	drag:RegisterForDrag("LeftButton")
	drag:SetScript("OnDragStart", function() win:StartMoving() end)
	drag:SetScript("OnDragStop", function()
		win:StopMovingOrSizing()
		win:SetUserPlaced(false)
		local point, _, relPoint, px, py = win:GetPoint()
		M.db.winPoint = { point, relPoint, px, py }
	end)

	local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -9)
	title:SetText("|cff33ccffRheizor|r · " .. L["Notas"])

	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() win:Hide() end)

	local hint = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
	hint:SetText(L["Los cambios se ven en pantalla al escribir. Mientras esta ventana está abierta se ven todas las notas activas."])

	-- Izquierda: notas
	local left = column(10, LIST_W, L["Notas"])
	noteList = scroll(left)
	noteList:SetPoint("TOPLEFT", 2, -2)
	noteList:SetPoint("BOTTOMRIGHT", -4, 62)
	noteList.child:SetSize(LIST_W - 8, 1)
	local new = button(left, L["Nueva"], (LIST_W - 12) / 2)
	new:SetPoint("BOTTOMLEFT", 4, 34)
	new:SetScript("OnClick", function()
		local note = M:NewNote()
		selectNote(note.id)
		titleBox:SetFocus()
		titleBox:HighlightText()
	end)
	dupButton = button(left, L["Duplicar"], (LIST_W - 12) / 2)
	dupButton:SetPoint("LEFT", new, "RIGHT", 4, 0)
	dupButton:SetScript("OnClick", function()
		if not selected then return end
		local note = M:DuplicateNote(selected)
		if note then selectNote(note.id) end
	end)
	deleteButton = button(left, L["Borrar"], LIST_W - 8)
	deleteButton:SetPoint("BOTTOMLEFT", 4, 6)
	deleteButton:SetScript("OnClick", function()
		if not selected then return end
		if not armed then
			armed = true
			drawNotes()
			return
		end
		armed = false
		M:DeleteNote(selected)
		selected = nil
		local first = M:GetNotes()[1]
		selectNote(first and first.id)
	end)

	-- Centro: título, texto y lista de deseos
	local mid = column(10 + LIST_W + 10, MID_W, L["Nota"])
	local titleLabel = mid:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	titleLabel:SetPoint("TOPLEFT", 8, -14)
	titleLabel:SetText(L["Título"])
	titleBox = inputBox(mid, 10, 60)
	titleBox:SetPoint("LEFT", titleLabel, "RIGHT", 8, 0)
	titleBox:SetPoint("RIGHT", mid, "RIGHT", -8, 0)
	titleBox:SetScript("OnTextChanged", function(self, userInput)
		local note = current()
		if not userInput or not note or not M:CanEditNote(note) then return end
		note.title = self:GetText()
		M:QueueRender(note.id)
		M:NoteEdited(note)
		drawNotes()
	end)
	titleBox:SetScript("OnEnterPressed", function(self)
		self:ClearFocus()
		textBox:SetFocus()
	end)

	-- Caja de texto con varias líneas
	local textFrame = CreateFrame("Frame", nil, mid, "BackdropTemplate")
	textFrame:SetPoint("TOPLEFT", 6, -38)
	textFrame:SetPoint("RIGHT", mid, "RIGHT", -6, 0)
	textFrame:SetHeight(EDIT_H)
	textFrame:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	textFrame:SetBackdropColor(0, 0, 0, 0.6)
	textFrame:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	textScroll = CreateFrame("ScrollFrame", nil, textFrame, "UIPanelScrollFrameTemplate")
	textScroll:SetPoint("TOPLEFT", 6, -6)
	textScroll:SetPoint("BOTTOMRIGHT", -26, 6)
	textBox = CreateFrame("EditBox", nil, textScroll)
	textBox:SetMultiLine(true)
	textBox:SetAutoFocus(false)
	textBox:SetFontObject(ChatFontNormal)
	textBox:SetWidth(MID_W - 12 - 32)
	textBox:SetMaxLetters(0)
	textScroll:SetScrollChild(textBox)
	textBox:SetScript("OnEscapePressed", textBox.ClearFocus)
	textBox:SetScript("OnTabPressed", function(self) self:Insert("  ") end)
	textBox:SetScript("OnTextChanged", function(self, userInput)
		local note = current()
		if not userInput or not note or not M:CanEditNote(note) then return end
		note.text = self:GetText()
		M:QueueRender(note.id)
		M:NoteEdited(note)
	end)
	-- La caja sigue al cursor al escribir
	textBox:SetScript("OnCursorChanged", function(self, _, y, _, h)
		local off = textScroll:GetVerticalScroll()
		local height = textScroll:GetHeight()
		y = -y
		if y < off then
			textScroll:SetVerticalScroll(y)
		elseif y + h > off + height then
			textScroll:SetVerticalScroll(math.max(0, y + h - height))
		end
	end)
	local function dropOnText()
		local kind, a, _, c = GetCursorInfo()
		if kind == "item" and NS(a) then
			insertInText("{item:" .. NS(a) .. "}")
		elseif kind == "spell" then
			local id = NS(c) or NS(a)
			if type(id) == "number" then insertInText("{spell:" .. id .. "}") end
		end
		ClearCursor()
	end
	textBox:SetScript("OnReceiveDrag", dropOnText)
	-- Clic en el hueco vacío: a escribir
	local focus = CreateFrame("Button", nil, textFrame)
	focus:SetAllPoints(textScroll)
	focus:SetFrameLevel(textScroll:GetFrameLevel() - 1)
	focus:SetScript("OnClick", function()
		textBox:SetFocus()
		textBox:SetCursorPosition(#(textBox:GetText() or ""))
	end)
	focus:SetScript("OnReceiveDrag", dropOnText)

	local help = button(mid, L["Formato"], 90)
	help:SetPoint("TOPLEFT", textFrame, "BOTTOMLEFT", 0, -6)
	help:SetScript("OnEnter", helpTooltip)
	help:SetScript("OnLeave", GameTooltip_Hide)
	help:SetScript("OnClick", helpTooltip)
	local clear = button(mid, L["Desmarcar casillas"], 140)
	clear:SetPoint("LEFT", help, "RIGHT", 4, 0)
	clear:SetScript("OnClick", function()
		local note = current()
		if not note or readOnly(note) then return end
		note.text = MD.ClearChecks(note.text)
		textBox:SetText(note.text)
		M:RenderNote(note.id)
		M:NoteEdited(note)
	end)
	local marks = button(mid, "{rt1}…{rt8}", 90)
	marks:SetPoint("LEFT", clear, "RIGHT", 4, 0)
	marks:SetScript("OnClick", function()
		local s = {}
		for i = 1, 8 do s[i] = "{rt" .. i .. "}" end
		textBox:SetFocus()
		insertInText(table.concat(s, " "))
	end)
	marks:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Marcas de banda"], 1, 1, 1)
		local line = ""
		for i = 1, 8 do line = line .. "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_" .. i .. ":16|t {rt" .. i .. "}  " end
		GameTooltip:AddLine(line, 1, 1, 1, true)
		GameTooltip:Show()
	end)
	marks:SetScript("OnLeave", GameTooltip_Hide)

	-- Lista de deseos
	local wishTitle = mid:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	wishTitle:SetPoint("TOPLEFT", help, "BOTTOMLEFT", 2, -12)
	wishTitle:SetText(L["Lista de deseos"])
	wishCount = mid:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	wishCount:SetPoint("LEFT", wishTitle, "RIGHT", 8, 0)
	local wishHint = mid:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	wishHint:SetPoint("LEFT", wishCount, "RIGHT", 8, 0)
	wishHint:SetPoint("RIGHT", mid, "RIGHT", -8, 0)
	wishHint:SetJustifyH("RIGHT")
	wishHint:SetText(L["Tienes / quieres"])

	local wishArea = CreateFrame("Button", nil, mid)
	wishArea:SetPoint("TOPLEFT", wishTitle, "BOTTOMLEFT", -2, -4)
	wishArea:SetPoint("BOTTOMRIGHT", mid, "BOTTOMRIGHT", -4, 62)
	wishArea:SetScript("OnReceiveDrag", onWishDrop)
	wishArea:SetScript("OnClick", onWishDrop)
	wishList = scroll(wishArea)
	wishList:SetAllPoints()
	wishList.child:SetSize(MID_W - 12, 1)

	itemBox = inputBox(mid, MID_W - 12 - 44 - 70 - 8, 200)
	itemBox:SetPoint("BOTTOMLEFT", 6, 34)
	itemBox:SetScript("OnEnterPressed", onAddWish)
	itemBox:SetScript("OnReceiveDrag", onWishDrop)
	itemBox:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Objeto"], 1, 1, 1)
		GameTooltip:AddLine(L["Su número, su nombre (si el juego ya lo conoce), \"20 Loto negro\", o Mayús + clic en el objeto con esta casilla activa. También puedes soltarlo en la lista."], nil, nil, nil, true)
		GameTooltip:Show()
	end)
	itemBox:SetScript("OnLeave", GameTooltip_Hide)
	local placeholder = itemBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	placeholder:SetPoint("LEFT", 6, 0)
	placeholder:SetText(L["Objeto (número, nombre o Mayús + clic)"])
	itemBox:HookScript("OnTextChanged", function(self) placeholder:SetShown(self:GetText() == "") end)
	itemBox:HookScript("OnEditFocusGained", function() placeholder:Hide() end)
	itemBox:HookScript("OnEditFocusLost", function(self) placeholder:SetShown(self:GetText() == "") end)
	qtyBox = inputBox(mid, 44, 5)
	qtyBox:SetPoint("LEFT", itemBox, "RIGHT", 4, 0)
	qtyBox:SetNumeric(true)
	qtyBox:SetScript("OnEnterPressed", onAddWish)
	qtyBox:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Cantidad"], 1, 1, 1)
		GameTooltip:Show()
	end)
	qtyBox:SetScript("OnLeave", GameTooltip_Hide)
	local add = button(mid, L["Añadir"], 70)
	add:SetPoint("LEFT", qtyBox, "RIGHT", 4, 0)
	add:SetScript("OnClick", onAddWish)

	statusText = mid:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	statusText:SetPoint("BOTTOMLEFT", 8, 12)
	statusText:SetPoint("RIGHT", mid, "RIGHT", -8, 0)
	statusText:SetJustifyH("LEFT")
	statusText:SetWordWrap(false)

	-- Derecha: ajustes
	local right = column(10 + LIST_W + 10 + MID_W + 10, SET_W, L["Ajustes de la nota"])
	settings = scroll(right)
	settings:SetPoint("TOPLEFT", 6, -6)
	settings:SetPoint("BOTTOMRIGHT", -4, 4)
	settings.child:SetSize(SET_W - 14, 1)
	settings.child:SetHeight(makeControls(settings.child) + 10)

	win:SetScript("OnShow", function()
		if not selected or not current() then
			local first = M:GetNotes()[1]
			selected = first and first.id
		end
		M:SetEditorOpen(true, selected)
		M:RefreshEditor()
	end)
	win:SetScript("OnHide", function()
		armed = false
		titleBox:ClearFocus()
		textBox:ClearFocus()
		itemBox:ClearFocus()
		qtyBox:ClearFocus()
		M:SetEditorOpen(false)
	end)

	hookLinks()

	local p = M.db.winPoint
	if p then win:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else win:SetPoint("CENTER") end
end

function M:ToggleEditor()
	if not win then createWindow() end
	win:SetShown(not win:IsShown())
end

-- Abre el editor con esa nota elegida (clic derecho en su título o el
-- engranaje de su recuadro de mover)
function M:OpenEditorAt(id)
	if not win then createWindow() end
	if win:IsShown() then
		selectNote(id)
	else
		selected = id
		win:Show()
	end
end
