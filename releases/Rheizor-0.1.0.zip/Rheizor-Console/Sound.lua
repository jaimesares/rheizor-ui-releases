-- Sonido (CVars). La voz de los errores está en Mensajes de error (Errors.lua).

local R = Rheizor:Namespace(...)

R:RegisterModule("sound", {
	title = "Sonido",
	group = "Configuraciones",
	options = {
		{ type = "toggle", cvar = "Sound_EnableSoundWhenGameIsInBG", name = "Sonido en segundo plano",
		  desc = "Sigue sonando el juego cuando la ventana no está activa." },
		{ type = "toggle", cvar = "Sound_EnableEmoteSounds", name = "Sonidos de emociones" },
		{ type = "toggle", cvar = "Sound_EnablePetSounds", name = "Sonidos de mascotas" },
		{ type = "toggle", cvar = "Sound_EnableAmbience", name = "Sonido ambiente" },
		{ type = "toggle", cvar = "Sound_EnableReverb", name = "Reverberación" },
	},
})
