-- Sistema: rendimiento, capturas e interfaz (CVars).
-- El despojo automático está en Rheizor-Automation y la ventana de botín bajo
-- el ratón la maneja Rheizor-Loot.

local R = Rheizor:Namespace(...)
local L = R.L

-- Límite de FPS: en el motor moderno hacen falta dos CVars (useMaxFPS + maxFPS).
-- En el deslizador, 0 significa "sin límite".
local function fpsLimit(useCVar, valueCVar, name, desc)
	return {
		type = "slider", id = valueCVar, name = name, desc = desc,
		min = 0, max = 240, step = 5, default = 0,
		format = function(v) return v < 1 and L["Sin límite"] or R.fmt.int(v) end,
		get = function()
			if C_CVar.GetCVar(useCVar) ~= "1" then return 0 end
			return tonumber(C_CVar.GetCVar(valueCVar)) or 0
		end,
		set = function(v)
			if v < 1 then
				R:SetCVar(useCVar, "0")
			else
				R:SetCVar(valueCVar, tostring(math.floor(v + 0.5)))
				R:SetCVar(useCVar, "1")
			end
		end,
	}
end

R:RegisterModule("system", {
	title = "Sistema",
	group = "Configuraciones",
	options = {
		{ type = "header", text = "Rendimiento" },
		fpsLimit("useMaxFPS", "maxFPS", "Límite de FPS"),
		fpsLimit("useMaxFPSBk", "maxFPSBk", "Límite de FPS en segundo plano",
			"FPS cuando la ventana del juego no está activa. Ahorra GPU y batería."),

		{ type = "header", text = "Capturas de pantalla" },
		{ type = "dropdown", cvar = "screenshotFormat", name = "Formato",
		  values = { { "jpeg", "JPG" }, { "png", "PNG" }, { "tga", "TGA" } } },
		{ type = "slider", cvar = "screenshotQuality", name = "Calidad (JPG)",
		  min = 1, max = 10, step = 1, format = R.fmt.int },

		{ type = "header", text = "Interfaz" },
		{ type = "dropdown", cvar = "statusTextDisplay", name = "Texto en barras de vida/maná",
		  values = {
			{ "NONE", "Ninguno" },
			{ "NUMERIC", "Números" },
			{ "PERCENT", "Porcentaje" },
			{ "BOTH", "Ambos" },
		  } },
		{ type = "toggle", cvar = "showTutorials", name = "Mostrar tutoriales" },
		{ type = "toggle", cvar = "scriptErrors", name = "Mostrar errores de Lua",
		  desc = "Muestra una ventana cuando un addon (o Rheizor) falla. Útil para depurar." },
	},
})
