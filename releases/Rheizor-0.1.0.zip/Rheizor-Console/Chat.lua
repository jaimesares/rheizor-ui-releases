-- Chat y bocadillos (CVars).

local R = Rheizor:Namespace(...)

R:RegisterModule("chat", {
	title = "Chat",
	group = "Configuraciones",
	options = {
		{ type = "header", text = "Ventana de chat" },
		{ type = "dropdown", cvar = "showTimestamps", name = "Marca de hora",
		  values = {
			{ "none", "Ninguna" },
			{ "%H:%M ", "15:27" },
			{ "%H:%M:%S ", "15:27:32" },
			{ "[%H:%M] ", "[15:27]" },
			{ "[%H:%M:%S] ", "[15:27:32]" },
			{ "%I:%M %p ", "03:27 PM" },
		  } },
		{ type = "dropdown", cvar = "chatStyle", name = "Estilo de chat",
		  values = { { "classic", "Clásico" }, { "im", "Mensajería instantánea" } } },
		{ type = "dropdown", cvar = "whisperMode", name = "Susurros",
		  values = {
			{ "inline", "En la ventana de chat" },
			{ "popout", "En una pestaña nueva" },
			{ "popout_and_inline", "Ambos" },
		  } },
		{ type = "toggle", cvar = "chatMouseScroll", name = "Desplazar con la rueda del ratón" },
		{ type = "toggle", cvar = "profanityFilter", name = "Filtro de lenguaje soez" },

		{ type = "header", text = "Bocadillos" },
		{ type = "toggle", cvar = "chatBubbles", name = "Bocadillos de chat" },
		{ type = "toggle", cvar = "chatBubblesParty", name = "Bocadillos de grupo" },
	},
})
