-- Combate: lanzamiento de hechizos y avisos (CVars).
-- Los ajustes del texto de combate de Blizzard (números de daño sobre el
-- objetivo, texto sobre tu personaje…) están en Rheizor-CombatText, en su
-- apartado "Texto de combate de Blizzard".

local R = Rheizor:Namespace(...)

R:RegisterModule("combat", {
	title = "Combate",
	group = "Configuraciones",
	options = {
		{ type = "header", text = "Hechizos" },
		{ type = "slider", cvar = "SpellQueueWindow", name = "Ventana de cola de hechizos",
		  min = 0, max = 400, step = 10, format = R.fmt.ms,
		  desc = "Margen para encadenar el siguiente hechizo antes de que termine el actual. Con poca latencia, 100-150 ms suele ir mejor." },
		{ type = "toggle", cvar = "autoSelfCast", name = "Autolanzamiento sobre uno mismo",
		  desc = "Los hechizos de ayuda se lanzan sobre ti si no tienes un objetivo aliado." },
		{ type = "slider", cvar = "spellActivationOverlayOpacity", name = "Opacidad de alertas de procs",
		  min = 0, max = 1, step = 0.05, format = R.fmt.percent },

		{ type = "header", text = "Avisos" },
		{ type = "toggle", cvar = "doNotFlashLowHealthWarning", invert = true, name = "Parpadeo rojo con poca vida" },
	},
})
