-- Mensajes de error rojos en el centro de la pantalla ("No tengo suficiente maná"…).
-- Rheizor recibe UI_ERROR_MESSAGE en lugar de UIErrorsFrame, descarta los
-- elegidos y le pasa el resto. Los mensajes amarillos (misiones) no se tocan.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

-- Categoría -> cadenas globales de Blizzard (ya traducidas al idioma del juego)
local CATEGORIES = {
	hidePower = { "ERR_OUT_OF_MANA", "ERR_OUT_OF_RAGE", "ERR_OUT_OF_ENERGY", "ERR_OUT_OF_FOCUS",
	              "ERR_OUT_OF_RUNIC_POWER", "ERR_OUT_OF_POWER_DISPLAY", "SPELL_FAILED_NO_POWER" },
	hideRange = { "ERR_OUT_OF_RANGE", "SPELL_FAILED_OUT_OF_RANGE", "ERR_SPELL_OUT_OF_RANGE", "SPELL_FAILED_TOO_CLOSE" },
	hideNotReady = { "ERR_SPELL_COOLDOWN", "ERR_ABILITY_COOLDOWN", "ERR_ITEM_COOLDOWN", "SPELL_FAILED_NOT_READY",
	                 "SPELL_FAILED_SPELL_IN_PROGRESS", "ERR_SPELL_FAILED_ANOTHER_IN_PROGRESS" },
	hideTarget = { "ERR_GENERIC_NO_TARGET", "ERR_NO_ATTACK_TARGET", "SPELL_FAILED_BAD_TARGETS",
	               "SPELL_FAILED_BAD_IMPLICIT_TARGETS", "SPELL_FAILED_TARGETS_DEAD", "ERR_INVALID_ATTACK_TARGET" },
	hideFacing = { "ERR_BADATTACKFACING", "SPELL_FAILED_UNIT_NOT_INFRONT", "SPELL_FAILED_NOT_INFRONT",
	               "SPELL_FAILED_NOT_BEHIND", "ERR_BADATTACKPOS" },
	hideMoving = { "SPELL_FAILED_MOVING", "ERR_NOT_WHILE_MOVING" },
}

local M = R:RegisterModule("errors", {
	title = "Mensajes de error",
	group = "Configuraciones",
	defaults = {
		mode = "filter",
		hidePower = true,
		hideRange = false,
		hideNotReady = false,
		hideTarget = false,
		hideFacing = false,
		hideMoving = false,
	},
	options = {
		{ type = "dropdown", key = "mode", name = "Mensajes rojos",
		  values = {
			{ "all", "Mostrar todos (Blizzard)" },
			{ "filter", "Ocultar los marcados abajo" },
			{ "combat", "Ocultar todos en combate" },
			{ "none", "Ocultar todos" },
		  },
		  desc = "Los mensajes amarillos de progreso de misiones no se ven afectados." },

		{ type = "header", text = "Qué ocultar" },
		{ type = "toggle", key = "hidePower", name = "Sin maná, ira o energía" },
		{ type = "toggle", key = "hideRange", name = "Fuera de alcance / demasiado cerca" },
		{ type = "toggle", key = "hideNotReady", name = "No está listo / otra acción en curso" },
		{ type = "toggle", key = "hideTarget", name = "Sin objetivo / objetivo no válido" },
		{ type = "toggle", key = "hideFacing", name = "Mirando en la dirección equivocada" },
		{ type = "toggle", key = "hideMoving", name = "No se puede hacer en movimiento" },

		{ type = "header", text = "Sonido" },
		{ type = "toggle", id = "err_speech", cvar = "Sound_EnableErrorSpeech", name = "Voz de errores",
		  desc = "El personaje dice en voz alta \"No tengo suficiente maná\", \"Fuera de alcance\", etc. Los mensajes que ocultas tampoco se oyen." },
	},
})

local lookup = {} -- texto del error -> categoría

local function buildLookup()
	for category, names in pairs(CATEGORIES) do
		for _, name in ipairs(names) do
			local text = _G[name]
			if type(text) == "string" then lookup[text] = category end
		end
	end
end

local function shouldHide(message)
	local mode = M.db.mode
	if mode == "none" then return true end
	if mode == "combat" and InCombatLockdown() then return true end
	message = NS(message)
	local category = message and lookup[message]
	return category and M.db[category] or false
end

local relay = CreateFrame("Frame")
relay:SetScript("OnEvent", function(_, event, ...)
	local _, message = ...
	-- Apagado en Rheizor sin recargar: se deja pasar todo
	if R:IsModuleRunning(M) and shouldHide(message) then return end
	local handler = UIErrorsFrame:GetScript("OnEvent")
	if handler then handler(UIErrorsFrame, event, ...) end
end)

-- Solo se toma el control si hace falta filtrar algo
function M:Apply()
	if not UIErrorsFrame then return end
	if self.db.mode == "all" then
		relay:UnregisterEvent("UI_ERROR_MESSAGE")
		UIErrorsFrame:RegisterEvent("UI_ERROR_MESSAGE")
	else
		UIErrorsFrame:UnregisterEvent("UI_ERROR_MESSAGE")
		relay:RegisterEvent("UI_ERROR_MESSAGE")
	end
end

function M:OnEnable()
	if not UIErrorsFrame then
		R.missing[L["Mensajes de error"]] = "UIErrorsFrame"
		return
	end
	buildLookup()
	self:Apply()
end

function M:OnOptionChanged()
	self:Apply()
end
