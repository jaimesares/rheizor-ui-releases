-- Nombres sobre la cabeza de las unidades (CVars).
-- Las opciones de placas de nombre están en Modules\Nameplates.lua.

local R = Rheizor:Namespace(...)

R:RegisterModule("names", {
	title = "Nombres sobre la cabeza",
	group = "Configuraciones",
	options = {
		{ type = "toggle", cvar = "UnitNameOwn", name = "Mi nombre" },
		{ type = "toggle", cvar = "UnitNameFriendlyPlayerName", name = "Jugadores aliados" },
		{ type = "toggle", cvar = "UnitNameEnemyPlayerName", name = "Jugadores enemigos" },
		{ type = "toggle", cvar = "UnitNameNPC", name = "PNJ" },
		{ type = "toggle", cvar = "UnitNamePlayerGuild", name = "Hermandad del jugador" },
		{ type = "toggle", cvar = "UnitNamePlayerPVPTitle", name = "Títulos de jugador" },
	},
})
