-- Cámara y efectos de pantalla (CVars).

local R = Rheizor:Namespace(...)

R:RegisterModule("camera", {
	title = "Cámara y efectos",
	group = "Configuraciones",
	options = {
		{ type = "header", text = "Cámara" },
		{ type = "slider", cvar = "cameraDistanceMaxZoomFactor", name = "Distancia máxima de zoom",
		  min = 1, max = 2.6, step = 0.1, format = R.fmt.dec1,
		  desc = "Cuánto puedes alejar la cámara. 2.6 es el máximo que permite el juego." },
		{ type = "slider", cvar = "cameraYawMoveSpeed", name = "Velocidad de giro horizontal",
		  min = 30, max = 360, step = 10, format = R.fmt.int },
		{ type = "slider", cvar = "cameraPitchMoveSpeed", name = "Velocidad de giro vertical",
		  min = 30, max = 360, step = 10, format = R.fmt.int },
		{ type = "toggle", cvar = "test_cameraDynamicPitch", name = "Inclinación dinámica (ActionCam)",
		  desc = "Coloca al personaje más abajo en pantalla para ver más horizonte. El juego mostrará un aviso de función experimental." },

		{ type = "header", text = "Efectos de pantalla" },
		{ type = "toggle", cvar = "ffxDeath", name = "Pantalla gris al morir" },
		{ type = "toggle", cvar = "ffxGlow", name = "Resplandor a pantalla completa" },
		{ type = "dropdown", cvar = "weatherDensity", name = "Densidad del clima",
		  values = { { "0", "Mínima" }, { "1", "Baja" }, { "2", "Media" }, { "3", "Alta" } },
		  desc = "Cantidad de lluvia, nieve y polvo." },
	},
})
