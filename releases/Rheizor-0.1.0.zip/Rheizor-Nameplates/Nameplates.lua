-- Placas de nombre propias (estilo Plater).
-- Se dibujan encima de la placa de Blizzard, que queda invisible pero sigue
-- gestionando la posición y los clics. Todos los valores de vida y
-- lanzamientos se pasan directamente a las barras, porque en el motor 12.x
-- pueden ser "secretos" y no se pueden operar desde un addon.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local TEXTURES = R.TEXTURES

local function isSecret(v)
	return issecretvalue and issecretvalue(v) or false
end

-- ¿Hay valor? Sin mirar dentro si es secreto (no se puede ni comparar)
local function present(v)
	return isSecret(v) or v ~= nil
end

-- Apilar las placas de enemigos. En el motor de Forever es un bit de
-- nameplateStackingTypes (como en el panel de Blizzard); si no existiera, la
-- antigua nameplateMotion (0 superpuestas, 1 apiladas)
local STACK_CVAR = "nameplateStackingTypes"
-- kind: "Enemy" o "Friendly"
local function stackBit(kind)
	local e = Enum and Enum.NamePlateStackType
	if e and e[kind] and C_CVar.GetCVarBitfield and C_CVar.GetCVar(STACK_CVAR) then return e[kind] end
end
local function getStacking(kind)
	local index = stackBit(kind)
	if index then return C_CVar.GetCVarBitfield(STACK_CVAR, index) and true or false end
	local motion = kind == "Enemy" and C_CVar.GetCVar("nameplateMotion")
	if motion then return motion ~= "0" end
	return false
end
local function setStacking(kind, on)
	local index = stackBit(kind)
	if index then
		on = on and true or false
		if not pcall(C_CVar.SetCVarBitfield, STACK_CVAR, index, on) or getStacking(kind) ~= on then
			R:Print(L["El juego no ha aceptado el cambio. Cámbialo en Opciones > Placas de nombre."])
		end
	elseif kind == "Enemy" and C_CVar.GetCVar("nameplateMotion") then
		R:SetCVar("nameplateMotion", on and "1" or "0")
	end
end

-- Margen con el borde de la pantalla: el juego tiene uno para placas grandes y
-- otro para el resto; aquí se cambian juntos. -1 = sin límite (se salen).
local function insetCVars(names)
	local function first()
		for _, n in ipairs(names) do
			if C_CVar.GetCVar(n) then return n end
		end
	end
	local function value()
		local n = first()
		return n and tonumber(C_CVar.GetCVar(n)) or -1
	end
	local function set(v)
		for _, n in ipairs(names) do
			if C_CVar.GetCVar(n) then R:SetCVar(n, string.format("%g", v)) end
		end
	end
	local clamp = {
		available = function() return first() ~= nil end,
		get = function() return value() >= 0 end,
		set = function(on)
			if on then
				for _, n in ipairs(names) do
					if C_CVar.GetCVar(n) then
						local d = tonumber(C_CVar.GetCVarDefault and C_CVar.GetCVarDefault(n))
						R:SetCVar(n, string.format("%g", (d and d >= 0) and d or 0.1))
					end
				end
			else
				set(-1)
			end
		end,
	}
	local margin = {
		available = clamp.available,
		get = function() return math.max(0, value()) end,
		set = function(v) set(math.floor(v / 0.01 + 0.5) * 0.01) end,
	}
	return clamp, margin
end
local TOP_CLAMP, TOP_MARGIN = insetCVars({ "nameplateOtherTopInset", "nameplateLargeTopInset" })
local BOTTOM_CLAMP, BOTTOM_MARGIN = insetCVars({ "nameplateOtherBottomInset", "nameplateLargeBottomInset" })

local function fmt3(v) return string.format("%.3f", v) end

-- Puntos de combo en la placa: las opciones son las de Rheizor-ComboPoints
-- (su base de datos); aquí solo se muestran. Sin ese addon salen desactivadas.
local function combo() return R.modules.combopoints end

local function comboOff()
	local cp = combo()
	if not cp then
		return L["Necesita el addon Rheizor · Puntos de combo instalado y activado en la lista de addons del juego."]
	end
	if not R:IsAddonActive(cp.addon) then
		return L["Rheizor · Puntos de combo está desactivado en /rz: actívalo para usar esto."]
	end
end

local function comboPlateOff()
	local why = comboOff()
	if why then return why end
	if not combo().db.showPlate then
		return L["Activa antes «Mostrar los puntos de combo en la placa»."]
	end
end

local function comboGet(key, default)
	return function()
		local cp = combo()
		local v = cp and cp.db and cp.db[key]
		if v == nil then return default end
		return v
	end
end

local function comboSet(key)
	return function(value)
		local cp = combo()
		if not (cp and cp.db) then return end
		cp.db[key] = value
		R:OptionChanged(cp, key)
	end
end

-- Opción de Rheizor-ComboPoints (id único para el panel de Blizzard)
local function comboOption(opt, default)
	local key = opt.cpKey
	opt.cpKey = nil
	opt.id = "combo_" .. key
	opt.get, opt.set, opt.default = comboGet(key, default), comboSet(key), default
	opt.disabled = opt.disabled or comboPlateOff
	return opt
end

local function threatOff()
	local d = R.db and R.db.plates
	if d and d.threat == "off" then return L["Activa primero «Colores de amenaza»."] end
end

local M = R:RegisterModule("plates", {
	title = "Placas de nombre",
	defaults = {
		enabled = false,
		friendly = false,
		width = 130,
		height = 12,
		texture = TEXTURES[2][1],
		bgAlpha = 0.6,
		border = true,
		classColors = true,
		threat = "off",
		threatValue = "scaled",
		threatPos = "right",
		threatSize = 11,
		threatFormat = "pct",
		threatShowOk = "tank",
		threatSecretColor = true,
		cThreatOk = "33cc4d",
		cThreatWarn = "ff9900",
		cThreatDanger = "ff1a1a",
		cThreatOfftank = "3380ff",
		nameSize = 10,
		levelSize = 10,
		outline = "OUTLINE",
		healthText = "percent",
		showLevel = true,
		eliteIcon = true,
		eliteIconStyle = "dragon",
		raidIcon = true,
		raidIconPos = "top",
		raidIconSize = 20,
		raidIconX = 0,
		raidIconY = 0,
		castbar = true,
		castHeight = 10,
		targetScale = 1.15,
		nonTargetScale = 1,
		changeScaleOnTarget = true,
		targetGlow = true,
		targetArrows = true,
		nonTargetAlpha = 0.6,
		auras = true,
		auraOnlyMine = true,
		auraSize = 22,
		auraMax = 6,
		auraTimer = true,
		stackMode = "blizzard",
		stackExtra = 4,
		stackWidth = 130,
		stackHeight = 24,
	},
	options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Activar placas de Rheizor",
		  desc = "Sustituye el aspecto de las placas de enemigos por las de Rheizor." },
		{ type = "toggle", key = "friendly", name = "Aplicar también a aliados",
		  desc = "Fuera de mazmorras. Dentro de estancias, Blizzard no permite modificar las placas aliadas." },

		{ type = "header", text = "Barra de vida" },
		{ type = "slider", key = "width", name = "Ancho", min = 60, max = 250, step = 2, format = R.fmt.int },
		{ type = "slider", key = "height", name = "Alto", min = 4, max = 30, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "texture", name = "Textura", values = TEXTURES },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "border", name = "Borde" },

		{ type = "header", text = "Textos" },
		{ type = "slider", key = "nameSize", name = "Tamaño del nombre", min = 6, max = 20, step = 1, format = R.fmt.int },
		{ type = "slider", key = "levelSize", name = "Tamaño del nivel", min = 6, max = 20, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "outline", name = "Contorno del texto",
		  values = { { "NONE", "Sin contorno" }, { "OUTLINE", "Fino" }, { "THICKOUTLINE", "Grueso" } } },
		{ type = "dropdown", key = "healthText", name = "Texto de vida",
		  values = { { "none", "Ninguno" }, { "percent", "Porcentaje" }, { "value", "Valor" }, { "both", "Valor y porcentaje" } } },
		{ type = "toggle", key = "showLevel", name = "Nivel y clasificación",
		  desc = "Nivel coloreado por dificultad; R indica raro. El icono señala a los élites." },
		{ type = "toggle", key = "eliteIcon", name = "Icono de élite",
		  desc = "Muestra un dragón o una estrella junto al nombre de los élites." },
		{ type = "dropdown", key = "eliteIconStyle", name = "Estilo del icono de élite",
		  values = { { "dragon", "Dragón dorado" }, { "star", "Estrella de Plater" } } },

		{ type = "header", text = "Marca de banda" },
		{ type = "toggle", key = "raidIcon", name = "Mostrar la marca (calavera, cruz…)" },
		{ type = "dropdown", key = "raidIconPos", name = "Posición de la marca",
		  values = {
			{ "top", "Encima (sobre el nombre y los perjuicios)" },
			{ "left", "A la izquierda de la barra" },
			{ "right", "A la derecha de la barra" },
			{ "center", "En el centro de la barra" },
		  } },
		{ type = "slider", key = "raidIconSize", name = "Tamaño de la marca", min = 10, max = 60, step = 1, format = R.fmt.int },
		{ type = "slider", key = "raidIconX", name = "Desplazamiento horizontal", min = -100, max = 100, step = 1, format = R.fmt.int },
		{ type = "slider", key = "raidIconY", name = "Desplazamiento vertical", min = -100, max = 100, step = 1, format = R.fmt.int,
		  desc = "Positivo, hacia arriba; negativo, hacia abajo." },

		{ type = "header", text = "Objetivo" },
		{ type = "toggle", key = "changeScaleOnTarget", name = "Cambiar tamaño según el objetivo",
		  desc = "Si se desactiva, todas las placas mantienen siempre el tamaño del objetivo." },
		{ type = "slider", key = "targetScale", name = "Tamaño del objetivo", min = 0.5, max = 3, step = 0.05 },
		{ type = "slider", key = "nonTargetScale", name = "Tamaño sin seleccionar", min = 0.5, max = 3, step = 0.05,
		  desc = "Se usa cuando está activado el cambio de tamaño según el objetivo." },
		{ type = "toggle", key = "targetGlow", name = "Borde blanco en el objetivo" },
		{ type = "toggle", key = "targetArrows", name = "Flechas a los lados del objetivo" },
		{ type = "slider", key = "nonTargetAlpha", name = "Opacidad del resto", min = 0.1, max = 1, step = 0.05,
		  desc = "Opacidad de las placas que no son tu objetivo cuando tienes uno." },

		{ type = "header", text = "Puntos de combo" },
		{ type = "note", text = "Necesita el addon Rheizor · Puntos de combo instalado y activado.",
		  available = function() return comboOff() ~= nil end },
		comboOption({ type = "toggle", cpKey = "showPlate", name = "Mostrar los puntos de combo en la placa",
		  desc = "Pone los puntos de combo de Rheizor · Puntos de combo sobre la placa de tu objetivo.",
		  refresh = true, disabled = comboOff }, false),
		comboOption({ type = "toggle", cpKey = "showScreen", name = "Mostrarlos también en la pantalla",
		  desc = "Además de en la placa, en el sitio de la pantalla donde los tengas. Desactívalo para verlos solo en la placa.",
		  refresh = true, disabled = comboOff }, true),
		comboOption({ type = "toggle", cpKey = "plateHideEmpty", name = "Ocultarlos en la placa si no tienes puntos" }, false),
		comboOption({ type = "dropdown", cpKey = "plateSide", name = "Posición de los puntos",
		  values = {
			{ "above", "Encima de la barra" },
			{ "below", "Debajo de la barra" },
			{ "left", "A la izquierda de la barra" },
			{ "right", "A la derecha de la barra" },
			{ "inside", "Dentro de la barra" },
		  } }, "above"),
		comboOption({ type = "slider", cpKey = "plateX", name = "Desplazamiento horizontal de los puntos",
		  min = -200, max = 200, step = 1, format = R.fmt.int,
		  desc = "También puedes arrastrarlos sobre la placa con /rz mover (con un objetivo que tenga placa)." }, 0),
		comboOption({ type = "slider", cpKey = "plateY", name = "Desplazamiento vertical de los puntos",
		  min = -200, max = 200, step = 1, format = R.fmt.int,
		  desc = "Positivo, hacia arriba; negativo, hacia abajo." }, 6),
		comboOption({ type = "slider", cpKey = "plateScale", name = "Tamaño de los puntos en la placa",
		  min = 0.3, max = 2, step = 0.05 }, 1),
		comboOption({ type = "dropdown", cpKey = "plateMissing", name = "Si el objetivo no tiene placa",
		  values = { { "hide", "No mostrar nada" }, { "screen", "Mostrarlos en su sitio de la pantalla" } },
		  desc = "Solo cuenta si no los tienes ya en la pantalla." }, "hide"),
		{ type = "button", name = "Probar los puntos de combo", text = "Probar", disabled = comboOff,
		  desc = "Los gana uno a uno y luego los gasta. Selecciona un enemigo con placa para verlos sobre ella.",
		  func = function() local cp = combo(); if cp then R:RunModuleAction(cp, cp.Test) end end },
		{ type = "button", name = "Forma, colores y efectos", text = "Más opciones", disabled = comboOff,
		  desc = "Abre las opciones de Rheizor · Puntos de combo.",
		  func = function() local cp = combo(); if cp then R:OpenModuleOptions(cp) end end },

		{ type = "header", text = "Barra de lanzamiento" },
		{ type = "toggle", key = "castbar", name = "Mostrar barra de lanzamiento",
		  desc = "Amarilla si se puede interrumpir, gris si no." },
		{ type = "slider", key = "castHeight", name = "Alto", min = 4, max = 24, step = 1, format = R.fmt.int },

		{ type = "header", text = "Perjuicios" },
		{ type = "toggle", key = "auras", name = "Mostrar perjuicios",
		  desc = "Iconos encima del nombre, como en Plater.\nSi en combate el juego no deja leerlos, se usan los iconos de la placa de Blizzard (con su aspecto) hasta salir de combate." },
		{ type = "toggle", key = "auraOnlyMine", name = "Solo los míos" },
		{ type = "slider", key = "auraSize", name = "Tamaño", min = 12, max = 40, step = 1, format = R.fmt.int },
		{ type = "slider", key = "auraMax", name = "Máximo de iconos", min = 1, max = 10, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "auraTimer", name = "Números de tiempo restante" },

		{ type = "header", text = "Colores" },
		{ type = "toggle", key = "classColors", name = "Color de clase en jugadores enemigos" },
		{ type = "dropdown", key = "threat", name = "Colores de amenaza",
		  values = {
			{ "off", "Desactivado" },
			{ "auto", "Automático (Rheizor-Core > Tanques y amenaza)" },
			{ "dps", "Siempre DPS / sanador" },
			{ "tank", "Siempre tanque" },
		  },
		  desc = "DPS: aviso si te acercas al primer puesto de amenaza, peligro si te atacan.\nTanque: bien si lo tienes, aviso si lo estás perdiendo, peligro si lo has perdido, y otro color si lo lleva otro tanque.\nAutomático: tanque o DPS según Rheizor-Core > Tanques y amenaza (actitud, oso, papel del grupo...)." },
		{ type = "dropdown", key = "threatShowOk", name = "Color de «bien»", disabled = threatOff,
		  values = {
			{ "tank", "Solo siendo tanque" },
			{ "always", "Siempre" },
			{ "never", "Nunca (color normal)" },
		  },
		  desc = "Siendo DPS, «bien» es que el enemigo no va a por ti: lo normal es dejarle su color de siempre." },
		{ type = "color", key = "cThreatOk", name = "Bien", disabled = threatOff },
		{ type = "color", key = "cThreatWarn", name = "Aviso", disabled = threatOff },
		{ type = "color", key = "cThreatDanger", name = "Peligro", disabled = threatOff },
		{ type = "color", key = "cThreatOfftank", name = "Lo lleva otro tanque", disabled = threatOff,
		  desc = "Quién es tanque y cuándo se usa: Rheizor-Core > Tanques y amenaza." },
		{ type = "toggle", key = "threatSecretColor", name = "Con amenaza secreta, el color del juego", disabled = threatOff,
		  desc = "Con los jefes el juego da la amenaza en secreto y no se sabe el nivel: la placa toma el color de amenaza del propio juego (gris, amarillo, naranja o rojo). Sin marcar, su color normal." },

		{ type = "header", text = "Tu amenaza en la placa" },
		{ type = "dropdown", key = "threatFormat", name = "Mostrar",
		  values = {
			{ "none", "No mostrar" },
			{ "pct", "Porcentaje — 85%" },
			{ "abs", "Total — 12,4K" },
			{ "both", "Ambos — 85% (12,4K)" },
			{ "diff", "Diferencia con el tanque — +500 / -500" },
			{ "diffPct", "Diferencia y porcentaje — -500 (85%)" },
		  },
		  desc = "Solo aparece en enemigos con los que estás en combate. El color sigue el modo de \"Colores de amenaza\" (DPS si está desactivado).\nEl total usa la opción \"Dividir el valor entre 100\" del medidor de amenaza, si lo tienes.\nDiferencia con el tanque: si tienes el agro, cuánta amenaza sacas al segundo (+500); si no, cuánta te saca el que lo tiene (-500). Se compara con tu grupo o banda; si el juego no da las cifras, sale el %." },
		{ type = "dropdown", key = "threatValue", name = "El 100% es…",
		  values = {
			{ "scaled", "Relativo (100% = le quitas el agro)" },
			{ "raw", "Respecto al que tiene el agro" },
		  },
		  desc = "Relativo: a 100% el enemigo cambia de objetivo hacia ti.\nRespecto al que tiene el agro: tu amenaza comparada con la del tanque (puede pasar de 100% antes de quitárselo: 110% cuerpo a cuerpo, 130% a distancia)." },
		{ type = "dropdown", key = "threatPos", name = "Posición",
		  values = {
			{ "right", "A la derecha de la barra" },
			{ "left", "A la izquierda de la barra" },
			{ "inside", "Dentro de la barra (derecha)" },
			{ "top", "Encima de la barra" },
		  } },
		{ type = "slider", key = "threatSize", name = "Tamaño", min = 7, max = 20, step = 1, format = R.fmt.int },

		{ type = "header", text = "Apilado de placas" },
		{ type = "toggle", id = "nameplateStackEnemy", name = "Apilar las placas de enemigos",
		  get = function() return getStacking("Enemy") end, set = function(v) setStacking("Enemy", v) end, default = true,
		  desc = "Apiladas no se tapan unas a otras; si no, se superponen." },
		{ type = "toggle", id = "nameplateStackFriendly", name = "Apilar las placas de aliados",
		  get = function() return getStacking("Friendly") end, set = function(v) setStacking("Friendly", v) end, default = false,
		  available = function() return stackBit("Friendly") ~= nil end },
		{ type = "dropdown", key = "stackMode", name = "Espacio que ocupa cada placa",
		  values = {
			{ "blizzard", "El de Blizzard (según su estilo y tamaño)" },
			{ "auto", "El de la placa de Rheizor" },
			{ "custom", "A medida" },
		  },
		  desc = "El juego separa las placas apiladas según este tamaño.\nEl de Rheizor: el ancho de la barra y el alto de la barra más el nombre, con su escala, más el espacio extra.\nA medida: el ancho y el alto de abajo.\nTambién es la zona donde se hace clic en la placa. Solo cambia fuera de combate." },
		{ type = "slider", key = "stackExtra", name = "Espacio extra entre placas", min = -20, max = 60, step = 1, format = R.fmt.int,
		  desc = "Con «El de la placa de Rheizor». Negativo, más juntas." },
		{ type = "slider", key = "stackWidth", name = "Ancho a medida", min = 10, max = 300, step = 1, format = R.fmt.int,
		  desc = "Con «A medida». Cuanto más estrecho, menos se apilan las placas que están una al lado de otra." },
		{ type = "slider", key = "stackHeight", name = "Alto a medida", min = 4, max = 120, step = 1, format = R.fmt.int,
		  desc = "Con «A medida». Es la separación vertical entre placas apiladas." },
		{ type = "slider", cvar = "nameplateOverlapV", name = "Separación vertical al apilar", optional = true,
		  min = 0.3, max = 3, step = 0.05, format = R.fmt.dec2,
		  desc = "Multiplica el alto de cada placa: 1 = pegadas; más, más separadas." },
		{ type = "slider", cvar = "nameplateOverlapH", name = "Separación horizontal al apilar", optional = true,
		  min = 0.3, max = 3, step = 0.05, format = R.fmt.dec2,
		  desc = "Multiplica el ancho: con menos, las placas que están un poco de lado ya no se apilan." },
		{ type = "slider", cvar = "nameplateMotionSpeed", name = "Velocidad al recolocarse", optional = true,
		  min = 0.005, max = 0.2, step = 0.005, format = fmt3,
		  desc = "Lo rápido que se mueven las placas a su sitio al apilarse. Más alto, más rápido." },
		{ type = "toggle", id = "nameplateTopClamp", name = "No dejar que se salgan por arriba",
		  get = TOP_CLAMP.get, set = TOP_CLAMP.set, available = TOP_CLAMP.available, default = true,
		  desc = "Las placas se quedan pegadas al borde superior de la pantalla en vez de desaparecer." },
		{ type = "slider", id = "nameplateTopMargin", name = "Margen superior",
		  get = TOP_MARGIN.get, set = TOP_MARGIN.set, available = TOP_MARGIN.available, default = 0.1,
		  min = 0, max = 0.5, step = 0.01,
		  desc = "Distancia al borde superior, en parte de la pantalla." },
		{ type = "toggle", id = "nameplateBottomClamp", name = "No dejar que se salgan por abajo",
		  get = BOTTOM_CLAMP.get, set = BOTTOM_CLAMP.set, available = BOTTOM_CLAMP.available, default = true },
		{ type = "slider", id = "nameplateBottomMargin", name = "Margen inferior",
		  get = BOTTOM_MARGIN.get, set = BOTTOM_MARGIN.set, available = BOTTOM_MARGIN.available, default = 0.1,
		  min = 0, max = 0.5, step = 0.01,
		  desc = "Distancia al borde inferior, en parte de la pantalla." },
		{ type = "dropdown", cvar = "nameplateTargetRadialPosition", name = "Placas fuera de la pantalla", optional = true,
		  values = {
			{ "0", "Ninguna" },
			{ "1", "Solo la del objetivo" },
			{ "2", "Todas las de combate" },
		  },
		  desc = "Mantiene en el borde de la pantalla las placas de enemigos que quedan fuera de vista." },

		{ type = "header", text = "Ajustes del juego" },
		{ type = "toggle", cvar = "nameplateShowEnemies", name = "Placas de enemigos" },
		{ type = "toggle", cvar = "nameplateShowFriendlyPlayers", name = "Placas de jugadores aliados" },
		{ type = "toggle", cvar = "nameplateShowAll", name = "Mostrar siempre",
		  desc = "Muestra las placas también fuera de combate." },
		{ type = "slider", cvar = "nameplateMaxDistance", name = "Distancia de las placas",
		  min = 20, max = 60, step = 1, format = R.fmt.int,
		  desc = "Distancia en metros a la que aparecen. El servidor puede limitar el máximo." },
		{ type = "slider", cvar = "nameplateOccludedAlphaMult", name = "Opacidad tras obstáculos",
		  min = 0, max = 1, step = 0.05 },
	},
	-- Lo que no se puede hacer en WoW Forever
	unsupported = {
		"Quién ha interrumpido a un enemigo: el juego casi siempre lo da en secreto (solo lo da claro en tus lanzamientos), así que casi siempre sale solo «Interrumpido».",
	},
})

local db
local active = {} -- unidad ("nameplate3") -> nuestro marco

----------------------------------------------------------------------
-- Creación
----------------------------------------------------------------------

local function makeBorder(parent, size)
	local b = CreateFrame("Frame", nil, parent, "BackdropTemplate")
	b:SetPoint("TOPLEFT", -size, size)
	b:SetPoint("BOTTOMRIGHT", size, -size)
	b:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = size })
	return b
end

local function createPlate(nameplate)
	local f = CreateFrame("Frame", nil, nameplate)
	f:SetPoint("CENTER")
	f:SetFrameLevel(nameplate:GetFrameLevel() + 20)

	local hp = CreateFrame("StatusBar", nil, f)
	hp:SetAllPoints()
	hp.bg = hp:CreateTexture(nil, "BACKGROUND")
	hp.bg:SetAllPoints()
	f.health = hp

	f.border = makeBorder(hp, 1)
	f.border:SetBackdropBorderColor(0, 0, 0, 1)
	f.targetBorder = makeBorder(hp, 2)
	f.targetBorder:SetBackdropBorderColor(1, 1, 1, 0.9)

	f.arrowL = f:CreateTexture(nil, "OVERLAY")
	f.arrowL:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
	f.arrowL:SetSize(16, 16)
	f.arrowL:SetPoint("RIGHT", hp, "LEFT", -2, 0)
	f.arrowR = f:CreateTexture(nil, "OVERLAY")
	f.arrowR:SetTexture("Interface\\ChatFrame\\ChatFrameExpandArrow")
	f.arrowR:SetTexCoord(1, 0, 0, 1)
	f.arrowR:SetSize(16, 16)
	f.arrowR:SetPoint("LEFT", hp, "RIGHT", 2, 0)

	f.name = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.name:SetPoint("BOTTOMLEFT", hp, "TOPLEFT", 0, 2)
	f.name:SetPoint("RIGHT", hp, "RIGHT", -24, 0)
	f.name:SetJustifyH("LEFT")
	f.name:SetWordWrap(false)
	f.eliteIcon = f:CreateTexture(nil, "OVERLAY")
	f.eliteIcon:SetPoint("RIGHT", f.name, "LEFT", -3, 0)
	f.eliteIcon:Hide()

	f.level = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.level:SetPoint("BOTTOMRIGHT", hp, "TOPRIGHT", 0, 2)

	f.hpText = hp:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.hpText:SetPoint("CENTER")

	f.threatText = hp:CreateFontString(nil, "OVERLAY", "GameFontNormal")

	f.raidIcon = f:CreateTexture(nil, "OVERLAY")
	f.raidIcon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcons")
	f.raidIcon:SetSize(20, 20)
	f.raidIcon:SetPoint("BOTTOM", f.name, "TOP", 0, 2)

	-- Perjuicios (fila centrada encima del nombre)
	f.auras = CreateFrame("Frame", nil, f)
	f.auras:SetSize(1, 1)
	f.auras.icons = {}

	-- Barra de lanzamiento
	local cb = CreateFrame("StatusBar", nil, f)
	cb:SetPoint("TOPLEFT", hp, "BOTTOMLEFT", 0, -3)
	cb:SetPoint("TOPRIGHT", hp, "BOTTOMRIGHT", 0, -3)
	cb.bg = cb:CreateTexture(nil, "BACKGROUND")
	cb.bg:SetAllPoints()
	cb.bg:SetColorTexture(0, 0, 0, 0.6)
	cb.border = makeBorder(cb, 1)
	cb.border:SetBackdropBorderColor(0, 0, 0, 1)
	cb.icon = cb:CreateTexture(nil, "OVERLAY")
	cb.icon:SetPoint("TOPRIGHT", hp, "TOPLEFT", -3, 0)
	cb.icon:SetPoint("BOTTOMRIGHT", cb, "BOTTOMLEFT", -3, 0)
	cb.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	cb.text = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	cb.text:SetPoint("LEFT", 3, 0)
	cb.text:SetPoint("RIGHT", -30, 0)
	cb.text:SetJustifyH("LEFT")
	cb.text:SetWordWrap(false)
	cb.time = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	cb.time:SetPoint("RIGHT", -3, 0)
	cb:Hide()
	f.cast = cb

	return f
end

----------------------------------------------------------------------
-- Estilo (tamaños, texturas, fuentes)
----------------------------------------------------------------------

local function setFont(fs, size)
	local font = fs:GetFont()
	fs:SetFont(font or STANDARD_TEXT_FONT, size, db.outline ~= "NONE" and db.outline or "")
end

local function applyStyle(f)
	f:SetSize(db.width, db.height)
	f.health:SetStatusBarTexture(db.texture)
	f.health.bg:SetColorTexture(0, 0, 0, db.bgAlpha)
	f.border:SetShown(db.border)
	f.cast:SetStatusBarTexture(db.texture)
	f.cast:SetHeight(db.castHeight)
	f.cast.icon:SetWidth(db.height + db.castHeight + 3)
	setFont(f.name, db.nameSize)
	f.eliteIcon:SetSize(math.max(db.nameSize + 4, 16), math.max(db.nameSize + 4, 16))
	setFont(f.level, db.levelSize)
	setFont(f.hpText, math.max(db.height - 2, 7))
	setFont(f.cast.text, math.max(db.castHeight - 1, 7))
	setFont(f.cast.time, math.max(db.castHeight - 1, 7))
	f.level:SetShown(db.showLevel)
	f.name:ClearAllPoints()
	f.name:SetPoint("BOTTOMLEFT", f.health, "TOPLEFT", 0, 2)
	if db.showLevel then
		f.name:SetPoint("RIGHT", f.level, "LEFT", -4, 0)
	else
		f.name:SetPoint("RIGHT", f.health, "RIGHT", 0, 0)
	end

	-- Amenaza: posición, y las flechas del objetivo se apartan para no taparla
	local t = f.threatText
	setFont(t, db.threatSize)
	t:ClearAllPoints()
	f.arrowL:ClearAllPoints()
	f.arrowR:ClearAllPoints()
	f.arrowL:SetPoint("RIGHT", f.health, "LEFT", -2, 0)
	f.arrowR:SetPoint("LEFT", f.health, "RIGHT", 2, 0)
	if db.threatPos == "left" then
		t:SetPoint("RIGHT", f.health, "LEFT", -4, 0)
		f.arrowL:SetPoint("RIGHT", t, "LEFT", -2, 0)
	elseif db.threatPos == "inside" then
		t:SetPoint("RIGHT", f.health, "RIGHT", -3, 0)
	elseif db.threatPos == "top" then
		t:SetPoint("BOTTOM", f.health, "TOP", 0, 2)
	else
		t:SetPoint("LEFT", f.health, "RIGHT", 4, 0)
		f.arrowR:SetPoint("LEFT", t, "RIGHT", 2, 0)
	end
	t:SetShown(db.threatFormat ~= "none")

	-- Perjuicios encima del nombre; la marca de banda, encima de ellos
	f.auras:ClearAllPoints()
	f.auras:SetPoint("BOTTOM", f.health, "TOP", 0, math.max(db.nameSize, db.showLevel and db.levelSize or 0) + 5)
	f.auras:SetHeight(db.auras and db.auraSize or 1)
	local ri = f.raidIcon
	local x, y = db.raidIconX or 0, db.raidIconY or 0
	ri:SetSize(db.raidIconSize, db.raidIconSize)
	ri:ClearAllPoints()
	if db.raidIconPos == "left" then
		-- Al otro lado de las flechas del objetivo y de la amenaza
		local ref = (db.threatPos == "left" and db.threatFormat ~= "none") and f.threatText or f.health
		ri:SetPoint("RIGHT", ref, "LEFT", -4 + x, y)
	elseif db.raidIconPos == "right" then
		local ref = (db.threatPos == "right" and db.threatFormat ~= "none") and f.threatText or f.health
		ri:SetPoint("LEFT", ref, "RIGHT", 4 + x, y)
	elseif db.raidIconPos == "center" then
		ri:SetPoint("CENTER", f.health, "CENTER", x, y)
	elseif db.auras then
		ri:SetPoint("BOTTOM", f.auras, "TOP", x, 2 + y)
	else
		ri:SetPoint("BOTTOM", f.name, "TOP", x, 2 + y)
	end
end

----------------------------------------------------------------------
-- Actualizaciones
----------------------------------------------------------------------

local function updateHealth(f)
	local unit = f.unit
	f.health:SetMinMaxValues(0, UnitHealthMax(unit))
	f.health:SetValue(UnitHealth(unit))

	local mode = db.healthText
	if mode == "none" then
		f.hpText:SetText("")
		return
	end
	local ok = pcall(function()
		local pct
		if UnitHealthPercent and CurveConstants then
			pct = UnitHealthPercent(unit, true, CurveConstants.ScaleTo100)
		else
			pct = UnitHealth(unit) / math.max(UnitHealthMax(unit), 1) * 100
		end
		local value = AbbreviateNumbers and AbbreviateNumbers(UnitHealth(unit)) or UnitHealth(unit)
		if mode == "percent" then
			f.hpText:SetFormattedText("%.0f%%", pct)
		elseif mode == "value" then
			f.hpText:SetFormattedText("%s", value)
		else
			f.hpText:SetFormattedText("%s · %.0f%%", value, pct)
		end
	end)
	if not ok then f.hpText:SetText("") end
end

-- Nivel de amenaza (Rheizor-Core > Tanques y amenaza): bien, aviso, peligro
-- u otro tanque lo tiene. La placa se lee con otro nombre del mismo enemigo
-- si la suya da la amenaza en secreto (R.ThreatUnit).
local THREAT_KEYS = { ok = "cThreatOk", warn = "cThreatWarn", danger = "cThreatDanger", offtank = "cThreatOfftank" }

-- ¿Tanque? "Automático" lo decide Rheizor-Core; desactivado cuenta como DPS
-- (para el color del texto de amenaza)
local function tankMode()
	if db.threat == "tank" then return true end
	if db.threat == "auto" then return R.IsPlayerTank and R:IsPlayerTank() or false end
	return false
end

-- Color de un nivel; nil si ese nivel deja el color normal
local function threatColor(lvl, tank)
	if lvl == "ok" then
		local show = db.threatShowOk
		if show == "never" or (show == "tank" and not tank) then return end
	end
	local key = THREAT_KEYS[lvl]
	if key then return { R.HexToRGB(db[key]) } end
end

local function updateColor(f)
	local unit = f.unit
	local color, secretStatus
	pcall(function()
		if NS(UnitIsTapDenied(unit)) then
			color = { 0.5, 0.5, 0.5 }
			return
		end
		if db.threat ~= "off" and R.ThreatLevel then
			local tank = tankMode()
			local lvl, status = R:ThreatLevel(unit, tank)
			if lvl then
				color = threatColor(lvl, tank)
				if color then return end
			elseif isSecret(status) and db.threatSecretColor then
				-- Secreto (jefes): el color que da el juego, sin saber el nivel
				secretStatus = status
				return
			end
		end
		if db.classColors and NS(UnitIsPlayer(unit)) then
			local class = NS(select(2, UnitClass(unit)))
			local c = class and RAID_CLASS_COLORS[class]
			if c then
				color = { c.r, c.g, c.b }
				return
			end
		end
		local reaction = NS(UnitReaction(unit, "player"))
		if reaction then
			if reaction <= 3 then color = { 0.85, 0.15, 0.15 }
			elseif reaction == 4 then color = { 0.95, 0.85, 0.2 }
			else color = { 0.2, 0.8, 0.3 } end
		end
	end)
	if secretStatus ~= nil then
		local ok, r, g, b = pcall(GetThreatStatusColor, secretStatus)
		if ok and pcall(f.health.SetStatusBarColor, f.health, r, g, b) then return end
	end
	color = color or { 0.85, 0.15, 0.15 }
	f.health:SetStatusBarColor(color[1], color[2], color[3])
end

-- El total de amenaza. Si se puede leer, se abrevia aquí (12,4K) siguiendo
-- la opción "dividir entre 100" del medidor. Si llega "secreto" no se puede
-- operar con él en Lua, pero el motor sí deja pintarlo: se intenta abreviar
-- con la función de Blizzard y, si no, va la cifra entera.
local function totalText(value)
	local v = NS(value)
	if v then
		local threat = R.modules.threat
		if threat and threat.db and threat.db.div100 then v = v / 100 end
		if v >= 1e6 then return string.format("%.1fM", v / 1e6) end
		if v >= 1e4 then return string.format("%.0fK", v / 1e3) end
		if v >= 1e3 then return string.format("%.1fK", v / 1e3) end
		return string.format("%d", math.floor(v + 0.5))
	end
	if AbbreviateNumbers then
		local ok, text = pcall(AbbreviateNumbers, value)
		if ok and text then return text end
	end
	return value
end

-- Diferencia con el tanque: con el agro, lo que le sacas al segundo de tu
-- grupo (positivo); sin él, lo que te saca el que lo tiene (negativo). nil si
-- alguna cifra no se puede leer o el que tiene el agro no es de tu grupo.
local PARTY_UNITS, RAID_UNITS = { "pet" }, {}
for i = 1, 4 do PARTY_UNITS[#PARTY_UNITS + 1] = "party" .. i; PARTY_UNITS[#PARTY_UNITS + 1] = "partypet" .. i end
for i = 1, 40 do RAID_UNITS[#RAID_UNITS + 1] = "raid" .. i; RAID_UNITS[#RAID_UNITS + 1] = "raidpet" .. i end

-- ¿Esta unidad del grupo eres tú? En banda UnitIsUnit puede llegar secreto;
-- el GUID de los miembros del grupo no lo es
local function isMe(unit)
	local same = NS(UnitIsUnit(unit, "player"))
	if same ~= nil then return same and true or false end
	local guid = NS(UnitGUID(unit))
	return guid ~= nil and guid == NS(UnitGUID("player"))
end

-- En Forever la amenaza leída desde la placa ("nameplate3") llega secreta,
-- pero la del mismo enemigo como "target" no (probado con /rz amenaza).
-- Rheizor-Core busca el mismo enemigo con otro nombre (Tanks.lua)
local threatSecret = R.ThreatSecret
local threatUnit = R.ThreatUnit

local function threatDiff(mob)
	local tanking, _, _, rawPct, mine = UnitDetailedThreatSituation("player", mob)
	tanking, rawPct, mine = NS(tanking), NS(rawPct), NS(mine)
	if not mine then return end
	-- Sin el agro basta con tus cifras: "respecto al que tiene el agro" es
	-- tu amenaza / la del tanque, así que la del tanque es tu amenaza * 100 / %
	-- (vale aunque el tanque no sea de tu grupo o sus cifras lleguen secretas)
	if not tanking and rawPct and rawPct > 0 then
		return mine - mine * 100 / rawPct
	end
	-- Con el agro hace falta la amenaza del segundo: la de tu grupo
	local second, tankValue, found = 0, nil, false
	for _, u in ipairs(IsInRaid() and RAID_UNITS or PARTY_UNITS) do
		if UnitExists(u) and not isMe(u) then
			local ok, isTanking, _, _, _, raw = pcall(UnitDetailedThreatSituation, u, mob)
			-- Una cifra secreta: no se sabe quién va segundo (sale el %)
			if ok and issecretvalue and issecretvalue(raw) then return end
			local v = ok and NS(raw) or nil
			if v then
				found = true
				if NS(isTanking) then tankValue = v end
				if v > second then second = v end
			end
		end
	end
	if tanking then return found and (mine - second) or mine end
	if tankValue then return mine - tankValue end
end

-- La lista de quién va primero no existe: para ordenar hace falta leer los
-- totales, y en Forever llegan secretos.
local function updateThreat(f)
	local t = f.threatText
	if db.threatFormat ~= "none" then
		local ok = pcall(function()
			local mob = threatUnit(f.unit)
			local _, status, scaled, raw, value = UnitDetailedThreatSituation("player", mob)
			local pct = db.threatValue == "raw" and raw or scaled
			if (db.threatFormat == "abs" and not present(value))
				or (db.threatFormat ~= "abs" and not present(pct)) then
				t:SetText("")
				return
			end
			-- Si el total no se puede pintar (no llega, o el motor no lo deja), queda el %
			local fmt = db.threatFormat
			local shown = fmt ~= "pct" and pcall(function()
				if fmt == "diff" or fmt == "diffPct" then
					local d = threatDiff(mob)
					if not d then error("sin cifras") end
					local text = (d >= 0 and "+" or "-") .. totalText(math.abs(d))
					if fmt == "diffPct" then
						t:SetFormattedText("%s (%.0f%%)", text, pct)
					else
						t:SetText(text)
					end
				elseif fmt == "abs" then
					t:SetFormattedText("%s", totalText(value))
				else
					t:SetFormattedText("%.0f%% (%s)", pct, totalText(value))
				end
			end)
			if not shown then
				if fmt == "abs" then
					t:SetText("")
				else
					t:SetFormattedText("%.0f%%", pct)
				end
			end
			-- En el color del nivel ("bien" siendo daño: blanco)
			local tank = tankMode()
			local lvl = NS(status) and R:ThreatLevel(f.unit, tank)
			if lvl and not (lvl == "ok" and not tank) then
				t:SetTextColor(R.HexToRGB(db[THREAT_KEYS[lvl]]))
			else
				t:SetTextColor(1, 1, 1)
			end
		end)
		if not ok then t:SetText("") end
	end
end

local function updateEliteIcon(f)
	local class = NS(UnitClassification(f.unit))
	local elite = class == "elite" or class == "rareelite" or class == "worldboss"
	if not db.eliteIcon or not elite then
		f.eliteIcon:Hide()
		return
	end
	if db.eliteIconStyle == "star" then
		f.eliteIcon:SetTexture("Interface\\AddOns\\Rheizor-Nameplates\\media\\star_full_64")
		f.eliteIcon:SetVertexColor(1, 0.85, 0.15)
	else
		f.eliteIcon:SetVertexColor(1, 1, 1)
		f.eliteIcon:SetAtlas("nameplates-icon-elite-gold")
	end
	f.eliteIcon:Show()
end

local function updateName(f)
	f.name:SetText(UnitName(f.unit))
	updateEliteIcon(f)
	f.level:SetText("")
	if not db.showLevel then return end
	pcall(function()
		local level = NS(UnitLevel(f.unit))
		local class = NS(UnitClassification(f.unit))
		if not level then return end
		local text = level < 0 and "??" or tostring(level)
		if class == "rare" or class == "rareelite" then text = text .. " R" end
		f.level:SetText(text)
		local c = GetCreatureDifficultyColor(level < 0 and 999 or level)
		f.level:SetTextColor(c.r, c.g, c.b)
	end)
end

local function updateRaidIcon(f)
	if not db.raidIcon then
		f.raidIcon:Hide()
		return
	end
	local index = GetRaidTargetIndex(f.unit)
	if isSecret(index) then
		-- En combate la marca puede venir en secreto: se le pasa tal cual a la
		-- textura (sin mirarla); si el juego no lo permite, no se ve hasta salir
		f.raidIcon:SetShown(pcall(SetRaidTargetIconTexture, f.raidIcon, index))
	elseif index then
		SetRaidTargetIconTexture(f.raidIcon, index)
		f.raidIcon:Show()
	else
		f.raidIcon:Hide()
	end
end

local function applyPlateScale(f, isTarget)
	local scale = (db.changeScaleOnTarget and not isTarget) and db.nonTargetScale or db.targetScale
	if not db.changeScaleOnTarget then
		-- La placa de Blizzard también cambia de escala al seleccionar. Compensar
		-- la escala efectiva del padre mantiene el tamaño real de Rheizor fijo.
		local ok, parentScale = pcall(f:GetParent().GetEffectiveScale, f:GetParent())
		if ok and parentScale and parentScale > 0 then
			scale = scale * UIParent:GetEffectiveScale() / parentScale
		end
	end
	if not f.appliedScale or math.abs(f.appliedScale - scale) > 0.001 then
		f:SetScale(scale)
		f.appliedScale = scale
	end
end

local function updateTarget(f)
	-- Se compara la placa del objetivo con esta (dos marcos: nunca es secreto).
	-- UnitIsUnit puede dar secreto en mazmorras y banda.
	local hasTarget = UnitExists("target")
	local isTarget = false
	if hasTarget then
		local plate = C_NamePlate.GetNamePlateForUnit("target")
		if plate then
			isTarget = plate == f:GetParent()
		else
			isTarget = NS(UnitIsUnit(f.unit, "target")) and true or false
		end
	end
	applyPlateScale(f, isTarget)
	f.targetBorder:SetShown(isTarget and db.targetGlow)
	f.arrowL:SetShown(isTarget and db.targetArrows)
	f.arrowR:SetShown(isTarget and db.targetArrows)
	f:SetAlpha((hasTarget and not isTarget) and db.nonTargetAlpha or 1)
	f:SetFrameLevel(f:GetParent():GetFrameLevel() + (isTarget and 40 or 20))
end

----------------------------------------------------------------------
-- Barra de lanzamiento
----------------------------------------------------------------------

local CAST_COLOR = { 1, 0.75, 0.1 }
local LOCKED_COLOR = { 0.6, 0.6, 0.6 }

local function castOnUpdate(cb, elapsed)
	cb.throttle = (cb.throttle or 0) + elapsed
	if cb.throttle < 0.05 then return end
	cb.throttle = 0
	pcall(function()
		if cb.hasDuration then
			cb.time:SetFormattedText("%.1f", cb.duration:GetRemainingDuration())
		elseif cb.endTime then
			local now = GetTime()
			local total = cb.endTime - cb.startTime
			local done = now - cb.startTime
			cb:SetMinMaxValues(0, total)
			cb:SetValue(cb.channel and (total - done) or done)
			cb.time:SetFormattedText("%.1f", math.max(cb.endTime - now, 0))
		end
	end)
end

local function castStop(f)
	f.cast:Hide()
	f.cast:SetScript("OnUpdate", nil)
end

local function castStart(f, channel)
	if not db.castbar then return castStop(f) end
	local unit, cb = f.unit, f.cast
	local name, text, texture, startMS, endMS, notInterruptible, _
	if channel then
		name, text, texture, startMS, endMS, _, notInterruptible = UnitChannelInfo(unit)
	else
		name, text, texture, startMS, endMS, _, _, notInterruptible = UnitCastingInfo(unit)
	end
	if not present(name) then return castStop(f) end

	cb.icon:SetTexture(texture)
	cb.text:SetText(name)
	cb.channel = channel
	cb.duration, cb.hasDuration, cb.startTime, cb.endTime = nil, nil, nil, nil

	-- La barra lleva su propio temporizador (los tiempos de enemigos son
	-- secretos). Protegido y sin comprobar el objeto, que puede ser secreto.
	local getDuration = channel and UnitChannelDuration or UnitCastingDuration
	if getDuration and cb.SetTimerDuration then
		local direction = channel and Enum.StatusBarTimerDirection.RemainingTime or Enum.StatusBarTimerDirection.ElapsedTime
		cb.hasDuration = pcall(function()
			local obj = getDuration(unit)
			cb:SetTimerDuration(obj, Enum.StatusBarInterpolation.Immediate, direction)
			cb.duration = obj
		end)
	end
	if not cb.hasDuration then
		cb.startTime, cb.endTime = NS(startMS), NS(endMS)
		if cb.startTime and cb.endTime then
			cb.startTime, cb.endTime = cb.startTime / 1000, cb.endTime / 1000
		else
			cb.startTime, cb.endTime = nil, nil
		end
	end

	local locked = NS(notInterruptible)
	local c = locked and LOCKED_COLOR or CAST_COLOR
	cb:SetStatusBarColor(c[1], c[2], c[3])
	cb.icon:SetDesaturated(locked and true or false)
	if isSecret(notInterruptible) then
		-- No se puede comprobar, pero el motor sí elige el color (y el gris del icono)
		local tex = cb:GetStatusBarTexture()
		if tex and tex.SetVertexColorFromBoolean and CreateColor then
			pcall(tex.SetVertexColorFromBoolean, tex, notInterruptible,
				CreateColor(LOCKED_COLOR[1], LOCKED_COLOR[2], LOCKED_COLOR[3], 1),
				CreateColor(CAST_COLOR[1], CAST_COLOR[2], CAST_COLOR[3], 1))
		end
		pcall(cb.icon.SetDesaturated, cb.icon, notInterruptible)
	end
	cb:SetScript("OnUpdate", castOnUpdate)
	cb:Show()
end

-- "Interrumpido por <nombre>" si el evento trae quién fue sin secreto. En
-- enemigos casi nunca pasa (el juego solo lo da claro en tus lanzamientos).
local function setInterrupter(fs, guid)
	if isSecret(guid) or guid == nil or guid == "" or not UnitNameFromGUID then return false end
	local ok, name = pcall(UnitNameFromGUID, guid)
	if not ok then return false end
	local fmt = SPELL_INTERRUPTED_BY or L["Interrumpido por %s"]
	if isSecret(name) then return (pcall(fs.SetFormattedText, fs, fmt, name)) end
	if name == nil or name == "" then return false end
	fs:SetText(fmt:format(name))
	return true
end

-- Argumentos del evento: castGUID, spellID, interruptedBy (GUID)
local function castInterrupted(f, _, _, interruptedBy)
	local cb = f.cast
	if not cb:IsShown() then return end
	cb:SetScript("OnUpdate", nil)
	cb.hasDuration = nil
	cb:SetStatusBarColor(1, 0.1, 0.1)
	cb:SetMinMaxValues(0, 1)
	cb:SetValue(1)
	if not setInterrupter(cb.text, interruptedBy) then cb.text:SetText(L["Interrumpido"]) end
	cb.time:SetText("")
	C_Timer.After(0.6, function()
		if f.cast == cb and not cb:GetScript("OnUpdate") then cb:Hide() end
	end)
end

-- Fin de un canalizado: si se ha cortado, el evento trae quién (sin secreto)
local function channelStop(f, castGUID, spellID, interruptedBy)
	if not isSecret(interruptedBy) and interruptedBy ~= nil and interruptedBy ~= "" then
		castInterrupted(f, castGUID, spellID, interruptedBy)
	else
		castStop(f)
	end
end

local function updateCast(f)
	if present(UnitCastingInfo(f.unit)) then
		castStart(f, false)
	elseif present(UnitChannelInfo(f.unit)) then
		castStart(f, true)
	else
		castStop(f)
	end
end

----------------------------------------------------------------------
-- Perjuicios
--
-- Se leen por la unidad de la placa ("nameplate3"), como Plater. Si en combate
-- el juego lo bloquea, se toman prestados los iconos de la placa de Blizzard
-- (su código sí puede leerlos) hasta salir de combate.
----------------------------------------------------------------------

local AURA_GAP = 2
local WHITE = "Interface\\Buttons\\WHITE8X8"
local auraContainerSerial = 0

-- El contenedor de auras del cliente filtra y pinta internamente en combate.
-- Las consultas C_UnitAuras hechas por Lua dan "Auras cannot be accessed when secret".
local function createAuraContainer(f)
	if not (C_XMLUtil and C_XMLUtil.GetTemplateInfo
		and C_XMLUtil.GetTemplateInfo("CustomAuraContainerTemplate")) then
		f.auraContainerError = "plantilla CustomAuraContainerTemplate no disponible"
		return
	end
	if not (AuraContainerSortMethod and AuraContainerSortDirection and AnchorUtil) then
		f.auraContainerError = "API de ordenación o anclaje no disponible"
		return
	end
	auraContainerSerial = auraContainerSerial + 1
	local ok, container = pcall(CreateFrame, "AuraContainer",
		"RheizorPlateAuraContainer" .. auraContainerSerial, f.auras, "CustomAuraContainerTemplate")
	if not ok or not container then
		f.auraContainerError = tostring(container)
		return
	end
	local initialized, initError = pcall(function()
		container:SetSize(1, 1)
		container:SetPoint("BOTTOM", f.auras, "BOTTOM")
		local layout = {
			elementSpacing = AURA_GAP, lineSpacing = AURA_GAP,
			groupLineSpacing = AURA_GAP, elementWidth = db.auraSize,
			elementHeight = db.auraSize, maximumLineSize = math.huge,
		}
		local options = {
			maxFrameCount = db.auraMax,
			sortMethod = AuraContainerSortMethod.Default,
			sortDirection = AuraContainerSortDirection.Normal,
			layout = layout,
			initializeFrame = function(button)
				local icon = button:CreateTexture(nil, "ARTWORK")
				icon:SetAllPoints()
				icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
				button:SetIcon(icon)
				local cooldown = CreateFrame("Cooldown", nil, button, "CooldownFrameTemplate")
				cooldown:SetAllPoints()
				cooldown:SetHideCountdownNumbers(not db.auraTimer)
				button:SetDurationCooldown(cooldown)
				local count = button:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
				count:SetPoint("BOTTOMRIGHT", 1, 0)
				button:SetApplicationCount(count)
			end,
		}
		container:AddAuraGroup("debuffs", db.auraOnlyMine and "HARMFUL|PLAYER" or "HARMFUL", options)
		container:SetAuraGroupLayout("debuffs", layout)
		container:SetFlowLayoutAnchorPoint("BOTTOMLEFT")
		container:SetFlowLayoutGrowthDirection(AnchorUtil.FlowDirection.Right, AnchorUtil.FlowDirection.Up)
		container:SetFlowLayoutMaximumLineSize(math.huge)
		container:SetEnabled(true)
	end)
	if not initialized then
		f.auraContainerError = tostring(initError)
		container:Hide()
		return
	end
	f.auraContainer = container
	f.auraContainerOptions = nil
end

local function updateAuraContainer(f)
	local container = f.auraContainer
	if not container then return false end
	local ok, err = pcall(function()
		local options = (db.auraOnlyMine and "mine" or "all") .. ":" .. db.auraMax .. ":" .. db.auraSize
		if options ~= f.auraContainerOptions then
			container:SetAuraGroupFilterString("debuffs", db.auraOnlyMine and "HARMFUL|PLAYER" or "HARMFUL")
			container:SetAuraGroupMaxFrameCount("debuffs", db.auraMax)
			container:SetAuraGroupLayout("debuffs", {
				elementSpacing = AURA_GAP, lineSpacing = AURA_GAP,
				groupLineSpacing = AURA_GAP, elementWidth = db.auraSize,
				elementHeight = db.auraSize, maximumLineSize = math.huge,
			})
			f.auraContainerOptions = options
		end
		local unit = db.auras and f.unit or nil
		if unit ~= f.auraContainerUnit then
			container:SetUnit(unit)
			f.auraContainerUnit = unit
		end
		if f.auraContainerShown ~= db.auras then
			container:SetShown(db.auras)
			f.auraContainerShown = db.auras
		end
	end)
	if ok then return true end
	if f.auraContainerError ~= tostring(err) then
		f.auraContainerError = tostring(err)
		R:Print("Nameplates AuraContainer: " .. f.auraContainerError)
	end
	container:Hide()
	return false
end

local function auraIcon(f, i)
	local icons = f.auras.icons
	local b = icons[i]
	if b then return b end
	b = CreateFrame("Frame", nil, f.auras, "BackdropTemplate")
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropColor(0, 0, 0, 1)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetPoint("TOPLEFT", 1, -1)
	b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
	b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
	b.cd:SetAllPoints(b.icon)
	b.cd:SetReverse(true)
	b.cd:SetDrawEdge(false)
	b.count = b:CreateFontString(nil, "OVERLAY")
	b.count:SetPoint("BOTTOMRIGHT", 1, 0)
	b.count:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
	icons[i] = b
	return b
end

-- El contenedor de auras de la placa de Blizzard
local function blizzardAuraFrame(f)
	local uf = f:GetParent() and f:GetParent().UnitFrame
	if not uf then return end
	-- En el cliente nuevo, mover AurasFrame no mueve los anclajes de sus listas.
	return uf.AurasFrame and (uf.AurasFrame.DebuffListFrame or uf.AurasFrame) or uf.BuffFrame
end

local borrowedAuras = setmetatable({}, { __mode = "k" })

local function centerBorrowed(f, container)
	local state = borrowedAuras[container]
	if not state or state.centered then return end
	if not state.points and not InCombatLockdown() then
		local ok, points = pcall(function()
			local original = {}
			for i = 1, container:GetNumPoints() do original[i] = { container:GetPoint(i) } end
			return original
		end)
		if ok then state.points = points end
	end
	local ok, err = pcall(function()
		container:ClearAllPoints()
		container:SetPoint("BOTTOM", f.auras, "BOTTOM", 0, 0)
	end)
	if ok then
		state.centered = true
	else
		pcall(container.SetPoint, container, "CENTER", state.root, "CENTER")
		if f.auraCenterError ~= tostring(err) then
			f.auraCenterError = tostring(err)
			R:Print("Nameplates: no se pudo centrar la fila de debuffs: " .. f.auraCenterError)
		end
	end
end

-- Cambiar solo el padre del marco de auras: sus anclajes siguen siendo los de
-- Blizzard. GetPoint/ClearAllPoints de este marco están restringidos en combate.
local function borrowBlizzard(f, on)
	local container = f.borrowedAuraFrame or blizzardAuraFrame(f)
	if not container then return end
	local ok, err = pcall(function()
		if on then
			if not borrowedAuras[container] then
				local uf = f:GetParent() and f:GetParent().UnitFrame
				local root = uf and uf.AurasFrame or container
				local state = {
					owner = f, alpha = container:GetAlpha(),
					root = root, rootParent = root:GetParent(),
					rootAlpha = root:GetAlpha(),
				}
				root:SetParent(f)
				borrowedAuras[container] = state
				root:SetAlpha(1)
			end
			f.borrowedAuraFrame = container
			container:SetAlpha(1)
			f.borrowing = true
			centerBorrowed(f, container)
		elseif borrowedAuras[container] then
			local state = borrowedAuras[container]
			borrowedAuras[container] = nil
			if state.centered then
				container:ClearAllPoints()
				if state.points then
					for _, point in ipairs(state.points) do container:SetPoint(unpack(point)) end
				else
					container:SetPoint("CENTER", state.root, "CENTER")
				end
			end
			container:SetAlpha(state.alpha)
			state.root:SetParent(state.rootParent)
			state.root:SetAlpha(state.rootAlpha)
			f.borrowedAuraFrame = nil
			f.borrowing = nil
		end
	end)
	if not ok and f.auraBorrowError ~= tostring(err) then
		f.auraBorrowError = tostring(err)
		R:Print("Nameplates: " .. f.auraBorrowError)
	end
end

-- La lista nativa no crea iconos si los perjuicios están desactivados en el juego.
local function enableBlizzardDebuffs()
	if not db.auras or InCombatLockdown() then return end
	for _, entry in ipairs({
		{ "nameplateEnemyNpcAuraDisplay", Enum and Enum.NamePlateEnemyNpcAuraDisplay },
		{ "nameplateEnemyPlayerAuraDisplay", Enum and Enum.NamePlateEnemyPlayerAuraDisplay },
	}) do
		local cvar, enum = entry[1], entry[2]
		if enum and enum.Debuffs and C_CVar.GetCVar(cvar) and C_CVar.SetCVarBitfield then
			if not C_CVar.GetCVarBitfield(cvar, enum.Debuffs) then
				pcall(C_CVar.SetCVarBitfield, cvar, enum.Debuffs, true)
			end
		end
	end
	if C_CVar.GetCVar("nameplateShowAllPersonalAuras") then
		R:SetCVar("nameplateShowAllPersonalAuras", "1")
	end
end

local function updateAuras(f, info)
	local icons = f.auras.icons
	local shown = 0
	local useBlizzard = false
	local native = blizzardAuraFrame(f)
	if db.auras and native and native:GetNumChildren() > 0 then
		if f.auraContainer then
			pcall(f.auraContainer.SetUnit, f.auraContainer, nil)
			f.auraContainerUnit = nil
			f.auraContainer:Hide()
			f.auraContainerShown = false
		end
		borrowBlizzard(f, true)
		for _, icon in ipairs(icons) do icon:Hide() end
		return
	end
	if f.auraContainer and updateAuraContainer(f) then
		borrowBlizzard(f, false)
		for _, icon in ipairs(icons) do icon:Hide() end
		return
	end
	f.auraCache = f.auraCache or {}
	if info and R.CacheAuras then R.CacheAuras(f.auraCache, f.unit, info) end

	if db.auras and R.ReadAuras then
		local filters = db.auraOnlyMine and { "HARMFUL|PLAYER" } or { "HARMFUL|PLAYER", "HARMFUL" }
		local list, _, failed = R.ReadAuras(f.unit, filters, db.auraMax, f.auraCache)
		list = list or {}
		if failed and #list == 0 then
			-- Solo recurrir a Blizzard si no se ha podido leer ningún perjuicio.
			-- Un fallo parcial no debe ocultar lo leído ni bloquear otras placas.
			useBlizzard = true
		else
			local size = db.auraSize
			for i, aura in ipairs(list) do
				shown = i
				local b = auraIcon(f, i)
				b:SetSize(size, size)
				b:ClearAllPoints()
				b:SetPoint("LEFT", f.auras, "LEFT", (i - 1) * (size + AURA_GAP), 0)
				b.count:SetFont(STANDARD_TEXT_FONT, math.max(8, math.floor(size * 0.45)), "OUTLINE")
				b.cd:SetHideCountdownNumbers(not db.auraTimer)
				pcall(R.SetAuraButton, b, f.unit, aura, i, "HARMFUL", true, false)
				b:Show()
			end
			f.auras:SetWidth(math.max(shown * (size + AURA_GAP) - AURA_GAP, 1))
		end
	end

	borrowBlizzard(f, useBlizzard)
	for i = shown + 1, #icons do icons[i]:Hide() end
end

----------------------------------------------------------------------
-- Alta y baja de placas
----------------------------------------------------------------------

local function hideBlizzard(uf, hide)
	if not uf then return end
	uf.rzHidden = hide
	if hide and not uf.rzAlphaHooked then
		uf.rzAlphaHooked = true
		hooksecurefunc(uf, "SetAlpha", function(self, alpha)
			if self.rzHidden and alpha ~= 0 then self:SetAlpha(0) end
		end)
	end
	pcall(uf.SetAlpha, uf, hide and 0 or 1)
end

local function shouldStyle(unit)
	if NS(UnitIsUnit(unit, "player")) then return false end
	if db.friendly then return true end
	return NS(UnitCanAttack("player", unit)) and true or false
end

local function fullUpdate(f)
	applyStyle(f)
	updateHealth(f)
	updateColor(f)
	updateThreat(f)
	updateName(f)
	updateRaidIcon(f)
	updateTarget(f)
	updateCast(f)
	updateAuras(f)
end

local function onAdded(unit)
	local nameplate = C_NamePlate.GetNamePlateForUnit(unit)
	if not nameplate then return end
	if not shouldStyle(unit) then
		hideBlizzard(nameplate.UnitFrame, false)
		if nameplate.rz then
			borrowBlizzard(nameplate.rz, false)
			nameplate.rz:Hide()
		end
		return
	end
	nameplate.rz = nameplate.rz or createPlate(nameplate)
	local f = nameplate.rz
	f.unit = unit
	f.auraCache = {}
	if not f.auraContainer then createAuraContainer(f) end
	active[unit] = f
	hideBlizzard(nameplate.UnitFrame, true)
	fullUpdate(f)
	f:Show()
end

local function onRemoved(unit)
	local f = active[unit]
	if not f then return end
	active[unit] = nil
	castStop(f)
	if f.auraContainer then
		pcall(f.auraContainer.SetUnit, f.auraContainer, nil)
		f.auraContainerUnit = nil
		f.auraContainer:Hide()
		f.auraContainerShown = false
	end
	borrowBlizzard(f, false)
	f:Hide()
	f.unit = nil
	f.auraCache = nil
end

-- La unidad de una placa ("nameplate3"). En Forever la placa la guarda en
-- unitToken (namePlateUnitToken era de clientes anteriores)
local function plateUnit(nameplate)
	return nameplate.namePlateUnitToken or nameplate.unitToken or (nameplate.UnitFrame and nameplate.UnitFrame.unit)
end

function M:RefreshAll()
	for _, f in pairs(active) do fullUpdate(f) end
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local unitHandlers = {
	UNIT_HEALTH = function(f) updateHealth(f) end,
	UNIT_MAXHEALTH = function(f) updateHealth(f) end,
	UNIT_THREAT_LIST_UPDATE = function(f) updateColor(f); updateThreat(f) end,
	UNIT_THREAT_SITUATION_UPDATE = function(f) updateColor(f); updateThreat(f) end,
	UNIT_FACTION = updateColor,
	UNIT_NAME_UPDATE = updateName,
	UNIT_LEVEL = updateName,
	UNIT_CLASSIFICATION_CHANGED = updateName,
	UNIT_SPELLCAST_START = function(f) castStart(f, false) end,
	UNIT_SPELLCAST_DELAYED = function(f) castStart(f, false) end,
	UNIT_SPELLCAST_CHANNEL_START = function(f) castStart(f, true) end,
	UNIT_SPELLCAST_CHANNEL_UPDATE = function(f) castStart(f, true) end,
	UNIT_SPELLCAST_STOP = castStop,
	UNIT_SPELLCAST_CHANNEL_STOP = channelStop,
	UNIT_SPELLCAST_FAILED = castStop,
	UNIT_SPELLCAST_INTERRUPTED = castInterrupted,
	UNIT_SPELLCAST_INTERRUPTIBLE = function(f) updateCast(f) end,
	UNIT_SPELLCAST_NOT_INTERRUPTIBLE = function(f) updateCast(f) end,
	UNIT_AURA = function(f, info)
		if not info then f.auraCache = {} end
		updateAuras(f, info)
		-- Blizzard puede crear sus botones después de recibir el mismo evento.
		local unit = f.unit
		C_Timer.After(0, function()
			if f.unit == unit then updateAuras(f) end
		end)
	end,
}

----------------------------------------------------------------------
-- Espacio que ocupa cada placa al apilarse
----------------------------------------------------------------------
-- El juego apila las placas según el tamaño que le da Blizzard con
-- C_NamePlate.SetNamePlateSize (según el estilo y tamaño de sus placas).
-- Aquí se puede poner el de la placa de Rheizor o uno a medida. Blizzard lo
-- vuelve a poner al cambiar sus opciones: se engancha y se reaplica.

local blizzardSize      -- { ancho, alto } que puso Blizzard
local overridden = false
local sizeHooked, sizeWarned = false, false

local function wantedStackSize()
	if db.stackMode == "custom" then
		return db.stackWidth, db.stackHeight
	elseif db.stackMode == "auto" and db.enabled then
		local scale = db.changeScaleOnTarget and db.nonTargetScale or db.targetScale
		local h = db.height + math.max(db.nameSize, db.levelSize) + 4
		return db.width * scale, math.max(4, h * scale + db.stackExtra)
	end
end

local function readBlizzardSize()
	local ok, w, h = pcall(C_NamePlate.GetNamePlateSize)
	if ok and NS(w) and NS(h) then blizzardSize = { w, h } end
end

local function applyStackSize()
	if not (C_NamePlate.SetNamePlateSize and C_NamePlate.GetNamePlateSize) then return end
	R:RunOutOfCombat(function()
		if not overridden then readBlizzardSize() end
		local w, h = wantedStackSize()
		local custom = w ~= nil
		if not custom then
			-- Volver al de Blizzard solo si se había cambiado
			if not (overridden and blizzardSize) then return end
			w, h = blizzardSize[1], blizzardSize[2]
		end
		if pcall(C_NamePlate.SetNamePlateSize, w, h) then
			overridden = custom
		elseif not sizeWarned then
			sizeWarned = true
			R:Print(L["El juego no deja cambiar el espacio de las placas: se queda el de Blizzard."])
		end
	end)
end

local function hookBlizzardSize()
	if sizeHooked or not (NamePlateDriverFrame and NamePlateDriverFrame.UpdateNamePlateSize) then return end
	sizeHooked = true
	hooksecurefunc(NamePlateDriverFrame, "UpdateNamePlateSize", function()
		readBlizzardSize()
		overridden = false
		if wantedStackSize() then applyStackSize() end
	end)
end

local STACK_KEYS = {
	stackMode = true, stackExtra = true, stackWidth = true, stackHeight = true, enabled = true,
	width = true, height = true, nameSize = true, levelSize = true,
	targetScale = true, nonTargetScale = true, changeScaleOnTarget = true,
}

local events = CreateFrame("Frame")

function M:Enable()
	if self.running then return end
	self.running = true
	enableBlizzardDebuffs()
	events.threatElapsed = 0
	events.scaleElapsed = 0
	events:SetScript("OnUpdate", function(self, elapsed)
		if not db.changeScaleOnTarget then
			self.scaleElapsed = self.scaleElapsed + elapsed
			if self.scaleElapsed >= 0.05 then
				self.scaleElapsed = 0
				for _, f in pairs(active) do applyPlateScale(f, false) end
			end
		end
		-- Amenaza cada 0,25 s: el color y el texto se leen a veces con otro
		-- nombre del enemigo (objetivo, foco...), que no manda eventos a la placa
		if db.threatFormat ~= "none" or db.threat ~= "off" then
			self.threatElapsed = self.threatElapsed + elapsed
			if self.threatElapsed >= 0.25 then
				self.threatElapsed = 0
				for _, f in pairs(active) do
					if db.threat ~= "off" then updateColor(f) end
					updateThreat(f)
				end
			end
		end
	end)

	events:RegisterEvent("NAME_PLATE_UNIT_ADDED")
	events:RegisterEvent("NAME_PLATE_UNIT_REMOVED")
	events:RegisterEvent("PLAYER_TARGET_CHANGED")
	events:RegisterEvent("RAID_TARGET_UPDATE")
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	for event in pairs(unitHandlers) do
		pcall(events.RegisterEvent, events, event)
	end
	events:SetScript("OnEvent", function(_, event, unit, ...)
		if event == "NAME_PLATE_UNIT_ADDED" then
			onAdded(unit)
		elseif event == "NAME_PLATE_UNIT_REMOVED" then
			onRemoved(unit)
		elseif event == "PLAYER_TARGET_CHANGED" then
			-- (la amenaza también: el objetivo es por donde se lee sin secreto)
			for _, f in pairs(active) do updateTarget(f); updateColor(f); updateThreat(f) end
		elseif event == "RAID_TARGET_UPDATE" then
			for _, f in pairs(active) do updateRaidIcon(f) end
		elseif event == "PLAYER_REGEN_ENABLED" then
			-- Fuera de combate se vuelve a intentar leerlas con nuestros iconos
			enableBlizzardDebuffs()
			for _, f in pairs(active) do updateAuras(f) end
		else
			local f = unit and active[unit]
			if f then unitHandlers[event](f, ...) end
		end
	end)

	for _, nameplate in pairs(C_NamePlate.GetNamePlates()) do
		local unit = plateUnit(nameplate)
		if unit then onAdded(unit) end
	end
end

function M:OnEnable()
	db = self.db
	-- "Mostrar tu amenaza en %" (sí/no) ahora es la opción "No mostrar" del formato
	if db.threatText ~= nil then
		if db.threatText == false then db.threatFormat = "none" end
		db.threatText = nil
	end
	if db.enabled then self:Enable() end
	-- Cambia quién es tanque: los colores, ya
	if R.OnTanksChanged then
		R:OnTanksChanged(function()
			if M.running then
				for _, f in pairs(active) do updateColor(f); updateThreat(f) end
			end
		end)
	end

	local function stackSetup()
		hookBlizzardSize()
		if wantedStackSize() then applyStackSize() end
	end
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_NamePlates", stackSetup)
	else
		stackSetup()
	end
end

function M:OnOptionChanged(key, value)
	if STACK_KEYS[key] then applyStackSize() end
	if key == "enabled" then
		if value then self:Enable() else R:NeedReload() end
	elseif key == "friendly" then
		for _, nameplate in pairs(C_NamePlate.GetNamePlates()) do
			local unit = plateUnit(nameplate)
			if unit then onRemoved(unit); if self.running then onAdded(unit) end end
		end
	elseif self.running then
		if key == "auras" then enableBlizzardDebuffs() end
		self:RefreshAll()
	end
end

----------------------------------------------------------------------
-- /rz amenaza: qué da el juego sobre tu objetivo (para ver si llega secreto)
----------------------------------------------------------------------

local function describe(v)
	if issecretvalue and issecretvalue(v) then return "|cffff4040secreto|r" end
	if v == nil then return "nil" end
	if type(v) == "number" then return string.format("%.1f", v) end
	return tostring(v)
end

local function threatReport()
	if not UnitExists("target") then
		R:Print(L["Pon de objetivo al enemigo con el que estás en combate y vuelve a escribirlo."])
		return
	end
	local mobs = { "target" }
	local plate = C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_NamePlate.GetNamePlateForUnit("target")
	local token = plate and plateUnit(plate)
	if token then mobs[#mobs + 1] = token end
	for _, mob in ipairs(mobs) do
		if C_Secrets and C_Secrets.ShouldUnitThreatValuesBeSecret then
			local ok, s = pcall(C_Secrets.ShouldUnitThreatValuesBeSecret, "player", mob)
			R:Print(("%s — %s: %s"):format(mob, L["cifras secretas"], ok and describe(s) or "?"))
		end
		local units = { "player" }
		for _, u in ipairs(IsInRaid() and RAID_UNITS or PARTY_UNITS) do
			if UnitExists(u) then units[#units + 1] = u end
		end
		for _, u in ipairs(units) do
			local ok, tanking, status, scaled, raw, value = pcall(UnitDetailedThreatSituation, u, mob)
			if ok then
				R:Print(("%s → %s: %s=%s  %s=%s  %%=%s  %% %s=%s  %s=%s"):format(mob, u,
					L["agro"], describe(tanking), L["estado"], describe(status), describe(scaled),
					L["tanque"], describe(raw), L["total"], describe(value)))
			end
		end
		local via = threatUnit(mob)
		local ok, d = pcall(threatDiff, via)
		R:Print(("%s — %s (%s %s): %s"):format(mob, L["diferencia"], L["leída como"], via, ok and describe(d) or ("error: " .. tostring(d))))
	end
end

-- /rz placa: estado real del contenedor nativo cuando Forever bloquea las APIs.
local function auraPlateReport()
	local plate = C_NamePlate.GetNamePlateForUnit("target")
	local f = plate and plate.rz
	if not f then
		R:Print("Placa: selecciona un enemigo con la placa visible.")
		return
	end
	local uf = plate.UnitFrame
	local auras = uf and uf.AurasFrame
	local container = blizzardAuraFrame(f)
	local function describeFrame(frame)
		if not frame then return "no existe" end
		local children = frame.GetNumChildren and frame:GetNumChildren() or 0
		return ("shown=%s alpha=%s effective=%s children=%s"):format(
			tostring(frame:IsShown()), tostring(frame:GetAlpha()),
			tostring(frame:GetEffectiveAlpha()), tostring(children))
	end
	R:Print("Placa: unit=" .. tostring(f.unit) .. " auras=" .. tostring(db.auras)
		.. " soloMios=" .. tostring(db.auraOnlyMine) .. " prestada=" .. tostring(f.borrowing))
	R:Print("UnitFrame: " .. describeFrame(uf))
	R:Print("AurasFrame: " .. describeFrame(auras))
	R:Print("DebuffListFrame: " .. describeFrame(auras and auras.DebuffListFrame))
	R:Print("Usada: " .. describeFrame(container))
	R:Print("AuraContainer: " .. describeFrame(f.auraContainer)
		.. " unit=" .. tostring(f.auraContainerUnit)
		.. " error=" .. tostring(f.auraContainerError))
	if f.auraContainer then
		local ok, result = pcall(function()
			local visible, first = 0, nil
			for _, child in ipairs({ f.auraContainer:GetChildren() }) do
				if child:IsShown() then
					visible = visible + 1
					if not first then
						first = ("%s x %s, alpha %s"):format(
							tostring(child:GetWidth()), tostring(child:GetHeight()),
							tostring(child:GetEffectiveAlpha()))
					end
				end
			end
			return "visibles=" .. visible .. " primero=" .. (first or "ninguno")
		end)
		R:Print("Iconos AuraContainer: " .. (ok and result or ("error=" .. tostring(result))))
	end
	for _, key in ipairs({ "nameplateEnemyNpcAuraDisplay", "nameplateEnemyPlayerAuraDisplay", "nameplateShowAllPersonalAuras" }) do
		R:Print(key .. "=" .. tostring(C_CVar.GetCVar(key)))
	end
end

-- /rz rangos: comparar la amenaza disponible para placas seleccionadas y no seleccionadas.
local function threatPlatesReport()
	local selected = C_NamePlate.GetNamePlateForUnit("target")
	local count = 0
	for unit, f in pairs(active) do
		count = count + 1
		local ok, tanking, status, scaled, raw, value = pcall(UnitDetailedThreatSituation, "player", unit)
		local textOK, shown = pcall(f.threatText.GetText, f.threatText)
		R:Print(("%s objetivo=%s secreto=%s estado=%s relativo=%s bruto=%s total=%s texto=%s"):format(
			unit, tostring(f:GetParent() == selected), tostring(threatSecret(unit)),
			ok and describe(status) or "error", ok and describe(scaled) or "error",
			ok and describe(raw) or "error", ok and describe(value) or "error",
			textOK and describe(shown) or "error"))
		if count >= 6 then break end
	end
	if count == 0 then R:Print("No hay placas de Rheizor visibles.") end
end

do
	local original = SlashCmdList.RHEIZOR
	if original then
		SlashCmdList.RHEIZOR = function(msg)
			local word = strtrim(msg or ""):match("^(%S+)")
			word = word and word:lower()
			if word == "placa" then
				auraPlateReport()
			elseif word == "rangos" then
				threatPlatesReport()
			elseif word == "amenaza" or word == "threat" then
				threatReport()
			else
				original(msg)
			end
		end
	end
end
