-- Barra de objetos equipados: un botón por cada casilla elegida (abalorios,
-- armas…) con su tiempo de reutilización.
--   Clic:           usar la pieza (abalorios con efecto al usar, etc.).
--   Ratón encima:   las piezas de tus bolsas que caben en esa casilla; clic
--                   en una para ponértela (según la opción, con Alt pulsado
--                   o con clic derecho).
-- Los botones son seguros (SecureActionButtonTemplate, type "item") para
-- poder usar objetos en combate; por eso colocarlos y cambiar sus
-- atributos solo se hace fuera de combate.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret
local G = R.modules.gear

-- Casillas que se pueden poner en la barra (sin camisa ni tabardo)
local BAR_SLOTS = { 1, 2, 3, 15, 5, 9, 10, 6, 7, 8, 11, 12, 13, 14, 16, 17, 18 }

local options = {
	{ type = "header", text = "Barra de objetos equipados" },
	{ type = "toggle", key = "enabled", name = "Activar barra de objetos",
	  desc = "Un botón por cada casilla elegida abajo: clic para usar la pieza (abalorios, etc.), con su tiempo de reutilización. Encima, las piezas de tus bolsas que caben en esa casilla para cambiarla." },
	{ type = "dropdown", key = "flyout", name = "Piezas de las bolsas",
	  desc = "Cuándo se ven las piezas de tus bolsas que caben en la casilla. En la ficha del personaje, Blizzard ya lo hace con Alt + ratón encima de cada casilla.",
	  values = { { "hover", "Al pasar el ratón" }, { "alt", "Con Alt pulsado" }, { "click", "Con clic derecho" } } },
	{ type = "dropdown", key = "orientation", name = "Orientación",
	  values = { { "horizontal", "Horizontal" }, { "vertical", "Vertical" } } },
	{ type = "slider", key = "size", name = "Tamaño de los botones", min = 24, max = 56, step = 2, format = R.fmt.int },
	{ type = "toggle", key = "fade", name = "Ocultar hasta pasar el ratón",
	  desc = "Aun invisibles, los botones se pueden pulsar." },
	{ type = "slider", key = "fadeAlpha", name = "Opacidad sin ratón", min = 0, max = 0.8, step = 0.05, format = R.fmt.percent },
	{ type = "toggle", key = "fadeCombat", name = "Mostrarla siempre en combate",
	  desc = "Marcada, en combate se ve entera aunque no pases el ratón. Desmárcala para que solo aparezca con el ratón." },
	{ type = "toggle", key = "locked", name = "Bloquear posición",
	  desc = "Desbloqueada, aparece un marco encima de la barra para arrastrarla." },
	{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
	{ type = "header", text = "Casillas de la barra" },
}
local defaults = {
	enabled = false,
	flyout = "hover",
	orientation = "horizontal",
	size = 36,
	fade = false,
	fadeAlpha = 0,
	fadeCombat = false,
	locked = true,
}
for _, slot in ipairs(BAR_SLOTS) do
	local key = "slot" .. slot
	defaults[key] = (slot == 13 or slot == 14)
	local name
	for _, s in ipairs(G.SLOTS) do
		if s[1] == slot then name = s[2] end
	end
	options[#options + 1] = { type = "toggle", key = key, name = name }
end

local M = R:RegisterModule("gearbar", {
	title = "Barra de objetos",
	group = "Equipamiento",
	defaults = defaults,
	options = options,
	unsupported = {
		"En combate el juego puede ocultar a los addons el tiempo de reutilización de los objetos: si pasa, el círculo de la barra se pone al día al salir de combate.",
		"En combate solo se pueden cambiar las armas: las demás piezas elegidas en la lista se ponen al salir de combate.",
	},
})

local db
local bar
local buttons = {}
local fly            -- lista de piezas de las bolsas
local hovered        -- botón de la barra con el ratón encima

local WHITE = "Interface\\Buttons\\WHITE8X8"
local GAP = 4
local FLY_SIZE = 32

----------------------------------------------------------------------
-- Tiempo de reutilización
----------------------------------------------------------------------

-- En combate los valores podrían llegar secretos: entonces se le pasan al
-- marco tal cual (si el juego no lo permite, se pone al día al salir)
local function setCooldown(cd, slot)
	local start, duration, enable = GetInventoryItemCooldown("player", slot)
	local s, d, e = NS(start), NS(duration), NS(enable)
	if s and d and e ~= nil then
		if (e == 1 or e == true) and s > 0 and d > 0 then
			cd:SetCooldown(s, d)
		else
			cd:Clear()
		end
	elseif start ~= nil and duration ~= nil then
		pcall(cd.SetCooldown, cd, start, duration)
	end
end

----------------------------------------------------------------------
-- Lista de piezas de las bolsas
----------------------------------------------------------------------

-- Piezas que caben en una casilla: de las bolsas o de la otra casilla
-- (anillos, abalorios, armas); no las del banco
local function candidates(slot)
	local out = {}
	if not GetInventoryItemsForSlot then return out end
	local found = {}
	local ok = pcall(GetInventoryItemsForSlot, slot, found)
	if not ok then return out end
	for loc, itemID in pairs(found) do
		local d = G.DecodeLocation(loc)
		if d and not d.bank and not (d.player and not d.bags and d.slot == slot) then
			local link, icon
			if d.bags then
				local info = C_Container.GetContainerItemInfo(d.bag, d.slot)
				link = info and NS(info.hyperlink)
				icon = info and NS(info.iconFileID)
			else
				link = NS(GetInventoryItemLink("player", d.slot))
				icon = NS(GetInventoryItemTexture("player", d.slot))
			end
			if link then
				out[#out + 1] = { loc = NS(loc), id = NS(itemID), link = link, icon = icon, bag = d.bags and d.bag, bslot = d.slot }
			end
		end
	end
	table.sort(out, function(a, b) return a.loc < b.loc end)
	return out
end

local function flyTooltip(self)
	local e = self.entry
	if not e then return end
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	if e.bag then
		GameTooltip:SetBagItem(e.bag, e.bslot)
	else
		GameTooltip:SetInventoryItem("player", e.bslot)
	end
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine(L["|cff33ccffClic:|r ponértela en %s"]:format(G.SlotName(fly.slot)), 1, 1, 1)
	GameTooltip:Show()
end

local function onFlyClick(self)
	local e, slot = self.entry, fly.slot
	if not e or not slot then return end
	if InCombatLockdown() and not G.COMBAT_SLOTS[slot] then
		-- En combate solo se pueden cambiar las armas: para después
		G.QueueItem(slot, e.link)
		R:Print(L["En combate: %s se pondrá al salir de combate."]:format(e.link))
	else
		G.EquipLocation(e.loc, slot)
	end
	fly:Hide()
end

local function flyButton(i)
	local b = fly.buttons[i]
	if b then return b end
	b = CreateFrame("Button", nil, fly)
	b:SetSize(FLY_SIZE, FLY_SIZE)
	local bg = b:CreateTexture(nil, "BACKGROUND")
	bg:SetPoint("TOPLEFT", -1, 1)
	bg:SetPoint("BOTTOMRIGHT", 1, -1)
	bg:SetColorTexture(0, 0, 0, 0.8)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetAllPoints()
	b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.2)
	b:SetScript("OnClick", onFlyClick)
	b:SetScript("OnEnter", flyTooltip)
	b:SetScript("OnLeave", GameTooltip_Hide)
	fly.buttons[i] = b
	return b
end

local function createFlyout()
	fly = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
	fly:SetFrameStrata("DIALOG")
	fly:SetClampedToScreen(true)
	fly:EnableMouse(true)
	fly:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	fly:SetBackdropColor(0.05, 0.05, 0.07, 0.92)
	fly:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	fly.buttons = {}
	fly:Hide()
	-- Se cierra al sacar el ratón de la barra y de la lista (salvo si se ha
	-- abierto con clic derecho: entonces hasta otro clic)
	fly:SetScript("OnUpdate", function(self, elapsed)
		self.t = (self.t or 0) + elapsed
		if self.t < 0.15 then return end
		self.t = 0
		if self.pinned then return end
		local owner = self.owner
		if not (owner and owner:IsMouseOver()) and not self:IsMouseOver(4, -4, -4, 4) then
			self:Hide()
		end
	end)
	fly:SetScript("OnHide", function(self)
		self.owner, self.pinned = nil, nil
	end)
end

local function showFlyout(owner, pinned)
	if not fly then createFlyout() end
	local list = candidates(owner.slot)
	if #list == 0 then
		fly:Hide()
		return
	end
	fly.owner, fly.slot, fly.pinned = owner, owner.slot, pinned
	local vertical = db.orientation == "vertical"
	local perLine = 6
	for i, e in ipairs(list) do
		local b = flyButton(i)
		b.entry = e
		b.icon:SetTexture(e.icon or 134400)
		local line, col = math.floor((i - 1) / perLine), (i - 1) % perLine
		b:ClearAllPoints()
		if vertical then
			-- Barra vertical: la lista sale a la derecha, en columnas
			b:SetPoint("TOPLEFT", fly, "TOPLEFT", 4 + line * (FLY_SIZE + 3), -4 - col * (FLY_SIZE + 3))
		else
			-- Barra horizontal: la lista sale hacia arriba, en filas
			b:SetPoint("BOTTOMLEFT", fly, "BOTTOMLEFT", 4 + col * (FLY_SIZE + 3), 4 + line * (FLY_SIZE + 3))
		end
		b:Show()
	end
	for i = #list + 1, #fly.buttons do fly.buttons[i]:Hide() end
	local lines = math.ceil(#list / perLine)
	local across = math.min(#list, perLine)
	local long = across * (FLY_SIZE + 3) + 5
	local short = lines * (FLY_SIZE + 3) + 5
	fly:ClearAllPoints()
	fly:SetScale(bar:GetEffectiveScale() / UIParent:GetEffectiveScale())
	if vertical then
		fly:SetSize(short, long)
		fly:SetPoint("TOPLEFT", owner, "TOPRIGHT", 4, 4)
	else
		fly:SetSize(long, short)
		fly:SetPoint("BOTTOMLEFT", owner, "TOPLEFT", -4, 4)
	end
	fly:Show()
end

----------------------------------------------------------------------
-- Botones
----------------------------------------------------------------------

local function buttonTooltip(self)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	local hasItem = GameTooltip:SetInventoryItem("player", self.slot)
	if not hasItem then GameTooltip:SetText(G.SlotName(self.slot), 1, 1, 1) end
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine(L["|cff33ccffClic:|r usar"], 1, 1, 1)
	if db.flyout == "click" then
		GameTooltip:AddLine(L["|cff33ccffClic derecho:|r piezas de tus bolsas para esta casilla"], 1, 1, 1)
	elseif db.flyout == "alt" then
		GameTooltip:AddLine(L["|cff33ccffAlt:|r piezas de tus bolsas para esta casilla"], 1, 1, 1)
	end
	GameTooltip:Show()
end

local function onEnter(self)
	hovered = self
	buttonTooltip(self)
	if db.flyout == "hover" or (db.flyout == "alt" and IsAltKeyDown()) then showFlyout(self) end
end

local function onLeave(self)
	if hovered == self then hovered = nil end
	GameTooltip:Hide()
end

local function createButton(i)
	local b = CreateFrame("Button", "RheizorGearBarButton" .. i, bar, "SecureActionButtonTemplate")
	b:RegisterForClicks("AnyUp", "AnyDown")
	-- Solo el clic izquierdo usa el objeto; el derecho queda para la lista
	-- Con "/use <casilla>": la acción "item" de Blizzard con una casilla
	-- llama a C_Item.IsEquippableItem(nil) y da error en WoW Forever
	b:SetAttribute("type1", "macro")

	b.bg = b:CreateTexture(nil, "BACKGROUND")
	b.bg:SetPoint("TOPLEFT", -2, 2)
	b.bg:SetPoint("BOTTOMRIGHT", 2, -2)
	b.bg:SetColorTexture(0, 0, 0, 0.8)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetAllPoints()
	b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	b.border = CreateFrame("Frame", nil, b, "BackdropTemplate")
	b.border:SetPoint("TOPLEFT", -2, 2)
	b.border:SetPoint("BOTTOMRIGHT", 2, -2)
	b.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	b.cd = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
	b.cd:SetAllPoints()
	b.cd:SetDrawEdge(false)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.18)

	b:SetScript("OnEnter", onEnter)
	b:SetScript("OnLeave", onLeave)
	b:HookScript("OnClick", function(self, button, down)
		if button ~= "RightButton" or down then return end
		if fly and fly:IsShown() and fly.owner == self then
			fly:Hide()
		else
			-- Clic derecho: la lista se queda abierta hasta otro clic
			showFlyout(self, true)
		end
	end)
	buttons[i] = b
	return b
end

local function qualityColor(quality)
	if quality and C_Item and C_Item.GetItemQualityColor then
		local r, g, b = C_Item.GetItemQualityColor(quality)
		if r then return r, g, b end
	end
	local c = quality and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
	if c then return c.r, c.g, c.b end
	return 0.35, 0.35, 0.35
end

local function updateButton(b)
	local slot = b.slot
	if not slot then return end
	local texture = NS(GetInventoryItemTexture("player", slot))
	if texture then
		b.icon:SetTexture(texture)
		b.icon:SetDesaturated(false)
		b.icon:SetAlpha(1)
		local quality = NS(GetInventoryItemQuality("player", slot))
		if quality and quality >= 2 then
			b.border:SetBackdropBorderColor(qualityColor(quality))
		else
			b.border:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
		end
		setCooldown(b.cd, slot)
	else
		b.icon:SetTexture(G.SlotTexture(slot))
		b.icon:SetDesaturated(true)
		b.icon:SetAlpha(0.45)
		b.border:SetBackdropBorderColor(0.25, 0.25, 0.25, 1)
		b.cd:Clear()
	end
end

function M:UpdateAll()
	for _, b in ipairs(buttons) do
		if b:IsShown() then updateButton(b) end
	end
end

function M:UpdateCooldowns()
	for _, b in ipairs(buttons) do
		if b:IsShown() and b.slot and NS(GetInventoryItemTexture("player", b.slot)) then setCooldown(b.cd, b.slot) end
	end
end

----------------------------------------------------------------------
-- Ver al pasar el ratón (la opacidad se puede cambiar también en combate)
----------------------------------------------------------------------

local function fadeTarget()
	if not db.fade or not db.locked then return 1 end
	if db.fadeCombat and InCombatLockdown() then return 1 end
	if bar:IsMouseOver(4, -4, -4, 4) or (fly and fly:IsShown()) then return 1 end
	return db.fadeAlpha
end

local function fadeUpdate(self, elapsed)
	self.fadeT = (self.fadeT or 0) + elapsed
	if self.fadeT < 0.05 then return end
	local dt = self.fadeT
	self.fadeT = 0
	local target = fadeTarget()
	local cur = self:GetAlpha()
	if math.abs(cur - target) < 0.01 then
		if cur ~= target then self:SetAlpha(target) end
		return
	end
	-- Aparece rápido y se va un poco más despacio
	if cur < target then
		cur = math.min(target, cur + dt * 6)
	else
		cur = math.max(target, cur - dt * 3)
	end
	self:SetAlpha(cur)
end

----------------------------------------------------------------------
-- Colocación (solo fuera de combate)
----------------------------------------------------------------------

local function layout()
	local size = db.size
	local vertical = db.orientation == "vertical"
	local n = 0
	for _, slot in ipairs(BAR_SLOTS) do
		if db["slot" .. slot] then
			n = n + 1
			local b = buttons[n] or createButton(n)
			b.slot = slot
			b:SetAttribute("macrotext1", "/use " .. slot)
			b:SetSize(size, size)
			b:ClearAllPoints()
			if vertical then
				b:SetPoint("TOPLEFT", bar, "TOPLEFT", 0, -(n - 1) * (size + GAP))
			else
				b:SetPoint("TOPLEFT", bar, "TOPLEFT", (n - 1) * (size + GAP), 0)
			end
			b:Show()
		end
	end
	for i = n + 1, #buttons do
		buttons[i]:Hide()
		buttons[i].slot = nil
		buttons[i]:SetAttribute("macrotext1", nil)
	end
	local long = math.max(1, n) * (size + GAP) - GAP
	if vertical then bar:SetSize(size, long) else bar:SetSize(long, size) end
	bar:SetShown(db.enabled and n > 0 or (db.enabled and not db.locked))
	bar.mover:SetShown(db.enabled and not db.locked)
	M:UpdateAll()
end

function M:ApplyLayout()
	R:RunOutOfCombat(function()
		if not bar then
			bar = CreateFrame("Frame", "RheizorGearBar", UIParent)
			bar:SetSize(40, 40)
			bar.mover = R:CreateMover(bar, "Barra de objetos", db, "point", { "CENTER", "CENTER", 0, -240 })
			bar:SetScript("OnUpdate", fadeUpdate)
		end
		bar.mover:Place()
		layout()
	end)
end

function M:ResetPosition()
	db.point = nil
	if bar then self:ApplyLayout() end
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, arg1)
	if not bar or not R:IsModuleRunning(M) or not db.enabled then return end
	if event == "PLAYER_EQUIPMENT_CHANGED" or event == "UNIT_INVENTORY_CHANGED" then
		M:UpdateAll()
		if fly and fly:IsShown() and fly.owner then showFlyout(fly.owner, fly.pinned) end
	elseif event == "BAG_UPDATE_DELAYED" then
		if fly and fly:IsShown() and fly.owner then showFlyout(fly.owner, fly.pinned) end
	elseif event == "MODIFIER_STATE_CHANGED" then
		-- Con la opción "Con Alt pulsado": Alt con el ratón encima de un botón
		if db.flyout == "alt" and hovered and hovered:IsMouseOver() and IsAltKeyDown() then showFlyout(hovered) end
	elseif event == "PLAYER_REGEN_ENABLED" then
		-- Fuera de combate los tiempos ya no son secretos
		C_Timer.After(0.2, function() M:UpdateAll() end)
	else
		M:UpdateCooldowns()
	end
end)

function M:OnEnable()
	db = self.db
	if not db.enabled then return end
	self:Start()
end

-- Se prepara la primera vez que se activa (al entrar o desde las opciones)
function M:Start()
	if self.running then return end
	self.running = true
	for _, e in ipairs({ "PLAYER_EQUIPMENT_CHANGED", "BAG_UPDATE_DELAYED", "BAG_UPDATE_COOLDOWN",
		"SPELL_UPDATE_COOLDOWN", "MODIFIER_STATE_CHANGED", "PLAYER_REGEN_ENABLED" }) do
		pcall(events.RegisterEvent, events, e)
	end
	pcall(events.RegisterUnitEvent, events, "UNIT_INVENTORY_CHANGED", "player")
	self:ApplyLayout()
end

function M:OnOptionChanged(key, value)
	if key == "enabled" and value then self:Start() end
	if not bar then return end
	if fly then fly:Hide() end
	self:ApplyLayout()
end
