-- Ventana de equipamiento (/rzgear):
--   Pestaña Conjuntos: la lista a la izquierda (clic: elegir, doble clic:
--   ponérselo) y, a la derecha, el nombre, el icono y qué casillas cambia
--   el conjunto elegido. "Guardar lo que llevas" guarda en él las piezas
--   puestas ahora mismo (así funcionan los conjuntos del juego).
--   Pestaña Automático: qué conjunto ponerse al montar, al descansar y en
--   cada forma o actitud (cada personaje los suyos).

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret
local M = R.modules.gear
local UI = R.UI or {}
local ES = C_EquipmentSet

local W, H = 690, 520
local LIST_W = 220
local ROW_H = 30
local ICON = 24
local WHITE = "Interface\\Buttons\\WHITE8X8"

local win, body, tabs, setsPane, autoPane
local list, rows = nil, {}
local nameBox, iconPreview
local iconButtons, slotRows = {}, {}
local saveButton, renameButton, deleteButton, equipButton, statusText
local autoRows, autoNote = {}, nil
local mode = "sets"      -- "sets" o "auto"
local selected           -- id del conjunto elegido; nil = uno nuevo
local edit = { icon = nil, ignore = {} }
local armed = false      -- "Borrar" pide un segundo clic

local function backdrop(f, alpha)
	if UI.SetBackdrop then return UI.SetBackdrop(f, alpha) end
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.05, 0.05, 0.07, alpha or 0.95)
	f:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
end

local function setStatus(text, r, g, b)
	statusText:SetText(text or "")
	statusText:SetTextColor(r or 1, g or 1, b or 1)
end

local function panelButton(parent, text, width)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width or 120, 22)
	b:SetText(text)
	return b
end

-- Lista desplegable (la del gestor de Rheizor)
local function dropdown(parent, width)
	local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
	b:SetSize(width, 22)
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropColor(0, 0, 0, 0.6)
	b:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	b.text:SetPoint("LEFT", 6, 0)
	b.text:SetPoint("RIGHT", -18, 0)
	b.text:SetJustifyH("LEFT")
	b.text:SetWordWrap(false)
	local arrow = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	arrow:SetPoint("RIGHT", -6, 0)
	arrow:SetText("v")
	b:SetScript("OnClick", function(self)
		if not self.values then return end
		if UI.OpenPopup then
			UI.OpenPopup(self, self.values, self.current, self.onPick)
		else
			-- Sin la lista del gestor: pasa al siguiente valor
			local nextIndex = 1
			for i, v in ipairs(self.values) do
				if v[1] == self.current then nextIndex = i % #self.values + 1 end
			end
			local v = self.values[nextIndex]
			self.onPick(v[1], v[2])
		end
	end)
	return b
end

----------------------------------------------------------------------
-- Pestaña Conjuntos: lista
----------------------------------------------------------------------

local selectSet   -- se define más abajo

local function newRow(i)
	local row = CreateFrame("Button", nil, list.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", list.child, "RIGHT")

	row.sel = row:CreateTexture(nil, "BACKGROUND")
	row.sel:SetAllPoints()
	row.sel:SetColorTexture(0.2, 0.8, 1, 0.22)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(0.2, 0.8, 1, 0.12)

	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetSize(ICON, ICON)
	row.icon:SetPoint("LEFT", 4, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.text:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 6, -1)
	row.text:SetPoint("RIGHT", -4, 0)
	row.text:SetJustifyH("LEFT")
	row.text:SetWordWrap(false)
	row.sub = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	row.sub:SetPoint("BOTTOMLEFT", row.icon, "BOTTOMRIGHT", 6, 0)
	row.sub:SetPoint("RIGHT", -4, 0)
	row.sub:SetJustifyH("LEFT")
	row.sub:SetWordWrap(false)

	row:SetScript("OnClick", function(self) selectSet(self.setID) end)
	row:SetScript("OnDoubleClick", function(self) M:EquipSet(self.setID) end)
	row:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(self.name or "", 1, 1, 1)
		GameTooltip:AddLine(L["Doble clic: ponértelo"], 0.6, 0.6, 0.6)
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	rows[i] = row
	return row
end

local function drawList(sets)
	for i, s in ipairs(sets) do
		local row = rows[i] or newRow(i)
		row.setID, row.name = s.id, s.name
		row.icon:SetTexture(s.icon)
		row.text:SetText(string.format("|cff888888%d.|r %s", i, s.name))
		local sub
		if s.equipped then
			sub = "|cff33ff33" .. L["puesto"] .. "|r"
		elseif s.lost > 0 then
			sub = "|cffff5555" .. L["(faltan %d)"]:format(s.lost) .. "|r"
		else
			sub = L["%d piezas"]:format(s.items)
		end
		row.sub:SetText(sub)
		row.sel:SetShown(s.id == selected)
		row:Show()
	end
	for i = #sets + 1, #rows do rows[i]:Hide() end
	list.child:SetHeight(math.max(1, #sets * ROW_H))
	if list.UpdateBar then list:UpdateBar() end
end

----------------------------------------------------------------------
-- Pestaña Conjuntos: detalle (nombre, icono, casillas)
----------------------------------------------------------------------

-- Iconos para elegir: el del conjunto, los de las piezas que llevas y el
-- signo de interrogación
local function iconChoices()
	local out, seen = {}, {}
	local function add(icon)
		icon = NS(icon)
		if icon and not seen[icon] then
			seen[icon] = true
			out[#out + 1] = icon
		end
	end
	if selected then
		local s = M:SetByID(selected)
		if s then add(s.icon) end
	end
	for _, s in ipairs(M.SLOTS) do add(GetInventoryItemTexture("player", s[1])) end
	add(M.QUESTION_ICON)
	return out
end

local function drawIcons()
	iconPreview.icon:SetTexture(edit.icon or M.QUESTION_ICON)
	local choices = iconChoices()
	for i, b in ipairs(iconButtons) do
		local icon = choices[i]
		b.value = icon
		if icon then
			b.icon:SetTexture(icon)
			b.sel:SetShown(icon == edit.icon)
			b:Show()
		else
			b:Hide()
		end
	end
end

local function drawSlots()
	local ids, locs = {}, {}
	if selected then
		local ok, t = pcall(ES.GetItemIDs, selected)
		if ok and type(t) == "table" then ids = t end
		ok, t = pcall(ES.GetItemLocations, selected)
		if ok and type(t) == "table" then locs = t end
	end
	for _, row in ipairs(slotRows) do
		local slot = row.slot
		local itemID, icon
		if selected then
			itemID = NS(ids[slot])
			if type(itemID) ~= "number" or itemID <= 1 then itemID = nil end
			icon = itemID and ((C_Item.GetItemIconByID and C_Item.GetItemIconByID(itemID)) or (GetItemIcon and GetItemIcon(itemID)))
		else
			itemID = NS(GetInventoryItemID("player", slot))
			icon = NS(GetInventoryItemTexture("player", slot))
		end
		row.itemID = itemID
		local included = not edit.ignore[slot]
		row.check:SetChecked(included)
		row.icon:SetTexture(icon or M.SlotTexture(slot))
		row.icon:SetDesaturated(not icon)
		row.icon:SetAlpha(included and 1 or 0.35)
		local missing = selected and NS(locs[slot]) == -1
		if not included then
			row.text:SetTextColor(0.5, 0.5, 0.5)
		elseif missing then
			row.text:SetTextColor(1, 0.33, 0.33)
		else
			row.text:SetTextColor(1, 1, 1)
		end
		row.text:SetText(M.SlotName(slot) .. (missing and included and (" " .. L["(falta)"]) or ""))
	end
end

local function drawDetail()
	local s = selected and M:SetByID(selected)
	if selected and not s then
		-- Borrado desde otro sitio (la ficha del personaje, otro addon)
		selected = nil
	end
	saveButton:SetText(selected and L["Guardar lo que llevas"] or L["Crear con lo que llevas"])
	renameButton:SetShown(selected ~= nil)
	deleteButton:SetShown(selected ~= nil)
	deleteButton:SetText(armed and L["|cffff5555¿Seguro? Pulsa otra vez|r"] or L["Borrar"])
	equipButton:SetEnabled(selected ~= nil)
	drawIcons()
	drawSlots()
end

function selectSet(id)
	selected = id
	armed = false
	setStatus("")
	local s = id and M:SetByID(id)
	if s then
		nameBox:SetText(s.name)
		edit.icon = s.icon
		edit.ignore = M:IgnoredSlots(id)
	else
		selected = nil
		nameBox:SetText("")
		edit.icon = NS(GetInventoryItemTexture("player", 5)) or NS(GetInventoryItemTexture("player", 16))
		edit.ignore = {}
	end
	nameBox:ClearFocus()
	M:RefreshWindow()
end

local function onSave()
	local id, err = M:SaveSet(selected, nameBox:GetText(), edit.icon, edit.ignore)
	if id then
		selected = id
		setStatus(L["Guardado: las piezas que llevas ahora son las del conjunto."], 0.2, 1, 0.2)
	else
		setStatus(err, 1, 0.33, 0.33)
	end
	armed = false
	M:RefreshWindow()
end

local function onRename()
	if not selected then return end
	local id, err = M:RenameSet(selected, nameBox:GetText(), edit.icon)
	if id then
		setStatus(L["Nombre e icono cambiados."], 0.2, 1, 0.2)
	else
		setStatus(err, 1, 0.33, 0.33)
	end
	M:RefreshWindow()
end

local function onDelete()
	if not selected then return end
	if not armed then
		armed = true
		M:RefreshWindow()
		return
	end
	armed = false
	M:DeleteSet(selected)
	selectSet(nil)
end

----------------------------------------------------------------------
-- Pestaña Automático
----------------------------------------------------------------------

local function setValues()
	local values = { { 0, L["(ninguno)"] } }
	for _, s in ipairs(M:GetSets()) do
		values[#values + 1] = { s.id, string.format("|T%s:16:16:0:0|t %s", tostring(s.icon), s.name) }
	end
	return values
end

local function valueText(values, current)
	for _, v in ipairs(values) do
		if v[1] == current then return v[2] end
	end
	return L["(ninguno)"]
end

local function autoRow(i)
	local row = autoRows[i]
	if not row then
		row = CreateFrame("Frame", nil, autoPane)
		row:SetHeight(28)
		row:SetPoint("TOPLEFT", 12, -12 - (i - 1) * 30)
		row:SetPoint("RIGHT", autoPane, "RIGHT", -12, 0)
		row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		row.label:SetPoint("LEFT", 0, 0)
		row.label:SetWidth(260)
		row.label:SetJustifyH("LEFT")
		row.label:SetWordWrap(false)
		row.drop = dropdown(row, 260)
		row.drop:SetPoint("LEFT", 270, 0)
		autoRows[i] = row
	end
	row:Show()
	return row
end

-- Formas o actitudes que conoce el personaje: { clave, nombre }
local function forms()
	local out = {}
	local n = GetNumShapeshiftForms and NS(GetNumShapeshiftForms()) or 0
	if n <= 0 then return out end
	out[1] = { 0, L["Sin forma ni actitud"] }
	for i = 1, n do
		local _, _, _, spellID = GetShapeshiftFormInfo(i)
		spellID = NS(spellID)
		local name = spellID and C_Spell and C_Spell.GetSpellName and C_Spell.GetSpellName(spellID)
		out[#out + 1] = { M.FormKey(i), NS(name) or L["Forma %d"]:format(i) }
	end
	return out
end

local function drawAuto()
	local me = M:CharData()
	for _, row in ipairs(autoRows) do row:Hide() end
	if not me then
		autoNote:SetText(L["Todavía no se sabe qué personaje eres; vuelve a abrir la ventana en unos segundos."])
		return
	end
	local auto = me.auto
	local values = setValues()
	local lines = {
		{ L["Al montar"], auto.mount, function(v) auto.mount = v end },
		{ L["Al descansar (posada o ciudad)"], auto.rest, function(v) auto.rest = v end },
	}
	for _, f in ipairs(forms()) do
		local key = f[1]
		lines[#lines + 1] = { f[2], auto.forms[key], function(v) auto.forms[key] = v end }
	end
	for i, line in ipairs(lines) do
		local row = autoRow(i)
		row.label:SetText(line[1])
		row.drop.values = values
		row.drop.current = line[2] or 0
		row.drop.text:SetText(valueText(values, line[2] or 0))
		local set = line[3]
		row.drop.onPick = function(value)
			set(value ~= 0 and value or nil)
			M:RefreshWindow()
		end
	end
	local note = L["Al bajar de la montura o dejar de descansar vuelves a llevar lo que tenías en esas casillas. En cada forma o actitud se pone su conjunto y se queda puesto."]
	if not M.db.auto then
		note = L["|cffff8800Los cambios automáticos están desactivados en las opciones (/rz).|r"] .. "\n\n" .. note
	end
	autoNote:ClearAllPoints()
	autoNote:SetPoint("TOPLEFT", 12, -12 - #lines * 30 - 10)
	autoNote:SetPoint("RIGHT", autoPane, "RIGHT", -12, 0)
	autoNote:SetText(note)
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

function M:RefreshWindow()
	if not win or not win:IsShown() then return end
	local sets = mode == "sets"
	setsPane:SetShown(sets)
	autoPane:SetShown(not sets)
	tabs.sets:SetEnabled(not sets)
	tabs.auto:SetEnabled(sets)
	if sets then
		drawList(M:GetSets())
		drawDetail()
	else
		drawAuto()
	end
end

local function createSetsPane()
	setsPane = CreateFrame("Frame", nil, body)
	setsPane:SetAllPoints()

	-- Lista de conjuntos
	local left = CreateFrame("Frame", nil, setsPane, "BackdropTemplate")
	left:SetPoint("TOPLEFT", 4, -4)
	left:SetPoint("BOTTOMLEFT", 4, 34)
	left:SetWidth(LIST_W)
	backdrop(left, 0.4)
	left:SetBackdropBorderColor(1, 1, 1, 0.08)
	if UI.MakeScroll then
		list = UI.MakeScroll(left)
	else
		list = CreateFrame("ScrollFrame", nil, left, "UIPanelScrollFrameTemplate")
		list.child = CreateFrame("Frame", nil, list)
		list:SetScrollChild(list.child)
	end
	list:SetPoint("TOPLEFT", 2, -2)
	list:SetPoint("BOTTOMRIGHT", -4, 2)
	list.child:SetSize(LIST_W - 8, 1)

	local new = panelButton(setsPane, L["Nuevo"], 106)
	new:SetPoint("BOTTOMLEFT", 4, 6)
	new:SetScript("OnClick", function()
		selectSet(nil)
		nameBox:SetFocus()
	end)
	equipButton = panelButton(setsPane, L["Ponérselo"], 110)
	equipButton:SetPoint("LEFT", new, "RIGHT", 4, 0)
	equipButton:SetScript("OnClick", function() if selected then M:EquipSet(selected) end end)

	-- Detalle
	local x = LIST_W + 18
	local label = setsPane:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	label:SetPoint("TOPLEFT", x, -10)
	label:SetText(L["Nombre"])

	nameBox = CreateFrame("EditBox", nil, setsPane, "BackdropTemplate")
	nameBox:SetPoint("TOPLEFT", x + 60, -6)
	nameBox:SetSize(220, 22)
	nameBox:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	nameBox:SetBackdropColor(0, 0, 0, 0.6)
	nameBox:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	nameBox:SetFontObject(GameFontHighlightSmall)
	nameBox:SetTextInsets(6, 6, 0, 0)
	nameBox:SetAutoFocus(false)
	nameBox:SetMaxLetters(16)
	nameBox:SetScript("OnEscapePressed", nameBox.ClearFocus)
	nameBox:SetScript("OnEnterPressed", nameBox.ClearFocus)

	-- Icono: el elegido y los disponibles
	local iconLabel = setsPane:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	iconLabel:SetPoint("TOPLEFT", x, -42)
	iconLabel:SetText(L["Icono"])

	iconPreview = CreateFrame("Frame", nil, setsPane)
	iconPreview:SetSize(36, 36)
	iconPreview:SetPoint("TOPLEFT", x, -60)
	local pbg = iconPreview:CreateTexture(nil, "BACKGROUND")
	pbg:SetPoint("TOPLEFT", -2, 2)
	pbg:SetPoint("BOTTOMRIGHT", 2, -2)
	pbg:SetColorTexture(0.2, 0.8, 1, 0.9)
	iconPreview.icon = iconPreview:CreateTexture(nil, "ARTWORK")
	iconPreview.icon:SetAllPoints()
	iconPreview.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	for i = 1, 20 do
		local b = CreateFrame("Button", nil, setsPane)
		b:SetSize(ICON, ICON)
		local col, line = (i - 1) % 10, math.floor((i - 1) / 10)
		b:SetPoint("TOPLEFT", x + 50 + col * (ICON + 3), -52 - line * (ICON + 3))
		b.icon = b:CreateTexture(nil, "ARTWORK")
		b.icon:SetAllPoints()
		b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		b.sel = b:CreateTexture(nil, "OVERLAY")
		b.sel:SetPoint("TOPLEFT", -2, 2)
		b.sel:SetPoint("BOTTOMRIGHT", 2, -2)
		b.sel:SetColorTexture(0.2, 0.8, 1, 0.35)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(1, 1, 1, 0.25)
		b:SetScript("OnClick", function(self)
			edit.icon = self.value
			drawIcons()
		end)
		iconButtons[i] = b
	end

	-- Casillas: marcadas = el conjunto las cambia
	local slotsLabel = setsPane:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	slotsLabel:SetPoint("TOPLEFT", x, -114)
	slotsLabel:SetText(L["Casillas que cambia el conjunto"])

	local perColumn = 10
	for i, s in ipairs(M.SLOTS) do
		local row = CreateFrame("Frame", nil, setsPane)
		row:SetSize(210, 22)
		local col, line = math.floor((i - 1) / perColumn), (i - 1) % perColumn
		row:SetPoint("TOPLEFT", x + col * 220, -134 - line * 23)
		row:EnableMouse(true)
		row.slot = s[1]
		row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
		row.check:SetSize(22, 22)
		row.check:SetPoint("LEFT", 0, 0)
		row.check:SetScript("OnClick", function(self)
			edit.ignore[row.slot] = (not self:GetChecked()) or nil
			drawSlots()
		end)
		row.icon = row:CreateTexture(nil, "ARTWORK")
		row.icon:SetSize(18, 18)
		row.icon:SetPoint("LEFT", row.check, "RIGHT", 2, 0)
		row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		row.text:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
		row.text:SetPoint("RIGHT", 0, 0)
		row.text:SetJustifyH("LEFT")
		row.text:SetWordWrap(false)
		row:SetScript("OnEnter", function(self)
			if not self.itemID then return end
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetItemByID(self.itemID)
			GameTooltip:Show()
		end)
		row:SetScript("OnLeave", GameTooltip_Hide)
		slotRows[i] = row
	end

	-- Acciones
	saveButton = panelButton(setsPane, "", 160)
	saveButton:SetPoint("TOPLEFT", x, -134 - perColumn * 23 - 8)
	saveButton:SetScript("OnClick", onSave)
	renameButton = panelButton(setsPane, L["Cambiar nombre e icono"], 160)
	renameButton:SetPoint("LEFT", saveButton, "RIGHT", 6, 0)
	renameButton:SetScript("OnClick", onRename)
	deleteButton = panelButton(setsPane, L["Borrar"], 90)
	deleteButton:SetPoint("LEFT", renameButton, "RIGHT", 6, 0)
	deleteButton:SetScript("OnClick", onDelete)

	statusText = setsPane:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	statusText:SetPoint("TOPLEFT", saveButton, "BOTTOMLEFT", 2, -8)
	statusText:SetPoint("RIGHT", setsPane, "RIGHT", -8, 0)
	statusText:SetJustifyH("LEFT")

	local hint = setsPane:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("BOTTOMLEFT", x, 10)
	hint:SetPoint("RIGHT", setsPane, "RIGHT", -8, 0)
	hint:SetJustifyH("LEFT")
	hint:SetText(L["Para cambiar una sola pieza: Alt + ratón sobre su casilla en la ficha del personaje (lista de Blizzard)."])
end

local function createAutoPane()
	autoPane = CreateFrame("Frame", nil, body)
	autoPane:SetAllPoints()
	autoNote = autoPane:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	autoNote:SetJustifyH("LEFT")
	autoNote:SetJustifyV("TOP")
	autoNote:SetWordWrap(true)
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorGear", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	backdrop(win, 0.94)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorGear")   -- se cierra con Esc

	local drag = CreateFrame("Frame", nil, win)
	drag:SetPoint("TOPLEFT")
	drag:SetPoint("TOPRIGHT", -30, 0)
	drag:SetHeight(30)
	drag:EnableMouse(true)
	drag:RegisterForDrag("LeftButton")
	drag:SetScript("OnDragStart", function() win:StartMoving() end)
	drag:SetScript("OnDragStop", function()
		win:StopMovingOrSizing()
		win:SetUserPlaced(false)
		local point, _, relPoint, px, py = win:GetPoint()
		M.db.winPoint = { point, relPoint, px, py }
	end)

	local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -9)
	title:SetText("|cff33ccffRheizor|r · " .. L["Equipamiento"])

	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() win:Hide() end)

	-- Pestañas
	tabs = {}
	local function tab(key, text, anchor)
		local b = panelButton(win, text, 120)
		b:SetScript("OnClick", function()
			mode = key
			M:RefreshWindow()
		end)
		if anchor then b:SetPoint("LEFT", anchor, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 12, -36) end
		tabs[key] = b
		return b
	end
	local t1 = tab("sets", L["Conjuntos"])
	tab("auto", L["Automático"], t1)

	body = CreateFrame("Frame", nil, win, "BackdropTemplate")
	body:SetPoint("TOPLEFT", 10, -64)
	body:SetPoint("BOTTOMRIGHT", -10, 10)
	backdrop(body, 0.6)
	body:SetBackdropBorderColor(1, 1, 1, 0.1)

	createSetsPane()
	createAutoPane()

	win:SetScript("OnShow", function()
		-- Al abrir, el conjunto puesto (o el primero)
		if not selected then
			local s = M:EquippedSet() or M:GetSets()[1]
			if s then
				selectSet(s.id)
				return
			end
			selectSet(nil)
			return
		end
		M:RefreshWindow()
	end)
	win:SetScript("OnHide", function()
		armed = false
		if nameBox then nameBox:ClearFocus() end
	end)

	local p = M.db.winPoint
	if p then win:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else win:SetPoint("CENTER") end
end

function M:ToggleWindow()
	if not M.CanUseSets() then
		R:Print(L["Tu versión del juego no tiene conjuntos de equipo."])
		return
	end
	if not win then createWindow() end
	win:SetShown(not win:IsShown())
end
