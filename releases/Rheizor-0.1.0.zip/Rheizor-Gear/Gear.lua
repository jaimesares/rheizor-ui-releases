-- Equipamiento: conjuntos de equipo al estilo de ItemRack.
--
-- Los conjuntos son los del propio juego (C_EquipmentSet): se guardan en el
-- servidor con cada personaje, el juego busca las piezas en bolsas y banco y
-- las cambia en el orden correcto, y son los mismos que se ven en la ficha
-- del personaje (pestaña de conjuntos de equipo de Blizzard). Este addon
-- añade lo que le falta a esa ventana:
--   · Un botón en pantalla con el conjunto puesto; clic: elegir otro.
--   · /rzgear <nombre>, /rz equipo <nombre> y teclas (Teclado > AddOns).
--   · En combate el cambio se deja para después (las armas, al momento).
--   · Cambios automáticos al montar, al descansar y por forma o actitud.
--   · En qué conjuntos está cada objeto, en su tooltip.
-- La ventana para crear y editar conjuntos está en Window.lua y la barra de
-- objetos equipados en GearBar.lua.
--
-- RheizorGearDB (compartido por la cuenta, aparte de RheizorDB) guarda por
-- personaje los cambios automáticos y lo que llevaba antes de cada uno.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret
local ES = C_EquipmentSet

-- Nombres para Teclado > AddOns (ver Bindings.xml)
BINDING_HEADER_RHEIZORGEAR = L["Rheizor · Equipamiento"]
BINDING_NAME_RHEIZORGEAR_WINDOW = L["Abrir la ventana de equipamiento"]
for i = 1, 10 do
	_G["BINDING_NAME_RHEIZORGEAR_SET" .. i] = L["Ponerse el conjunto %d"]:format(i)
end

local M = R:RegisterModule("gear", {
	title = "Conjuntos",
	group = "Equipamiento",
	defaults = {
		button = true,
		showName = true,
		locked = true,
		scale = 1,
		combatWeapons = true,
		announce = true,
		tooltip = true,
		auto = true,
	},
	options = {
		{ type = "header", text = "Conjuntos de equipo" },
		{ type = "button", name = "Ventana de equipamiento", text = "Abrir",
		  desc = "Crear, guardar, renombrar y borrar conjuntos, elegir qué casillas cambia cada uno y los cambios automáticos. También con /rzgear o /rz equipo.",
		  func = function(mod) mod:ToggleWindow() end },
		{ type = "toggle", key = "button", name = "Botón de conjuntos en pantalla",
		  desc = "Muestra el icono del conjunto que llevas puesto. Clic: elegir otro conjunto. Clic derecho: abrir la ventana de equipamiento." },
		{ type = "toggle", key = "showName", name = "Nombre del conjunto bajo el botón" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueado, aparece un marco encima del botón para arrastrarlo." },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 2, step = 0.05 },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

		{ type = "header", text = "Combate" },
		{ type = "toggle", key = "combatWeapons", name = "Cambiar las armas al momento en combate",
		  desc = "En combate el juego solo deja cambiar las armas. Activado, las armas del conjunto se ponen ya y el resto al salir de combate; desactivado, se cambia todo al salir de combate." },

		{ type = "header", text = "Avisos y tooltip" },
		{ type = "toggle", key = "announce", name = "Avisar en el chat al cambiar de conjunto" },
		{ type = "toggle", key = "tooltip", name = "Conjuntos en el tooltip de los objetos",
		  desc = "Añade «En conjuntos: …» al tooltip de las piezas que forman parte de algún conjunto." },

		{ type = "header", text = "Cambios automáticos" },
		{ type = "toggle", key = "auto", name = "Cambios automáticos de conjunto",
		  desc = "Qué conjunto ponerte al montar, al descansar (posada o ciudad) o en cada forma o actitud se elige en la ventana de equipamiento, pestaña Automático; cada personaje tiene los suyos." },
	},
	unsupported = {
		"Cambiar de conjunto al entrar o salir de combate: en combate el juego solo deja cambiar las armas, así que el resto del conjunto siempre espera a que acabe el combate.",
		"Más de 10 conjuntos por personaje: es el límite del juego.",
	},
})

local db      -- opciones del módulo (perfil)
local store   -- RheizorGearDB
local me      -- datos de este personaje en RheizorGearDB

----------------------------------------------------------------------
-- Casillas de equipo (en el orden de la ficha del personaje)
----------------------------------------------------------------------

-- { casilla, nombre, nombre interno para GetInventorySlotInfo }
M.SLOTS = {
	{ 1, "Cabeza", "HeadSlot" },
	{ 2, "Cuello", "NeckSlot" },
	{ 3, "Hombros", "ShoulderSlot" },
	{ 15, "Espalda", "BackSlot" },
	{ 5, "Pecho", "ChestSlot" },
	{ 4, "Camisa", "ShirtSlot" },
	{ 19, "Tabardo", "TabardSlot" },
	{ 9, "Muñecas", "WristSlot" },
	{ 10, "Manos", "HandsSlot" },
	{ 6, "Cintura", "WaistSlot" },
	{ 7, "Piernas", "LegsSlot" },
	{ 8, "Pies", "FeetSlot" },
	{ 11, "Dedo 1", "Finger0Slot" },
	{ 12, "Dedo 2", "Finger1Slot" },
	{ 13, "Abalorio 1", "Trinket0Slot" },
	{ 14, "Abalorio 2", "Trinket1Slot" },
	{ 16, "Mano principal", "MainHandSlot" },
	{ 17, "Mano secundaria", "SecondaryHandSlot" },
	{ 18, "A distancia", "RangedSlot" },
}

local slotInfo = {}
for _, s in ipairs(M.SLOTS) do slotInfo[s[1]] = s end

function M.SlotName(slot)
	local s = slotInfo[slot]
	return s and L[s[2]] or tostring(slot)
end

-- Textura de la casilla vacía (la silueta gris de la ficha)
function M.SlotTexture(slot)
	local s = slotInfo[slot]
	if s and GetInventorySlotInfo then
		local ok, _, texture = pcall(GetInventorySlotInfo, s[3])
		if ok and texture then return texture end
	end
	return "Interface\\PaperDoll\\UI-Backpack-EmptySlot"
end

-- Las únicas casillas que el juego deja cambiar en combate
M.COMBAT_SLOTS = INVSLOTS_EQUIPABLE_IN_COMBAT or { [16] = true, [17] = true, [18] = true }

M.QUESTION_ICON = 134400   -- Interface\Icons\INV_Misc_QuestionMark

----------------------------------------------------------------------
-- Conjuntos (C_EquipmentSet)
----------------------------------------------------------------------

function M.CanUseSets()
	return ES ~= nil and ES.GetEquipmentSetIDs ~= nil and ES.UseEquipmentSet ~= nil
end

-- Conjuntos del personaje en orden de creación: ese es el número que usan
-- las teclas y /rzgear 3 (no cambia al renombrar)
function M:GetSets()
	local list = {}
	if not M.CanUseSets() then return list end
	local ok, ids = pcall(ES.GetEquipmentSetIDs)
	if not ok or type(ids) ~= "table" then return list end
	for _, id in ipairs(ids) do
		id = NS(id)
		if type(id) == "number" then
			local name, icon, _, equipped, numItems, _, _, numLost = ES.GetEquipmentSetInfo(id)
			name = NS(name)
			if name then
				list[#list + 1] = {
					id = id,
					name = name,
					icon = NS(icon) or M.QUESTION_ICON,
					equipped = NS(equipped) and true or false,
					items = NS(numItems) or 0,
					lost = NS(numLost) or 0,
				}
			end
		end
	end
	table.sort(list, function(a, b) return a.id < b.id end)
	return list
end

function M:SetByID(id)
	if type(id) ~= "number" then return end
	for i, s in ipairs(self:GetSets()) do
		if s.id == id then
			s.index = i
			return s
		end
	end
end

-- El conjunto que se lleva puesto ahora (el primero que coincida)
function M:EquippedSet()
	for _, s in ipairs(self:GetSets()) do
		if s.equipped then return s end
	end
end

-- Por número (orden de la lista) o por nombre, sin distinguir mayúsculas;
-- si no hay uno exacto, el primero que contenga el texto
function M:FindSet(text)
	text = strtrim(text or "")
	if text == "" then return end
	local sets = self:GetSets()
	local n = tonumber(text)
	if n then return sets[n] end
	local low = text:lower()
	for _, s in ipairs(sets) do
		if s.name:lower() == low then return s end
	end
	for _, s in ipairs(sets) do
		if s.name:lower():find(low, 1, true) then return s end
	end
end

-- Casillas que un conjunto no toca: { [casilla] = true }
function M:IgnoredSlots(id)
	local out = {}
	if not id or not ES.GetIgnoredSlots then return out end
	local ok, t = pcall(ES.GetIgnoredSlots, id)
	if ok and type(t) == "table" then
		for slot, ignored in pairs(t) do
			if NS(ignored) then out[slot] = true end
		end
	end
	return out
end

-- Guarda lo que llevas puesto en un conjunto (uno nuevo si id es nil).
-- ignore: { [casilla] = true } con las casillas que el conjunto no cambia.
-- Devuelve el id del conjunto, o nil y el motivo.
function M:SaveSet(id, name, icon, ignore)
	if not M.CanUseSets() then return nil, L["Tu versión del juego no tiene conjuntos de equipo."] end
	name = strtrim(name or "")
	if name == "" then return nil, L["Escribe un nombre para el conjunto."] end
	local other = NS(ES.GetEquipmentSetID(name))
	if other and other ~= id then return nil, L["Ya tienes un conjunto con ese nombre."] end
	if not id and (NS(ES.GetNumEquipmentSets()) or 0) >= (MAX_EQUIPMENT_SETS_PER_PLAYER or 10) then
		return nil, L["Ya tienes el máximo de conjuntos que permite el juego (%d)."]:format(MAX_EQUIPMENT_SETS_PER_PLAYER or 10)
	end

	-- Las casillas ignoradas se marcan antes de guardar (como hace la ficha
	-- del personaje) y se limpian después para no afectar a otros guardados
	ES.ClearIgnoredSlotsForSave()
	for slot in pairs(ignore or {}) do ES.IgnoreSlotForSave(slot) end
	if id then
		ES.SaveEquipmentSet(id, icon)
		local current = NS(ES.GetEquipmentSetInfo(id))
		if current ~= name then ES.ModifyEquipmentSet(id, name, icon) end
	else
		ES.CreateEquipmentSet(name, icon)
		id = NS(ES.GetEquipmentSetID(name))
	end
	ES.ClearIgnoredSlotsForSave()
	return id
end

-- Solo el nombre y el icono, sin volver a guardar las piezas
function M:RenameSet(id, name, icon)
	name = strtrim(name or "")
	if name == "" then return nil, L["Escribe un nombre para el conjunto."] end
	local other = NS(ES.GetEquipmentSetID(name))
	if other and other ~= id then return nil, L["Ya tienes un conjunto con ese nombre."] end
	ES.ModifyEquipmentSet(id, name, icon)
	return id
end

function M:DeleteSet(id)
	if not id then return end
	ES.DeleteEquipmentSet(id)
	-- Los cambios automáticos que usaban este conjunto se quedan sin él
	if me then
		local auto = me.auto
		if auto.mount == id then auto.mount = nil end
		if auto.rest == id then auto.rest = nil end
		for k, v in pairs(auto.forms) do
			if v == id then auto.forms[k] = nil end
		end
	end
end

----------------------------------------------------------------------
-- Cambiar piezas sueltas
----------------------------------------------------------------------

local PLAYER = ITEM_INVENTORY_LOCATION_PLAYER or 0x00100000
local BAGS = ITEM_INVENTORY_LOCATION_BAGS or 0x00200000
local BANK = ITEM_INVENTORY_LOCATION_BANK or 0x00400000
local BAG_SHIFT = ITEM_INVENTORY_BAG_BIT_OFFSET or 8

-- Dónde está una pieza según los números de ubicación que dan
-- GetInventoryItemsForSlot y C_EquipmentSet.GetItemLocations:
-- { player, bank, bags, bag, slot }. En los conjuntos, -1 (falta),
-- 0 (casilla vacía) y 1 (ignorada) no son ubicaciones.
function M.DecodeLocation(loc)
	loc = NS(loc)
	if type(loc) ~= "number" or loc < 2 then return end
	if EquipmentManager_GetLocationData then
		local ok, d = pcall(EquipmentManager_GetLocationData, loc)
		if ok and type(d) == "table" and d.slot then
			return { player = d.isPlayer, bank = d.isBank, bags = d.isBags, bag = d.bag, slot = d.slot }
		end
	end
	-- Lo mismo que hace Blizzard (Shared\EquipmentManager.lua)
	local d = {
		player = bit.band(loc, PLAYER) ~= 0,
		bank = bit.band(loc, BANK) ~= 0,
		bags = bit.band(loc, BAGS) ~= 0,
	}
	local slot = loc
	if d.player then
		slot = slot - PLAYER
	elseif d.bank then
		slot = slot - BANK
	end
	if d.bags then
		slot = slot - BAGS
		d.bag = bit.rshift(slot, BAG_SHIFT)
		slot = slot - bit.lshift(d.bag, BAG_SHIFT)
		if d.bank then d.bag = d.bag + (ITEM_INVENTORY_BANK_BAG_OFFSET or 0) end
	end
	d.slot = slot
	return d
end

-- Pone en la casilla invSlot la pieza que está en loc (una bolsa u otra
-- casilla, p. ej. el otro abalorio). Igual que la lista de piezas de la ficha
-- del personaje: cogerla y soltarla en la casilla; lo que había vuelve a su
-- sitio. true si se ha intentado.
function M.EquipLocation(loc, invSlot)
	local d = M.DecodeLocation(loc)
	if not d or d.bank then return false end
	if IsInventoryItemLocked(invSlot) then return false end
	ClearCursor()
	if d.bags then
		C_Container.PickupContainerItem(d.bag, d.slot)
	elseif d.player then
		if d.slot == invSlot then return false end
		PickupInventoryItem(d.slot)
	else
		return false
	end
	if not CursorHasItem() then return false end
	if C_PaperDollInfo and C_PaperDollInfo.CursorCanGoInSlot and not C_PaperDollInfo.CursorCanGoInSlot(invSlot) then
		ClearCursor()
		return false
	end
	PickupInventoryItem(invSlot)
	return true
end

-- Pone una pieza por su enlace (lo que se guarda para deshacer un cambio
-- automático). El juego la busca en las bolsas.
function M.EquipLink(link, invSlot)
	if not link then return end
	if NS(GetInventoryItemLink("player", invSlot)) == link then return end
	if IsInventoryItemLocked(invSlot) then return end
	local equip = (C_Item and C_Item.EquipItemByName) or EquipItemByName
	if equip then pcall(equip, link, invSlot) end
end

----------------------------------------------------------------------
-- Poner conjuntos (y lo que queda pendiente para después del combate)
----------------------------------------------------------------------

local pendingSet          -- id del conjunto que se pondrá al salir de combate
local pendingItems = {}   -- [casilla] = enlace, para después del combate
local announceID          -- conjunto pedido por Rheizor (para avisar en el chat)
local retries = 0

-- Pone piezas sueltas { [casilla] = enlace }. En combate solo las armas (si
-- weaponsNow); el resto espera. Devuelve true si algo ha quedado pendiente.
function M.ApplyItems(items, weaponsNow)
	local slots = {}
	for slot in pairs(items) do slots[#slots + 1] = slot end
	table.sort(slots)   -- mano principal antes que la secundaria
	local later = false
	for _, slot in ipairs(slots) do
		if InCombatLockdown() and not (weaponsNow and M.COMBAT_SLOTS[slot]) then
			pendingItems[slot] = items[slot]
			later = true
		else
			pendingItems[slot] = nil
			M.EquipLink(items[slot], slot)
		end
	end
	if later then M:UpdateButton() end
	return later
end

-- Deja una pieza para después del combate (la lista de piezas de la barra)
function M.QueueItem(slot, link)
	if not link then return end
	pendingItems[slot] = link
	M:UpdateButton()
end

function M:HasPending()
	return pendingSet ~= nil or next(pendingItems) ~= nil
end

-- En combate: solo las armas del conjunto, ya
local function equipSetWeapons(id)
	if not ES.GetItemLocations then return end
	local ok, locs = pcall(ES.GetItemLocations, id)
	if not ok or type(locs) ~= "table" then return end
	for _, slot in ipairs({ 16, 17, 18 }) do
		local loc = NS(locs[slot])
		if loc and loc > 1 then M.EquipLocation(loc, slot) end
	end
end

-- set: el conjunto (tabla de GetSets) o su id. quiet: sin mensajes (los
-- cambios automáticos avisan igualmente al terminar si "announce")
function M:EquipSet(set, quiet)
	if type(set) == "number" then set = self:SetByID(set) end
	if not set or not M.CanUseSets() then return end

	if InCombatLockdown() then
		pendingSet = set.id
		-- Pedir un conjunto sustituye a lo que hubiera pendiente
		wipe(pendingItems)
		if db.combatWeapons then equipSetWeapons(set.id) end
		if not quiet then
			R:Print(L["En combate: %s se pondrá al salir de combate."]:format("|cffffd100" .. set.name .. "|r")
				.. (db.combatWeapons and (" " .. L["Las armas ya se han cambiado."]) or ""))
		end
		self:UpdateButton()
		return
	end

	pendingSet = nil
	wipe(pendingItems)
	-- Con piezas bloqueadas (cambiando, lanzando un hechizo…) el juego no
	-- puede; se reintenta un par de veces antes de rendirse
	local ok, locked = pcall(ES.EquipmentSetContainsLockedItems, set.id)
	local casting = NS((UnitCastingInfo("player"))) or NS((UnitChannelInfo("player")))
	if (ok and NS(locked)) or casting then
		if retries < 4 then
			retries = retries + 1
			C_Timer.After(0.5, function() M:EquipSet(set.id, quiet) end)
		else
			retries = 0
			if not quiet then R:Print(L["No se puede cambiar de equipo ahora (piezas bloqueadas o lanzando un hechizo)."]) end
		end
		return
	end
	retries = 0

	announceID = set.id
	if me then me.last = set.id end
	local used, err = pcall(ES.UseEquipmentSet, set.id)
	if not used then R:Print(tostring(err)) end
	self:UpdateButton()
end

-- Al salir de combate: primero el conjunto pendiente, luego las piezas
local function flushPending()
	if InCombatLockdown() then return end
	if pendingSet then
		local id = pendingSet
		pendingSet = nil
		M:EquipSet(id, true)
	end
	if next(pendingItems) then
		local items = {}
		for slot, link in pairs(pendingItems) do items[slot] = link end
		wipe(pendingItems)
		C_Timer.After(1, function() M.ApplyItems(items, true) end)
	end
	M:UpdateButton()
end

----------------------------------------------------------------------
-- Cambios automáticos (montura, descanso, forma o actitud)
----------------------------------------------------------------------

local state = {}   -- último estado visto: mounted, resting, form

-- Booleano, o nil si el juego lo da en secreto (entonces no se decide nada)
local function flag(value)
	if issecretvalue and issecretvalue(value) then return nil end
	return value and true or false
end

-- Las formas se guardan por el hechizo que las da (el número de forma cambia
-- al aprender otras); 0 = sin forma
function M.FormKey(index)
	if not index or index == 0 then return 0 end
	local _, _, _, spellID = GetShapeshiftFormInfo(index)
	return NS(spellID) or index
end

local function currentForm()
	if not GetShapeshiftForm then return 0 end
	return NS(GetShapeshiftForm()) or state.form or 0
end

-- Lo que se lleva en las casillas que cambia un conjunto (para devolverlo)
local function snapshotFor(id)
	local ignored = M:IgnoredSlots(id)
	local items = {}
	for _, s in ipairs(M.SLOTS) do
		local slot = s[1]
		if not ignored[slot] then
			local link = NS(GetInventoryItemLink("player", slot))
			if link then items[slot] = link end
		end
	end
	return items
end

local function autoEnter(kind, id)
	if not M:SetByID(id) then return end
	-- Si ya había algo guardado (p. ej. /reload montado) se conserva lo de antes
	if not me.saved[kind] then me.saved[kind] = snapshotFor(id) end
	M:EquipSet(id, true)
end

local function autoLeave(kind)
	local items = me.saved[kind]
	me.saved[kind] = nil
	if items then M.ApplyItems(items, db.combatWeapons) end
end

-- init: solo apunta el estado actual (al entrar no se cambia nada)
function M:CheckAuto(init)
	if not me then return end
	local mounted = flag(IsMounted())
	local resting = flag(IsResting())
	local form = currentForm()
	if init or not db.auto then
		state.mounted, state.resting, state.form = mounted, resting, form
		-- Lo guardado de una sesión anterior solo sirve si se sigue montado o
		-- descansando (p. ej. tras /reload); si no, ya no se devolvería nunca
		if mounted == false then me.saved.mount = nil end
		if resting == false then me.saved.rest = nil end
		return
	end
	local auto = me.auto

	if mounted ~= nil and mounted ~= state.mounted then
		state.mounted = mounted
		if mounted then
			if auto.mount then autoEnter("mount", auto.mount) end
		else
			autoLeave("mount")
		end
	end

	if resting ~= nil and resting ~= state.resting then
		state.resting = resting
		if resting then
			if auto.rest then autoEnter("rest", auto.rest) end
		else
			autoLeave("rest")
		end
	end

	if form ~= state.form then
		state.form = form
		local id = auto.forms[M.FormKey(form)]
		if id then M:EquipSet(id, true) end
	end
end

-- Datos de este personaje (cambios automáticos)
function M:CharData()
	return me
end

----------------------------------------------------------------------
-- Tooltip de los objetos: "En conjuntos: A, B"
----------------------------------------------------------------------

local itemSets, itemSetsDirty = {}, true

local function rebuildItemSets()
	wipe(itemSets)
	itemSetsDirty = false
	if not ES.GetItemIDs then return end
	for _, s in ipairs(M:GetSets()) do
		local ok, ids = pcall(ES.GetItemIDs, s.id)
		if ok and type(ids) == "table" then
			local seen = {}
			for _, itemID in pairs(ids) do
				itemID = NS(itemID)
				-- 0 y 1 marcan casilla vacía o ignorada, no objetos
				if type(itemID) == "number" and itemID > 1 and not seen[itemID] then
					seen[itemID] = true
					local list = itemSets[itemID] or {}
					itemSets[itemID] = list
					list[#list + 1] = s.name
				end
			end
		end
	end
end

local function addSetsLine(tooltip, id)
	-- El gancho del tooltip no se puede quitar: apagado en Rheizor, no hace nada
	if not R:IsModuleRunning(M) or not db.tooltip or not tooltip.AddLine then return end
	if itemSetsDirty then rebuildItemSets() end
	local list = itemSets[id]
	if not list then return end
	tooltip:AddLine(L["En conjuntos: %s"]:format(table.concat(list, ", ")), 0.2, 0.8, 1, true)
	-- Sin :Show(): con TooltipDataProcessor Blizzard lo muestra justo después
end

local function hookTooltips()
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
			if not db then return end
			local id = data and NS(data.id)
			if type(id) == "number" then addSetsLine(tooltip, id) end
		end)
	end
end

----------------------------------------------------------------------
-- Botón en pantalla con el conjunto puesto
----------------------------------------------------------------------

local UI = R.UI or {}
local WHITE = "Interface\\Buttons\\WHITE8X8"
local button

local function buttonTooltip(self)
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	local set = M:EquippedSet()
	GameTooltip:SetText(set and set.name or L["Sin conjunto"], 1, 1, 1)
	if M:HasPending() then
		GameTooltip:AddLine(L["Hay un cambio esperando a que acabe el combate."], 1, 0.82, 0, true)
	end
	GameTooltip:AddLine(" ")
	GameTooltip:AddLine(L["|cff33ccffClic:|r elegir conjunto"], 1, 1, 1)
	GameTooltip:AddLine(L["|cff33ccffClic derecho:|r ventana de equipamiento"], 1, 1, 1)
	GameTooltip:Show()
end

-- Menú con los conjuntos (la lista desplegable del gestor de Rheizor)
function M:OpenSetMenu(owner)
	local values, current = {}, nil
	for i, s in ipairs(self:GetSets()) do
		local text = string.format("|T%s:16:16:0:0|t %d. %s", tostring(s.icon), i, s.name)
		if s.lost > 0 then text = text .. " |cffff5555" .. L["(faltan %d)"]:format(s.lost) .. "|r" end
		values[#values + 1] = { s.id, text }
		if s.equipped and not current then current = s.id end
	end
	values[#values + 1] = { "window", "|cff888888" .. L["Abrir la ventana de equipamiento"] .. "|r" }
	local function pick(value)
		if value == "window" then
			M:ToggleWindow()
		else
			M:EquipSet(value)
		end
	end
	if UI.OpenPopup then
		UI.OpenPopup(owner, values, current, pick)
	else
		self:ToggleWindow()
	end
end

local function createButton()
	button = CreateFrame("Button", "RheizorGearSetButton", UIParent)
	button:SetSize(36, 36)
	button:SetFrameStrata("MEDIUM")
	button:RegisterForClicks("LeftButtonUp", "RightButtonUp")

	local bg = button:CreateTexture(nil, "BACKGROUND")
	bg:SetPoint("TOPLEFT", -2, 2)
	bg:SetPoint("BOTTOMRIGHT", 2, -2)
	bg:SetColorTexture(0, 0, 0, 0.8)

	button.icon = button:CreateTexture(nil, "ARTWORK")
	button.icon:SetAllPoints()
	button.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)

	button.border = CreateFrame("Frame", nil, button, "BackdropTemplate")
	button.border:SetPoint("TOPLEFT", -2, 2)
	button.border:SetPoint("BOTTOMRIGHT", 2, -2)
	button.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	button.border:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)

	local hl = button:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.18)

	-- "..." si hay un cambio esperando al final del combate
	button.wait = button:CreateFontString(nil, "OVERLAY")
	button.wait:SetFont(STANDARD_TEXT_FONT, 16, "OUTLINE")
	button.wait:SetPoint("CENTER")
	button.wait:SetTextColor(1, 0.82, 0)

	button.label = button:CreateFontString(nil, "OVERLAY")
	button.label:SetFont(STANDARD_TEXT_FONT, 10, "OUTLINE")
	button.label:SetPoint("TOP", button, "BOTTOM", 0, -4)
	button.label:SetWidth(110)
	button.label:SetWordWrap(false)

	button:SetScript("OnClick", function(self, which)
		if which == "RightButton" then
			M:ToggleWindow()
		else
			GameTooltip:Hide()
			M:OpenSetMenu(self)
		end
	end)
	button:SetScript("OnEnter", buttonTooltip)
	button:SetScript("OnLeave", GameTooltip_Hide)

	button.mover = R:CreateMover(button, "Conjunto de equipo", db, "point", { "CENTER", "CENTER", -300, -200 })
end

function M:UpdateButton()
	if button then
		local set = self:EquippedSet()
		if set then
			button.icon:SetTexture(set.icon)
			button.icon:SetDesaturated(false)
			button.label:SetText(db.showName and set.name or "")
			button.label:SetTextColor(1, 1, 1)
		else
			button.icon:SetTexture(M.QUESTION_ICON)
			button.icon:SetDesaturated(true)
			button.label:SetText(db.showName and L["Sin conjunto"] or "")
			button.label:SetTextColor(0.6, 0.6, 0.6)
		end
		button.wait:SetText(self:HasPending() and "..." or "")
	end
	if M.RefreshWindow then M:RefreshWindow() end
end

function M:ApplyButton()
	-- Sin conjuntos en el juego el botón no tendría nada que elegir
	if not M.CanUseSets() then return end
	if not button then createButton() end
	button:SetScale(db.scale)
	button.mover:Place()
	button.mover:SetShown(not db.locked)
	button:SetShown(db.button and true or false)
	self:UpdateButton()
end

function M:ResetPosition()
	db.point = nil
	if button then button.mover:Place() end
end

----------------------------------------------------------------------
-- Comandos: /rzgear y /rz equipo
----------------------------------------------------------------------

local function printHelp()
	R:Print(L["/rzgear - abrir la ventana de equipamiento"])
	R:Print(L["/rzgear <nombre o número> - ponerse ese conjunto"])
	R:Print(L["/rzgear guardar <nombre> - guardar lo que llevas en ese conjunto (lo crea si no existe)"])
	R:Print(L["También con /rz equipo …"])
end

function M:Command(msg)
	msg = strtrim(msg or "")
	local word, rest = msg:match("^(%S+)%s*(.-)$")
	word = word and word:lower() or ""
	if msg == "" then
		self:ToggleWindow()
	elseif word == "ayuda" or word == "help" then
		printHelp()
	elseif word == "guardar" or word == "save" then
		local set = self:FindSet(rest)
		if set and set.name:lower() ~= rest:lower() then set = nil end
		local id, err
		if set then
			id, err = self:SaveSet(set.id, set.name, set.icon, self:IgnoredSlots(set.id))
		else
			local icon = NS(GetInventoryItemTexture("player", 5)) or NS(GetInventoryItemTexture("player", 16))
			id, err = self:SaveSet(nil, rest, icon, nil)
		end
		if id then
			R:Print(L["Conjunto guardado: %s"]:format("|cffffd100" .. strtrim(rest) .. "|r"))
		else
			R:Print(err or "?")
		end
	else
		local set = self:FindSet(msg)
		if set then
			self:EquipSet(set)
		else
			R:Print(L["No tienes ningún conjunto llamado «%s». Escribe /rzgear ayuda."]:format(msg))
		end
	end
end

SLASH_RHEIZORGEAR1 = "/rzgear"
SlashCmdList.RHEIZORGEAR = function(msg)
	R:RunModuleAction(M, function(m) m:Command(msg) end)
end

-- /rz equipo … : se añade al comando /rz del núcleo sin cambiarlo (lo que
-- no es "equipo" sigue yendo a su sitio)
do
	local original = SlashCmdList.RHEIZOR
	if original then
		SlashCmdList.RHEIZOR = function(msg)
			local word, rest = strtrim(msg or ""):match("^(%S+)%s*(.-)$")
			word = word and word:lower()
			if word == "equipo" or word == "gear" or word == "conjunto" or word == "set" then
				R:RunModuleAction(M, function(m) m:Command(rest) end)
			else
				original(msg)
			end
		end
	end
end

-- Teclas (Bindings.xml)
function RheizorGear_Toggle()
	R:RunModuleAction(M, function(m) m:ToggleWindow() end)
end

function RheizorGear_EquipIndex(index)
	R:RunModuleAction(M, function(m)
		local set = m:GetSets()[index]
		if set then
			m:EquipSet(set)
		else
			R:Print(L["No tienes conjunto número %d."]:format(index))
		end
	end)
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local throttled = {}
local function later(key, delay, fn)
	if throttled[key] then return end
	throttled[key] = true
	C_Timer.After(delay, function()
		throttled[key] = nil
		fn()
	end)
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, arg1, arg2)
	-- Apagado en Rheizor (sin recargar aún): no hace nada
	if not R:IsModuleRunning(M) then return end
	if event == "PLAYER_REGEN_ENABLED" then
		C_Timer.After(0.3, flushPending)
	elseif not me then
		return
	elseif event == "EQUIPMENT_SETS_CHANGED" then
		itemSetsDirty = true
		later("button", 0.2, function() M:UpdateButton() end)
	elseif event == "PLAYER_EQUIPMENT_CHANGED" then
		later("button", 0.3, function() M:UpdateButton() end)
	elseif event == "EQUIPMENT_SWAP_FINISHED" then
		local ok, id = NS(arg1), NS(arg2)
		if id and id == announceID then
			announceID = nil
			if db.announce then
				local set = M:SetByID(id)
				local name = "|cffffd100" .. (set and set.name or "?") .. "|r"
				if ok then
					R:Print(L["Conjunto puesto: %s"]:format(name))
				else
					R:Print(L["No se ha podido poner entero el conjunto %s (¿falta alguna pieza o tienes las bolsas llenas?)."]:format(name))
				end
			end
		end
		later("button", 0.2, function() M:UpdateButton() end)
	elseif event == "PLAYER_MOUNT_DISPLAY_CHANGED" or event == "PLAYER_UPDATE_RESTING"
		or event == "UPDATE_SHAPESHIFT_FORM" or event == "UPDATE_SHAPESHIFT_FORMS" or event == "UNIT_AURA" then
		later("auto", 0.3, function() M:CheckAuto() end)
	end
end)

local EVENTS = {
	"EQUIPMENT_SETS_CHANGED", "EQUIPMENT_SWAP_FINISHED", "PLAYER_EQUIPMENT_CHANGED", "PLAYER_REGEN_ENABLED",
	"PLAYER_MOUNT_DISPLAY_CHANGED", "PLAYER_UPDATE_RESTING", "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS",
}

-- Personaje: nombre completo y reino (en Forever hay apellidos: nunca solo
-- UnitName). Al entrar el nombre aún podría ser "Unknown": se reintenta.
local function charKey()
	local name = R.PlayerFullName()
	if not name or name == "?" or name == UNKNOWNOBJECT or name == "Unknown" then return end
	return name .. " - " .. (GetRealmName() or "?")
end

local function bindCharacter(tries)
	local key = charKey()
	if not key then
		if (tries or 0) < 10 then C_Timer.After(1, function() bindCharacter((tries or 0) + 1) end) end
		return
	end
	store.chars[key] = store.chars[key] or {}
	me = store.chars[key]
	me.name = R.PlayerFullName()
	me.realm = GetRealmName()
	me.auto = me.auto or {}
	me.auto.forms = me.auto.forms or {}
	me.saved = me.saved or {}
	M:CheckAuto(true)
	M:UpdateButton()
end

function M:OnEnable()
	db = self.db
	RheizorGearDB = type(RheizorGearDB) == "table" and RheizorGearDB or {}
	store = RheizorGearDB
	store.version = 1
	store.chars = store.chars or {}

	-- Lo pendiente de la barra de objetos se pone al salir de combate aunque
	-- no haya conjuntos
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	if not M.CanUseSets() then
		R:Print(L["Tu versión del juego no tiene conjuntos de equipo: Rheizor · Equipamiento solo puede usar la barra de objetos."])
		return
	end

	for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
	-- Por si montar no avisa con su propio evento en esta versión
	pcall(events.RegisterUnitEvent, events, "UNIT_AURA", "player")

	self:ApplyButton()
	hookTooltips()
	bindCharacter()
end

function M:OnOptionChanged(key)
	if key == "auto" then
		self:CheckAuto(true)
	elseif key ~= "tooltip" and key ~= "announce" and key ~= "combatWeapons" then
		self:ApplyButton()
	end
end
