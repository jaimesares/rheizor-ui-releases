-- Rheizor-ActionBars: barras de acción propias en lugar de las de Blizzard
-- (como Bartender o Dominos): posición, tamaño, filas, número de botones,
-- página, cuándo se ve cada barra, fundido al pasar el ratón y estilo.
--
-- No crea botones: usa los de Blizzard (ActionButton1-12,
-- MultiBarBottomLeftButton1-12…, StanceButton1-10, PetActionButton1-10) y
-- los mete en barras propias. Así las teclas de siempre (Esc > Opciones >
-- Atajos > Barra de acción 1 a 8), el modo de asignar teclas, las
-- reutilizaciones, el alcance y los resplandores siguen siendo los de
-- Blizzard, que ya sabe manejar los valores secretos de WoW Forever. Las
-- barras de Blizzard, ya vacías, se guardan en un marco oculto.
--
-- Para no ensuciar (taint) el código seguro de Blizzard:
--   · no se escribe ningún campo en sus botones ni en sus barras: lo propio
--     va en la tabla "side"
--   · solo métodos de marco (SetParent, SetPoint, SetAttribute…) fuera de
--     combate, y ganchos posteriores (hooksecurefunc, HookScript)
--   · en combate, la página y la visibilidad las cambian fragmentos
--     seguros (state drivers), nunca este código
--
-- Qué enseña cada botón: su atributo "actionpage" (acción = número del
-- botón + (página - 1) * 12). Blizzard muestra u oculta cada botón según
-- tenga acción, "showgrid" (huecos vacíos) y "statehidden" (botones de
-- más), y aquí se usan esos mismos atributos.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local floor, ceil, min, max = math.floor, math.ceil, math.min, math.max

local function clamp(v, lo, hi)
	v = tonumber(v) or lo
	if v < lo then return lo elseif v > hi then return hi end
	return v
end

----------------------------------------------------------------------
-- Barras: las 8 de Blizzard (con la página donde guardan sus acciones),
-- la de posturas y la de mascota
----------------------------------------------------------------------

local BARS = {
	{ key = "actionbar1", frame = "RheizorActionBar1", id = 1, title = "Barra 1 (principal)", main = true,
	  prefix = "ActionButton", blizz = "MainActionBar", page = 1, point = { "BOTTOM", "BOTTOM", 0, 14 } },
	{ key = "actionbar2", frame = "RheizorActionBar2", id = 2, title = "Barra 2",
	  prefix = "MultiBarBottomLeftButton", blizz = "MultiBarBottomLeft", page = 6, setting = "PROXY_SHOW_ACTIONBAR_2",
	  point = { "BOTTOM", "BOTTOM", 0, 58 } },
	{ key = "actionbar3", frame = "RheizorActionBar3", id = 3, title = "Barra 3",
	  prefix = "MultiBarBottomRightButton", blizz = "MultiBarBottomRight", page = 5, setting = "PROXY_SHOW_ACTIONBAR_3",
	  point = { "BOTTOM", "BOTTOM", 0, 102 } },
	{ key = "actionbar4", frame = "RheizorActionBar4", id = 4, title = "Barra 4", vertical = true,
	  prefix = "MultiBarRightButton", blizz = "MultiBarRight", page = 3, setting = "PROXY_SHOW_ACTIONBAR_4",
	  point = { "RIGHT", "RIGHT", -4, 0 } },
	{ key = "actionbar5", frame = "RheizorActionBar5", id = 5, title = "Barra 5", vertical = true,
	  prefix = "MultiBarLeftButton", blizz = "MultiBarLeft", page = 4, setting = "PROXY_SHOW_ACTIONBAR_5",
	  point = { "RIGHT", "RIGHT", -48, 0 } },
	{ key = "actionbar6", frame = "RheizorActionBar6", id = 6, title = "Barra 6",
	  prefix = "MultiBar5Button", blizz = "MultiBar5", page = 13, setting = "PROXY_SHOW_ACTIONBAR_6",
	  point = { "BOTTOM", "BOTTOM", 0, 146 } },
	{ key = "actionbar7", frame = "RheizorActionBar7", id = 7, title = "Barra 7",
	  prefix = "MultiBar6Button", blizz = "MultiBar6", page = 14, setting = "PROXY_SHOW_ACTIONBAR_7",
	  point = { "BOTTOM", "BOTTOM", 0, 190 } },
	{ key = "actionbar8", frame = "RheizorActionBar8", id = 8, title = "Barra 8",
	  prefix = "MultiBar7Button", blizz = "MultiBar7", page = 15, setting = "PROXY_SHOW_ACTIONBAR_8",
	  point = { "BOTTOM", "BOTTOM", 0, 234 } },
	{ key = "actionbarStance", frame = "RheizorStanceBar", title = "Barra de posturas/formas", kind = "stance", count = 10,
	  prefix = "StanceButton", blizz = "StanceBar", point = { "BOTTOMRIGHT", "BOTTOM", -258, 146 } },
	{ key = "actionbarPet", frame = "RheizorPetBar", title = "Barra de mascota", kind = "pet", count = 10,
	  prefix = "PetActionButton", blizz = "PetActionBar", point = { "BOTTOMLEFT", "BOTTOM", 258, 146 } },
}

----------------------------------------------------------------------
-- Listas de valores
----------------------------------------------------------------------

local ORIENT = { { "h", "Horizontal" }, { "v", "Vertical" } }
local GROW_H = { { "right", "De izquierda a derecha" }, { "left", "De derecha a izquierda" } }
local GROW_V = { { "up", "De abajo arriba" }, { "down", "De arriba abajo" } }
local FLYOUT = {
	{ "auto", "Automática" }, { "UP", "Hacia arriba" }, { "DOWN", "Hacia abajo" },
	{ "LEFT", "Hacia la izquierda" }, { "RIGHT", "Hacia la derecha" },
}
local SHOW = {
	{ "always", "Siempre" },
	{ "combat", "Solo en combate" },
	{ "nocombat", "Solo fuera de combate" },
	{ "target", "Con objetivo" },
	{ "group", "En grupo o en banda" },
	{ "custom", "Condiciones propias" },
}
-- Página de cada barra de Blizzard (la 1 cambia con formas y sigilo: 7 a 10).
-- Como texto: el panel de opciones de Blizzard no admite números en las listas
local PAGES = {
	{ "1", "1 · barra 1" }, { "2", "2 · barra 1, página 2" }, { "3", "3 · barra 4" }, { "4", "4 · barra 5" },
	{ "5", "5 · barra 3" }, { "6", "6 · barra 2" },
	{ "7", "7 · barra 1 en forma o sigilo 1" }, { "8", "8 · barra 1 en forma 2" },
	{ "9", "9 · barra 1 en forma 3" }, { "10", "10 · barra 1 en forma 4" },
	{ "13", "13 · barra 6" }, { "14", "14 · barra 7" }, { "15", "15 · barra 8" },
}
local STYLES = { { "blizzard", "Blizzard" }, { "clean", "Limpio: icono cuadrado y borde fino" } }
local FINISH = {
	{ "none", "Ninguno" },
	{ "pulse", "Pulso: el icono crece y se desvanece" },
	{ "flash", "Destello" },
	{ "both", "Pulso y destello" },
}

-- 5 = el tamaño que trae el juego
local function fmtGame(v)
	if v < 6 then return L["Del juego"] end
	return R.fmt.int(v)
end

----------------------------------------------------------------------
-- Módulo general
----------------------------------------------------------------------

local G = R:RegisterModule("actionbars", {
	title = "Barras de acción",
	defaults = {
		locked = true,
		style = "blizzard",
		hotkeys = true,
		hotkeySize = 5,
		macroNames = true,
		countSize = 5,
		rangeTint = true,
		cdFinish = "pulse",
		cdFinishSize = 1.8,
		cdFinishTime = 0.4,
	},
	options = {
		{ type = "header", text = "Barras de acción" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueadas se ven todas las barras activas, cada una con un recuadro para arrastrarla y un engranaje para abrir su página. También con /rz mover." },
		{ type = "button", name = "Asignar teclas", text = "Abrir", func = function(mod) mod:KeybindMode() end,
		  desc = "Abre el modo de Blizzard para asignar teclas: pasa el ratón por un botón y pulsa la tecla. Son las teclas de Blizzard (Barra de acción 1 a 8, posturas y mascota), así que también se cambian en Esc > Opciones > Atajos." },

		{ type = "header", text = "Botones" },
		{ type = "dropdown", key = "style", name = "Estilo", values = STYLES,
		  desc = "Limpio: sin el marco de Blizzard, icono recortado y un borde negro fino. Para volver al de Blizzard hace falta /reload." },
		{ type = "toggle", key = "hotkeys", name = "Mostrar la tecla de cada botón" },
		{ type = "slider", key = "hotkeySize", name = "Tamaño del texto de la tecla", min = 5, max = 20, step = 1, format = fmtGame },
		{ type = "toggle", key = "macroNames", name = "Mostrar el nombre de las macros" },
		{ type = "slider", key = "countSize", name = "Tamaño del número de cargas", min = 5, max = 24, step = 1, format = fmtGame,
		  desc = "El número de cargas o de objetos que quedan." },
		{ type = "toggle", key = "rangeTint", name = "Icono en rojo si está fuera de alcance",
		  desc = "Además de la tecla en rojo que ya pone Blizzard." },
		{ type = "dropdown", key = "cdFinish", name = "Efecto al recuperar una habilidad", values = FINISH,
		  desc = "Cuando termina la reutilización de un hechizo u objeto de las barras 1 a 8. No salta con la reutilización global (GCD) ni en barras ocultas." },
		{ type = "slider", key = "cdFinishSize", name = "Tamaño del pulso", min = 1.2, max = 3, step = 0.1,
		  format = function(v) return string.format("×%.1f", v) end },
		{ type = "slider", key = "cdFinishTime", name = "Duración del efecto", min = 0.2, max = 1.5, step = 0.05,
		  format = function(v) return string.format("%.2f s", v) end },

		{ type = "header", text = "Ajustes del juego" },
		{ type = "toggle", cvar = "lockActionBars", name = "Bloquear los botones",
		  desc = "Para no sacar sin querer un hechizo de la barra. Con Mayús + arrastrar sí se puede." },
		{ type = "toggle", cvar = "ActionButtonUseKeyDown", name = "Lanzar al pulsar la tecla",
		  desc = "Sin marcar, se lanza al soltarla." },
		{ type = "toggle", cvar = "countdownForCooldowns", name = "Números en las reutilizaciones",
		  desc = "Los segundos que faltan, encima de cada botón." },
	},
})

----------------------------------------------------------------------
-- Un módulo (y una página) por barra
----------------------------------------------------------------------

local function barDefaults(conf)
	local d = {
		numButtons = conf.count or 12,
		orient = conf.vertical and "v" or "h",
		lines = 1,
		growH = "right",
		growV = conf.vertical and "down" or "up",
		size = conf.kind and 32 or 40,
		padding = 2,
		alpha = 1,
		show = "always",
		custom = "[combat] show; hide",
		fade = false,
		fadeAlpha = 0,
		fadeCombat = true,
	}
	-- Las barras 2 a 8 se encienden como estén en Blizzard (al copiarlas)
	if not conf.setting then d.enabled = true end
	if not conf.kind then
		d.showEmpty = false
		d.flyout = "auto"
	end
	if conf.main then
		d.pageBonus = true
		d.pageBar = true
	else
		d.hideVehicle = conf.kind ~= "pet"
		if not conf.kind then d.page = tostring(conf.page) end
	end
	return d
end

local function barDesc(conf)
	if conf.kind == "stance" then
		return L["Las posturas, formas, auras o sigilos de tu clase. Sus teclas son las de «Barra de posturas» en Esc > Opciones > Atajos."]
	elseif conf.kind == "pet" then
		return L["Solo se ve con mascota. Sus teclas son las de «Barra de mascota» en Esc > Opciones > Atajos."]
	end
	return L["Es la barra de acción %d de Blizzard: sus teclas se asignan en Esc > Opciones > Atajos. Aunque la ocultes, sus teclas siguen funcionando."]:format(conf.id)
end

local function barOptions(conf)
	local o = {}
	local function add(t) o[#o + 1] = t end
	local total = conf.count or 12

	add({ type = "header", text = conf.title })
	add({ type = "toggle", key = "enabled", name = "Mostrar esta barra", desc = barDesc(conf) })
	add({ type = "slider", key = "numButtons", name = "Botones", min = 1, max = total, step = 1, format = R.fmt.int })
	add({ type = "dropdown", key = "orient", name = "Orientación", values = ORIENT })
	add({ type = "slider", key = "lines", name = "Filas (columnas si es vertical)", min = 1, max = total, step = 1, format = R.fmt.int,
	      desc = "Con 12 botones y 2 filas quedan dos filas de 6." })
	add({ type = "dropdown", key = "growH", name = "Orden horizontal", values = GROW_H })
	add({ type = "dropdown", key = "growV", name = "Orden vertical", values = GROW_V })

	add({ type = "header", text = "Aspecto" })
	add({ type = "slider", key = "size", name = "Tamaño de los botones", min = 16, max = 64, step = 1, format = R.fmt.int })
	add({ type = "slider", key = "padding", name = "Separación", min = 0, max = 20, step = 1, format = R.fmt.int })
	add({ type = "slider", key = "alpha", name = "Opacidad", min = 0.1, max = 1, step = 0.05 })
	if not conf.kind then
		add({ type = "toggle", key = "showEmpty", name = "Mostrar los huecos vacíos",
		      desc = "Sin marcar, los botones sin nada solo se ven mientras arrastras un hechizo o un objeto." })
		add({ type = "dropdown", key = "flyout", name = "Menús desplegables hacia", values = FLYOUT,
		      desc = "Hacia dónde se abren los menús de hechizos (portales, tótems...). Automática: hacia el centro de la pantalla." })
	end

	if conf.main then
		add({ type = "header", text = "Página" })
		add({ type = "toggle", key = "pageBonus", name = "Cambiar con formas, sigilo y actitudes",
		      desc = "Como en Blizzard: en forma felina, de oso, en sigilo o en cada actitud de guerrero la barra enseña su propia página." })
		add({ type = "toggle", key = "pageBar", name = "Cambiar de página con las teclas de Blizzard",
		      desc = "Mayús + rueda, Mayús + 1 a 6 y las teclas «Página siguiente» y «Página anterior» de los atajos." })
	elseif not conf.kind then
		add({ type = "header", text = "Página" })
		add({ type = "dropdown", key = "page", name = "Acciones que muestra", values = PAGES,
		      desc = "Cada barra de Blizzard guarda sus 12 acciones en una página. Con otra página, esta barra enseña las acciones de otra barra." })
	end

	add({ type = "header", text = "Cuándo se ve" })
	add({ type = "dropdown", key = "show", name = "Mostrar", values = SHOW })
	add({ type = "text", key = "custom", name = "Condiciones propias",
	      desc = "Solo con «Condiciones propias» en Mostrar. Como en una macro, terminando en show o hide. Por ejemplo:\n[combat] show; [mod:shift] show; hide\n[@target,harm] show; hide" })
	if not conf.main then
		add({ type = "toggle", key = "hideVehicle", name = "Ocultar en vehículos" })
	end

	add({ type = "header", text = "Ver al pasar el ratón" })
	add({ type = "toggle", key = "fade", name = "Ocultar hasta pasar el ratón",
	      desc = "Aun invisibles, los botones se pueden pulsar y sus teclas funcionan." })
	add({ type = "slider", key = "fadeAlpha", name = "Opacidad sin ratón", min = 0, max = 0.8, step = 0.05 })
	add({ type = "toggle", key = "fadeCombat", name = "Mostrarla siempre en combate",
	      desc = "Marcada, en combate se ve entera aunque no pases el ratón. Desmárcala para que solo aparezca con el ratón." })

	add({ type = "header", text = "Posición" })
	add({ type = "button", name = "Volver a su sitio", text = "Restablecer", func = function(mod) mod:ResetPosition() end,
	      desc = "La devuelve a su sitio por defecto. Para moverla, desbloquea las barras en la página «Barras de acción» o usa /rz mover." })
	return o
end

local applyLater    -- más abajo

for _, conf in ipairs(BARS) do
	local mod = R:RegisterModule(conf.key, {
		title = conf.title,
		defaults = barDefaults(conf),
		options = barOptions(conf),
	})
	conf.mod = mod
	function mod:OnOptionChanged()
		if self.bar then applyLater(self.bar) end
	end
	function mod:ResetPosition()
		self.db.point = nil
		if self.bar then applyLater(self.bar) end
	end
end

----------------------------------------------------------------------
-- Estado
----------------------------------------------------------------------

local gdb
local built = false
local hider                                   -- donde se guardan las barras de Blizzard
local bars = {}                               -- las barras creadas, en el orden de BARS
local side = setmetatable({}, { __mode = "k" }) -- lo propio de cada botón o marco de Blizzard
local hovered = {}
local lastBar
local inCombat, dragging, keybinding = false, false, false

-- Lo que toca botones protegidos: ahora, o al salir de combate (una vez por clave)
local queued = {}
local function later(key, fn)
	if not InCombatLockdown() then
		fn()
		return
	end
	if queued[key] then return end
	queued[key] = true
	R:RunOutOfCombat(function()
		queued[key] = nil
		fn()
	end)
end

----------------------------------------------------------------------
-- Fragmentos seguros
----------------------------------------------------------------------

-- Enseña u oculta la barra. "rz-vis" viene de sus condiciones, "rz-override"
-- de la barra de vehículo de Blizzard y "rz-force" de desbloquear, asignar
-- teclas o arrastrar un hechizo
local SNIPPET_UPDATE = [[
	if self:GetAttribute("rz-force") or (self:GetAttribute("rz-vis") ~= "hide" and not self:GetAttribute("rz-override")) then
		self:Show()
	else
		self:Hide()
	end
]]

local SNIPPET_VIS = [[
	self:SetAttribute("rz-vis", newstate)
	self:RunAttribute("rz-update")
]]

local SNIPPET_OVERRIDE = [[
	self:SetAttribute("rz-override", newstate == "on")
	self:RunAttribute("rz-update")
]]

-- Página de la barra 1: la misma cuenta que hace Blizzard
-- (ActionBarController_UpdateAll) para vehículos, formas y demás
local SNIPPET_PAGE = [[
	local page = tonumber(newstate)
	if not page then
		if HasVehicleActionBar() then
			page = GetVehicleBarIndex()
		elseif HasOverrideActionBar() then
			page = GetOverrideBarIndex()
		elseif HasTempShapeshiftActionBar() then
			page = GetTempShapeshiftBarIndex()
		elseif HasBonusActionBar() and GetActionBarPage() == 1 then
			page = GetBonusBarIndex()
		else
			page = GetActionBarPage()
		end
	end
	self:ChildUpdate("page", page or 1)
]]

local SNIPPET_CHILD_PAGE = [[
	self:SetAttribute("actionpage", message)
]]

-- Tras ocultarse un botón: Blizzard oculta los que pasan del número de
-- botones de su Modo edición; si aquí tiene que verse, vuelve a enseñarse
local SNIPPET_RESHOW = [[
	if self:IsShown() or self:GetAttribute("statehidden") then return end
	local page = self:GetAttribute("actionpage")
	if not page then return end
	if (self:GetAttribute("showgrid") or 0) > 0 or HasAction(self:GetID() + (page - 1) * 12) then
		self:Show(true)
	end
]]

----------------------------------------------------------------------
-- Disposición
----------------------------------------------------------------------

-- Coloca los botones dentro de la barra y ajusta su tamaño
local function layout(bar)
	local db = bar.mod.db
	local total = #bar.buttons
	local n = clamp(floor(tonumber(db.numButtons) or total), 1, total)
	local lines = clamp(floor(tonumber(db.lines) or 1), 1, n)
	local per = ceil(n / lines)
	lines = ceil(n / per)
	local vertical = db.orient == "v"
	local cols, rows
	if vertical then cols, rows = lines, per else cols, rows = per, lines end

	local size = clamp(db.size, 16, 64)
	local pad = clamp(db.padding, 0, 20)
	local h = db.growH == "left" and "RIGHT" or "LEFT"
	local v = db.growV == "down" and "TOP" or "BOTTOM"
	local point = v .. h
	local sx = h == "LEFT" and 1 or -1
	local sy = v == "BOTTOM" and 1 or -1

	for i, b in ipairs(bar.buttons) do
		local native = b:GetWidth()
		if not native or native <= 0 then native = bar.conf.kind and 30 or 45 end
		local s = size / native
		b:SetScale(s)
		b:ClearAllPoints()
		if i <= n then
			local k = i - 1
			local c, r
			if vertical then
				r, c = k % per, floor(k / per)
			else
				c, r = k % per, floor(k / per)
			end
			-- Las distancias de SetPoint van en la escala del propio botón
			b:SetPoint(point, bar, point, sx * c * (size + pad) / s, sy * r * (size + pad) / s)
			if b:GetAttribute("statehidden") then b:SetAttribute("statehidden", nil) end
		else
			b:SetPoint("CENTER", bar, "CENTER", 0, 0)
			if not b:GetAttribute("statehidden") then b:SetAttribute("statehidden", true) end
			b:Hide()
		end
	end
	bar:SetSize(max(1, cols * size + (cols - 1) * pad), max(1, rows * size + (rows - 1) * pad))
end

-- Enseña los botones que tienen que verse (Blizzard lo vuelve a decidir
-- cada vez que cambia una acción, con las mismas reglas)
local function refreshShown(bar)
	local kind = bar.conf.kind
	local forms = kind == "stance" and (GetNumShapeshiftForms() or 0) or 0
	for i, b in ipairs(bar.buttons) do
		if not b:GetAttribute("statehidden") then
			local grid = (b:GetAttribute("showgrid") or 0) > 0
			local show
			if kind == "stance" then
				show = i <= forms
			elseif kind == "pet" then
				show = grid or (PetHasActionBar() and NS(GetPetActionInfo(b:GetID())) ~= nil) or false
			else
				local page = tonumber(b:GetAttribute("actionpage")) or 1
				show = grid or NS(C_ActionBar.HasAction(b:GetID() + (page - 1) * 12)) or false
			end
			if show ~= b:IsShown() then b:SetShown(show) end
		end
	end
end

-- Huecos vacíos: un bit propio en "showgrid" (los de Blizzard son 1, 2 y 4).
-- Se quita el 1, que es "Mostrar siempre los botones" del Modo edición
local GRID_BIT = 16
local function setGrid(b, on)
	local old = b:GetAttribute("showgrid") or 0
	local v = bit.band(old, bit.bnot(1 + GRID_BIT))
	if on then v = bit.bor(v, GRID_BIT) end
	if v ~= old then b:SetAttribute("showgrid", v) end
end

-- Hacia dónde se abren los menús de hechizos
local function updateFlyout(bar)
	if bar.conf.kind then return end
	local dir = bar.mod.db.flyout
	if not dir or dir == "auto" then
		dir = "UP"
		local x, y = bar:GetCenter()
		if x and y then
			if bar:GetHeight() > bar:GetWidth() then
				dir = x > UIParent:GetWidth() / 2 and "LEFT" or "RIGHT"
			else
				dir = y < UIParent:GetHeight() / 2 and "UP" or "DOWN"
			end
		end
	end
	for _, b in ipairs(bar.buttons) do
		if b:GetAttribute("flyoutDirection") ~= dir then b:SetAttribute("flyoutDirection", dir) end
	end
end

----------------------------------------------------------------------
-- Página y visibilidad
----------------------------------------------------------------------

local function pageDriver(db)
	local s = "[overridebar][vehicleui][possessbar][shapeshift] possess; "
	if db.pageBar then
		s = s .. "[bar:2] 2; [bar:3] 3; [bar:4] 4; [bar:5] 5; [bar:6] 6; "
	end
	if db.pageBonus then
		s = s .. "[bonusbar:1] 7; [bonusbar:2] 8; [bonusbar:3] 9; [bonusbar:4] 10; "
	end
	return s .. "[bonusbar:5] possess; 1"
end

local warned = {}
local function customDriver(bar)
	local text = strtrim(bar.mod.db.custom or "")
	if text ~= "" and pcall(SecureCmdOptionParse, text) then return text end
	if not warned[bar] then
		warned[bar] = true
		R:Print(L["%s: las condiciones propias están vacías o no son válidas; la barra se ve siempre."]:format(R.T(bar.conf.title)))
	end
end

local function visDriver(bar)
	local db, conf = bar.mod.db, bar.conf
	if not db.enabled then return "hide" end
	local s = "[petbattle] hide; "
	if db.hideVehicle and not conf.main then
		if conf.kind == "stance" then
			s = s .. "[vehicleui][possessbar][overridebar] hide; "
		else
			s = s .. "[vehicleui] hide; "
		end
	end
	if conf.kind == "pet" then s = s .. "[@pet,noexists] hide; " end
	local mode = db.show
	if mode == "combat" then return s .. "[combat] show; hide"
	elseif mode == "nocombat" then return s .. "[nocombat] show; hide"
	elseif mode == "target" then return s .. "[@target,exists] show; hide"
	elseif mode == "group" then return s .. "[group] show; hide"
	elseif mode == "custom" then
		local custom = customDriver(bar)
		if custom then return s .. custom end
	end
	return s .. "show"
end

-- Se ven a la fuerza: desbloqueadas, asignando teclas o arrastrando un hechizo
local function updateForce(bar)
	local db = bar.mod.db
	local force = db.enabled and (not gdb.locked or keybinding or dragging) and true or nil
	if bar:GetAttribute("rz-force") ~= force then bar:SetAttribute("rz-force", force) end
	SecureHandlerExecute(bar, [[ self:RunAttribute("rz-update") ]])
end

----------------------------------------------------------------------
-- Aspecto de los botones (solo métodos de sus texturas y textos)
----------------------------------------------------------------------

local COOLDOWNS = { "cooldown", "chargeCooldown", "lossOfControlCooldown" }
local OVERLAYS = { "Border", "Flash", "NewActionTexture", "SpellHighlightTexture" }

local function applyStyle(b)
	local s = side[b]
	local icon = b.icon
	if not (s and icon) or gdb.style ~= "clean" then return end
	-- Un punto de pantalla, en las unidades del botón (que está escalado)
	local px = 1 / max(b:GetScale(), 0.01)
	if not s.bg then
		s.bg = b:CreateTexture(nil, "BACKGROUND", nil, -8)
		s.bg:SetAllPoints()
		s.bg:SetColorTexture(0, 0, 0, 0.75)
	end
	s.bg:Show()
	icon:ClearAllPoints()
	icon:SetPoint("TOPLEFT", px, -px)
	icon:SetPoint("BOTTOMRIGHT", -px, px)
	icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	if b.IconMask and icon.RemoveMaskTexture and not s.unmasked then
		s.unmasked = pcall(icon.RemoveMaskTexture, icon, b.IconMask)
	end
	local normal = b:GetNormalTexture()
	if normal then normal:SetAlpha(0) end
	if b.SlotArt then b.SlotArt:SetAlpha(0) end
	if b.SlotBackground then b.SlotBackground:SetAlpha(0) end

	local function flat(tex, r, g, bl, a)
		if not tex then return end
		tex:ClearAllPoints()
		tex:SetAllPoints(icon)
		tex:SetColorTexture(r, g, bl, a)
	end
	flat(b:GetPushedTexture(), 1, 1, 1, 0.25)
	flat(b:GetHighlightTexture(), 1, 1, 1, 0.2)
	if b.GetCheckedTexture then flat(b:GetCheckedTexture(), 1, 0.82, 0, 0.35) end

	for _, key in ipairs(COOLDOWNS) do
		local cd = b[key]
		if cd then
			cd:ClearAllPoints()
			cd:SetAllPoints(icon)
		end
	end
	for _, key in ipairs(OVERLAYS) do
		local t = b[key]
		if t then
			t:ClearAllPoints()
			t:SetAllPoints(b)
		end
	end
end

local function setFontSize(fs, s, key, size)
	if not fs then return end
	if not s[key] then s[key] = { fs:GetFont() } end
	local orig = s[key]
	if not orig[1] then return end
	-- 5 o menos = el del juego (solo se toca si antes se había cambiado)
	if size >= 6 then
		fs:SetFont(orig[1], size, orig[3] or "")
		s[key].changed = true
	elseif orig.changed then
		fs:SetFont(orig[1], orig[2], orig[3] or "")
		orig.changed = nil
	end
end

local function applyText(b)
	local s = side[b]
	if not s then return end
	if b.HotKey then
		b.HotKey:SetAlpha(gdb.hotkeys and 1 or 0)
		setFontSize(b.HotKey, s, "hotkeyFont", gdb.hotkeySize or 5)
	end
	if b.Name then b.Name:SetAlpha(gdb.macroNames and 1 or 0) end
	if b.Count then setFontSize(b.Count, s, "countFont", gdb.countSize or 5) end
end

-- Icono en rojo fuera de alcance: se tiñe el propio icono (no una capa
-- encima, que no se desvanece con la barra y se veía en huecos vacíos).
-- Se guarda el color que pone Blizzard (sin maná, no usable…) y se
-- multiplica por rojo, así no se pelean.
local function paintIcon(b, s)
	local c = s.color
	s.painting = true
	if s.red then
		b.icon:SetVertexColor(c[1], c[2] * 0.25, c[3] * 0.25)
	else
		b.icon:SetVertexColor(c[1], c[2], c[3])
	end
	s.painting = false
end

local function setTint(b, on)
	local s = side[b]
	if not (s and b.icon) then return end
	on = on and gdb.rangeTint and true or false
	if not s.color then
		local r, g, bl = b.icon:GetVertexColor()
		if not (NS(r) and NS(g) and NS(bl)) then r, g, bl = 1, 1, 1 end
		s.color = { r or 1, g or 1, bl or 1 }
		hooksecurefunc(b.icon, "SetVertexColor", function(_, r2, g2, b2)
			if s.painting then return end
			if not (NS(r2) and NS(g2) and NS(b2)) then return end
			s.color[1], s.color[2], s.color[3] = r2 or 1, g2 or 1, b2 or 1
			if s.red then paintIcon(b, s) end
		end)
	end
	if s.red == on then return end
	s.red = on
	paintIcon(b, s)
end

local function eachButton(fn)
	for _, bar in ipairs(bars) do
		for _, b in ipairs(bar.buttons) do fn(b) end
	end
end

----------------------------------------------------------------------
-- Efecto al recuperar una habilidad: se mira el estado de cada acción
-- (en reutilización propia o no; la global no cuenta) y al pasar de «en
-- reutilización» a «lista» se pinta un efecto en un marco propio encima
-- del botón (nada se escribe en el botón de Blizzard)
----------------------------------------------------------------------

local function call(fn, ...)
	if not fn then return end
	local ok, a, b, c, d = pcall(fn, ...)
	if ok then return a, b, c, d end
end

-- Mientras dispara la varita (o el disparo automático) todos los hechizos
-- salen en reutilización sin ser la global: entonces no se sabe nada nuevo
-- (nil = no cambiar), salvo del hechizo que acabas de lanzar
local function wandLocked(id)
	return R.InRangedLockout and R:InRangedLockout() and not (id and R:CastRecently(id))
end

local function spellOnCD(id)
	local info = call(C_Spell and C_Spell.GetSpellCooldown, id)
	if type(info) ~= "table" then return end
	local active, gcd = NS(info.isActive), NS(info.isOnGCD)
	if active == nil then return end
	local cd = (active and not gcd) and true or false
	if cd and wandLocked(id) then return "keep" end
	return cd
end

local function timesOnCD(start, duration)
	start, duration = NS(start), NS(duration)
	if not (start and duration) then return end
	-- 1,5 s o menos: la reutilización global
	return (start > 0 and duration > 1.5) and true or false
end

-- true / false, o nil si no se puede saber (valores secretos): entonces no
-- se cambia nada
local function actionOnCD(action)
	local kind, id = call(GetActionInfo, action)
	kind, id = NS(kind), NS(id)
	if kind == "macro" then
		local spell = NS(call(GetMacroSpell, id))
		if spell then kind, id = "spell", spell end
	end
	if kind == "spell" and id then
		local cd = spellOnCD(id)
		if cd == "keep" then return nil end
		if cd ~= nil then return cd end
	elseif kind == "item" and id then
		local cd = timesOnCD(call((C_Item and C_Item.GetItemCooldown) or (C_Container and C_Container.GetItemCooldown), id))
		if cd ~= nil then return cd end
	end
	if not kind then return false end
	local cd = timesOnCD(call(GetActionCooldown, action))
	if cd and kind ~= "item" and wandLocked(kind == "spell" and id or nil) then return nil end
	return cd
end

local fxPool = {}

local function getFx()
	for _, f in ipairs(fxPool) do
		if not f:IsShown() then return f end
	end
	local f = CreateFrame("Frame", nil, UIParent)
	f:SetFrameStrata("HIGH")
	f:Hide()
	f.icon = f:CreateTexture(nil, "ARTWORK")
	f.icon:SetAllPoints()
	f.flash = f:CreateTexture(nil, "OVERLAY")
	f.flash:SetAllPoints()
	f.flash:SetColorTexture(1, 1, 1)
	f.flash:SetBlendMode("ADD")
	local ag = f:CreateAnimationGroup()
	f.scale = ag:CreateAnimation("Scale")
	f.scale:SetOrigin("CENTER", 0, 0)
	f.fade = ag:CreateAnimation("Alpha")
	f.fade:SetToAlpha(0)
	ag:SetScript("OnFinished", function() f:Hide() end)
	f.anim = ag
	fxPool[#fxPool + 1] = f
	return f
end

local function playFinish(b)
	local mode = gdb.cdFinish
	if mode == "none" or not b:IsVisible() then return end
	local alpha = NS(b:GetEffectiveAlpha()) or 1
	if alpha < 0.05 then return end
	local target = b.icon or b
	local w, h = NS(target:GetWidth()), NS(target:GetHeight())
	local es, us = NS(target:GetEffectiveScale()), NS(UIParent:GetEffectiveScale())
	if not (w and h and es and us) or w <= 0 or us <= 0 then return end
	local pulse = mode == "pulse" or mode == "both"
	local tex = pulse and b.icon and NS(b.icon:GetTexture())
	local f = getFx()
	f:ClearAllPoints()
	f:SetPoint("CENTER", target, "CENTER")
	f:SetSize(w * es / us, h * es / us)
	f.icon:SetShown(tex and true or false)
	if tex then
		f.icon:SetTexture(tex)
		if gdb.style == "clean" then f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92) else f.icon:SetTexCoord(0, 1, 0, 1) end
	end
	-- Sin icono (o solo destello): el destello se ve igual
	local flash = mode == "flash" or mode == "both" or not tex
	f.flash:SetShown(flash)
	f.flash:SetAlpha(tex and 0.5 or 0.8)
	local size = (pulse and tex) and clamp(gdb.cdFinishSize, 1, 3) or 1
	local time = clamp(gdb.cdFinishTime, 0.1, 2)
	if f.scale.SetScaleFrom then
		f.scale:SetScaleFrom(1, 1)
		f.scale:SetScaleTo(size, size)
	else
		f.scale:SetScale(size, size)
	end
	f.scale:SetDuration(time)
	f.fade:SetFromAlpha(min(alpha, 1))
	f.fade:SetDuration(time)
	f.anim:Stop()
	f:SetAlpha(min(alpha, 1))
	f:Show()
	f.anim:Play()
end

local finishPending = false
local function checkFinish()
	finishPending = false
	if not built then return end
	local on = gdb.cdFinish ~= "none"
	for _, bar in ipairs(bars) do
		if not bar.conf.kind then
			for _, b in ipairs(bar.buttons) do
				local s = side[b]
				local action = s and NS(b.action)
				if action then
					local cd = actionOnCD(action)
					if s.cdAction ~= action then
						-- Otra acción en el botón (página, arrastrar): sin efecto
						s.cdAction, s.wasCD = action, cd
					elseif cd ~= nil then
						if on and s.wasCD and not cd then playFinish(b) end
						s.wasCD = cd
					end
				end
			end
		end
	end
end

local function queueFinish()
	if finishPending then return end
	finishPending = true
	C_Timer.After(0.05, checkFinish)
end

----------------------------------------------------------------------
-- Fundido al pasar el ratón (un único OnUpdate, solo mientras algo cambia)
----------------------------------------------------------------------

local FADE_TIME = 0.2
local fader = CreateFrame("Frame")
fader:Hide()
fader:SetScript("OnUpdate", function(self, elapsed)
	local step = elapsed / FADE_TIME
	local moving = false
	for _, bar in ipairs(bars) do
		local a, t = bar.alphaNow or 1, bar.alphaTarget or 1
		if a ~= t then
			a = a < t and min(t, a + step) or max(t, a - step)
			bar.alphaNow = a
			bar:SetAlpha(a)
			moving = true
		end
	end
	if not moving then self:Hide() end
end)

local checkLater

-- true si el ratón está sobre la barra; el segundo valor indica que no está
-- sobre un botón (hueco entre botones, menú desplegable) y hay que volver a mirar
local function mouseOn(bar)
	if hovered[bar] then return true end
	if bar:IsVisible() and bar:IsMouseOver() then return true, true end
	local flyout = SpellFlyout
	if bar == lastBar and flyout and flyout:IsShown() and flyout:IsMouseOver() then return true, true end
	return false
end

function G:Evaluate()
	if not built then return end
	local recheck = false
	for _, bar in ipairs(bars) do
		local db = bar.mod.db
		local target = clamp(db.alpha, 0.1, 1)
		if not gdb.locked or keybinding then
			target = 1
		elseif db.fade then
			local over, loose = mouseOn(bar)
			recheck = recheck or loose
			if not (over or dragging or (db.fadeCombat and inCombat)) then
				target = min(clamp(db.fadeAlpha, 0, 1), target)
			end
		end
		if bar.alphaTarget ~= target then
			bar.alphaTarget = target
			fader:Show()
		end
	end
	if recheck then checkLater() end
end

local pending = false
function checkLater()
	if pending then return end
	pending = true
	-- Pequeño margen para pasar de un botón a otro sin parpadeo
	C_Timer.After(0.25, function()
		pending = false
		G:Evaluate()
	end)
end

local function onEnter(b)
	local s = side[b]
	if not (s and s.bar) then return end
	hovered[s.bar] = true
	lastBar = s.bar
	G:Evaluate()
end

local function onLeave(b)
	local s = side[b]
	if not (s and s.bar) then return end
	hovered[s.bar] = nil
	checkLater()
end

----------------------------------------------------------------------
-- Aplicar la configuración de una barra (fuera de combate)
----------------------------------------------------------------------

local function applyBar(bar)
	local db, conf = bar.mod.db, bar.conf
	layout(bar)
	if conf.main then
		RegisterStateDriver(bar, "page", pageDriver(db))
	elseif not conf.kind then
		local page = tonumber(db.page) or conf.page
		for _, b in ipairs(bar.buttons) do
			if b:GetAttribute("actionpage") ~= page then b:SetAttribute("actionpage", page) end
		end
	end
	if not conf.kind then
		for _, b in ipairs(bar.buttons) do setGrid(b, db.showEmpty) end
	end
	bar.mover:Place()
	updateFlyout(bar)
	RegisterStateDriver(bar, "vis", visDriver(bar))
	updateForce(bar)
	refreshShown(bar)
	for _, b in ipairs(bar.buttons) do
		applyStyle(b)
		applyText(b)
	end
	bar.mover:SetShown(not gdb.locked and db.enabled and true or false)
end

function applyLater(bar)
	if not built then return end
	later(bar, function()
		applyBar(bar)
		G:Evaluate()
	end)
end

function G:UpdateForce()
	if not built then return end
	-- Los recuadros para mover no son protegidos: al momento
	for _, bar in ipairs(bars) do
		bar.mover:SetShown(not gdb.locked and bar.mod.db.enabled and true or false)
	end
	later("force", function()
		for _, bar in ipairs(bars) do updateForce(bar) end
	end)
	self:Evaluate()
end

----------------------------------------------------------------------
-- Copiar la barra de Blizzard (la primera vez): cuántos botones, filas,
-- tamaño, separación, dónde está y si se ve, para que al instalar el
-- addon todo quede igual que antes
----------------------------------------------------------------------

local function importBar(bar)
	local db, conf = bar.mod.db, bar.conf
	if db.imported then return end
	db.imported = true
	if conf.setting then
		local ok, shown = pcall(Settings.GetValue, conf.setting)
		db.enabled = (ok and shown) and true or false
	end
	local f = _G[conf.blizz]
	if type(f) ~= "table" then return end

	if not conf.kind and tonumber(f.numButtonsShowable) then
		db.numButtons = clamp(floor(f.numButtonsShowable), 1, #bar.buttons)
	end
	if f.isHorizontal ~= nil then db.orient = f.isHorizontal and "h" or "v" end
	if tonumber(f.numRows) then db.lines = clamp(floor(f.numRows), 1, 12) end
	db.growH = f.addButtonsToRight == false and "left" or "right"
	db.growV = f.addButtonsToTop and "up" or "down"
	if f.visibility == "InCombat" then
		db.show = "combat"
	elseif f.visibility == "OutOfCombat" then
		db.show = "nocombat"
	elseif f.visibility == "Hidden" then
		db.enabled = false
	end
	if not conf.kind and bar.buttons[1] then
		db.showEmpty = bit.band(bar.buttons[1]:GetAttribute("showgrid") or 0, 1) > 0
	end

	-- Lo que ocupan de verdad sus botones, en unidades de la pantalla
	local us = UIParent:GetEffectiveScale()
	local n = conf.kind and #bar.buttons or db.numButtons
	local measured, size, l, r, t, bt = 0
	for i = 1, n do
		local b = bar.buttons[i]
		if b and (not conf.kind or b:IsShown()) and b:GetLeft() then
			local s = b:GetEffectiveScale() / us
			size = size or b:GetWidth() * s
			local bl, br, btop, bb = b:GetLeft() * s, b:GetRight() * s, b:GetTop() * s, b:GetBottom() * s
			l = l and min(l, bl) or bl
			r = r and max(r, br) or br
			t = t and max(t, btop) or btop
			bt = bt and min(bt, bb) or bb
			measured = measured + 1
		end
	end
	if not size or size < 8 or measured == 0 then return end

	db.size = clamp(floor(size + 0.5), 16, 64)
	local count = conf.kind and measured or n
	local lines = clamp(db.lines, 1, count)
	local per = ceil(count / lines)
	lines = ceil(count / per)
	local cols, rows = per, lines
	if db.orient == "v" then cols, rows = lines, per end
	local pad
	if cols > 1 then
		pad = ((r - l) - cols * size) / (cols - 1)
	elseif rows > 1 then
		pad = ((t - bt) - rows * size) / (rows - 1)
	end
	if pad then db.padding = clamp(floor(pad + 0.5), 0, 20) end
	db.point = { "TOPLEFT", "BOTTOMLEFT", floor(l + 0.5), floor(t + 0.5) }
end

----------------------------------------------------------------------
-- Montar las barras y esconder las de Blizzard
----------------------------------------------------------------------

local function createBar(conf)
	local mod = conf.mod
	local buttons = {}
	for i = 1, conf.count or 12 do
		local b = _G[conf.prefix .. i]
		if type(b) == "table" and b.SetParent then buttons[#buttons + 1] = b end
	end
	if #buttons == 0 then
		R.missing[L["Barras de acción"] .. ": " .. R.T(conf.title)] = conf.prefix .. "1"
		return
	end

	local bar = CreateFrame("Frame", conf.frame, UIParent, "SecureHandlerStateTemplate")
	bar:SetSize(1, 1)
	bar:SetFrameStrata("MEDIUM")
	bar.conf, bar.mod, bar.buttons = conf, mod, buttons
	bar:SetAttribute("rz-update", SNIPPET_UPDATE)
	bar:SetAttribute("_onstate-vis", SNIPPET_VIS)
	bar:SetAttribute("_onstate-override", SNIPPET_OVERRIDE)
	if conf.main then bar:SetAttribute("_onstate-page", SNIPPET_PAGE) end

	bar.mover = R:CreateMover(bar, conf.title, mod.db, "point", conf.point)
	bar.mover:HookScript("OnDragStop", function() updateFlyout(bar) end)

	mod.bar = bar
	bars[#bars + 1] = bar
	return bar
end

-- Las barras de Blizzard quedan vacías, pero la principal tiene su marco,
-- grifos y números de página: todas van a un marco oculto. Siguen
-- funcionando por dentro (actualizan los botones, sus teclas…)
local function hideBlizzard()
	for _, conf in ipairs(BARS) do
		local f = _G[conf.blizz]
		if type(f) == "table" and f.SetParent then
			if f:GetParent() ~= hider then f:SetParent(hider) end
			if not side[f] then
				side[f] = {}
				-- Por si algo de Blizzard la vuelve a poner en la pantalla
				hooksecurefunc(f, "SetParent", function(frame, parent)
					if parent ~= hider then
						later(frame, function()
							if frame:GetParent() ~= hider then frame:SetParent(hider) end
						end)
					end
				end)
			end
		end
	end
end

local function onActionChanged(b)
	local s = side[b]
	if s and s.action ~= b.action then
		s.action = b.action
		setTint(b, false)
	end
end

local function restyle(b)
	applyStyle(b)
end

local function grab(bar)
	local conf = bar.conf
	for _, b in ipairs(bar.buttons) do
		if b:GetParent() ~= bar then b:SetParent(bar) end
		if not side[b] then
			side[b] = { bar = bar }
			b:HookScript("OnEnter", onEnter)
			b:HookScript("OnLeave", onLeave)
			if b.UpdateButtonArt then hooksecurefunc(b, "UpdateButtonArt", restyle) end
			if not conf.kind then
				SecureHandlerWrapScript(b, "OnHide", bar, "return nil, true", SNIPPET_RESHOW)
				if b.UpdateAction then hooksecurefunc(b, "UpdateAction", onActionChanged) end
				if b.cooldown then b.cooldown:HookScript("OnCooldownDone", queueFinish) end
				if conf.main then b:SetAttribute("_childupdate-page", SNIPPET_CHILD_PAGE) end
			end
		end
	end
end

-- Con la barra de vehículo de Blizzard en pantalla (vehículos con su propio
-- aspecto), la barra 1 se oculta, como hace Blizzard con la suya
local function watchOverride(bar)
	local ob = OverrideActionBar
	if not (bar and type(ob) == "table" and ob.IsVisible) or side[ob] then return end
	side[ob] = {}
	local w = CreateFrame("Frame", nil, ob, "SecureHandlerShowHideTemplate")
	w:SetFrameRef("bar", bar)
	w:SetAttribute("_onshow", [[ self:GetFrameRef("bar"):SetAttribute("state-override", "on") ]])
	w:SetAttribute("_onhide", [[ self:GetFrameRef("bar"):SetAttribute("state-override", "off") ]])
	w:Show()
	bar:SetAttribute("state-override", ob:IsVisible() and "on" or "off")
end

local function registerEvents()
	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	events:RegisterEvent("ACTIONBAR_SHOWGRID")
	events:RegisterEvent("ACTIONBAR_HIDEGRID")
	events:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
	events:RegisterEvent("UI_SCALE_CHANGED")
	events:RegisterEvent("DISPLAY_SIZE_CHANGED")
	events:RegisterEvent("PLAYER_ENTERING_WORLD")
	events:SetScript("OnEvent", function(_, event)
		if event == "PLAYER_ENTERING_WORLD" then
			-- Las acciones de las barras pueden llegar después de montarlas
			C_Timer.After(0.5, function()
				later("shown", function()
					for _, bar in ipairs(bars) do refreshShown(bar) end
				end)
			end)
		elseif event == "PLAYER_REGEN_DISABLED" then
			inCombat = true
			G:Evaluate()
		elseif event == "PLAYER_REGEN_ENABLED" then
			inCombat = false
			G:Evaluate()
		elseif event == "ACTIONBAR_SHOWGRID" then
			dragging = true
			G:UpdateForce()
		elseif event == "ACTIONBAR_HIDEGRID" then
			dragging = false
			G:UpdateForce()
		elseif event == "EDIT_MODE_LAYOUTS_UPDATED" then
			-- El Modo edición vuelve a aplicar sus ajustes a las barras de
			-- Blizzard (huecos vacíos, número de botones…): después, lo nuestro
			C_Timer.After(0.5, function()
				later("editmode", function()
					hideBlizzard()
					for _, bar in ipairs(bars) do
						if not bar.conf.kind then
							for _, b in ipairs(bar.buttons) do setGrid(b, bar.mod.db.showEmpty) end
						end
						refreshShown(bar)
					end
				end)
			end)
		else
			later("flyout", function()
				for _, bar in ipairs(bars) do updateFlyout(bar) end
			end)
		end
	end)
	inCombat = InCombatLockdown()

	-- Efecto al recuperar una habilidad
	local cdEvents = CreateFrame("Frame")
	for _, e in ipairs({ "SPELL_UPDATE_COOLDOWN", "ACTIONBAR_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN", "ACTIONBAR_SLOT_CHANGED" }) do
		pcall(cdEvents.RegisterEvent, cdEvents, e)
	end
	cdEvents:SetScript("OnEvent", queueFinish)
	-- Al acabar el bloqueo de la varita se vuelve a mirar (Rheizor-Core)
	if R.OnRangedLockEnd then R:OnRangedLockEnd(queueFinish) end
	queueFinish()

	-- Rango: Blizzard avisa a cada botón; aquí solo se mira el resultado
	hooksecurefunc("ActionButton_UpdateRangeIndicator", function(b, checksRange, inRange)
		if not side[b] then return end
		local checks, ok = NS(checksRange), NS(inRange)
		setTint(b, checks and ok == false)
	end)

	-- Modo de asignar teclas de Blizzard: se ven todas las barras
	if QuickKeybindFrame then
		QuickKeybindFrame:HookScript("OnShow", function()
			keybinding = true
			G:UpdateForce()
		end)
		QuickKeybindFrame:HookScript("OnHide", function()
			keybinding = false
			G:UpdateForce()
		end)
	end
end

local function takeOver(doImport)
	if built then return end
	if InCombatLockdown() then
		R:RunOutOfCombat(function() takeOver(doImport) end)
		return
	end

	hider = hider or CreateFrame("Frame", "RheizorActionBarsHider", UIParent)
	hider:Hide()
	for _, conf in ipairs(BARS) do
		if not conf.mod.bar then createBar(conf) end
	end
	-- Antes de quitarle los botones a Blizzard, que es de donde se copian
	local imported = false
	if doImport then
		for _, bar in ipairs(bars) do
			if not bar.mod.db.imported then
				importBar(bar)
				imported = true
			end
		end
	end

	hideBlizzard()
	for _, bar in ipairs(bars) do grab(bar) end
	built = true
	local bar1 = BARS[1].mod.bar
	if OverrideActionBar then
		watchOverride(bar1)
	elseif EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_OverrideActionBar", function()
			later("override", function() watchOverride(bar1) end)
		end)
	end
	registerEvents()

	for _, bar in ipairs(bars) do applyBar(bar) end
	G:Evaluate()

	if imported then
		R:Print(L["Barras de acción: copiadas de las de Blizzard tal como las tenías. Cámbialas en /rz > Barras de acción."])
	end
end

function G:OnEnable()
	gdb = self.db

	local needImport = false
	for _, conf in ipairs(BARS) do
		if not conf.mod.db.imported then needImport = true end
	end
	if not needImport then
		takeOver(false)
		return
	end

	-- La primera vez se copian las barras de Blizzard, y su diseño del Modo
	-- edición llega un poco después de entrar (y el del perfil de Rheizor, 3 s
	-- más tarde): se espera a que estén colocadas
	local done = false
	local function go()
		if done then return end
		done = true
		takeOver(true)
	end
	if EditModeManagerFrame and EditModeManagerFrame.layoutInfo then
		C_Timer.After(1, go)
	else
		local wait = CreateFrame("Frame")
		wait:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
		wait:SetScript("OnEvent", function(f)
			f:UnregisterAllEvents()
			C_Timer.After(4, go)
		end)
		C_Timer.After(15, go)
	end
end

function G:OnOptionChanged(key)
	if not built then return end
	if key == "locked" then
		self:UpdateForce()
	elseif key == "style" then
		if gdb.style == "clean" then
			later("style", function() eachButton(applyStyle) end)
		else
			R:NeedReload()
		end
	elseif key == "rangeTint" then
		if not gdb.rangeTint then eachButton(function(b) setTint(b, false) end) end
	else
		later("text", function() eachButton(applyText) end)
	end
end

-- Modo de asignar teclas de Blizzard
function G:KeybindMode()
	if InCombatLockdown() then
		R:Print(L["No se puede asignar teclas en combate."])
		return
	end
	if not (QuickKeybindFrame and QuickKeybindFrame.Show) then
		R:Print(L["Este cliente no tiene el modo de asignar teclas de Blizzard: usa Esc > Opciones > Atajos."])
		return
	end
	QuickKeybindFrame:Show()
end
