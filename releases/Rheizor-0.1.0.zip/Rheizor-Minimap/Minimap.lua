-- Minimapa: forma (redonda o cuadrada), borde y ocultar botones y adornos.

local R = Rheizor:Namespace(...)
local L = R.L

local BORDER_COLORS = { { "class", "Color de clase" } }
for _, c in ipairs(R.COLORS) do table.insert(BORDER_COLORS, c) end
table.insert(BORDER_COLORS, 1, { "000000", "|cff777777Negro|r" })

local M = R:RegisterModule("minimap", {
	title = "Minimapa",
	defaults = {
		shape = "round",   -- "round", "roundclean" (sin aro) o "square"
		borderSize = 2,
		borderColor = "000000",
		hideZoom = false,
		hideHeader = false,
		hideCalendar = false,
		hideClock = false,
		hideTracking = false,
		hideCompartment = false,
		hideDayNight = false,
		detach = false,
		locked = true,
	},
	options = {
		{ type = "header", text = "Forma y borde" },
		{ type = "dropdown", key = "shape", name = "Forma",
		  values = { { "round", "Redonda" }, { "roundclean", "Redonda sin aro" }, { "square", "Cuadrada" } },
		  desc = "Redonda sin aro: quita el aro decorativo de Blizzard.\nCuadrada: quita el aro y recorta el mapa en cuadrado. Los addons con botones en el minimapa lo detectan y colocan sus iconos en las esquinas.\n\nPara que el mapa gire con tu personaje: Esc > Modo edición > Minimapa > Rotar minimapa." },
		{ type = "slider", key = "borderSize", name = "Grosor del borde (cuadrada)", min = 0, max = 6, step = 1, format = R.fmt.int,
		  desc = "0 = sin borde." },
		{ type = "dropdown", key = "borderColor", name = "Color del borde (cuadrada)", values = BORDER_COLORS },

		{ type = "header", text = "Ocultar elementos" },
		{ type = "toggle", key = "hideZoom", name = "Ocultar botones de zoom", reload = true,
		  desc = "Oculta los botones + y -. Puedes seguir usando la rueda del ratón." },
		{ type = "toggle", key = "hideHeader", name = "Ocultar cabecera de zona", reload = true,
		  desc = "Oculta la barra superior con el nombre de la zona." },
		{ type = "toggle", key = "hideCalendar", name = "Ocultar calendario", reload = true },
		{ type = "toggle", key = "hideClock", name = "Ocultar reloj", reload = true },
		{ type = "toggle", key = "hideTracking", name = "Ocultar botón de rastreo", reload = true },
		{ type = "toggle", key = "hideCompartment", name = "Ocultar menú de addons", reload = true,
		  desc = "Oculta el botón que agrupa los iconos de addons." },
		{ type = "toggle", key = "hideDayNight", name = "Ocultar indicador día/noche", reload = true },

		{ type = "header", text = "Posición" },
		{ type = "toggle", key = "detach", name = "Mover el minimapa por separado",
		  desc = "Despega el mapa del bloque de Blizzard: el nombre de la zona, el rastreo, el correo y el resto se quedan donde están (se mueven con el Modo edición del juego) y el mapa lo colocas tú arrastrándolo (desbloquéalo abajo o usa /rz mover).\n\nPara volver a pegarlo hace falta /reload." },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueado, el minimapa se puede arrastrar (solo si está separado)." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end,
		  desc = "Vuelve a ponerlo donde está el bloque de Blizzard." },
	},
})

-- Los ganchos no se pueden quitar: con el addon apagado en Rheizor siguen
-- llamándose, pero no hacen nada
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

-- "Textures\\MinimapMask" era la máscara del cliente clásico antiguo; en el
-- motor 12.x no carga y el mapa se quedaba cuadrado. Esta existe en los dos.
local MASK_ROUND = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local MASK_SQUARE = "Interface\\Buttons\\WHITE8X8"
-- Aro/brújula de Blizzard (motor moderno y clásico). Con el minimapa rotando
-- (Modo edición) WoW Forever añade un segundo aro debajo: el "Underlay"
local RING = { "MinimapCompassTexture", "MinimapCompassTextureUnderlay", "MinimapBorder" }

local border

-- Convención usada por LibDBIcon y otros addons para colocar sus botones.
-- Es una función global: solo se define en OnEnable, así con el módulo
-- apagado no dice "SQUARE" ni pisa la de otro addon de minimapa
local function minimapShape()
	return running() and M.db.shape == "square" and "SQUARE" or "ROUND"
end

local function applyHybrid(mask)
	local hm = HybridMinimap
	if not (hm and hm.MapCanvas and hm.CircleMask) then return end
	pcall(function()
		hm.MapCanvas:SetUseMaskTexture(false)
		hm.CircleMask:SetTexture(mask)
		hm.MapCanvas:SetUseMaskTexture(true)
	end)
end

local settingMask = false

function M:ApplyShape()
	local db = self.db
	local square = db.shape == "square"
	local mask = square and MASK_SQUARE or MASK_ROUND

	settingMask = true
	Minimap:SetMaskTexture(mask)
	settingMask = false
	applyHybrid(mask)
	-- Los puntos de misiones, grupo, etc. se recolocan según la nueva forma
	if Minimap.SetZoom and Minimap.GetZoom then
		local zoom = Minimap:GetZoom()
		pcall(Minimap.SetZoom, Minimap, zoom > 0 and zoom - 1 or zoom + 1)
		pcall(Minimap.SetZoom, Minimap, zoom)
	end
	if Minimap.UpdateBlips then pcall(Minimap.UpdateBlips, Minimap) end
	-- Los anillos de misiones/arqueología se ven raros en un mapa cuadrado
	if Minimap.SetArchBlobRingScalar then pcall(Minimap.SetArchBlobRingScalar, Minimap, square and 0 or 1) end
	if Minimap.SetQuestBlobRingScalar then pcall(Minimap.SetQuestBlobRingScalar, Minimap, square and 0 or 1) end

	local hideRing = square or db.shape == "roundclean"
	for _, path in ipairs(RING) do
		local tex = R:Resolve(path)
		if tex and tex.SetAlpha then tex:SetAlpha(hideRing and 0 or 1) end
	end

	-- Borde cuadrado
	if not border then
		border = CreateFrame("Frame", nil, Minimap, "BackdropTemplate")
		border:SetFrameLevel(Minimap:GetFrameLevel() + 5)
	end
	local size = db.borderSize
	if square and size > 0 then
		border:ClearAllPoints()
		border:SetPoint("TOPLEFT", -size, size)
		border:SetPoint("BOTTOMRIGHT", size, -size)
		border:SetBackdrop({ edgeFile = MASK_SQUARE, edgeSize = size })
		local r, g, b
		if db.borderColor == "class" then
			local c = RAID_CLASS_COLORS[R:PlayerClass()]
			r, g, b = c.r, c.g, c.b
		else
			r, g, b = R.HexToRGB(db.borderColor)
		end
		border:SetBackdropBorderColor(r, g, b, 1)
		border:Show()
	else
		border:Hide()
	end
end

----------------------------------------------------------------------
-- Minimapa separado del bloque de Blizzard
----------------------------------------------------------------------

local mover
local placing = false

local function place()
	if placing or not mover or not M.db.detach or not running() then return end
	if InCombatLockdown() and Minimap:IsProtected() then
		R:RunOutOfCombat(place)
		return
	end
	placing = true
	pcall(mover.Place, mover)
	placing = false
end

-- Donde está ahora, para que al separarlo no salte de sitio
local function currentPoint()
	local x, y = Minimap:GetCenter()
	if not x then return { "TOPRIGHT", "TOPRIGHT", -30, -30 } end
	return { "CENTER", "BOTTOMLEFT", x, y }
end

function M:ApplyDetach()
	local db = self.db
	if not db.detach then
		if mover then
			mover:Hide()
			R:NeedReload()
		end
		return
	end
	if not mover then
		mover = R:CreateMover(Minimap, L["Minimapa"], db, "point", currentPoint())
		-- Blizzard recoloca el mapa dentro de su bloque (al cambiar el
		-- Modo edición, al girar la cabecera…): se devuelve a su sitio
		hooksecurefunc(Minimap, "SetPoint", place)
	end
	place()
	mover:SetShown(not db.locked)
end

function M:ResetPosition()
	self.db.point = nil
	if not mover then return end
	-- Vuelve a la esquina donde está el bloque de Blizzard
	local cluster = MinimapCluster
	local x, y = cluster and cluster:GetCenter()
	if x then
		local s = cluster:GetEffectiveScale() / Minimap:GetEffectiveScale()
		self.db.point = { "CENTER", "BOTTOMLEFT", x * s, y * s }
	end
	place()
end

function M:OnEnable()
	-- Antes "ocultar el anillo" era una casilla aparte
	if self.db.hideRing ~= nil then
		if self.db.hideRing and self.db.shape == "round" then self.db.shape = "roundclean" end
		self.db.hideRing = nil
	end

	started = true
	GetMinimapShape = minimapShape
	self:ApplyShape()
	self:ApplyDetach()

	-- Al activar o quitar "Rotar minimapa" (Modo edición), Blizzard vuelve a
	-- poner su máscara redonda: se recupera la cuadrada justo después
	hooksecurefunc(Minimap, "SetMaskTexture", function()
		if settingMask or not running() or M.db.shape ~= "square" then return end
		C_Timer.After(0, function() if running() then M:ApplyShape() end end)
	end)

	-- El minimapa "híbrido" (algunas zonas interiores) se carga aparte
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_HybridMinimap", function()
			if running() then applyHybrid(self.db.shape == "square" and MASK_SQUARE or MASK_ROUND) end
		end)
	end
end

function M:OnOptionChanged(key)
	if key == "shape" or key == "borderSize" or key == "borderColor" then
		self:ApplyShape()
	elseif key == "detach" or key == "locked" then
		self:ApplyDetach()
	end
end

R:AttachHiders(M, {
	hideZoom        = { "Minimap.ZoomIn", "Minimap.ZoomOut" },
	hideHeader      = { "MinimapCluster.BorderTop", "MinimapCluster.ZoneTextButton" },
	hideCalendar    = { "GameTimeFrame" },
	hideClock       = { "TimeManagerClockButton", addon = "Blizzard_TimeManager" },
	hideTracking    = { "MinimapCluster.Tracking", "MiniMapTracking" },
	hideCompartment = { "AddonCompartmentFrame" },
	hideDayNight    = { "MinimapCluster.DielFrame" },
})
