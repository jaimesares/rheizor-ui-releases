-- Bolsas: comerciante automático, nivel de objeto, basura y ajustes de las bolsas.

local R = Rheizor:Namespace(...)
local L = R.L

-- (El contador de huecos libres de la mochila lo muestra siempre el juego:
-- la CVar clásica displayFreeBagSlots no existe en este cliente)
local options = {
	{ type = "header", text = "Aspecto" },
	{ type = "toggle", cvar = "combinedBags", name = "Bolsas combinadas",
	  desc = "Muestra todas las bolsas en una sola ventana." },
	{ type = "toggle", key = "ilvl", name = "Nivel de objeto en el equipo",
	  desc = "Muestra el nivel de objeto de armas y armaduras en las bolsas, coloreado por calidad." },
	{ type = "toggle", key = "junkDim", name = "Oscurecer la basura",
	  desc = "Muestra los objetos grises en blanco y negro para distinguirlos de un vistazo." },

	{ type = "header", text = "Posición" },
	{ type = "dropdown", key = "place", name = "Dónde se abren",
	  values = {
		{ "blizzard", "Donde las pone el juego" },
		{ "move", "Donde yo quiera (con botón para moverlas)" },
		{ "fixed", "Donde yo quiera (sin botón)" },
	  },
	  desc = "Con botón: al abrir las bolsas aparece un botón encima; arrástralo para moverlas (clic derecho: volver a su sitio). Cuando estén donde quieres, elige «sin botón»." },
	{ type = "button", name = "Volver a su sitio", text = "Restablecer",
	  desc = "Las bolsas vuelven a abrirse abajo a la derecha.",
	  func = function(mod) mod:ResetPosition() end },
}

-- Ordenación (solo si existe en esta versión; no son CVars)
if C_Container and (C_Container.GetSortBagsRightToLeft or C_Container.GetInsertItemsLeftToRight or C_Container.SortBags) then
	table.insert(options, { type = "header", text = "Ordenar" })
end
if C_Container and C_Container.GetSortBagsRightToLeft then
	table.insert(options, { type = "toggle", id = "sortRightToLeft", name = "Ordenar de derecha a izquierda",
		desc = "Al ordenar, los objetos se colocan empezando por la última bolsa.",
		default = false,
		get = function() return C_Container.GetSortBagsRightToLeft() end,
		set = function(v) C_Container.SetSortBagsRightToLeft(v) end })
end
if C_Container and C_Container.GetInsertItemsLeftToRight then
	table.insert(options, { type = "toggle", id = "insertLeftToRight", name = "Botín nuevo en la bolsa izquierda",
		desc = "Lo que recoges va primero a la bolsa de más a la izquierda en vez de a la mochila.",
		default = false,
		get = function() return C_Container.GetInsertItemsLeftToRight() end,
		set = function(v) C_Container.SetInsertItemsLeftToRight(v) end })
end
if C_Container and C_Container.SortBags then
	table.insert(options, { type = "button", name = "Ordenar bolsas", text = "Ordenar",
		func = function() C_Container.SortBags() end })
end

table.insert(options, { type = "header", text = "Comerciante" })
table.insert(options, { type = "toggle", key = "autoSell", name = "Vender basura automáticamente",
	desc = "Vende los objetos grises al abrir un comerciante." })
table.insert(options, { type = "toggle", key = "autoRepair", name = "Reparar automáticamente",
	desc = "Repara todo el equipo al abrir un comerciante que pueda reparar." })
table.insert(options, { type = "toggle", key = "guildRepair", name = "Usar fondos de hermandad",
	desc = "Al reparar automáticamente, paga primero con el dinero de la hermandad si te deja." })

local M = R:RegisterModule("bags", {
	title = "Bolsas",
	defaults = {
		autoSell = false,
		autoRepair = false,
		guildRepair = false,
		ilvl = false,
		junkDim = false,
		-- Posición: "blizzard", "move" (con botón para arrastrar) o "fixed"
		place = "blizzard",
		-- Esquina de abajo a la derecha de la bolsa principal, respecto a la
		-- de UIParent (x, y en unidades de UIParent); nil = donde la pone Blizzard
		pos = nil,
	},
	options = options,
})

----------------------------------------------------------------------
-- Comerciante
----------------------------------------------------------------------

local NUM_BAGS = NUM_BAG_SLOTS or 4

local money = R.Money

local function sellJunk()
	local total, count = 0, 0
	local slots = {}
	for bag = 0, NUM_BAGS do
		for slot = 1, C_Container.GetContainerNumSlots(bag) do
			local info = C_Container.GetContainerItemInfo(bag, slot)
			if info and info.quality == Enum.ItemQuality.Poor and not info.hasNoValue then
				local price = select(11, C_Item.GetItemInfo(info.itemID)) or 0
				if price > 0 then
					total = total + price * info.stackCount
					count = count + 1
					table.insert(slots, { bag, slot })
				end
			end
		end
	end
	if count == 0 then return end

	if C_MerchantFrame and C_MerchantFrame.SellAllJunkItems then
		C_MerchantFrame.SellAllJunkItems()
	else
		for _, s in ipairs(slots) do C_Container.UseContainerItem(s[1], s[2]) end
	end
	R:Print(string.format(L["Vendida basura (%d): %s"], count, money(total)))
end

local function repair()
	if not CanMerchantRepair() then return end
	local cost, canRepair = GetRepairAllCost()
	if not canRepair or cost <= 0 then return end

	if M.db.guildRepair and CanGuildBankRepair and CanGuildBankRepair() then
		RepairAllItems(true)
		R:Print(string.format(L["Reparado con fondos de hermandad: %s"], money(cost)))
	elseif GetMoney() >= cost then
		RepairAllItems()
		R:Print(string.format(L["Reparado: %s"], money(cost)))
	else
		R:Print(string.format(L["|cffff5555No tienes dinero suficiente para reparar|r (%s)"], money(cost)))
	end
end

----------------------------------------------------------------------
-- Nivel de objeto y basura en los botones de las bolsas
----------------------------------------------------------------------

local EQUIP_CLASSES = { [Enum.ItemClass.Weapon] = true, [Enum.ItemClass.Armor] = true }

local function decorate(button)
	local bag, slot = button:GetBagID(), button:GetID()
	if not bag or not slot then return end

	if not button.rzIlvl then
		button.rzIlvl = button:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
		button.rzIlvl:SetPoint("TOPLEFT", 2, -2)
	end
	button.rzIlvl:SetText("")

	local info = C_Container.GetContainerItemInfo(bag, slot)
	local icon = button.icon or button.Icon

	-- Basura
	if icon then
		local isJunk = M.db.junkDim and info and info.quality == Enum.ItemQuality.Poor
		if isJunk then
			icon:SetDesaturated(true)
			icon:SetAlpha(0.5)
			button.rzDimmed = true
		elseif button.rzDimmed then
			icon:SetDesaturated(false)
			icon:SetAlpha(1)
			button.rzDimmed = nil
		end
	end

	-- Nivel de objeto
	if not (M.db.ilvl and info and info.hyperlink) then return end
	local _, _, quality, _, _, _, _, _, equipLoc, _, _, classID = C_Item.GetItemInfo(info.hyperlink)
	if not classID then
		M.pendingRefresh = true
		return
	end
	if not EQUIP_CLASSES[classID] or equipLoc == "" or equipLoc == "INVTYPE_BAG" then return end

	local loc = ItemLocation:CreateFromBagAndSlot(bag, slot)
	local level = loc and C_Item.GetCurrentItemLevel(loc)
	if level and level > 1 then
		button.rzIlvl:SetText(level)
		local r, g, b = C_Item.GetItemQualityColor(quality or 1)
		button.rzIlvl:SetTextColor(r, g, b)
	end
end

-- Los ganchos de Blizzard no se pueden quitar: si se apaga el addon en
-- Rheizor, siguen llamándose pero no hacen nada. (No se usa
-- R:IsModuleRunning: durante el propio OnEnable aún da false)
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

local function decorateFrame(frame)
	if not frame:IsShown() or not running() then return end
	if frame.EnumerateValidItems then
		for _, button in frame:EnumerateValidItems() do decorate(button) end
	elseif frame.Items then
		for _, button in ipairs(frame.Items) do decorate(button) end
	end
end

local containerFrames = {}

function M:RefreshBags()
	for _, frame in ipairs(containerFrames) do decorateFrame(frame) end
end

local function hookContainers()
	local list = { ContainerFrameCombinedBags }
	for i = 1, (NUM_CONTAINER_FRAMES or 13) do
		table.insert(list, _G["ContainerFrame" .. i])
	end
	for _, frame in pairs(list) do
		if frame and not frame.rzHooked then
			frame.rzHooked = true
			table.insert(containerFrames, frame)
			local method = frame.UpdateItems and "UpdateItems" or (frame.Update and "Update")
			if method then
				hooksecurefunc(frame, method, decorateFrame)
			end
			frame:HookScript("OnShow", decorateFrame)
		end
	end
	if #containerFrames == 0 then
		R.missing[L["Bolsas: ventanas"]] = "ContainerFrameCombinedBags / ContainerFrame1..13"
	end
end

----------------------------------------------------------------------
-- Posición. Blizzard vuelve a colocar las bolsas cada vez que se abren
-- (UpdateContainerFrameAnchors); justo después se desplazan todas juntas
-- para que la principal (la combinada o la mochila) quede donde se guardó.
----------------------------------------------------------------------

local handle, dragging

-- ¿Posición propia? ¿Con el botón para arrastrarlas?
local function customPlace() return M.db.place == "move" or M.db.place == "fixed" end
local function showHandle() return M.db.place == "move" end

local function visibleBags()
	local list = {}
	for _, frame in ipairs(containerFrames) do
		if frame:IsShown() and frame:GetRight() then list[#list + 1] = frame end
	end
	return list
end

local function mainBag(list)
	for _, f in ipairs(list) do
		if f == ContainerFrameCombinedBags then return f end
	end
	for _, f in ipairs(list) do
		if f.GetBagID and f:GetBagID() == 0 then return f end
	end
	return list[1]
end

-- Esquina de abajo a la derecha, en píxeles de pantalla
local function corner(f)
	local s = f:GetEffectiveScale()
	return f:GetRight() * s, f:GetBottom() * s
end

-- Mueve todas las bolsas abiertas para que la principal acabe en (tx, ty)
local function shiftTo(list, main, tx, ty)
	local cx, cy = corner(main)
	local dx, dy = tx - cx, ty - cy
	if math.abs(dx) < 0.5 and math.abs(dy) < 0.5 then return end
	-- Primero se leen todas (algunas pueden ir ancladas a otras) y luego se colocan
	local spots = {}
	for i, f in ipairs(list) do
		local s = f:GetEffectiveScale()
		spots[i] = { (f:GetLeft() * s + dx) / s, (f:GetBottom() * s + dy) / s }
	end
	for i, f in ipairs(list) do
		f:ClearAllPoints()
		f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", spots[i][1], spots[i][2])
	end
end

local function updateHandle()
	if not handle then return end
	local main = running() and showHandle() and mainBag(visibleBags())
	if not main then
		if not dragging then handle:Hide() end
		return
	end
	handle:ClearAllPoints()
	handle:SetPoint("BOTTOM", main, "TOP", 0, 4)
	handle:Show()
end

function M:ApplyPosition()
	if not running() then
		if handle then handle:Hide() end
		return
	end
	if customPlace() and self.db.pos then
		local list = visibleBags()
		local main = mainBag(list)
		if main then
			if InCombatLockdown() and main:IsProtected() then
				R:RunOutOfCombat(function() M:ApplyPosition() end)
				return
			end
			local ui = UIParent:GetEffectiveScale()
			shiftTo(list, main, (UIParent:GetRight() + self.db.pos[1]) * ui, (UIParent:GetBottom() + self.db.pos[2]) * ui)
		end
	end
	updateHandle()
end

-- Vuelve a dejar las bolsas donde las pone Blizzard
local function blizzardAnchors()
	if UpdateContainerFrameAnchors and not InCombatLockdown() then UpdateContainerFrameAnchors() end
end

function M:ResetPosition()
	self.db.pos = nil
	blizzardAnchors()
	updateHandle()
end

local function stopDrag()
	if not dragging then return end
	dragging = nil
	handle:SetScript("OnUpdate", nil)
	updateHandle()
end

local function createHandle()
	handle = CreateFrame("Button", nil, UIParent, "UIPanelButtonTemplate")
	handle:SetSize(130, 20)
	handle:SetText(L["Mover bolsas"])
	handle:SetFrameStrata("HIGH")
	handle:RegisterForClicks("RightButtonUp")
	handle:Hide()
	handle:SetScript("OnClick", function() M:ResetPosition() end)
	handle:SetScript("OnMouseDown", function(self, button)
		if button ~= "LeftButton" then return end
		local main = mainBag(visibleBags())
		if not main or (InCombatLockdown() and main:IsProtected()) then return end
		local mx, my = GetCursorPosition()
		local bx, by = corner(main)
		dragging = { mx = mx, my = my, bx = bx, by = by }
		self:SetScript("OnUpdate", function()
			local list = visibleBags()
			local m = mainBag(list)
			if not m then stopDrag() return end
			local x, y = GetCursorPosition()
			local tx, ty = dragging.bx + x - dragging.mx, dragging.by + y - dragging.my
			shiftTo(list, m, tx, ty)
			local ui = UIParent:GetEffectiveScale()
			M.db.pos = { tx / ui - UIParent:GetRight(), ty / ui - UIParent:GetBottom() }
		end)
	end)
	handle:SetScript("OnMouseUp", stopDrag)
	handle:SetScript("OnHide", stopDrag)
	handle:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Mover bolsas"])
		GameTooltip:AddLine(L["Arrastra para mover las bolsas. Clic derecho: volver a su sitio."], 1, 1, 1, true)
		GameTooltip:AddLine(L["Puedes ocultar este botón en /rz > Bolsas."], 0.6, 0.6, 0.6, true)
		GameTooltip:Show()
	end)
	handle:SetScript("OnLeave", GameTooltip_Hide)
end

local function hookPositions()
	createHandle()
	local function later() C_Timer.After(0, function() M:ApplyPosition() end) end
	if UpdateContainerFrameAnchors then
		hooksecurefunc("UpdateContainerFrameAnchors", function() M:ApplyPosition() end)
	end
	-- Por si esta versión las coloca de otra forma
	for _, frame in ipairs(containerFrames) do
		frame:HookScript("OnShow", later)
		frame:HookScript("OnHide", later)
	end
end

----------------------------------------------------------------------

function M:OnEnable()
	-- Antes eran dos casillas ("Mover las bolsas" y "Botón para moverlas")
	if self.db.move ~= nil or self.db.handle ~= nil then
		if self.db.move then
			self.db.place = (self.db.handle == false) and "fixed" or "move"
		else
			self.db.place = "blizzard"
		end
		self.db.move, self.db.handle = nil, nil
	end

	started = true
	hookContainers()
	hookPositions()

	local events = CreateFrame("Frame")
	events:RegisterEvent("MERCHANT_SHOW")
	events:RegisterEvent("GET_ITEM_INFO_RECEIVED")
	events:SetScript("OnEvent", function(_, event)
		if not running() then return end
		if event == "MERCHANT_SHOW" then
			if M.db.autoRepair then repair() end
			if M.db.autoSell then sellJunk() end
		elseif event == "GET_ITEM_INFO_RECEIVED" and M.pendingRefresh then
			M.pendingRefresh = nil
			C_Timer.After(0.2, function() M:RefreshBags() end)
		end
	end)
end

function M:OnOptionChanged(key)
	if key == "ilvl" or key == "junkDim" then
		self:RefreshBags()
	elseif key == "place" then
		if customPlace() then self:ApplyPosition() else blizzardAnchors() updateHandle() end
	end
end
