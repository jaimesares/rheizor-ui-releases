-- Estadísticas del personaje (al estilo CharacterStatsClassic): un panel
-- junto a la ventana del personaje con atributos, cuerpo a cuerpo, a
-- distancia, hechizos, defensa, resistencias y varios (experiencia…).
--
-- Dos modos:
--  * Dos columnas: cada columna muestra una categoría entera, elegida con el
--    desplegable de su título (como el addon original).
--  * Personalizada: secciones hechas a mano en el editor, con grupos enteros
--    o estadísticas sueltas, en el orden y la columna que quieras.
-- Solo se actualiza mientras se ve.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local CATEGORIES = {
	{ "base", "Atributos" },
	{ "melee", "Cuerpo a cuerpo" },
	{ "ranged", "A distancia" },
	{ "spell", "Hechizos" },
	{ "defense", "Defensa" },
	{ "resist", "Resistencias" },
	{ "misc", "Varios" },
	{ "prof", "Profesiones" },
	{ "currency", "Monedas y JcJ" },
}
local COLUMN_VALUES = {}
for _, c in ipairs(CATEGORIES) do COLUMN_VALUES[#COLUMN_VALUES + 1] = c end
local COLUMN2_VALUES = { { "auto", "Según la clase" } }
for _, c in ipairs(CATEGORIES) do COLUMN2_VALUES[#COLUMN2_VALUES + 1] = c end

local M = R:RegisterModule("stats", {
	title = "Estadísticas",
	defaults = {
		enabled = true,
		anchor = "character",
		locked = true,
		visibility = "character",
		withCharacter = true,
		vCombat = "any",
		vSolo = true,
		vParty = true,
		vRaid = true,
		vInstance = false,
		vTarget = false,
		vMounted = false,
		vHover = false,
		hiddenAlpha = 0,
		layout = "columns",
		arrange = "columns",
		gridWidth = 420,
		columns = 2,
		autoFlow = false,
		col1 = "base",
		col2 = "auto",
		col3 = "defense",
		col4 = "misc",
		fontSize = 12,
		scale = 1,
		bgAlpha = 0.85,
		decimals = "2",
		profFormat = "rankMax",
		tooltips = true,
		panelButtons = "show",
		colorBuffs = true,
		label = "name",
		showMods = true,
		grouped = true,
		gap = 16,
		rowGap = 0,
		colGap = 14,
		hideBlizzard = false,
		-- db.sections (modo personalizado) se crea al abrir el editor
	},
	-- No hay forma de ocultar opciones según otra, así que cada nombre dice
	-- con qué modo funciona
	options = {
		{ type = "toggle", key = "enabled", name = "Mostrar el panel de estadísticas" },

		{ type = "header", text = "Qué estadísticas" },
		{ type = "dropdown", key = "layout", name = "Qué se muestra",
		  values = {
			{ "columns", "Categorías enteras, una por columna" },
			{ "custom", "Selección personalizada" },
		  },
		  desc = "Categorías enteras: cada columna muestra una categoría completa; haz clic en su título para cambiarla.\nSelección personalizada: tus propias secciones, con grupos enteros o estadísticas sueltas en el orden que quieras (botón «Editar»)." },
		{ type = "button", name = "Selección personalizada", text = "Editar",
		  desc = "Abre el editor: añade grupos o estadísticas sueltas, ordénalas con las flechas y elige en qué columna va cada sección. También con el engranaje del panel.",
		  func = function(mod) mod:OpenEditor() end },
		{ type = "dropdown", key = "col1", name = "Categorías enteras: columna 1", values = COLUMN_VALUES },
		{ type = "dropdown", key = "col2", name = "Categorías enteras: columna 2", values = COLUMN2_VALUES,
		  desc = "Según la clase: cuerpo a cuerpo para guerreros y pícaros, a distancia para cazadores y hechizos para el resto." },
		{ type = "dropdown", key = "col3", name = "Categorías enteras: columna 3", values = COLUMN_VALUES,
		  desc = "Con 3 columnas o más." },
		{ type = "dropdown", key = "col4", name = "Categorías enteras: columna 4", values = COLUMN_VALUES,
		  desc = "Con 4 columnas o más. Las columnas 5 a 12 se eligen con el desplegable de su título." },

		{ type = "header", text = "Colocación" },
		{ type = "dropdown", key = "arrange", name = "Forma",
		  values = {
			{ "columns", "En columnas" },
			{ "vertical", "Todo en vertical" },
			{ "horizontal", "Todo en horizontal" },
			{ "grid", "Cuadrícula de tamaño libre" },
		  },
		  desc = "En columnas: el número de columnas de abajo.\nTodo en vertical: una sola columna.\nTodo en horizontal: una sola línea.\nCuadrícula de tamaño libre: arrastra la esquina de abajo a la derecha del panel para cambiar el ancho y las estadísticas se colocan solas en celdas." },
		{ type = "slider", key = "columns", name = "Número de columnas", min = 1, max = 12, step = 1, format = R.fmt.int,
		  desc = "Con la forma «En columnas», cuántas columnas hay. Con «Categorías enteras» es también cuántas categorías se muestran, sea cual sea la forma." },
		{ type = "toggle", key = "autoFlow", name = "Selección personalizada en columnas: repartir solas",
		  desc = "En vez de usar la columna de cada sección, se reparten solas. Con «Agrupar por secciones», cada sección entera va a la columna más corta; sin agrupar, las estadísticas a partes iguales." },
		{ type = "slider", key = "gridWidth", name = "Cuadrícula: ancho", min = 120, max = 1600, step = 10, format = R.fmt.int,
		  desc = "Solo con la forma «Cuadrícula de tamaño libre». También arrastrando la esquina del panel." },
		{ type = "toggle", key = "grouped", name = "Agrupar por secciones",
		  desc = "Con títulos y un hueco entre secciones. Desactivado, todas las estadísticas salen seguidas, sin títulos (con «Categorías enteras» el desplegable de cada columna queda en estas opciones)." },
		{ type = "slider", key = "gap", name = "Separación entre nombre y valor", min = 0, max = 80, step = 2, format = R.fmt.int,
		  desc = "Espacio mínimo entre el nombre o icono y su valor. El ancho del panel se ajusta solo." },
		{ type = "slider", key = "rowGap", name = "Separación entre filas", min = 0, max = 12, step = 1, format = R.fmt.int },
		{ type = "slider", key = "colGap", name = "Separación entre columnas", min = 0, max = 60, step = 2, format = R.fmt.int },

		{ type = "header", text = "Aspecto" },
		{ type = "slider", key = "scale", name = "Tamaño del panel", min = 0.6, max = 1.5, step = 0.05, format = R.fmt.percent },
		{ type = "slider", key = "fontSize", name = "Tamaño de letra", min = 9, max = 18, step = 1, format = R.fmt.int },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "dropdown", key = "label", name = "Cada estadística se muestra con",
		  values = {
			{ "name", "Su nombre" },
			{ "icon", "Su icono" },
			{ "both", "Icono y nombre" },
		  } },
		{ type = "dropdown", key = "decimals", name = "Decimales en los porcentajes",
		  values = { { "0", "Ninguno — 12%" }, { "1", "Uno — 12,3%" }, { "2", "Dos — 12,34%" } } },
		{ type = "dropdown", key = "profFormat", name = "Profesiones: cómo se muestran",
		  values = {
			{ "rank", "Actual — 150" },
			{ "rankMax", "Actual / máximo — 150 / 225" },
			{ "pct", "Porcentaje del máximo — 67%" },
			{ "rankMaxPct", "Actual / máximo y porcentaje — 150 / 225 (67%)" },
		  },
		  desc = "El máximo es el de tu rango actual (aprendiz 75, oficial 150, experto 225, artesano 300). Solo salen las profesiones que conoces; se añaden con la categoría «Profesiones» en una columna o en el editor." },
		{ type = "toggle", key = "showMods", name = "Beneficios y perjuicios entre paréntesis",
		  desc = "Al lado del total, lo que suman los beneficios y restan los perjuicios: 55 (+10 -3). Así no hace falta pasar el ratón." },
		{ type = "toggle", key = "colorBuffs", name = "Verde si está mejorado, rojo si está reducido",
		  desc = "Colorea los valores que suben o bajan por beneficios y perjuicios." },
		{ type = "toggle", key = "tooltips", name = "Detalles al pasar el ratón" },
		{ type = "dropdown", key = "panelButtons", name = "Engranaje y candado del panel",
		  values = {
			{ "show", "Siempre visibles" },
			{ "hover", "Al pasar el ratón por el panel" },
			{ "hide", "Ocultos" },
		  },
		  desc = "Ocultos: el editor se abre con el botón «Editar» de arriba, y el candado sigue como lo dejaste (bloqueado o no)." },

		{ type = "header", text = "Posición" },
		{ type = "dropdown", key = "anchor", name = "Posición",
		  values = {
			{ "character", "Pegado a la ventana del personaje" },
			{ "free", "Donde yo quiera" },
		  },
		  desc = "Donde yo quiera: se mueve con «Bloquear posición» desactivado o con /rz mover." },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Solo con «Donde yo quiera»." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

		{ type = "header", text = "Cuándo se ve" },
		{ type = "dropdown", key = "visibility", name = "Mostrar",
		  values = {
			{ "character", "Solo con la ventana del personaje" },
			{ "always", "Siempre" },
			{ "rules", "Según las condiciones de abajo" },
			{ "mouseover", "Al pasar el ratón por encima" },
		  },
		  desc = "Con «Siempre», con condiciones o al pasar el ratón conviene ponerlo en «Donde yo quiera», para tenerlo a la vista sin la ventana del personaje." },
		{ type = "slider", key = "hiddenAlpha", name = "Opacidad sin el ratón encima", min = 0, max = 0.8, step = 0.05,
		  desc = "Con «Al pasar el ratón por encima» (o la condición de ratón de abajo), lo que se ve el panel sin el ratón. 0% = invisible." },
		{ type = "toggle", key = "withCharacter", name = "Condiciones: mostrar siempre con la ventana del personaje",
		  desc = "Aunque no se cumplan las condiciones." },
		{ type = "dropdown", key = "vCombat", name = "Condiciones: combate",
		  values = {
			{ "any", "Dentro y fuera de combate" },
			{ "combat", "Solo en combate" },
			{ "nocombat", "Solo fuera de combate" },
		  } },
		{ type = "toggle", key = "vSolo", name = "Condiciones: yendo solo" },
		{ type = "toggle", key = "vParty", name = "Condiciones: en grupo" },
		{ type = "toggle", key = "vRaid", name = "Condiciones: en banda" },
		{ type = "toggle", key = "vInstance", name = "Condiciones: solo dentro de mazmorras y bandas",
		  desc = "Además de lo anterior, solo dentro de una estancia." },
		{ type = "toggle", key = "vTarget", name = "Condiciones: solo con objetivo" },
		{ type = "toggle", key = "vMounted", name = "Condiciones: ocultar al ir montado" },
		{ type = "toggle", key = "vHover", name = "Condiciones: si no se cumplen, aparecer al pasar el ratón",
		  desc = "El panel sigue en su sitio (con la opacidad sin ratón de arriba) y se ve al poner el ratón encima." },

		{ type = "header", text = "Avanzado" },
		{ type = "toggle", key = "hideBlizzard", name = "Ocultar las estadísticas de Blizzard",
		  desc = "Quita el panel de estadísticas propio de la ventana del personaje. Al volver a activarlas hace falta /reload." },
	},
	unsupported = {
		"En combate el juego oculta tus estadísticas a los addons: algunas se siguen viendo al día pero sin detalles ni colores, y el resto muestra en gris su valor de antes del combate.",
	},
})

local db
local GREEN, RED, WHITE = "|cff40ff40", "|cffff4040", "|cffffffff"

----------------------------------------------------------------------
-- Lectura segura: cualquier función puede faltar en esta versión o
-- devolver valores secretos
----------------------------------------------------------------------

-- En combate el juego da muchas estadísticas como valores secretos: se
-- apunta si alguno lo era, para no mostrar un resultado incompleto
local sawSecret = false

-- (El Lua de WoW es 5.1: no hay table.pack, se cuenta con select("#"))
local function pack(...)
	return { n = select("#", ...), ... }
end

local function get(fn, ...)
	if type(fn) ~= "function" then return end
	local r = pack(pcall(fn, ...))
	if not r[1] then return end
	for i = 2, r.n do
		local v = r[i]
		r[i] = NS(v)
		if v ~= nil and r[i] == nil then sawSecret = true end
	end
	return unpack(r, 2, r.n)
end

-- Un valor tal cual (puede ser secreto): solo sirve para dibujarlo
local function rawGet(fn, index, ...)
	if type(fn) ~= "function" then return end
	local r = pack(pcall(fn, ...))
	if r[1] then return r[index + 1] end
end

local function num(v) return type(v) == "number" and v or nil end

local function pct(v)
	v = num(v)
	if not v then return "—" end
	return string.format("%." .. (tonumber(db.decimals) or 2) .. "f%%", v)
end

local function int(v)
	v = num(v)
	if not v then return "—" end
	return tostring(math.floor(v + 0.5))
end

-- Color según beneficios (pos) y perjuicios (neg)
local function buffColor(pos, neg)
	if not db.colorBuffs then return WHITE end
	if num(neg) and neg < 0 then return RED end
	if num(pos) and pos > 0 then return GREEN end
	return WHITE
end

-- Reducción de daño físico de la armadura contra un enemigo de tu nivel
-- (la del juego si existe, como en su ventana del personaje)
local function armorReduction(armor)
	local level = NS(UnitLevel("player")) or 60
	local eff = C_PaperDollInfo and num(get(C_PaperDollInfo.GetArmorEffectiveness, armor, level))
	if eff then return eff * 100 end
	local k = level < 60 and (400 + 85 * level) or (467.5 * level - 22167.5)
	return armor / (armor + k) * 100
end

-- Habilidad con el arma de una ranura, como la calcula la ventana del
-- personaje de Blizzard (WoW Forever no tiene UnitAttackBothHands ni
-- UnitRangedAttack): tipo de arma -> línea de habilidad -> C_SkillInfo
local WEAPON_SKILL = {}
if Enum and Enum.ItemWeaponSubclass then
	local W = Enum.ItemWeaponSubclass
	for sub, skill in pairs({
		Sword1H = 43, Axe1H = 44, Bows = 45, Guns = 46, Mace1H = 54, Sword2H = 55, Staff = 136,
		Mace2H = 160, Axe2H = 172, Dagger = 173, Thrown = 176, Crossbow = 226, Wand = 228,
		Polearm = 229, Unarmed = 162,
	}) do
		if W[sub] then WEAPON_SKILL[W[sub]] = skill end
	end
end
local FERAL_SKILL, UNARMED_SKILL = 3014, 162

-- Valor (rango + bonificación) de la ranura 16, 17 o 18; nil si no lleva arma
local function weaponSkill(slot)
	if not (C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID) then return end
	local skillID
	if slot ~= 18 and R:PlayerClass() == "DRUID" and (num(get(GetShapeshiftForm)) or 0) ~= 0 then
		skillID = FERAL_SKILL
	else
		local itemID = GetInventoryItemID and GetInventoryItemID("player", slot)
		if not itemID then
			if slot ~= 16 then return end
			skillID = UNARMED_SKILL
		else
			local getInfo = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
			local _, _, _, _, _, classID, subclassID = get(getInfo, itemID)
			if Enum and Enum.ItemClass and classID ~= Enum.ItemClass.Weapon then return end
			skillID = WEAPON_SKILL[subclassID or -1]
		end
	end
	if not skillID then return end
	local info = get(C_SkillInfo.GetSkillLineInfoByID, skillID)
	if type(info) ~= "table" or not num(info.rank) then return end
	return info.rank + (num(info.modifier) or 0)
end

-- Total con los beneficios y perjuicios al lado: "55 (+10 -3)"
local function withMods(text, pos, neg)
	if not db.showMods then return text end
	local parts = {}
	if num(pos) and pos > 0 then parts[#parts + 1] = GREEN .. "+" .. int(pos) .. "|r" end
	if num(neg) and neg < 0 then parts[#parts + 1] = RED .. int(neg) .. "|r" end
	if #parts == 0 then return text end
	return text .. " |cffaaaaaa(|r" .. table.concat(parts, " ") .. "|cffaaaaaa)|r"
end

local function weaponDps(minD, maxD, speed)
	if not num(minD) or not num(maxD) or not num(speed) or speed <= 0 then return end
	return (minD + maxD) / 2 / speed
end

local function range(minD, maxD)
	return string.format("%d - %d", minD, maxD + 0.5)
end

local function short(v)
	if AbbreviateNumbers then
		local ok, text = pcall(AbbreviateNumbers, v)
		if ok and text then return text end
	end
	return int(v)
end

-- Escuelas de magia de GetSpellBonusDamage / GetSpellCritChance
local SCHOOLS = { [2] = "Sagrado", [3] = "Fuego", [4] = "Naturaleza", [5] = "Escarcha", [6] = "Sombras", [7] = "Arcano" }

----------------------------------------------------------------------
-- Registro de estadísticas. Cada una tiene un id ("melee.crit"), su
-- categoría, su nombre y una función que devuelve el texto y, si quiere,
-- líneas de detalle { { izquierda, derecha }, … }
----------------------------------------------------------------------

local STATS = {}       -- id -> { cat, name, fn }
local CAT_STATS = {}   -- categoría -> { ids en su orden }

local function def(cat, key, name, fn)
	local id = cat .. "." .. key
	STATS[id] = { cat = cat, name = name, fn = fn }
	CAT_STATS[cat] = CAT_STATS[cat] or {}
	table.insert(CAT_STATS[cat], id)
end

local function primaryStat(i)
	return function()
		local base, stat, pos, neg = get(UnitStat, "player", i)
		if not num(stat) then return "—" end
		local lines = { { L["Base"], int(base) } }
		if num(pos) and pos > 0 then lines[#lines + 1] = { L["Beneficios"], GREEN .. "+" .. int(pos) } end
		if num(neg) and neg < 0 then lines[#lines + 1] = { L["Perjuicios"], RED .. int(neg) } end
		return withMods(buffColor(pos, neg) .. int(stat) .. "|r", pos, neg), lines
	end
end

local function armorStat()
	local base, effective, _, pos, neg = get(UnitArmor, "player")
	effective = num(effective) or num(base)
	if not effective then return "—" end
	return withMods(buffColor(pos, neg) .. int(effective) .. "|r", pos, neg), {
		{ L["Reducción de daño físico"], string.format("%.1f%%", armorReduction(effective)) },
		{ "|cffaaaaaa" .. L["Contra un enemigo de tu nivel."] .. "|r", "" },
	}
end

local function bySchool(fn, format)
	local best, lines = 0, {}
	for school = 2, 7 do
		local v = num(get(fn, school)) or 0
		best = math.max(best, v)
		lines[#lines + 1] = { L[SCHOOLS[school]], format(v) }
	end
	return format(best), lines
end

-- Atributos
def("base", "str", "Fuerza", primaryStat(1))
def("base", "agi", "Agilidad", primaryStat(2))
def("base", "sta", "Aguante", primaryStat(3))
def("base", "int", "Intelecto", primaryStat(4))
def("base", "spi", "Espíritu", primaryStat(5))
def("base", "armor", "Armadura", armorStat)

-- Cuerpo a cuerpo
def("melee", "damage", "Daño", function()
	local minD, maxD, minOff, maxOff, pos, neg = get(UnitDamage, "player")
	if not num(minD) or not num(maxD) then return "—" end
	local lines
	if num(minOff) and num(maxOff) and minOff > 0 then
		lines = { { L["Mano izquierda"], range(minOff, maxOff) } }
	end
	return buffColor(pos, neg) .. range(minD, maxD), lines
end)
def("melee", "speed", "Velocidad", function()
	local main, off = get(UnitAttackSpeed, "player")
	if not num(main) then return "—" end
	if num(off) and off > 0 then return string.format("%.2f / %.2f", main, off) end
	return string.format("%.2f", main)
end)
def("melee", "dps", "Daño por segundo", function()
	local minD, maxD, minOff, maxOff = get(UnitDamage, "player")
	local main, off = get(UnitAttackSpeed, "player")
	local dps = weaponDps(minD, maxD, main)
	if not dps then return "—" end
	local offDps = weaponDps(minOff, maxOff, off)
	if offDps and offDps > 0 then
		return string.format("%.1f", dps + offDps), {
			{ L["Mano derecha"], string.format("%.1f", dps) },
			{ L["Mano izquierda"], string.format("%.1f", offDps) },
		}
	end
	return string.format("%.1f", dps)
end)
def("melee", "ap", "Poder de ataque", function()
	local base, pos, neg = get(UnitAttackPower, "player")
	if not num(base) then return "—" end
	local total = base + (num(pos) or 0) + (num(neg) or 0)
	return withMods(buffColor(pos, neg) .. int(total) .. "|r", pos, neg), {
		{ L["Daño por segundo extra"], string.format("%.1f", total / 14) },
	}
end)
def("melee", "hit", "Golpe", function() return pct(get(GetHitModifier)) end)
def("melee", "crit", "Crítico", function() return pct(get(GetCritChance)) end)
def("melee", "skill", "Habilidad con arma", function()
	local main = weaponSkill(16)
	if not main then return "—" end
	local off = weaponSkill(17)
	if off then return int(main) .. " / " .. int(off) end
	return int(main)
end)

-- A distancia
def("ranged", "damage", "Daño", function()
	local speed, minD, maxD, pos, neg = get(UnitRangedDamage, "player")
	if not num(speed) or speed <= 0 or not num(minD) or not num(maxD) then return "—" end
	return buffColor(pos, neg) .. range(minD, maxD)
end)
def("ranged", "speed", "Velocidad", function()
	local speed = get(UnitRangedDamage, "player")
	if not num(speed) or speed <= 0 then return "—" end
	return string.format("%.2f", speed)
end)
def("ranged", "dps", "Daño por segundo", function()
	local speed, minD, maxD = get(UnitRangedDamage, "player")
	local dps = weaponDps(minD, maxD, speed)
	return dps and string.format("%.1f", dps) or "—"
end)
def("ranged", "ap", "Poder de ataque", function()
	local base, pos, neg = get(UnitRangedAttackPower, "player")
	if not num(base) then return "—" end
	return withMods(buffColor(pos, neg) .. int(base + (num(pos) or 0) + (num(neg) or 0)) .. "|r", pos, neg)
end)
def("ranged", "hit", "Golpe", function() return pct(get(GetHitModifier)) end)
def("ranged", "crit", "Crítico", function() return pct(get(GetRangedCritChance)) end)
def("ranged", "skill", "Habilidad con arma", function()
	return int(weaponSkill(18))
end)

-- Hechizos
def("spell", "damage", "Daño con hechizos", function() return bySchool(GetSpellBonusDamage, int) end)
def("spell", "healing", "Sanación", function() return int(get(GetSpellBonusHealing)) end)
def("spell", "hit", "Golpe", function() return pct(get(GetSpellHitModifier)) end)
def("spell", "crit", "Crítico", function() return bySchool(GetSpellCritChance, pct) end)
def("spell", "regen", "Regeneración de maná", function()
	local notCasting, casting = get(GetManaRegen)
	if not num(notCasting) then return "—" end
	casting = num(casting) or 0
	return string.format("%d / %d", notCasting * 5 + 0.5, casting * 5 + 0.5), {
		{ L["Maná cada 5 s sin lanzar"], int(notCasting * 5) },
		{ L["Maná cada 5 s lanzando"], int(casting * 5) },
	}
end)

-- Defensa
def("defense", "armor", "Armadura", armorStat)
-- (UnitDefense no existe en WoW Forever; Blizzard usa UnitDefenseSkill)
def("defense", "defense", "Defensa", function()
	local base, mod = get(UnitDefenseSkill, "player")
	if not num(base) then return "—" end
	return withMods(buffColor(mod, mod) .. int(base + (num(mod) or 0)) .. "|r", mod, mod)
end)
def("defense", "dodge", "Esquivar", function() return pct(get(GetDodgeChance)) end)
def("defense", "parry", "Parar", function() return pct(get(GetParryChance)) end)
def("defense", "block", "Bloquear", function() return pct(get(GetBlockChance)) end)
def("defense", "blockValue", "Valor de bloqueo", function()
	local v = num(get(GetShieldBlock))
	return v and v > 0 and int(v) or "—"
end)

-- Resistencias (UnitResistance: 2 fuego, 3 naturaleza, 4 escarcha, 5 sombras, 6 arcano)
for _, r in ipairs({ { 2, "fire", "Fuego" }, { 3, "nature", "Naturaleza" }, { 4, "frost", "Escarcha" }, { 5, "shadow", "Sombras" }, { 6, "arcane", "Arcano" } }) do
	def("resist", r[2], r[3], function()
		local base, total, bonus, minus = get(UnitResistance, "player", r[1])
		total = num(total) or num(base)
		if not total then return "—" end
		return withMods(buffColor(bonus, minus) .. int(total) .. "|r", bonus, minus)
	end)
end

-- Varios
local function maxLevel()
	return get(GetMaxLevelForPlayerExpansion) or get(GetMaxPlayerLevel) or MAX_PLAYER_LEVEL or 60
end
local function atMaxLevel()
	local level = NS(UnitLevel("player"))
	return level and level >= maxLevel()
end

def("misc", "level", "Nivel", function() return int(NS(UnitLevel("player"))) end)
def("misc", "xp", "Experiencia", function()
	if atMaxLevel() then return "|cff888888" .. L["nivel máximo"] .. "|r" end
	local xp, max = num(get(UnitXP, "player")), num(get(UnitXPMax, "player"))
	if not xp or not max or max <= 0 then return "—" end
	return pct(xp / max * 100), {
		{ L["Actual"], short(xp) .. " / " .. short(max) },
		{ L["Falta para subir"], short(max - xp) },
	}
end)
def("misc", "rested", "Descanso", function()
	if atMaxLevel() then return "—" end
	local rested, max = num(get(GetXPExhaustion)) or 0, num(get(UnitXPMax, "player"))
	if not max or max <= 0 then return "—" end
	return pct(rested / max * 100), {
		{ L["Experiencia de descanso"], short(rested) },
		{ "|cffaaaaaa" .. L["Hasta 150% de un nivel."] .. "|r", "" },
	}
end)
def("misc", "health", "Vida máxima", function() return short(num(get(UnitHealthMax, "player"))) end)
def("misc", "power", "Maná / energía máxima", function() return short(num(get(UnitPowerMax, "player"))) end)
def("misc", "moveSpeed", "Velocidad de movimiento", function()
	local current, run = get(GetUnitSpeed, "player")
	local speed = (num(current) and current > 0) and current or num(run)
	if not speed then return "—" end
	return pct(speed / 7 * 100)
end)
def("misc", "durability", "Durabilidad", function()
	local cur, max, lowest = 0, 0, nil
	for slot = 1, 19 do
		local c, m = get(GetInventoryItemDurability, slot)
		if num(c) and num(m) and m > 0 then
			cur, max = cur + c, max + m
			lowest = math.min(lowest or 1, c / m)
		end
	end
	if max == 0 then return "—" end
	return pct(cur / max * 100), { { L["Pieza más dañada"], pct((lowest or 1) * 100) } }
end)
def("misc", "ilvl", "Nivel de objeto medio", function()
	local avg, equipped = get(GetAverageItemLevel)
	equipped = num(equipped) or num(avg)
	if not equipped or equipped <= 0 then return "—" end
	return string.format("%.1f", equipped)
end)

-- Profesiones (líneas de habilidad). Las que no conoces no salen en el panel
local function profInfo(skillID)
	if not (C_SkillInfo and C_SkillInfo.GetSkillLineInfoByID) then return end
	local info = get(C_SkillInfo.GetSkillLineInfoByID, skillID)
	if type(info) ~= "table" or not num(info.rank) or info.rank <= 0 then return end
	return info
end

local function profText(info)
	local rank, max, bonus = info.rank, num(info.maxRank) or 0, num(info.modifier) or 0
	local color = bonus > 0 and buffColor(bonus) or WHITE
	local current = color .. int(rank + bonus) .. "|r"
	local share = max > 0 and string.format("%d%%", rank / max * 100) or "—"
	local fmt = db.profFormat
	if fmt == "rank" then return current end
	if fmt == "pct" then return share end
	local text = current .. " / " .. int(max)
	if fmt == "rankMaxPct" then text = text .. " |cffaaaaaa(" .. share .. ")|r" end
	return text
end

local PROFESSIONS = {
	{ "alchemy", 171, "Alquimia", "Trade_Alchemy" },
	{ "blacksmithing", 164, "Herrería", "Trade_BlackSmithing" },
	{ "enchanting", 333, "Encantamiento", "Trade_Engraving" },
	{ "engineering", 202, "Ingeniería", "Trade_Engineering" },
	{ "herbalism", 182, "Herboristería", "Trade_Herbalism" },
	{ "leatherworking", 165, "Peletería", "Trade_LeatherWorking" },
	{ "mining", 186, "Minería", "Trade_Mining" },
	{ "skinning", 393, "Desuello", "INV_Misc_Pelt_Wolf_01" },
	{ "tailoring", 197, "Sastrería", "Trade_Tailoring" },
	{ "cooking", 185, "Cocina", "INV_Misc_Food_15" },
	{ "firstaid", 129, "Primeros auxilios", "Spell_Holy_SealOfSacrifice" },
	{ "fishing", 356, "Pesca", "Trade_Fishing" },
	{ "lockpicking", 633, "Forzar cerraduras", "Spell_Nature_MoonKey" },
}
for _, p in ipairs(PROFESSIONS) do
	local skillID = p[2]
	def("prof", p[1], p[3], function()
		local info = profInfo(skillID)
		if not info then return "—" end
		local rank, max, bonus = info.rank, num(info.maxRank) or 0, num(info.modifier) or 0
		local lines = { { L["Actual"], int(rank) .. " / " .. int(max) } }
		if bonus > 0 then lines[#lines + 1] = { L["Bonificación"], GREEN .. "+" .. int(bonus) } end
		if max > rank then lines[#lines + 1] = { L["Falta para el máximo"], int(max - rank) } end
		return profText(info), lines
	end)
	STATS["prof." .. p[1]].known = function() return profInfo(skillID) ~= nil end
end

-- Monedas y JcJ. Cada versión del juego tiene unas funciones distintas: lo
-- que no existe (o no tienes) no sale en el panel. Las monedas de la lista
-- del juego (pestaña Monedas) se añaden solas al verlas (ScanCurrencies).
local HONOR_ID, ARENA_ID = 1901, 1900

local function currencyInfo(id)
	if not (C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo) then return end
	local info = get(C_CurrencyInfo.GetCurrencyInfo, id)
	if type(info) == "table" and type(info.name) == "string" and info.name ~= "" then return info end
end

local function currencyText(info)
	local q, max = num(info.quantity) or 0, num(info.maxQuantity) or 0
	local lines = {}
	local week, weekMax = num(info.quantityEarnedThisWeek), num(info.maxWeeklyQuantity)
	if weekMax and weekMax > 0 then lines[#lines + 1] = { L["Esta semana"], int(week or 0) .. " / " .. int(weekMax) } end
	if max > 0 then lines[#lines + 1] = { L["Máximo"], int(max) } end
	local total = num(info.totalEarned)
	if total and total > 0 then lines[#lines + 1] = { L["Conseguido en total"], int(total) } end
	return (max > 0 and (int(q) .. " / " .. int(max)) or int(q)), lines
end

local function pointsStat(oldFn, id)
	return function()
		local v = num(get(oldFn))
		if v then return int(v) end
		local info = currencyInfo(id)
		if info then return currencyText(info) end
		return "—"
	end, function()
		return num(get(oldFn)) ~= nil or currencyInfo(id) ~= nil
	end
end

def("currency", "gold", "Oro", function() return R.Money(num(get(GetMoney)) or 0) end)

-- El honor no se oculta aunque el juego aún no dé la moneda: al entrar (antes
-- de cargar las monedas) o con 0 puntos GetCurrencyInfo puede venir vacío
local honorFn = pointsStat(GetHonorCurrency, HONOR_ID)
def("currency", "honor", "Puntos de honor", function()
	local text, lines = honorFn()
	if text ~= "—" then return text, lines end
	local v = num(get(UnitHonor, "player"))
	return int(v or 0)
end)
STATS["currency.honor"].known = function()
	return GetHonorCurrency ~= nil or (C_CurrencyInfo and C_CurrencyInfo.GetCurrencyInfo) ~= nil or UnitHonor ~= nil
end
local arenaFn, arenaKnown = pointsStat(GetArenaCurrency, ARENA_ID)
def("currency", "arena", "Puntos de arena", arenaFn)
STATS["currency.arena"].known = arenaKnown

def("currency", "kills", "Muertes con honor", function()
	local hk = num(get(GetPVPLifetimeStats))
	if not hk then return "—" end
	local lines = {}
	local todayHK, todayHonor = get(GetPVPSessionStats)
	if num(todayHK) then
		lines[#lines + 1] = { L["Hoy"], int(todayHK) .. (num(todayHonor) and ("  |cffaaaaaa(" .. int(todayHonor) .. " " .. L["honor"] .. ")|r") or "") }
	end
	local weekHK, weekHonor = get(GetPVPThisWeekStats)
	if num(weekHK) then
		lines[#lines + 1] = { L["Esta semana"], int(weekHK) .. (num(weekHonor) and ("  |cffaaaaaa(" .. int(weekHonor) .. " " .. L["honor"] .. ")|r") or "") }
	end
	local _, dk = get(GetPVPLifetimeStats)
	if num(dk) and dk > 0 then lines[#lines + 1] = { L["Muertes deshonrosas"], int(dk) } end
	return int(hk), lines
end)
STATS["currency.kills"].known = function() return num(get(GetPVPLifetimeStats)) ~= nil end

local function rankName(rank)
	local name, number = get(GetPVPRankInfo, rank)
	if type(name) == "string" and name ~= "" and (num(number) or 1) > 0 then return name end
end
def("currency", "rank", "Rango JcJ", function()
	local rank = num(get(UnitPVPRank, "player"))
	if not rank then return "—" end
	local name = rankName(rank)
	local lines = {}
	local progress = num(get(GetPVPRankProgress))
	if name and progress then lines[#lines + 1] = { L["Progreso al siguiente rango"], pct(progress * 100) } end
	local _, _, highest = get(GetPVPLifetimeStats)
	local best = num(highest) and rankName(highest)
	if best then lines[#lines + 1] = { L["Rango más alto"], best } end
	return name or ("|cff888888" .. L["Sin rango"] .. "|r"), lines
end)
STATS["currency.rank"].known = function() return num(get(UnitPVPRank, "player")) ~= nil end

-- Iconos (texturas del juego clásico)
local ICONS = {
	["base.str"] = "Spell_Nature_Strength",
	["base.agi"] = "Ability_Rogue_Sprint",
	["base.sta"] = "Spell_Holy_WordFortitude",
	["base.int"] = "Spell_Holy_MagicalSentry",
	["base.spi"] = "Spell_Holy_DivineSpirit",
	["base.armor"] = "INV_Chest_Plate01",
	["melee.damage"] = "INV_Sword_04",
	["melee.speed"] = "INV_Misc_PocketWatch_01",
	["melee.dps"] = "Ability_DualWield",
	["melee.ap"] = "Ability_Warrior_BattleShout",
	["melee.hit"] = "Ability_Marksmanship",
	["melee.crit"] = "Ability_CriticalStrike",
	["melee.skill"] = "INV_Sword_27",
	["ranged.damage"] = "INV_Weapon_Bow_07",
	["ranged.speed"] = "INV_Misc_PocketWatch_01",
	["ranged.dps"] = "Ability_Hunter_RunningShot",
	["ranged.ap"] = "Ability_TrueShot",
	["ranged.hit"] = "Ability_Marksmanship",
	["ranged.crit"] = "Ability_Hunter_AimedShot",
	["ranged.skill"] = "INV_Weapon_Bow_05",
	["spell.damage"] = "Spell_Fire_FireBolt02",
	["spell.healing"] = "Spell_Holy_GreaterHeal",
	["spell.hit"] = "Spell_Holy_SearingLight",
	["spell.crit"] = "Spell_Fire_SoulBurn",
	["spell.regen"] = "Spell_Nature_ManaRegenTotem",
	["defense.armor"] = "Spell_Holy_DevotionAura",
	["defense.defense"] = "Ability_Defend",
	["defense.dodge"] = "Ability_Rogue_Feint",
	["defense.parry"] = "Ability_Parry",
	["defense.block"] = "INV_Shield_05",
	["defense.blockValue"] = "INV_Shield_06",
	["resist.fire"] = "Spell_Fire_FireArmor",
	["resist.nature"] = "Spell_Nature_ProtectionformNature",
	["resist.frost"] = "Spell_Frost_FrostWard",
	["resist.shadow"] = "Spell_Shadow_AntiShadow",
	["resist.arcane"] = "Spell_Nature_StarFall",
	["misc.level"] = "INV_Misc_Book_09",
	["misc.xp"] = "INV_Misc_Book_11",
	["misc.rested"] = "Spell_Nature_Sleep",
	["misc.health"] = "INV_Potion_54",
	["misc.power"] = "INV_Potion_76",
	["misc.moveSpeed"] = "Ability_Rogue_Sprint",
	["misc.durability"] = "Trade_BlackSmithing",
	["misc.ilvl"] = "INV_Chest_Chain_05",
	["currency.gold"] = "INV_Misc_Coin_01",
	["currency.honor"] = "INV_BannerPVP_02",
	["currency.arena"] = "Ability_Warrior_OffensiveStance",
	["currency.kills"] = "Ability_Warrior_Challange",
	["currency.rank"] = "Spell_Holy_SealOfMight",
}
for _, p in ipairs(PROFESSIONS) do ICONS["prof." .. p[1]] = p[4] end
for id, icon in pairs(ICONS) do
	if STATS[id] then STATS[id].icon = "Interface\\Icons\\" .. icon end
end

-- Valores que el juego deja dibujar aunque sean secretos (sin operar con
-- ellos): así siguen al día en combate. Devuelven formato y valor.
local function pctFormat() return "%." .. (tonumber(db.decimals) or 2) .. "f%%" end
local RAW = {
	["base.armor"] = function() return "%d", rawGet(UnitArmor, 2, "player") end,
	["defense.armor"] = function() return "%d", rawGet(UnitArmor, 2, "player") end,
	["melee.hit"] = function() return pctFormat(), rawGet(GetHitModifier, 1) end,
	["melee.crit"] = function() return pctFormat(), rawGet(GetCritChance, 1) end,
	["ranged.hit"] = function() return pctFormat(), rawGet(GetHitModifier, 1) end,
	["ranged.crit"] = function() return pctFormat(), rawGet(GetRangedCritChance, 1) end,
	["spell.healing"] = function() return "%d", rawGet(GetSpellBonusHealing, 1) end,
	["spell.hit"] = function() return pctFormat(), rawGet(GetSpellHitModifier, 1) end,
	["defense.dodge"] = function() return pctFormat(), rawGet(GetDodgeChance, 1) end,
	["defense.parry"] = function() return pctFormat(), rawGet(GetParryChance, 1) end,
	["defense.block"] = function() return pctFormat(), rawGet(GetBlockChance, 1) end,
	["defense.blockValue"] = function() return "%d", rawGet(GetShieldBlock, 1) end,
	["misc.level"] = function() return "%d", rawGet(UnitLevel, 1, "player") end,
	["misc.health"] = function() return "%d", rawGet(UnitHealthMax, 1, "player") end,
	["misc.power"] = function() return "%d", rawGet(UnitPowerMax, 1, "player") end,
}
for i, key in ipairs({ "str", "agi", "sta", "int", "spi" }) do
	RAW["base." .. key] = function() return "%d", rawGet(UnitStat, 2, "player", i) end
end
for school, key in pairs({ [2] = "fire", [3] = "nature", [4] = "frost", [5] = "shadow", [6] = "arcane" }) do
	RAW["resist." .. key] = function() return "%d", rawGet(UnitResistance, 2, "player", school) end
end
for id, fn in pairs(RAW) do
	if STATS[id] then STATS[id].raw = fn; STATS[id].id = id end
end
for id, stat in pairs(STATS) do stat.id = id end

-- Monedas de la lista del juego: se registran al verlas y se recuerdan
-- (db.currencies) para que estén desde el principio en la próxima sesión,
-- también en tus secciones personalizadas
local function addCurrency(id, name, icon)
	local key = "currency.c" .. id
	if STATS[key] or id == HONOR_ID or id == ARENA_ID then return false end
	def("currency", "c" .. id, name, function()
		local info = currencyInfo(id)
		if not info then return "—" end
		return currencyText(info)
	end)
	local stat = STATS[key]
	stat.id = key
	stat.icon = icon
	stat.known = function() return currencyInfo(id) ~= nil end
	return true
end

function M:ScanCurrencies()
	if type(db.currencies) ~= "table" then db.currencies = {} end
	local added = false
	for id, saved in pairs(db.currencies) do
		if type(saved) == "table" and addCurrency(tonumber(id) or id, saved.name or "?", saved.icon) then added = true end
	end
	if not (C_CurrencyInfo and C_CurrencyInfo.GetCurrencyListSize and C_CurrencyInfo.GetCurrencyListInfo) then return added end
	for i = 1, num(get(C_CurrencyInfo.GetCurrencyListSize)) or 0 do
		local info = get(C_CurrencyInfo.GetCurrencyListInfo, i)
		if type(info) == "table" and not info.isHeader and type(info.name) == "string" and info.name ~= "" then
			local id = num(info.currencyID)
			if not id and C_CurrencyInfo.GetCurrencyListLink then
				local link = get(C_CurrencyInfo.GetCurrencyListLink, i)
				id = type(link) == "string" and tonumber(link:match("currency:(%d+)")) or nil
			end
			if id then
				db.currencies[id] = { name = info.name, icon = num(info.iconFileID) or info.iconFileID }
				if addCurrency(id, info.name, info.iconFileID) then added = true end
			end
		end
	end
	return added
end

local CATEGORY_NAME = {}
for _, c in ipairs(CATEGORIES) do CATEGORY_NAME[c[1]] = c[2] end

-- Columna derecha "según la clase"
local function autoCategory()
	local class = R:PlayerClass()
	if class == "WARRIOR" or class == "ROGUE" then return "melee" end
	if class == "HUNTER" then return "ranged" end
	return "spell"
end

local MAX_COLUMNS = 12
local function numColumns()
	return math.max(1, math.min(MAX_COLUMNS, math.floor(tonumber(db.columns) or 2)))
end

-- Categoría de la columna i en "Una categoría por columna". Las columnas
-- 5 a 12 no tienen opción propia: si no se han elegido con su desplegable,
-- van rotando por las categorías
local function columnCategory(i)
	local cat = db["col" .. i]
	if cat == nil then cat = CATEGORIES[(i - 1) % #CATEGORIES + 1][1] end
	if cat == "auto" then cat = autoCategory() end
	return cat
end

local function copy(list)
	local t = {}
	for i, v in ipairs(list or {}) do t[i] = v end
	return t
end

-- Secciones del modo personalizado: { name = "", cat = "base", col = 1, stats = { ids } }
local function defaultSections()
	return {
		{ name = "", cat = "base", col = 1, stats = copy(CAT_STATS.base) },
		{ name = "", cat = "defense", col = 1, stats = copy(CAT_STATS.defense) },
		{ name = "", cat = autoCategory(), col = 2, stats = copy(CAT_STATS[autoCategory()]) },
		{ name = "", cat = "misc", col = 2, stats = { "misc.xp", "misc.rested", "misc.durability" } },
	}
end

local function ensureSections()
	if type(db.sections) ~= "table" then db.sections = defaultSections() end
	return db.sections
end

local function sectionTitle(sec)
	if sec.name and sec.name ~= "" then return sec.name end
	return L[CATEGORY_NAME[sec.cat] or sec.cat or ""]
end

----------------------------------------------------------------------
-- Panel
----------------------------------------------------------------------

local PAD = 8
local panel, mover, gear, grip, lockButton
local headers, rows = {}, {}
local usedHeaders, usedRows = 0, 0

local function rowHeight() return db.fontSize + 5 end

local function setFont(fs, size)
	fs:SetFont(STANDARD_TEXT_FONT, size or db.fontSize, "")
	fs:SetShadowOffset(1, -1)
	fs:SetShadowColor(0, 0, 0, 1)
end

local function showTooltip(self)
	if not db.tooltips or not self.statName then return end
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	GameTooltip:SetText(self.statName .. "  " .. (self.statValue or ""), 1, 1, 1)
	for _, l in ipairs(self.lines or {}) do
		GameTooltip:AddDoubleLine(l[1], l[2], 1, 0.82, 0, 1, 1, 1)
	end
	GameTooltip:Show()
end

local function getRow()
	usedRows = usedRows + 1
	local row = rows[usedRows]
	if not row then
		row = CreateFrame("Frame", nil, panel)
		row:EnableMouse(true)
		row.label = row:CreateFontString(nil, "OVERLAY")
		row.label:SetPoint("LEFT", 4, 0)
		row.label:SetJustifyH("LEFT")
		row.valueText = row:CreateFontString(nil, "OVERLAY")
		row.valueText:SetPoint("RIGHT", -4, 0)
		row.valueText:SetJustifyH("RIGHT")
		local hl = row:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(1, 1, 1, 0.06)
		row:SetScript("OnEnter", showTooltip)
		row:SetScript("OnLeave", GameTooltip_Hide)
		rows[usedRows] = row
	end
	row:ClearAllPoints()
	row:Show()
	setFont(row.label)
	setFont(row.valueText)
	row.label:SetTextColor(1, 0.82, 0)
	return row
end

local function openColumnMenu(self)
	local key = "col" .. self.column
	local values = self.column == 2 and COLUMN2_VALUES or COLUMN_VALUES
	local function pick(v)
		db[key] = v
		M:Refresh()
	end
	if R.UI and R.UI.OpenPopup then
		R.UI.OpenPopup(self, values, db[key] or columnCategory(self.column), pick)
	else
		-- Sin desplegable: pasa a la siguiente
		for i, v in ipairs(values) do
			if v[1] == db[key] then pick(values[i % #values + 1][1]) return end
		end
		pick(values[1][1])
	end
end

-- Título de sección; en "Dos columnas" es un botón que abre el desplegable
local function getHeader()
	usedHeaders = usedHeaders + 1
	local h = headers[usedHeaders]
	if not h then
		h = CreateFrame("Button", nil, panel)
		h.text = h:CreateFontString(nil, "OVERLAY")
		h.text:SetPoint("LEFT", 4, 0)
		h.text:SetPoint("RIGHT", -4, 0)
		h.text:SetJustifyH("LEFT")
		h.line = h:CreateTexture(nil, "ARTWORK")
		h.line:SetColorTexture(0.2, 0.8, 1, 0.4)
		h.line:SetHeight(1)
		h.line:SetPoint("BOTTOMLEFT", 2, 0)
		h.line:SetPoint("BOTTOMRIGHT", -2, 0)
		h.hl = h:CreateTexture(nil, "HIGHLIGHT")
		h.hl:SetAllPoints()
		h.hl:SetColorTexture(0.2, 0.8, 1, 0.12)
		h:SetScript("OnClick", function(self)
			if self.column then openColumnMenu(self) end
		end)
		headers[usedHeaders] = h
	end
	h:ClearAllPoints()
	h:Show()
	setFont(h.text, db.fontSize + 1)
	return h
end

-- Rellena una fila con su estadística
local lastGood = {}   -- id -> { texto, detalles }: el último valor legible

-- Ancho de un texto. Con un valor secreto dibujado el ancho también puede
-- llegar secreto: se estima
local function textWidth(fs)
	local ok, w = pcall(fs.GetStringWidth, fs)
	w = ok and NS(w)
	if type(w) == "number" then return w end
	return db.fontSize * 4
end

local function plain(text)
	return (text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

local function fillRow(row, stat)
	sawSecret = false
	local ok, value, lines = pcall(stat.fn)
	if not ok then value, lines = "—", nil end
	local secret = sawSecret

	-- El valor que se ve: normal, el secreto dibujado tal cual, o el último
	-- bueno en gris hasta salir de combate
	local drawn = false
	if not secret then
		if ok then lastGood[stat.id] = { value, lines } end
		row.valueText:SetText(value or "—")
	else
		if stat.raw then
			local fmt, v = stat.raw()
			if v ~= nil then
				drawn = pcall(row.valueText.SetFormattedText, row.valueText, fmt, v)
			end
		end
		local cached = lastGood[stat.id]
		if drawn then
			value, lines = nil, { { "|cffaaaaaa" .. L["En combate: sin detalles hasta salir."] .. "|r", "" } }
		elseif cached then
			value = "|cff999999" .. plain(cached[1] or "—") .. "|r"
			lines = { { "|cffaaaaaa" .. L["El juego oculta este valor en combate: es el de antes."] .. "|r", "" } }
			row.valueText:SetText(value)
		else
			value = "—"
			row.valueText:SetText(value)
		end
	end
	row.statName, row.statValue, row.lines, row.statId = L[stat.name], value, lines, stat.id
	-- Nombre, icono o los dos
	local size = db.fontSize + 2
	local icon = stat.icon and string.format("|T%s:%d:%d:0:0:64:64:5:59:5:59|t", stat.icon, size, size) or ""
	if db.label == "icon" and icon ~= "" then
		row.label:SetText(icon)
	elseif db.label == "both" and icon ~= "" then
		row.label:SetText(icon .. " " .. L[stat.name])
	else
		row.label:SetText(L[stat.name])
	end
end

-- Se dibuja en dos pasos: primero se rellenan las filas de cada columna,
-- luego se mide lo que ocupan los textos y se colocan. Así el ancho se ajusta
-- solo y la separación entre nombre y valor es la elegida.
function M:Refresh()
	if not panel or not panel:IsShown() then return end
	self:ScanCurrencies()
	for i = 1, #rows do rows[i]:Hide() end
	for i = 1, #headers do headers[i]:Hide() end
	usedRows, usedHeaders = 0, 0

	local rh = rowHeight()
	local n = numColumns()
	local arrange = db.arrange or "columns"
	grip:SetShown(arrange == "grid" and not db.frozen)
	lockButton:Update()
	lockButton:SetShown(db.panelButtons ~= "hide")

	-- 1) Secciones con sus marcos ya rellenos: { header, rows = {}, col }
	local sections = {}
	local function addSection(col, title, stats, dropdown)
		local sec = { col = col or 1, rows = {} }
		if db.grouped then
			local h = getHeader()
			h.column = dropdown
			h.text:SetText("|cff33ccff" .. title .. "|r" .. (dropdown and " |TInterface\\Buttons\\Arrow-Down-Up:0|t" or ""))
			-- Con el candado, el desplegable del título no se abre
			h:EnableMouse(dropdown ~= nil and not db.frozen)
			sec.header = h
		end
		for _, id in ipairs(stats) do
			local stat = STATS[id]
			-- Una profesión que no tienes no ocupa fila
			if stat and not (stat.known and not stat.known()) then
				local row = getRow()
				fillRow(row, stat)
				sec.rows[#sec.rows + 1] = row
			end
		end
		if sec.header or #sec.rows > 0 then sections[#sections + 1] = sec end
	end

	if db.layout == "custom" then
		for _, s in ipairs(ensureSections()) do addSection(s.col, sectionTitle(s), s.stats) end
	else
		-- Una categoría por columna (en vertical, horizontal o cuadrícula,
		-- una detrás de otra)
		for i = 1, n do
			local cat = columnCategory(i)
			addSection(i, L[CATEGORY_NAME[cat] or cat or ""], CAT_STATS[cat] or {}, i)
		end
	end

	-- Anchos: celda de estadística = nombre + separación + valor
	-- Bloqueado (candado): cada ancho se apunta la primera vez y luego se
	-- reutiliza, así los valores cambian sin mover nada de sitio
	local function fixed(key, computed)
		local f = db.frozen
		if type(f) ~= "table" then return computed end
		if f[key] == nil then f[key] = computed end
		return f[key]
	end

	local function rowWidth(row)
		return fixed("row:" .. (row.statId or "?"), textWidth(row.label) + db.gap + textWidth(row.valueText) + 8)
	end
	local function headerWidth(h)
		return textWidth(h.text) + 12
	end

	-- 2a) Vertical, horizontal y cuadrícula: celdas que avanzan de izquierda a
	-- derecha y saltan de línea cada "perLine" (nil = nunca)
	if arrange ~= "columns" then
		local cellW = 40
		for _, sec in ipairs(sections) do
			for _, row in ipairs(sec.rows) do cellW = math.max(cellW, rowWidth(row)) end
			if sec.header and arrange ~= "horizontal" then cellW = math.max(cellW, headerWidth(sec.header)) end
		end
		cellW = fixed("cell", cellW)
		local uniform = arrange ~= "horizontal"   -- en horizontal cada celda mide lo suyo
		local perLine
		if arrange == "vertical" then
			perLine = 1
		elseif arrange == "grid" then
			perLine = math.max(1, math.floor((db.gridWidth - PAD * 2 + db.colGap) / (cellW + db.colGap)))
		end
		local lineW = perLine and (perLine * cellW + (perLine - 1) * db.colGap) or 0

		local x, y, col, right = PAD, PAD, 0, PAD
		local function newLine()
			if col > 0 then y = y + rh + db.rowGap end
			x, col = PAD, 0
		end
		for si, sec in ipairs(sections) do
			if sec.header then
				if arrange == "horizontal" then
					-- Título dentro de la misma línea, antes de sus estadísticas
					if si > 1 then x = x + 10 end
					local w = headerWidth(sec.header)
					sec.header:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -y)
					sec.header:SetSize(w, rh)
					x = x + w + db.colGap
					right = math.max(right, x)
				else
					newLine()
					if si > 1 then y = y + 6 end
					sec.header:SetPoint("TOPLEFT", panel, "TOPLEFT", PAD, -y)
					sec.header:SetSize(lineW, rh + 4)
					y = y + rh + 6
				end
			end
			for _, row in ipairs(sec.rows) do
				if perLine and col >= perLine then newLine() end
				local w = uniform and cellW or rowWidth(row)
				row:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -y)
				row:SetSize(w, rh)
				x, col = x + w + db.colGap, col + 1
				right = math.max(right, x - db.colGap)
			end
		end
		if col > 0 then y = y + rh end
		local width = arrange == "grid" and db.gridWidth or (math.max(right, PAD + lineW) + PAD)
		panel:SetSize(math.max(width, 60), math.max(y, 30) + PAD)
		gear:SetShown(db.layout == "custom" and db.panelButtons ~= "hide")
		return
	end

	-- 2b) En columnas
	local cols = {}   -- elementos de cada columna, en orden
	for i = 1, n do cols[i] = {} end
	local function push(items, sec)
		if sec.header then items[#items + 1] = { header = sec.header } end
		for _, row in ipairs(sec.rows) do items[#items + 1] = { row = row } end
		if #items > 0 then items[#items].sectionEnd = true end
	end

	if db.layout == "custom" and db.autoFlow and n > 1 then
		if db.grouped then
			-- Secciones enteras, cada una a la columna que va más corta
			local heights = {}
			for i = 1, n do heights[i] = 0 end
			for _, sec in ipairs(sections) do
				local best = 1
				for i = 2, n do if heights[i] < heights[best] then best = i end end
				push(cols[best], sec)
				heights[best] = heights[best] + #sec.rows * (rh + db.rowGap) + (sec.header and rh + 12 or 0)
			end
		else
			-- Sin títulos: las estadísticas a partes iguales
			local all = {}
			for _, sec in ipairs(sections) do push(all, sec) end
			local per = math.ceil(#all / n)
			local c = 1
			for _, it in ipairs(all) do
				if #cols[c] >= per and c < n then c = c + 1 end
				table.insert(cols[c], it)
			end
		end
	else
		for _, sec in ipairs(sections) do
			push(cols[math.max(1, math.min(n, sec.col))], sec)
		end
	end

	-- Ancho de cada columna: el nombre más largo + separación + el valor más largo
	local function measure(items)
		local labelW, valueW, headerW = 0, 0, 0
		for _, it in ipairs(items) do
			if it.row then
				labelW = math.max(labelW, textWidth(it.row.label))
				valueW = math.max(valueW, textWidth(it.row.valueText))
			else
				headerW = math.max(headerW, textWidth(it.header.text) + 4)
			end
		end
		return math.max(labelW + db.gap + valueW, headerW, 40) + 8
	end

	local function place(items, x, width)
		local y = PAD
		for i, it in ipairs(items) do
			local f = it.header or it.row
			f:SetPoint("TOPLEFT", panel, "TOPLEFT", x, -y)
			if it.header then
				f:SetSize(width, rh + 4)
				y = y + rh + 6
			else
				f:SetSize(width, rh)
				y = y + rh + (i < #items and db.rowGap or 0)
			end
			if it.sectionEnd and i < #items and db.grouped then y = y + 6 end
		end
		return y
	end

	-- Columnas de izquierda a derecha; las vacías no ocupan sitio
	local x, bottom, right = PAD, 30, PAD
	for i = 1, n do
		if #cols[i] > 0 then
			local w = fixed("col" .. i, measure(cols[i]))
			bottom = math.max(bottom, place(cols[i], x, w))
			right = x + w
			x = right + db.colGap
		end
	end
	panel:SetSize(math.max(right + PAD, 60), bottom + PAD)
	gear:SetShown(db.layout == "custom" and db.panelButtons ~= "hide")
end

----------------------------------------------------------------------
-- Editor del modo personalizado
----------------------------------------------------------------------

local editor, editorList
local editorRows = {}
local ED_W, ED_ROW = 470, 24

local function changed()
	-- Si está bloqueado, los anchos se vuelven a tomar con el nuevo contenido
	if db.frozen then db.frozen = {} end
	M:DrawEditor()
	M:Refresh()
end

local function move(list, i, delta)
	local j = i + delta
	if j < 1 or j > #list then return end
	list[i], list[j] = list[j], list[i]
	changed()
end

local function iconButton(parent, texture, tip, onClick)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(18, 18)
	b:SetNormalTexture(texture)
	b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
	b:SetScript("OnClick", function(self) onClick(self) end)
	b:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(tip, 1, 1, 1)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", GameTooltip_Hide)
	return b
end

local function smallButton(parent, width, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width, 20)
	b:SetScript("OnClick", function(self) onClick(self) end)
	return b
end

local function popup(owner, values, onPick)
	if R.UI and R.UI.OpenPopup then R.UI.OpenPopup(owner, values, nil, onPick) end
end

-- Estadísticas que se pueden añadir a una sección: primero la categoría,
-- luego la estadística (o todas las que falten)
local function addStatMenu(owner, sec)
	popup(owner, COLUMN_VALUES, function(cat)
		local have = {}
		for _, id in ipairs(sec.stats) do have[id] = true end
		local values = {}
		for _, id in ipairs(CAT_STATS[cat] or {}) do
			if not have[id] then values[#values + 1] = { id, L[STATS[id].name] } end
		end
		if #values == 0 then return end
		table.insert(values, 1, { "__all", "|cff33ccff" .. L["Todas las que faltan"] .. "|r" })
		popup(owner, values, function(id)
			if id == "__all" then
				for i = 2, #values do sec.stats[#sec.stats + 1] = values[i][1] end
			else
				sec.stats[#sec.stats + 1] = id
			end
			changed()
		end)
	end)
end

local function newEditorRow(i)
	local r = CreateFrame("Frame", nil, editorList.child)
	r:SetHeight(ED_ROW)
	r:SetPoint("TOPLEFT", 0, -(i - 1) * ED_ROW)
	r:SetPoint("RIGHT", editorList.child, "RIGHT")

	r.bg = r:CreateTexture(nil, "BACKGROUND")
	r.bg:SetAllPoints()

	-- Sección: nombre editable, columna, añadir estadística
	r.title = CreateFrame("EditBox", nil, r, "BackdropTemplate")
	r.title:SetPoint("LEFT", 4, 0)
	r.title:SetSize(170, 20)
	r.title:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	r.title:SetBackdropColor(0, 0, 0, 0.6)
	r.title:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	r.title:SetFontObject(GameFontHighlightSmall)
	r.title:SetTextInsets(5, 5, 0, 0)
	r.title:SetAutoFocus(false)
	r.title:SetMaxLetters(30)
	local function commit(self)
		if not r.sec then return end
		local text = strtrim(self:GetText() or "")
		-- Si deja el nombre de la categoría, se guarda vacío (así se traduce)
		if text == L[CATEGORY_NAME[r.sec.cat] or ""] then text = "" end
		if text ~= (r.sec.name or "") then
			r.sec.name = text
			M:Refresh()
		end
	end
	r.title:SetScript("OnEnterPressed", function(self) commit(self); self:ClearFocus() end)
	r.title:SetScript("OnEditFocusLost", commit)
	r.title:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)

	r.col = smallButton(r, 80, function()
		-- Pasa a la siguiente columna (y de la última a la primera)
		local n = numColumns()
		r.sec.col = (math.min(r.sec.col or 1, n) % n) + 1
		changed()
	end)
	r.col:SetPoint("LEFT", r.title, "RIGHT", 6, 0)
	r.add = smallButton(r, 110, function(self) addStatMenu(self, r.sec) end)
	r.add:SetPoint("LEFT", r.col, "RIGHT", 4, 0)
	r.add:SetText(L["+ Estadística"])

	-- Estadística
	r.label = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.label:SetPoint("LEFT", 26, 0)
	r.label:SetJustifyH("LEFT")

	-- Flechas y quitar (valen para las dos)
	r.remove = iconButton(r, "Interface\\Buttons\\UI-GroupLoot-Pass-Up", L["Quitar"], function()
		table.remove(r.list, r.index)
		changed()
	end)
	r.remove:SetPoint("RIGHT", -4, 0)
	r.down = iconButton(r, "Interface\\Buttons\\Arrow-Down-Up", L["Bajar"], function() move(r.list, r.index, 1) end)
	r.down:SetPoint("RIGHT", r.remove, "LEFT", -4, 0)
	r.up = iconButton(r, "Interface\\Buttons\\Arrow-Up-Up", L["Subir"], function() move(r.list, r.index, -1) end)
	r.up:SetPoint("RIGHT", r.down, "LEFT", -2, 0)

	editorRows[i] = r
	return r
end

function M:DrawEditor()
	if not editor or not editor:IsShown() then return end
	local sections = ensureSections()
	local n = 0
	local function row()
		n = n + 1
		local r = editorRows[n] or newEditorRow(n)
		r:Show()
		return r
	end
	for si, sec in ipairs(sections) do
		local r = row()
		r.sec, r.list, r.index = sec, sections, si
		r.bg:SetColorTexture(0.2, 0.8, 1, 0.15)
		r.title:Show(); r.col:Show(); r.add:Show(); r.label:Hide()
		if not r.title:HasFocus() then r.title:SetText(sectionTitle(sec)) end
		local n = numColumns()
		r.col:SetText(L["Columna %d"]:format(math.min(sec.col or 1, n)))
		r.col:SetEnabled(n > 1 and not db.autoFlow)
		r.up:SetEnabled(si > 1); r.down:SetEnabled(si < #sections)
		for i, id in ipairs(sec.stats) do
			local sr = row()
			sr.sec, sr.list, sr.index = nil, sec.stats, i
			sr.bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.03 or 0)
			sr.title:Hide(); sr.col:Hide(); sr.add:Hide(); sr.label:Show()
			local stat = STATS[id]
			sr.label:SetText(stat and (L[stat.name] .. "  |cff888888" .. L[CATEGORY_NAME[stat.cat]] .. "|r") or ("|cffff4040" .. id .. "|r"))
			sr.up:SetEnabled(i > 1); sr.down:SetEnabled(i < #sec.stats)
		end
	end
	for i = n + 1, #editorRows do editorRows[i]:Hide() end
	editorList.child:SetHeight(math.max(1, n * ED_ROW))
	if editorList.UpdateBar then editorList:UpdateBar() end
end

local function createEditor()
	editor = CreateFrame("Frame", "RheizorStatsEditor", UIParent, "BackdropTemplate")
	editor:SetSize(ED_W, 480)
	editor:SetPoint("CENTER")
	editor:SetFrameStrata("DIALOG")
	editor:SetToplevel(true)
	editor:SetClampedToScreen(true)
	editor:SetMovable(true)
	editor:EnableMouse(true)
	editor:RegisterForDrag("LeftButton")
	editor:SetScript("OnDragStart", editor.StartMoving)
	editor:SetScript("OnDragStop", editor.StopMovingOrSizing)
	if R.UI and R.UI.SetBackdrop then
		R.UI.SetBackdrop(editor, 0.96)
	else
		editor:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
		editor:SetBackdropColor(0.05, 0.05, 0.07, 0.96)
		editor:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	end
	table.insert(UISpecialFrames, "RheizorStatsEditor")

	local title = editor:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 12, -10)
	title:SetText("|cff33ccffRheizor|r · " .. L["Estadísticas"])
	local hint = editor:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("TOPLEFT", 12, -32)
	hint:SetPoint("RIGHT", -12, 0)
	hint:SetJustifyH("LEFT")
	hint:SetText(L["Cada sección tiene un nombre (se puede cambiar), una columna y sus estadísticas. Ordena con las flechas."])

	local close = CreateFrame("Button", nil, editor, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)

	local body = CreateFrame("Frame", nil, editor, "BackdropTemplate")
	body:SetPoint("TOPLEFT", 10, -52)
	body:SetPoint("BOTTOMRIGHT", -10, 40)
	body:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	body:SetBackdropColor(0, 0, 0, 0.4)
	body:SetBackdropBorderColor(1, 1, 1, 0.1)

	if R.UI and R.UI.MakeScroll then
		editorList = R.UI.MakeScroll(body)
	else
		editorList = CreateFrame("ScrollFrame", nil, body, "UIPanelScrollFrameTemplate")
		editorList.child = CreateFrame("Frame", nil, editorList)
		editorList:SetScrollChild(editorList.child)
	end
	editorList:SetPoint("TOPLEFT", 4, -4)
	editorList:SetPoint("BOTTOMRIGHT", -6, 4)
	editorList.child:SetSize(ED_W - 36, 1)

	-- Pie: añadir un grupo entero, restablecer
	local addGroup = smallButton(editor, 150, function(self)
		popup(self, COLUMN_VALUES, function(cat)
			local sections = ensureSections()
			sections[#sections + 1] = { name = "", cat = cat, col = 1, stats = copy(CAT_STATS[cat]) }
			changed()
			editorList:ScrollTo(editorList:GetVerticalScrollRange() + 1000)
		end)
	end)
	addGroup:SetPoint("BOTTOMLEFT", 10, 12)
	addGroup:SetText(L["+ Añadir grupo"])

	local reset = smallButton(editor, 130, function()
		db.sections = defaultSections()
		changed()
	end)
	reset:SetPoint("BOTTOMRIGHT", -10, 12)
	reset:SetText(L["Restablecer"])

	editor:SetScript("OnShow", function() M:DrawEditor() end)
	editor:SetScript("OnHide", function() if R.UI and R.UI.ClosePopup then R.UI.ClosePopup() end end)
end

function M:OpenEditor()
	if not db then return end
	ensureSections()
	if db.layout ~= "custom" then
		db.layout = "custom"
		R:Print(L["Estadísticas: selección personalizada activada."])
	end
	if not editor then createEditor() end
	editor:Show()
	self:DrawEditor()
	self:Refresh()
end

----------------------------------------------------------------------
-- Cuándo y dónde se ve
----------------------------------------------------------------------

-- Pestaña "Personaje" de la ventana del personaje (no reputación, habilidades…)
local function hostFrame()
	return PaperDollFrame or CharacterFrame
end

local function characterOpen()
	local host = hostFrame()
	return host and host:IsVisible()
end

local function place()
	if not panel then return end
	if db.anchor == "character" and CharacterFrame then
		panel:ClearAllPoints()
		panel:SetPoint("TOPLEFT", CharacterFrame, "TOPRIGHT", 4, -12)
	else
		mover:Place()
	end
end

local events = CreateFrame("Frame")

local pending = false
local function refreshSoon()
	if pending then return end
	pending = true
	C_Timer.After(0.1, function()
		pending = false
		M:Refresh()
	end)
end
events:SetScript("OnEvent", refreshSoon)

local EVENTS = {
	"PLAYER_EQUIPMENT_CHANGED", "COMBAT_RATING_UPDATE", "SKILL_LINES_CHANGED", "PLAYER_LEVEL_UP",
	"CHARACTER_POINTS_CHANGED", "SPELL_POWER_CHANGED", "PLAYER_DAMAGE_DONE_MODS",
	"PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "PLAYER_MONEY", "UPDATE_INVENTORY_DURABILITY",
	"PLAYER_REGEN_ENABLED",   -- al salir de combate los valores vuelven a leerse
	"CURRENCY_DISPLAY_UPDATE", "HONOR_CURRENCY_UPDATE", "PLAYER_PVP_KILLS_CHANGED", "PLAYER_PVP_RANK_CHANGED",
}
local UNIT_EVENTS = {
	"UNIT_STATS", "UNIT_AURA", "UNIT_ATTACK_POWER", "UNIT_RANGED_ATTACK_POWER", "UNIT_DAMAGE",
	"UNIT_RANGEDDAMAGE", "UNIT_ATTACK_SPEED", "UNIT_RESISTANCES", "UNIT_DEFENSE", "UNIT_MAXPOWER",
	"UNIT_MAXHEALTH",
}

-- Eventos solo mientras el panel se ve
local function listen(on)
	events:UnregisterAllEvents()
	if not on then return end
	for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
	for _, e in ipairs(UNIT_EVENTS) do pcall(events.RegisterUnitEvent, events, e, "player") end
end

-- Condiciones de "Según las condiciones": combate, solo/grupo/banda, estancia
local inCombat = false

local function rulesPass()
	if db.vCombat == "combat" and not inCombat then return false end
	if db.vCombat == "nocombat" and inCombat then return false end
	if db.vTarget and not NS(UnitExists("target")) then return false end
	if db.vMounted and IsMounted and NS(IsMounted()) then return false end
	if db.vInstance then
		local inside, kind = IsInInstance()
		if not inside or (kind ~= "party" and kind ~= "raid") then return false end
	end
	if IsInRaid() then return db.vRaid end
	if IsInGroup() then return db.vParty end
	return db.vSolo
end

-- Los ganchos de la ventana del personaje no se pueden quitar: si se apaga
-- el addon en Rheizor, siguen llamándose pero no hacen nada. (No se usa
-- R:IsModuleRunning: durante el propio OnEnable aún da false)
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

-- Con "al pasar el ratón" el panel queda en su sitio, casi o del todo
-- transparente, y se ve con el ratón encima
function M:UpdateVisibility()
	if not panel then return end
	local show, hover = false, false
	if db.enabled and running() then
		if db.anchor == "free" and not db.locked then
			show = true   -- desbloqueado: a la vista para moverlo
		elseif db.visibility == "always" then
			show = true
		elseif characterOpen() and (db.withCharacter or db.visibility == "character") then
			show = true
		elseif db.visibility == "rules" then
			show = rulesPass()
			hover = not show and db.vHover
		elseif db.visibility == "mouseover" then
			hover = true
		end
	end
	local alpha = 1
	if hover then
		show = true
		if not (panel:IsShown() and panel:IsMouseOver()) then alpha = db.hiddenAlpha or 0 end
	end
	panel:SetAlpha(alpha)
	panel:SetShown(show)
end

-- Eventos de las condiciones: solo con "Según las condiciones"
local visEvents = CreateFrame("Frame")
visEvents:SetScript("OnEvent", function(_, event)
	if event == "PLAYER_REGEN_DISABLED" then
		inCombat = true
	elseif event == "PLAYER_REGEN_ENABLED" then
		inCombat = false
	end
	M:UpdateVisibility()
end)

local hoverTicker

function M:UpdateVisibilityEvents()
	visEvents:UnregisterAllEvents()
	local rules = db.enabled and db.visibility == "rules"
	-- El ratón se mira 6 veces por segundo, solo si se usa
	local hover = db.enabled and (db.visibility == "mouseover" or (rules and db.vHover))
	if hover and not hoverTicker then
		hoverTicker = C_Timer.NewTicker(0.15, function() M:UpdateVisibility() end)
	elseif not hover and hoverTicker then
		hoverTicker:Cancel()
		hoverTicker = nil
	end
	if not rules then return end
	inCombat = InCombatLockdown() or (NS(UnitAffectingCombat("player")) and true or false)
	for _, e in ipairs({ "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "GROUP_ROSTER_UPDATE", "PLAYER_ENTERING_WORLD",
		"ZONE_CHANGED_NEW_AREA", "PLAYER_TARGET_CHANGED", "PLAYER_MOUNT_DISPLAY_CHANGED" }) do
		pcall(visEvents.RegisterEvent, visEvents, e)
	end
	-- Por si montar no avisa con su propio evento en esta versión
	if db.vMounted then pcall(visEvents.RegisterUnitEvent, visEvents, "UNIT_AURA", "player") end
end

function M:ApplyStyle()
	if not panel then return end
	panel:SetScale(db.scale)
	panel:SetBackdropColor(0.05, 0.05, 0.07, db.bgAlpha)
	panel:SetBackdropBorderColor(0.2, 0.8, 1, db.bgAlpha > 0 and 0.6 or 0)
	mover:SetShown(db.anchor == "free" and not db.locked)
	place()
end

function M:ResetPosition()
	db.point = nil
	place()
end

local function createPanel()
	panel = CreateFrame("Frame", "RheizorStats", UIParent, "BackdropTemplate")
	panel:SetFrameStrata(CharacterFrame and CharacterFrame:GetFrameStrata() or "MEDIUM")
	panel:SetSize(200, 100)
	panel:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	panel:Hide()
	mover = R:CreateMover(panel, L["Estadísticas"], db, "point", { "LEFT", "LEFT", 420, 0 })
	panel:SetScript("OnShow", function()
		listen(true)
		M:Refresh()
	end)
	panel:SetScript("OnHide", function() listen(false) end)

	-- Engranaje: abre el editor (modo personalizado)
	gear = iconButton(panel, "Interface\\Buttons\\UI-OptionsButton", L["Editar estadísticas"], function() M:OpenEditor() end)
	gear:SetSize(14, 14)

	-- Candado: fija los anchos para que las estadísticas no cambien de sitio
	-- (y desactiva el asa y los desplegables de los títulos)
	lockButton = iconButton(panel, "Interface\\Buttons\\LockButton-Unlocked-Up", L["Bloquear la colocación"], function()
		if db.frozen then
			db.frozen = nil
		else
			db.frozen = {}   -- se llena con los anchos actuales en el siguiente dibujado
		end
		M:Refresh()
		GameTooltip_Hide()
	end)
	lockButton:SetSize(16, 16)
	-- Encima del panel, para no tapar ningún valor
	lockButton:SetPoint("BOTTOMRIGHT", panel, "TOPRIGHT", 0, 2)
	lockButton:SetFrameLevel(panel:GetFrameLevel() + 5)
	function lockButton:Update()
		local locked = type(db.frozen) == "table"
		self:SetNormalTexture(locked and "Interface\\Buttons\\LockButton-Locked-Up" or "Interface\\Buttons\\LockButton-Unlocked-Up")
		self:GetNormalTexture():SetDesaturated(not locked)
	end
	lockButton:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		if db.frozen then
			GameTooltip:SetText(L["Colocación bloqueada"], 1, 1, 1)
			GameTooltip:AddLine(L["Los valores cambian pero nada se mueve de sitio. Clic para desbloquear."], nil, nil, nil, true)
		else
			GameTooltip:SetText(L["Bloquear la colocación"], 1, 1, 1)
			GameTooltip:AddLine(L["Fija el ancho de cada estadística y columna tal como está ahora, para que no se desplacen cuando cambian los números."], nil, nil, nil, true)
		end
		GameTooltip:Show()
	end)
	gear:SetPoint("RIGHT", lockButton, "LEFT", -2, 0)

	-- Asa para cambiar el ancho de la cuadrícula
	grip = CreateFrame("Button", nil, panel)
	grip:SetSize(14, 14)
	grip:SetPoint("BOTTOMRIGHT", -1, 1)
	grip:SetFrameLevel(panel:GetFrameLevel() + 5)
	grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
	grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
	grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
	local function follow()
		local left = panel:GetLeft()
		if not left then return end
		local x = GetCursorPosition() / panel:GetEffectiveScale()
		local width = math.floor(math.max(120, math.min(1600, x - left + 6)))
		if width ~= db.gridWidth then
			db.gridWidth = width
			M:Refresh()
		end
	end
	grip:SetScript("OnMouseDown", function(self) self:SetScript("OnUpdate", follow) end)
	grip:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)
	grip:SetScript("OnHide", function(self) self:SetScript("OnUpdate", nil) end)
	grip:Hide()
	gear:SetFrameLevel(panel:GetFrameLevel() + 5)

	-- Engranaje y candado «al pasar el ratón»: invisibles pero pulsables; el
	-- margen de arriba cubre los botones, que están encima del panel
	local buttonsT = 0
	panel:HookScript("OnUpdate", function(self, elapsed)
		buttonsT = buttonsT + elapsed
		if buttonsT < 0.1 then return end
		buttonsT = 0
		local a = 1
		if db.panelButtons == "hover" and not self:IsMouseOver(20, 0, 0, 0) then a = 0 end
		if gear:GetAlpha() ~= a then
			gear:SetAlpha(a)
			lockButton:SetAlpha(a)
		end
	end)

	local host = hostFrame()
	if host then
		host:HookScript("OnShow", function() M:UpdateVisibility() end)
		host:HookScript("OnHide", function() M:UpdateVisibility() end)
	else
		R.missing[L["Estadísticas: ventana del personaje"]] = "PaperDollFrame / CharacterFrame"
	end
end

local function hideBlizzard()
	R:KeepHidden({ "CharacterStatsPane" }, function() return db.hideBlizzard and running() end, L["Estadísticas de Blizzard"])
end

function M:OnEnable()
	db = self.db
	started = true
	-- La versión anterior tenía un modo "lista" con casillas por categoría:
	-- pasa a una disposición personalizada con esas mismas categorías
	if db.layout == "list" then
		local sections = {}
		for _, c in ipairs(CATEGORIES) do
			local key = "show" .. c[1]:sub(1, 1):upper() .. c[1]:sub(2)
			if db[key] then sections[#sections + 1] = { name = "", cat = c[1], col = 1, stats = copy(CAT_STATS[c[1]]) } end
		end
		db.sections = #sections > 0 and sections or nil
		db.layout = "custom"
	end
	-- El oro pasó de "Varios" a "Monedas y JcJ"
	if type(db.sections) == "table" then
		for _, sec in ipairs(db.sections) do
			if type(sec) == "table" and type(sec.stats) == "table" then
				for i, id in ipairs(sec.stats) do
					if id == "misc.gold" then sec.stats[i] = "currency.gold" end
				end
			end
		end
	end
	-- Restos del modo "lista" (sus casillas por categoría) que ya no se leen
	for _, c in ipairs(CATEGORIES) do
		db["show" .. c[1]:sub(1, 1):upper() .. c[1]:sub(2)] = nil
	end
	-- Antes había una casilla "mostrar también con la ventana cerrada"
	if db.showAlways then
		db.visibility = "always"
		db.showAlways = nil
	end
	self:ScanCurrencies()
	createPanel()
	if db.hideBlizzard then hideBlizzard() end
	self:ApplyStyle()
	self:UpdateVisibilityEvents()
	self:UpdateVisibility()
end

function M:OnOptionChanged(key)
	if key == "hideBlizzard" then
		if db.hideBlizzard then hideBlizzard() else R:NeedReload() end
	end
	-- Un cambio de aspecto o de contenido con el candado puesto: los anchos
	-- se vuelven a tomar (el candado sigue puesto)
	if db.frozen then db.frozen = {} end
	self:ApplyStyle()
	self:UpdateVisibilityEvents()
	self:UpdateVisibility()
	self:Refresh()
	self:DrawEditor()
end
