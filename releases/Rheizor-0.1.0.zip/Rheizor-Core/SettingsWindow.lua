-- Ventana de opciones del juego (Esc > Opciones): se puede arrastrar desde su
-- barra de título o cualquier zona vacía, recuerda la posición y admite tamaño
-- y transparencia, para ir configurando viendo la interfaz detrás.

local R = Rheizor:Namespace(...)

local M = R:RegisterModule("settingswin", {
	title = "Ventana de opciones",
	defaults = {
		movable = true,
		remember = true,
		scale = 1,
		alpha = 1,
	},
	options = {
		{ type = "header", text = "Ventana de opciones del juego" },
		{ type = "toggle", key = "movable", name = "Poder moverla",
		  desc = "Arrastra la ventana desde su título o desde cualquier zona vacía." },
		{ type = "toggle", key = "remember", name = "Recordar la posición",
		  desc = "Al volver a abrirla aparece donde la dejaste." },
		{ type = "button", name = "Posición", text = "Centrar", func = function(mod) mod:ResetPosition() end },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 1.2, step = 0.05 },
		{ type = "slider", key = "alpha", name = "Opacidad", min = 0.3, max = 1, step = 0.05,
		  desc = "Para ver a través de la ventana lo que estás cambiando." },
	},
})

local db
local panel

local function savePosition()
	local point, _, relPoint, x, y = panel:GetPoint()
	if point then db.point = { point, relPoint, x, y } end
end

local function applyPosition()
	if not (db.remember and db.point) then return end
	panel:ClearAllPoints()
	panel:SetPoint(db.point[1], UIParent, db.point[2], db.point[3], db.point[4])
end

function M:Apply()
	if not panel then return end
	if InCombatLockdown() and panel:IsProtected() then
		R:RunOutOfCombat(function() M:Apply() end)
		return
	end
	panel:SetScale(db.scale)
	panel:SetAlpha(db.alpha)
	if panel:IsShown() then applyPosition() end
end

function M:ResetPosition()
	db.point = nil
	if panel and not (InCombatLockdown() and panel:IsProtected()) then
		panel:ClearAllPoints()
		panel:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
	end
end

local function startMoving()
	if not db.movable or (InCombatLockdown() and panel:IsProtected()) then return end
	panel:StartMoving()
end

local function stopMoving()
	panel:StopMovingOrSizing()
	panel:SetUserPlaced(false)   -- la posición la guardamos nosotros
	savePosition()
end

function M:OnEnable()
	db = self.db
	panel = SettingsPanel
	if type(panel) ~= "table" then
		R.missing["Ventana de opciones"] = "SettingsPanel"
		return
	end

	panel:SetMovable(true)
	panel:SetClampedToScreen(true)
	panel:RegisterForDrag("LeftButton")
	panel:HookScript("OnDragStart", startMoving)
	panel:HookScript("OnDragStop", stopMoving)

	-- Asa sobre la barra de título (deja libre el botón de cerrar)
	local handle = CreateFrame("Frame", nil, panel)
	handle:SetPoint("TOPLEFT", 0, 0)
	handle:SetPoint("TOPRIGHT", -32, 0)
	handle:SetHeight(24)
	handle:EnableMouse(true)
	handle:RegisterForDrag("LeftButton")
	handle:SetScript("OnDragStart", startMoving)
	handle:SetScript("OnDragStop", stopMoving)
	handle:SetScript("OnEnter", function(self)
		if not db.movable then return end
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(R.L["Arrastra para mover"])
		GameTooltip:Show()
	end)
	handle:SetScript("OnLeave", GameTooltip_Hide)

	-- El juego la recoloca al abrirla: ponemos la nuestra justo después
	panel:HookScript("OnShow", function()
		M:Apply()
		C_Timer.After(0, function() if panel:IsShown() then applyPosition() end end)
	end)

	self:Apply()
end

function M:OnOptionChanged()
	self:Apply()
end
