-- Lectura de auras compartida (marcos de unidad, placas de nombre...).
--
-- En combate el motor 12.x bloquea la lectura por índice a los addons
-- ("Auras cannot be accessed when secret"), así que:
--   1) la API de lista (sus valores pueden venir secretos, pero se pueden mostrar)
--   2) por índice, protegido: si el motor lo bloquea, se muestra lo que haya dado
--      y se vuelve a intentar al salir de combate
--   3) lo que trae el propio evento UNIT_AURA (R.CacheAuras), como Plater

local _, R = ...
local NS = R.NotSecret
local L = R.L

local EMPTY = {}
local CUA = C_UnitAuras

local MAX_AURAS = 40
R.MAX_AURAS = MAX_AURAS

-- Lee una aura suelta; si el motor la bloquea devuelve false (se salta y se sigue).
-- Cuenta las bloqueadas y guarda el último error para /rz auras.
local blocked, lastBlockError = 0, nil
local function tryAura(fn, ...)
	local ok, aura = pcall(fn, ...)
	if not ok then
		blocked = blocked + 1
		lastBlockError = aura
		return false
	end
	return aura
end

-- API antigua (UnitDebuff/UnitBuff): en algunos clientes va por otro camino
local function legacyAura(unit, i, filter)
	local fn = filter:find("HARMFUL") and UnitDebuff or UnitBuff
	if not fn then return nil end
	local name, icon, count, dispelName, duration, expirationTime, source, _, _, spellId =
		fn(unit, i, filter:find("PLAYER") and "PLAYER" or nil)
	if name == nil then return nil end
	return {
		name = name, icon = icon, applications = count, dispelName = dispelName,
		duration = duration, expirationTime = expirationTime, spellId = spellId,
		isFromPlayerOrPlayerPet = NS(source) and (source == "player" or source == "pet" or source == "vehicle"),
	}
end

-- Cada método añade a "out" las auras que consiga leer. Una aura bloqueada no
-- tira las demás: se salta y se sigue con la siguiente.
local AURA_METHODS = {
	{ name = "GetUnitAuras", api = "GetUnitAuras", fn = function(unit, filter, out)
		local ok, list = pcall(CUA.GetUnitAuras, unit, filter, MAX_AURAS)
		if not ok then return false end
		for _, aura in ipairs(type(list) == "table" and list or EMPTY) do out[#out + 1] = aura end
	end },
	{ name = "GetUnitAuraInstanceIDs", api = "GetUnitAuraInstanceIDs", fn = function(unit, filter, out)
		local ok, ids = pcall(CUA.GetUnitAuraInstanceIDs, unit, filter)
		if not ok then return false end
		for _, id in ipairs(type(ids) == "table" and ids or EMPTY) do
			local aura = tryAura(CUA.GetAuraDataByAuraInstanceID, unit, id)
			if aura then out[#out + 1] = aura end
		end
	end },
	{ name = "GetAuraSlots", api = "GetAuraSlots", fn = function(unit, filter, out)
		local slots = { pcall(CUA.GetAuraSlots, unit, filter, MAX_AURAS) }
		if not slots[1] then return false end
		for i = 3, #slots do
			local aura = tryAura(CUA.GetAuraDataBySlot, unit, slots[i])
			if aura then out[#out + 1] = aura end
		end
	end },
	{ name = "GetAuraDataByIndex", api = "GetAuraDataByIndex", fn = function(unit, filter, out)
		local failed = false
		for i = 1, MAX_AURAS do
			local aura = tryAura(CUA.GetAuraDataByIndex, unit, i, filter)
			if aura == nil then break end
			if aura then out[#out + 1] = aura else failed = true end
		end
		if failed and #out == 0 then return false end
	end },
	-- Último recurso: solo se usa si los anteriores se encontraron auras bloqueadas
	{ name = "UnitDebuff/UnitBuff", legacy = true, fn = function(unit, filter, out)
		for i = 1, MAX_AURAS do
			local aura = tryAura(legacyAura, unit, i, filter)
			if aura == nil then break end
			if aura then out[#out + 1] = aura end
		end
	end },
}

-- ¿Pasa esta aura el filtro? Como Plater: se le pregunta al juego por su id
local function auraMatches(unit, id, aura, filter)
	if CUA.IsAuraFilteredOutByInstanceID then
		local ok, out = pcall(CUA.IsAuraFilteredOutByInstanceID, unit, id, filter)
		if ok and NS(out) ~= nil then return not NS(out) end
	end
	-- Sin esa función: con los datos del aura, si no están ocultos
	local harmful = NS(aura.isHarmful)
	if harmful == nil then
		local helpful = NS(aura.isHelpful)
		if helpful == nil then return false end
		harmful = not helpful
	end
	if (filter:find("HARMFUL") ~= nil) ~= harmful then return false end
	if filter:find("PLAYER") then return NS(aura.isFromPlayerOrPlayerPet) == true end
	return true
end

-- Auras que trae el propio evento UNIT_AURA (así lee Plater): llegan aunque la
-- consulta directa esté bloqueada en combate. "cache" es una tabla por unidad.
function R.CacheAuras(cache, unit, info)
	-- Actualización completa (o sin datos): se vacía y se lee lo que se pueda
	if type(info) ~= "table" or NS(info.isFullUpdate) == true then
		wipe(cache)
		return
	end
	pcall(function()
		for _, aura in ipairs(info.addedAuras or EMPTY) do
			local id = NS(aura.auraInstanceID)
			if id then cache[id] = aura end
		end
		for _, id in ipairs(info.updatedAuraInstanceIDs or EMPTY) do
			id = NS(id)
			if id then
				local aura = tryAura(CUA.GetAuraDataByAuraInstanceID, unit, id)
				if aura then cache[id] = aura end
			end
		end
		for _, id in ipairs(info.removedAuraInstanceIDs or EMPTY) do
			id = NS(id)
			if id then cache[id] = nil end
		end
	end)
end

-- Junta lo que consigan todos los métodos y todos los filtros, sin repetir.
-- Devuelve la lista, si tuvo que usar la API antigua y si el juego bloqueó algo
-- (la lista puede estar incompleta).
function R.ReadAuras(unit, filters, limit, cache)
	if limit < 1 or not CUA then return EMPTY end
	local result, seen = {}, {}
	local usedLegacy, failed = false, false
	local blockedStart = blocked
	for _, filter in ipairs(filters) do
		local blockedBefore = blocked
		local start = #result
		for _, m in ipairs(AURA_METHODS) do
			local found = {}
			if not m.legacy and m.api and not CUA[m.api] then
				-- Esta función no existe en este cliente: no cuenta como bloqueo
			elseif not m.legacy then
				local ok, res = pcall(m.fn, unit, filter, found)
				if not ok or res == false then failed = true end
			elseif blocked > blockedBefore then
				-- Alguna aura de este filtro estaba bloqueada: la API antigua
				-- sustituye lo leído con este filtro (no trae auraInstanceID)
				for i = #result, start + 1, -1 do result[i] = nil end
				pcall(m.fn, unit, filter, found)
				usedLegacy = true
			end
			for _, aura in ipairs(found) do
				local id = NS(aura.auraInstanceID)
				if not id and m.legacy then
					-- Sin id: se evita repetir por nombre + fin
					local n, e = NS(aura.name), NS(aura.expirationTime)
					id = n and e and ("L" .. n .. e)
				end
				if not id or not seen[id] then
					if id then seen[id] = true end
					result[#result + 1] = aura
					if #result >= limit then return result end
				end
			end
		end
		-- Lo que vino con el evento y la consulta directa no ha dado
		if cache then
			for id, aura in pairs(cache) do
				if not seen[id] and auraMatches(unit, id, aura, filter) then
					seen[id] = true
					result[#result + 1] = aura
					if #result >= limit then return result end
				end
			end
		end
	end
	return result, usedLegacy, failed or blocked > blockedStart
end

-- Pinta un aura en un botón con .icon, .count, .cd (Cooldown) y borde (BackdropTemplate)
function R.SetAuraButton(b, unit, aura, index, filter, debuff, hostile)
	b.unit, b.index, b.filter, b.auraID, b.fakeName = unit, index, filter, aura.auraInstanceID, nil
	b.icon:SetTexture(aura.icon)

	local count = NS(aura.applications)
	if count then
		b.count:SetText(count > 1 and count or "")
	elseif not (CUA.GetAuraApplicationDisplayCount and pcall(function()
		b.count:SetText(CUA.GetAuraApplicationDisplayCount(unit, aura.auraInstanceID, 2, 99))
	end)) then
		b.count:SetText("")
	end

	local dur, exp = NS(aura.duration), NS(aura.expirationTime)
	if dur and exp then
		if dur > 0 then b.cd:SetCooldown(exp - dur, dur) b.cd:Show() else b.cd:Hide() end
	elseif not (CUA.GetAuraDuration and b.cd.SetCooldownFromDurationObject and pcall(function()
		b.cd:SetCooldownFromDurationObject(CUA.GetAuraDuration(unit, aura.auraInstanceID))
		b.cd:Show()
	end)) then
		b.cd:Hide()
	end

	local r, g, bl = 0, 0, 0
	if debuff then
		pcall(function()
			local c = DebuffTypeColor and DebuffTypeColor[NS(aura.dispelName) or "none"]
			if c then r, g, bl = c.r, c.g, c.b end
		end)
	end
	b:SetBackdropBorderColor(r, g, bl, 1)
	b.icon:SetDesaturated(debuff and hostile and NS(aura.isFromPlayerOrPlayerPet) == false or false)
end

-- /rz auras: qué métodos funcionan ahora mismo con el objetivo
function R:DiagnoseAuras()
	local unit = "target"
	if not UnitExists(unit) then
		self:Print(L["Selecciona un objetivo (mejor en combate y con un perjuicio tuyo puesto)."])
		return
	end
	self:Print(InCombatLockdown() and L["Auras del objetivo (en combate):"] or L["Auras del objetivo (fuera de combate):"])
	for _, filter in ipairs({ "HELPFUL", "HARMFUL", "HARMFUL|PLAYER" }) do
		for _, m in ipairs(AURA_METHODS) do
			local found = {}
			local blockedBefore = blocked
			lastBlockError = nil
			local ok, res = pcall(m.fn, unit, filter, found)
			local nBlocked = blocked - blockedBefore
			local result
			if not ok then
				result = "|cffff5555error|r " .. (tostring(res):gsub("^.-:%d+: ", "")):sub(1, 70)
			elseif res == false and #found == 0 then
				result = L["|cffff5555bloqueado|r"]
			else
				local names = {}
				for _, aura in ipairs(found) do
					names[#names + 1] = NS(aura.name) or "?"
					if NS(aura.isFromPlayerOrPlayerPet) then names[#names] = names[#names] .. "*" end
				end
				result = "|cff33ff33" .. #found .. "|r " .. table.concat(names, ", "):sub(1, 90)
			end
			if nBlocked > 0 then
				result = result .. L[" |cffff5555+%d bloqueadas|r"]:format(nBlocked)
				if lastBlockError then
					result = result .. " (" .. (tostring(lastBlockError):gsub("^.-:%d+: ", "")):sub(1, 60) .. ")"
				end
			end
			self:Print(filter .. " · " .. m.name .. ": " .. result)
		end
	end

	-- La misma unidad leída por su placa de nombre (así la lee Plater)
	local plate = C_NamePlate and C_NamePlate.GetNamePlateForUnit and C_NamePlate.GetNamePlateForUnit(unit)
	local token = plate and (plate.namePlateUnitToken or plate.unitToken or (plate.UnitFrame and plate.UnitFrame.unit))
	if token then
		local list, _, failed = R.ReadAuras(token, { "HARMFUL|PLAYER", "HARMFUL" }, MAX_AURAS)
		local names = {}
		for _, aura in ipairs(list) do names[#names + 1] = NS(aura.name) or "?" end
		self:Print(L["Por su placa (%s), perjuicios: |cff33ff33%d|r "]:format(token, #list)
			.. table.concat(names, ", "):sub(1, 80) .. (failed and L[" |cffff5555(con bloqueos)|r"] or ""))
	else
		self:Print(L["Por su placa: el objetivo no tiene placa de nombre visible."])
	end
	local uf = self.modules.unitframes
	if uf and uf.DiagnoseBlizzard then uf:DiagnoseBlizzard() end
	self:Print(L["(* = puesta por ti; ? = nombre oculto por el juego)"])
end
