-- Plantillas de distribución: dónde van los marcos, barras de lanzamiento,
-- amenaza, etc. de Rheizor y, con el Modo edición de Blizzard, las barras de
-- acción, el micromenú y las bolsas. Las usa el asistente de instalación.
--
-- Cada plantilla solo toca posiciones, tamaños y desvanecidos. Las posiciones
-- son { punto, puntoRelativo, x, y } respecto a la pantalla (UIParent), casi
-- todas desde abajo en el centro para que valgan en cualquier resolución.

local R = Rheizor:Namespace(...)
local L = R.L

local function P(point, rel, x, y) return { point, rel, x, y } end

----------------------------------------------------------------------
-- Base: todo lo que fija una plantilla (así cambiar de una a otra no deja restos)
----------------------------------------------------------------------

local function base()
	return {
		-- Elegir una plantilla activa lo que coloca (por si venías de "Sin cambios")
		-- Las alturas (y) de lo que va abajo en el centro son orientativas: al
		-- aplicar la plantilla se suben o bajan todas juntas para quedar justo
		-- encima de las barras de acción (R:FitLayoutToBars)
		unitframes      = { enabled = true },
		uf_player       = { point = P("BOTTOM", "BOTTOM", -310, 240), width = 260, height = 52 },
		uf_target       = { point = P("BOTTOM", "BOTTOM", 310, 240), width = 260, height = 52 },
		uf_targettarget = { point = P("BOTTOM", "BOTTOM", 530, 250), width = 150, height = 30 },
		uf_pet          = { point = P("BOTTOM", "BOTTOM", -310, 204), width = 150, height = 30 },
		uf_focus        = { point = P("BOTTOM", "BOTTOM", -310, 344), width = 220, height = 40 },
		uf_focustarget  = { point = P("BOTTOM", "BOTTOM", -115, 350), width = 150, height = 30 },
		aura_target     = { bPos = "top", dPos = "top" },
		aura_focus      = { bPos = "top", dPos = "top" },
		castbars = {
			enabled = true,
			pPoint = P("BOTTOM", "BOTTOM", 0, 190), pWidth = 280, pHeight = 24,
			tPoint = P("BOTTOM", "BOTTOM", 310, 214), tWidth = 260, tHeight = 20,
			fPoint = P("BOTTOM", "BOTTOM", -310, 390), fWidth = 220, fHeight = 18,
		},
		swing   = { enabled = true, point = P("BOTTOM", "BOTTOM", 0, 222), width = 240 },
		totems  = { enabled = true, point = P("BOTTOM", "BOTTOM", 0, 280) },
		threat  = { enabled = true, point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -110, 300), width = 220 },
		raidtools = { point = P("TOP", "TOP", 0, -20) },
		bars = {
			hideGryphons = true,
			fadeMain = false, fadeBar2 = false, fadeBar3 = false, fadeBar4 = false, fadeBar5 = false,
			fadeStance = false, fadePet = false, fadeMicro = false, fadeBags = false, fadeXP = false, fadeXP2 = false,
		},
	}
end

-- Barras de Blizzard colocadas en el centro, micromenú y bolsas a la derecha.
-- La experiencia va pegada abajo del todo (salvo que la plantilla la suba)
-- y las barras encima, sin taparla. La barra 6 (si la tienes) va en la pila.
local function centeredBlizzard(name, extra, xpOnTop)
	local y = xpOnTop and 8 or 30
	local systems = {
		{ "ActionBar", "MainBar",      P("BOTTOM", "BOTTOM", 0, y) },
		{ "ActionBar", "Bar2",         P("BOTTOM", "BOTTOM", 0, y + 44) },
		{ "ActionBar", "Bar3",         P("BOTTOM", "BOTTOM", 0, y + 88) },
		{ "ActionBar", "Bar6",         P("BOTTOM", "BOTTOM", 0, y + 132) },
		{ "ActionBar", "StanceBar",    P("BOTTOM", "BOTTOM", -150, y + 178) },
		{ "ActionBar", "PetActionBar", P("BOTTOM", "BOTTOM", 150, y + 178) },
		{ "MicroMenu", nil,            P("BOTTOMRIGHT", "BOTTOMRIGHT", -8, 4) },
		{ "Bags",      nil,            P("BOTTOMRIGHT", "BOTTOMRIGHT", -8, 46) },
	}
	if not xpOnTop then
		systems[#systems + 1] = { "StatusTrackingBar", "StatusTrackingBar1", P("BOTTOM", "BOTTOM", 0, 0) }
		systems[#systems + 1] = { "StatusTrackingBar", "StatusTrackingBar2", P("BOTTOM", "BOTTOM", 0, 14) }
	end
	for _, s in ipairs(extra or {}) do systems[#systems + 1] = s end
	return { name = name, systems = systems }
end

local function merge(t, changes)
	for mod, values in pairs(changes) do
		t[mod] = t[mod] or {}
		for k, v in pairs(values) do t[mod][k] = v end
	end
	return t
end

----------------------------------------------------------------------
-- Plantillas
----------------------------------------------------------------------

R.LAYOUTS = {
	{
		id = "centered",
		name = "Centrada",
		desc = "Todo agrupado abajo en el centro: barras apiladas, tus marcos a los lados de la barra de lanzamiento y micromenú y bolsas a la derecha. La recomendada.",
		db = base(),
		blizzard = centeredBlizzard("Rheizor Centrada"),
	},
	{
		id = "classic",
		name = "Clásica",
		desc = "La distribución de siempre: tu marco y el del objetivo arriba a la izquierda y las barras de Blizzard en su sitio clásico.",
		db = merge(base(), {
			uf_player       = { point = P("TOPLEFT", "TOPLEFT", 40, -40) },
			uf_pet          = { point = P("TOPLEFT", "TOPLEFT", 60, -92) },
			uf_target       = { point = P("TOPLEFT", "TOPLEFT", 300, -40) },
			uf_targettarget = { point = P("TOPLEFT", "TOPLEFT", 540, -48) },
			uf_focus        = { point = P("TOPLEFT", "TOPLEFT", 40, -260) },
			uf_focustarget  = { point = P("TOPLEFT", "TOPLEFT", 240, -264) },
			aura_target     = { bPos = "bottom", dPos = "bottom" },
			aura_focus      = { bPos = "bottom", dPos = "bottom" },
			castbars = {
				pPoint = P("BOTTOM", "BOTTOM", 0, 180),
				tPoint = P("TOPLEFT", "TOPLEFT", 300, -180),
				fPoint = P("TOPLEFT", "TOPLEFT", 40, -300),
			},
			swing   = { point = P("BOTTOM", "BOTTOM", 0, 212) },
			totems  = { point = P("BOTTOM", "BOTTOM", 0, 270) },
			threat  = { point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -110, 180) },
			bars    = { hideGryphons = false },
		}),
		-- Diseño "Clásico" que trae el juego (el segundo de los predefinidos)
		blizzard = { preset = 2 },
		preview = {
			{ "bar",   P("BOTTOM", "BOTTOM", -110, 4), 540, 40 },
			{ "bar",   P("BOTTOM", "BOTTOM", -110, 48), 540, 40 },
			{ "micro", P("BOTTOM", "BOTTOM", 305, 4), 280, 36 },
			{ "micro", P("BOTTOM", "BOTTOM", 305, 44), 200, 36 },
		},
	},
	{
		id = "minimal",
		name = "Minimalista",
		desc = "Limpia y centrada: marcos grandes junto a la barra de lanzamiento, sin grifos, la experiencia arriba del todo y la barra 3, las laterales, el micromenú, las bolsas y la experiencia ocultos hasta que pasas el ratón.",
		db = merge(base(), {
			uf_player       = { point = P("BOTTOM", "BOTTOM", -340, 236), width = 300, height = 62 },
			uf_target       = { point = P("BOTTOM", "BOTTOM", 340, 236), width = 300, height = 62 },
			uf_targettarget = { point = P("BOTTOM", "BOTTOM", 582, 250), width = 160, height = 34 },
			uf_pet          = { point = P("BOTTOM", "BOTTOM", -340, 196), width = 160, height = 34 },
			uf_focus        = { point = P("BOTTOM", "BOTTOM", -340, 354), width = 240, height = 44 },
			uf_focustarget  = { point = P("BOTTOM", "BOTTOM", -135, 360), width = 150, height = 30 },
			castbars = {
				pPoint = P("BOTTOM", "BOTTOM", 0, 190), pWidth = 260, pHeight = 22,
				tPoint = P("BOTTOM", "BOTTOM", 340, 210), tWidth = 300, tHeight = 20,
				fPoint = P("BOTTOM", "BOTTOM", -340, 404), fWidth = 240, fHeight = 18,
			},
			swing   = { point = P("BOTTOM", "BOTTOM", 0, 220), width = 220 },
			totems  = { point = P("BOTTOM", "BOTTOM", 0, 276) },
			-- La barra de banda baja un poco para no tapar la experiencia
			raidtools = { point = P("TOP", "TOP", 0, -34) },
			bars = {
				hideGryphons = true,
				fadeBar3 = true, fadeBar4 = true, fadeBar5 = true,
				fadeMicro = true, fadeBags = true, fadeXP = true, fadeXP2 = true,
			},
		}),
		blizzard = centeredBlizzard("Rheizor Minimalista", {
			-- Experiencia y reputación arriba del todo, en el centro
			{ "StatusTrackingBar", "StatusTrackingBar1", P("TOP", "TOP", 0, -2) },
			{ "StatusTrackingBar", "StatusTrackingBar2", P("TOP", "TOP", 0, -16) },
		}, true),
	},
	{
		id = "healer",
		name = "Sanador",
		desc = "Los marcos de grupo y banda de Blizzard en el centro, justo encima de tu barra de lanzamiento, y tus marcos más abiertos a los lados.",
		db = merge(base(), {
			uf_player       = { point = P("BOTTOM", "BOTTOM", -420, 240) },
			uf_pet          = { point = P("BOTTOM", "BOTTOM", -420, 204) },
			uf_target       = { point = P("BOTTOM", "BOTTOM", 420, 240) },
			uf_targettarget = { point = P("BOTTOM", "BOTTOM", 640, 250) },
			uf_focus        = { point = P("BOTTOM", "BOTTOM", -420, 344) },
			uf_focustarget  = { point = P("BOTTOM", "BOTTOM", -225, 350) },
			castbars = {
				tPoint = P("BOTTOM", "BOTTOM", 420, 214),
				fPoint = P("BOTTOM", "BOTTOM", -420, 390),
			},
			totems  = { point = P("BOTTOM", "BOTTOM", -420, 400) },
			threat  = { point = P("BOTTOMRIGHT", "BOTTOMRIGHT", -110, 330) },
		}),
		blizzard = centeredBlizzard("Rheizor Sanador", {
			{ "UnitFrame", "Party", P("BOTTOM", "BOTTOM", 0, 280) },
			{ "UnitFrame", "Raid",  P("BOTTOM", "BOTTOM", 0, 280) },
		}),
	},
	{
		id = "none",
		name = "Sin cambios",
		desc = "No toca tu interfaz: los marcos, barras y placas de Blizzard se quedan como están y lo visual de Rheizor empieza apagado. Luego lo vas activando a tu ritmo en /rz.",
		untouched = true,
		db = {
			unitframes = { enabled = false },
			castbars   = { enabled = false },
			plates     = { enabled = false },
			swing      = { enabled = false },
			threat     = { enabled = false },
			totems     = { enabled = false },
			sct        = { enabled = false },
			appearance = { enabled = false },
			chatmod    = { enabled = false },
			raidtools  = { enabled = false },
			bars = {
				hideGryphons = false,
				fadeMain = false, fadeBar2 = false, fadeBar3 = false, fadeBar4 = false, fadeBar5 = false,
				fadeStance = false, fadePet = false, fadeMicro = false, fadeBags = false, fadeXP = false, fadeXP2 = false,
			},
		},
		-- Sin "blizzard": el Modo edición de Blizzard no se toca
		preview = {
			{ "bar",   P("BOTTOM", "BOTTOM", 0, 4), 540, 40 },
			{ "bar",   P("BOTTOM", "BOTTOM", 0, 48), 540, 40 },
			{ "micro", P("BOTTOMRIGHT", "BOTTOMRIGHT", -8, 4), 280, 36 },
			{ "micro", P("BOTTOMRIGHT", "BOTTOMRIGHT", -8, 44), 200, 36 },
			{ "blizz", P("TOPLEFT", "TOPLEFT", 20, -20), 230, 80 },
			{ "blizz", P("TOPLEFT", "TOPLEFT", 260, -20), 230, 80 },
		},
	},
}

R.DEFAULT_LAYOUT = "centered"

for _, t in ipairs(R.LAYOUTS) do
	t.name, t.desc = R.T(t.name), R.T(t.desc)
end

function R:GetLayout(id)
	for _, t in ipairs(self.LAYOUTS) do
		if t.id == id then return t end
	end
end

-- Escribe las posiciones de la plantilla en una base de datos de perfil
-- (sirve antes de que existan los módulos: se completan luego con sus valores)
function R:ApplyLayoutToDB(id, db)
	local t = self:GetLayout(id)
	if not t then return end
	for mod, values in pairs(t.db) do
		db[mod] = type(db[mod]) == "table" and db[mod] or {}
		for k, v in pairs(values) do db[mod][k] = self.DeepCopy(v) end
	end
	-- Para que el asistente sepa cuál está puesta (módulo "wizard")
	db.wizard = type(db.wizard) == "table" and db.wizard or {}
	db.wizard.layout = id
end

----------------------------------------------------------------------
-- Modo edición de Blizzard: crea (o rehace) un diseño con las barras
-- colocadas y lo activa. Si algo no existe en este cliente, se salta.
----------------------------------------------------------------------

local SYSTEM_INDEX = {
	ActionBar = "EditModeActionBarSystemIndices",
	UnitFrame = "EditModeUnitFrameSystemIndices",
	StatusTrackingBar = "EditModeStatusTrackingBarSystemIndices",
}

function R:CanLayoutBlizzard()
	return C_EditMode and C_EditMode.GetLayouts and C_EditMode.SaveLayouts and C_EditMode.SetActiveLayout
		and EditModePresetLayoutManager and EditModePresetLayoutManager.GetCopyOfPresetLayouts
		and Enum and Enum.EditModeSystem and true or false
end

local function resolve(entry)
	local system = Enum.EditModeSystem[entry[1]]
	if not system then return end
	local index
	if entry[2] then
		local enum = Enum[SYSTEM_INDEX[entry[1]] or ""]
		index = enum and enum[entry[2]]
		if not index then return end
	end
	return system, index
end

-- Devuelve true si se ha podido aplicar
function R:ApplyBlizzardLayout(id)
	local t = self:GetLayout(id)
	local spec = t and t.blizzard
	if not spec or not self:CanLayoutBlizzard() or InCombatLockdown() then return false end

	local ok, err = pcall(function()
		local presets = EditModePresetLayoutManager:GetCopyOfPresetLayouts()
		local info = C_EditMode.GetLayouts()
		if spec.preset then
			C_EditMode.SetActiveLayout(math.min(spec.preset, #presets))
			return
		end

		local layout = presets[1]
		layout.layoutName = spec.name
		layout.layoutType = Enum.EditModeLayoutType and Enum.EditModeLayoutType.Account or layout.layoutType
		local moved = 0
		for _, entry in ipairs(spec.systems) do
			local system, index = resolve(entry)
			if system then
				for _, s in ipairs(layout.systems) do
					if s.system == system and (index == nil or s.systemIndex == index) then
						local p = entry[3]
						s.anchorInfo = { point = p[1], relativeTo = "UIParent", relativePoint = p[2], offsetX = p[3], offsetY = p[4] }
						s.anchorInfo2 = nil
						s.isInDefaultPosition = false
						moved = moved + 1
					end
				end
			end
		end
		if moved == 0 then error("no systems") end

		-- Si ya había un diseño de Rheizor con ese nombre, se sustituye
		for i = #info.layouts, 1, -1 do
			if info.layouts[i].layoutName == spec.name then table.remove(info.layouts, i) end
		end
		table.insert(info.layouts, layout)
		info.activeLayout = #presets + #info.layouts
		C_EditMode.SaveLayouts(info)
		C_EditMode.SetActiveLayout(info.activeLayout)
	end)
	if not ok then
		self:Print(L["No se han podido colocar las barras de Blizzard (%s). Colócalas en Esc > Modo edición."]:format(tostring(err)))
	end
	return ok
end

-- Vuelve al diseño "Moderno" de Blizzard si el personaje usa uno de
-- Rheizor (o uno de sus preajustes). Un diseño propio del jugador no se toca.
function R:RestoreBlizzardLayout()
	if not self:CanLayoutBlizzard() or InCombatLockdown() then return false end
	local ok = pcall(function()
		local presets = EditModePresetLayoutManager:GetCopyOfPresetLayouts()
		local info = C_EditMode.GetLayouts()
		local active = info.activeLayout or 1
		local custom = info.layouts[active - #presets]
		local ours = false
		for _, t in pairs(self.LAYOUTS) do
			local spec = t.blizzard
			if spec and spec.preset and spec.preset == active then ours = true end
			if spec and spec.name and custom and custom.layoutName == spec.name then ours = true end
		end
		-- El que pone el perfil (BlizzardLayout.lua)
		if custom and self.IsProfileBlizzardLayout and self:IsProfileBlizzardLayout(custom.layoutName) then ours = true end
		if ours and active ~= 1 then C_EditMode.SetActiveLayout(1) end
	end)
	return ok
end

----------------------------------------------------------------------
-- Ajustar a las barras reales: cada cliente y cada escala deja las barras
-- de acción a una altura distinta, así que se mide dónde acaban de verdad
-- (con el diseño ya activo) y se sube o baja todo lo de Rheizor que va
-- abajo para quedar justo encima.
----------------------------------------------------------------------

-- Marcos del Modo edición (o, si no, por nombre) de un tipo de sistema
local FALLBACK_BARS = {
	"MainActionBar", "MainMenuBar", "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBar5",
	"StanceBar", "PetActionBar", "MainStatusTrackingBarContainer", "SecondaryStatusTrackingBarContainer",
	"MainMenuBarArtFrame", "MainMenuExpBar", "ReputationWatchBar",
}

local function barFrames()
	local list = {}
	local mgr = EditModeManagerFrame
	local frames = mgr and mgr.registeredSystemFrames
	local E = Enum and Enum.EditModeSystem
	if type(frames) == "table" and E then
		local want = { [E.ActionBar or -1] = true, [E.StatusTrackingBar or -1] = true }
		for _, f in pairs(frames) do
			if type(f) == "table" and want[f.system] then list[#list + 1] = f end
		end
	end
	-- Lo que no esté en el Modo edición (arte clásico, etc.)
	for _, name in ipairs(FALLBACK_BARS) do
		local f = _G[name]
		if type(f) == "table" and f.GetTop then list[#list + 1] = f end
	end
	return list
end

-- Borde de arriba (en unidades de UIParent) de las barras visibles que hay
-- abajo en el centro de la pantalla; nil si no se encuentra ninguna
function R:MeasureBarsTop()
	local us = UIParent:GetEffectiveScale()
	local cx, h = UIParent:GetWidth() / 2, UIParent:GetHeight()
	local top
	for _, f in ipairs(barFrames()) do
		local ok, visible = pcall(f.IsVisible, f)
		if ok and visible and f:GetTop() and f:GetLeft() then
			local s = f:GetEffectiveScale() / us
			local l, r, t, b = f:GetLeft() * s, f:GetRight() * s, f:GetTop() * s, f:GetBottom() * s
			if b < h * 0.4 and r > cx - 320 and l < cx + 320 and t > (top or 0) then top = t end
		end
	end
	return top
end

local function bottomAnchored(v)
	return type(v) == "table" and type(v[1]) == "string" and type(v[2]) == "string"
		and v[1]:find("^BOTTOM") and v[2]:find("^BOTTOM") and type(v[4]) == "number"
end

-- Sube o baja lo que la plantilla coloca abajo para que lo más bajo quede
-- justo encima de las barras. Devuelve cuánto se ha movido (o nil)
function R:FitLayoutToBars(id, db)
	local t = self:GetLayout(id)
	if not t or t.untouched then return end
	local top = self:MeasureBarsTop()
	if not top then return end
	local lowest
	for _, values in pairs(t.db) do
		for _, v in pairs(values) do
			if bottomAnchored(v) and v[1] == "BOTTOM" then lowest = math.min(lowest or v[4], v[4]) end
		end
	end
	if not lowest then return end
	local delta = math.floor(top + 10 - lowest + 0.5)
	for mod, values in pairs(t.db) do
		for key, v in pairs(values) do
			local cur = type(db[mod]) == "table" and db[mod][key]
			if bottomAnchored(v) and type(cur) == "table" then cur[4] = v[4] + delta end
		end
	end
	return delta
end

----------------------------------------------------------------------
-- Diagnóstico (/rz diag): dónde están las barras de este cliente, para
-- poder ajustar las plantillas
----------------------------------------------------------------------

local DIAG_NAMES = {
	"MainActionBar", "MainMenuBar", "MainMenuBarArtFrame", "MainMenuBarArtFrameBackground",
	"MainMenuBarLeftEndCap", "MainMenuBarRightEndCap", "MultiBarBottomLeft", "MultiBarBottomRight",
	"MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6", "MultiBar7", "StanceBar", "PetActionBar",
	"MicroMenuContainer", "MicroMenu", "BagsBar", "MainMenuBarBackpackButton",
	"StatusTrackingBarManager", "MainStatusTrackingBarContainer", "SecondaryStatusTrackingBarContainer",
	"MainMenuExpBar", "ReputationWatchBar", "PlayerFrame", "TargetFrame", "PartyFrame", "CompactRaidFrameContainer",
	"ObjectiveTrackerFrame", "MinimapCluster", "ChatFrame1",
}

local function describeFrame(f)
	local us = UIParent:GetEffectiveScale()
	local ok, visible = pcall(f.IsVisible, f)
	local out = (ok and visible) and "visible" or "oculto"
	if f.GetLeft and f:GetLeft() then
		local s = f:GetEffectiveScale() / us
		out = out .. string.format("  x=%d y=%d  %dx%d  escala=%.2f",
			f:GetLeft() * s, f:GetBottom() * s, f:GetWidth() * s, f:GetHeight() * s, f:GetScale())
	end
	if f.GetPoint and f:GetNumPoints() > 0 then
		local p, rel, rp, x, y = f:GetPoint(1)
		out = out .. string.format("  [%s %s %s %d %d]", tostring(p), rel and rel.GetName and (rel:GetName() or "?") or tostring(rel), tostring(rp), x or 0, y or 0)
	end
	return out
end

function R:BarsDiagnostic()
	local lines = {}
	local function add(s) lines[#lines + 1] = s end
	local pw, ph = GetPhysicalScreenSize()
	add(string.format("Rheizor diag · %s · pantalla %dx%d · UIParent %dx%d · uiScale %s (useUiScale %s)",
		date("%Y-%m-%d %H:%M"), pw or 0, ph or 0, UIParent:GetWidth(), UIParent:GetHeight(),
		tostring(C_CVar.GetCVar("uiScale")), tostring(C_CVar.GetCVar("useUiScale"))))
	add("Build: " .. tostring((GetBuildInfo())) .. " · interfaz " .. tostring(select(4, GetBuildInfo())))
	add("Plantilla: " .. tostring(self.db.wizard and self.db.wizard.layout) .. " · barras hasta y=" .. tostring(self:MeasureBarsTop()))

	if C_EditMode and C_EditMode.GetLayouts then
		local ok, info = pcall(C_EditMode.GetLayouts)
		if ok and info then
			local presets = EditModePresetLayoutManager and #EditModePresetLayoutManager:GetCopyOfPresetLayouts() or 0
			local active = info.activeLayout or 0
			local custom = info.layouts and info.layouts[active - presets]
			add(string.format("Modo edición: diseño %d (%s), %d predefinidos", active, custom and custom.layoutName or "predefinido", presets))
		end
	end

	local E = Enum and Enum.EditModeSystem
	local names = {}
	if E then for k, v in pairs(E) do names[v] = k end end
	local mgr = EditModeManagerFrame
	if mgr and type(mgr.registeredSystemFrames) == "table" then
		add("")
		add("Sistemas del Modo edición:")
		for _, f in pairs(mgr.registeredSystemFrames) do
			if type(f) == "table" then
				add(string.format("  %s #%s %s: %s", tostring(names[f.system] or f.system), tostring(f.systemIndex),
					f.GetName and f:GetName() or "?", describeFrame(f)))
			end
		end
	end
	add("")
	add("Marcos:")
	for _, name in ipairs(DIAG_NAMES) do
		local f = _G[name]
		if type(f) == "table" and f.GetObjectType then
			add("  " .. name .. ": " .. describeFrame(f))
		else
			add("  " .. name .. ": no existe")
		end
	end
	add("")
	add("Rheizor:")
	for _, key in ipairs({ "uf_player", "uf_target", "uf_pet", "uf_focus" }) do
		local d = self.db[key]
		if type(d) == "table" and type(d.point) == "table" then
			add(string.format("  %s: %s %s %s %s  %sx%s", key, tostring(d.point[1]), tostring(d.point[2]),
				tostring(d.point[3]), tostring(d.point[4]), tostring(d.width), tostring(d.height)))
		end
	end
	return table.concat(lines, "\n")
end

----------------------------------------------------------------------
-- Vista previa: rectángulos en una pantalla de 1366 x 768
----------------------------------------------------------------------

local SW, SH = 1366, 768

local UNIT_SIZE = {
	uf_player = { 260, 52 }, uf_target = { 260, 52 }, uf_targettarget = { 150, 30 },
	uf_pet = { 150, 30 }, uf_focus = { 220, 40 },
}

local BLIZZ_SIZE = {
	-- (la barra 6 no se dibuja: casi nadie la tiene activada)
	MainBar = { 540, 40 }, Bar2 = { 540, 40 }, Bar3 = { 540, 40 },
	StanceBar = { 280, 30 }, PetActionBar = { 280, 30 },
	MicroMenu = { 280, 36 }, Bags = { 200, 38 },
	Party = { 150, 200 }, Raid = { 360, 170 },
	StatusTrackingBar1 = { 570, 12 }, StatusTrackingBar2 = { 570, 12 },
}
local BLIZZ_KIND = {
	MainBar = "bar", Bar2 = "bar", Bar3 = "bar", Bar6 = "bar", StanceBar = "bar", PetActionBar = "bar",
	MicroMenu = "micro", Bags = "micro", Party = "group", Raid = "group",
	StatusTrackingBar1 = "xp", StatusTrackingBar2 = "xp",
}

local function fx(point)
	if point:find("LEFT") then return 0 elseif point:find("RIGHT") then return 1 end
	return 0.5
end
local function fy(point)
	if point:find("TOP") then return 1 elseif point:find("BOTTOM") then return 0 end
	return 0.5
end

-- Rectángulo { x, y, w, h } en píxeles de la pantalla de muestra (origen abajo a la izquierda)
local function rect(p, w, h)
	local ax = fx(p[2]) * SW + p[3]
	local ay = fy(p[2]) * SH + p[4]
	return { ax - fx(p[1]) * w, ay - fy(p[1]) * h, w, h }
end

-- Lista de { tipo, x, y, w, h } normalizados (0 a 1) para dibujar la plantilla
function R:LayoutPreview(id)
	local t = self:GetLayout(id)
	local out = {}
	local function add(kind, r)
		out[#out + 1] = { kind, r[1] / SW, r[2] / SH, r[3] / SW, r[4] / SH }
	end
	-- Lo que no cambia: chat y minimapa
	add("static", rect(P("BOTTOMLEFT", "BOTTOMLEFT", 30, 40), 420, 170))
	add("static", rect(P("TOPRIGHT", "TOPRIGHT", -20, -20), 170, 170))

	if t.preview then
		for _, e in ipairs(t.preview) do add(e[1], rect(e[2], e[3], e[4])) end
	elseif t.blizzard and t.blizzard.systems then
		for _, e in ipairs(t.blizzard.systems) do
			local key = e[2] or e[1]
			local size = BLIZZ_SIZE[key]
			if size then add(BLIZZ_KIND[key], rect(e[3], size[1], size[2])) end
		end
	end
	if t.untouched then return out end

	local db = t.db
	for mod, size in pairs(UNIT_SIZE) do
		local d = db[mod]
		add("unit", rect(d.point, d.width or size[1], d.height or size[2]))
	end
	local c = db.castbars
	add("cast", rect(c.pPoint, c.pWidth, c.pHeight))
	add("cast", rect(c.tPoint, c.tWidth, c.tHeight))
	add("threat", rect(db.threat.point, db.threat.width, 110))
	add("swing", rect(db.swing.point, db.swing.width, 30))
	return out
end
