-- Historial de copias de seguridad de cada perfil, por si alguien lo lía.
--   RheizorDB.snapshots[perfil] = { { id, name, auto, time, data = { db, cvars } }, ... }
-- (la más nueva al final). Se guarda una sola al entrar si la configuración
-- ha cambiado desde la última, y otra antes de todo lo que la sustituye:
-- importar, restablecer, el asistente, copiar un perfil, restaurar...
-- También se pueden guardar a mano con un nombre (/rz, página de Rheizor-Core).

local R = Rheizor:Namespace(...)
local L = R.L

-- Cuántas copias se guardan por perfil. Son de toda la cuenta (como las
-- copias), en RheizorDB.snapshotLimits = { auto = 10, manual = 20 }
local DEFAULT_AUTO, DEFAULT_MANUAL = 10, 20

local function limits()
	local s = R.store and R.store.snapshotLimits
	local auto = s and tonumber(s.auto) or DEFAULT_AUTO
	local manual = s and tonumber(s.manual) or DEFAULT_MANUAL
	return auto, manual
end

local function equal(a, b)
	if a == b then return true end
	if type(a) ~= "table" or type(b) ~= "table" then return false end
	for k, v in pairs(a) do
		if not equal(v, b[k]) then return false end
	end
	for k in pairs(b) do
		if a[k] == nil then return false end
	end
	return true
end

local function all()
	if type(R.store.snapshots) ~= "table" then R.store.snapshots = {} end
	return R.store.snapshots
end

local function listFor(profile)
	local snaps = all()
	if type(snaps[profile]) ~= "table" then snaps[profile] = {} end
	return snaps[profile]
end

local function isAuto(s) return s.auto and true or false end
-- Las de al entrar (las antiguas no llevan la marca: se miran por el nombre)
local function isLogin(s) return s.login or s.name == L["Al entrar"] or s.name == "Al entrar" or s.name == "On login" end

-- Guarda una copia del perfil actual. Las automáticas no se guardan si no
-- ha cambiado nada desde la última copia y se borran las más viejas.
-- login = la de al entrar: son las primeras que se borran, para que las de
-- "Antes de copiar/importar/restaurar…" duren más (el 26/09 una copia de
-- perfil machacó uno y su única copia buena se perdió tras unos cuantos
-- inicios de sesión).
-- Devuelve la copia, o nil si no se ha guardado.
function R:TakeSnapshot(name, auto, login)
	if not (self.store and self.CaptureConfig) then return end
	auto = auto and true or false
	local MAX_AUTO, MAX_MANUAL = limits()
	-- Con 0 automáticas no se guarda ninguna sola
	if auto and MAX_AUTO <= 0 then return end
	local snaps = listFor(self.profile)
	local data = self:CaptureConfig()
	local last = snaps[#snaps]
	if auto and last and equal(last.data, data) then
		-- Igual que la de al entrar: esa pasa a ser la de antes del cambio
		-- (con su nombre) para que no se borre la primera
		if not login and isLogin(last) then
			last.name, last.login = name, nil
			return last
		end
		return
	end

	local count = 0
	for _, s in ipairs(snaps) do
		if isAuto(s) == auto then count = count + 1 end
	end
	if not auto and count >= MAX_MANUAL then
		self:Print(L["Ya tienes %d copias guardadas a mano en este perfil. Borra alguna para guardar otra."]:format(MAX_MANUAL))
		return
	end
	-- Sobran automáticas: primero se van las de al entrar más viejas, luego las demás
	for _, pass in ipairs({ "login", "any" }) do
		local i = 1
		while auto and count >= MAX_AUTO and i <= #snaps do
			local s = snaps[i]
			if isAuto(s) and (pass == "any" or isLogin(s)) then
				table.remove(snaps, i)
				count = count - 1
			else
				i = i + 1
			end
		end
	end

	local seq = (tonumber(self.store.snapshotSeq) or 0) + 1
	self.store.snapshotSeq = seq
	local snap = { id = seq, name = name, auto = auto or nil, login = login and true or nil, time = time(), data = data }
	snaps[#snaps + 1] = snap
	return snap
end

-- Cambiar el límite no borra nada al momento (el deslizador se puede
-- arrastrar arriba y abajo): las automáticas que sobren se van la próxima
-- vez que se guarde una. Las manuales nunca se borran solas.
local function setLimit(key, value)
	if not R.store then return end
	if type(R.store.snapshotLimits) ~= "table" then R.store.snapshotLimits = {} end
	R.store.snapshotLimits[key] = math.floor(value + 0.5)
end

R:RegisterModule("snapshots", {
	title = "Copias de seguridad",
	-- Historial, guardar, restaurar, exportar e importar: lo dibuja Manager.lua
	panel = "backups",
	options = {
		{ type = "header", text = "Cuántas se guardan en cada perfil" },
		{ type = "slider", id = "snapshotsAuto", name = "Copias automáticas", min = 0, max = 50, step = 1, format = R.fmt.int,
		  default = DEFAULT_AUTO,
		  get = function() return (limits()) end,
		  set = function(v) setLimit("auto", v) end,
		  desc = "Las que se guardan solas al entrar (si algo ha cambiado) y antes de importar, restablecer o restaurar. Al llegar al máximo, cada nueva sustituye a la más antigua. Si bajas el número, las más viejas que sobren se borran la próxima vez que se guarde una. Con 0 no se guarda ninguna sola." },
		{ type = "slider", id = "snapshotsManual", name = "Copias guardadas a mano", min = 1, max = 100, step = 1, format = R.fmt.int,
		  default = DEFAULT_MANUAL,
		  get = function() return select(2, limits()) end,
		  set = function(v) setLimit("manual", v) end,
		  desc = "Las que guardas tú con un nombre. Nunca se borran solas: al llegar al máximo no deja guardar más hasta que borres alguna." },
	},
})

function R:SaveSnapshot(name)
	name = strtrim(name or "")
	if name == "" then name = L["Copia manual"] end
	if #name > 40 then name = name:sub(1, 40) end
	if self:TakeSnapshot(name, false) then
		self:Print(L["Copia guardada: %s"]:format(name))
	end
end

-- Copias que se pueden restaurar desde este perfil: las suyas y las de
-- perfiles que ya no existen (por ejemplo, tras borrarlo todo). Más nuevas primero.
function R:GetSnapshotList()
	local out = {}
	for profile, snaps in pairs(all()) do
		if type(snaps) == "table" and (profile == self.profile or type(self.store.profiles[profile]) ~= "table") then
			for _, s in ipairs(snaps) do
				if type(s) == "table" and type(s.data) == "table" then
					out[#out + 1] = { snap = s, profile = profile }
				end
			end
		end
	end
	table.sort(out, function(a, b) return (a.snap.id or 0) > (b.snap.id or 0) end)
	return out
end

function R:SnapshotLabel(entry)
	local s = entry.snap
	local text = date("%d/%m %H:%M", s.time or 0) .. "  " .. (s.name or "?")
	if s.auto then text = text .. " |cff888888(" .. L["automática"] .. ")|r" end
	if entry.profile ~= self.profile then
		text = text .. " |cffff8800[" .. self:ProfileLabel(entry.profile) .. "]|r"
	end
	return text
end

local function find(id)
	for profile, snaps in pairs(all()) do
		if type(snaps) == "table" then
			for i, s in ipairs(snaps) do
				if s.id == id then return s, snaps, i end
			end
		end
	end
end

-- Deja el perfil actual como estaba en esa copia y recarga
function R:RestoreSnapshot(id)
	if InCombatLockdown() then
		self:Print(L["No se puede restaurar en combate."])
		return
	end
	local s = find(id)
	if not s then return end
	local data = s.data
	self:TakeSnapshot(L["Antes de restaurar"], true)
	self:RestoreConfig(data)
	ReloadUI()
end

function R:DeleteSnapshot(id)
	local _, snaps, i = find(id)
	if snaps then table.remove(snaps, i) end
end

-- Una copia al entrar (solo si algo ha cambiado desde la última). Un poco
-- después, cuando los módulos ya han rellenado sus valores por defecto.
local events = CreateFrame("Frame")
events:RegisterEvent("PLAYER_LOGIN")
events:SetScript("OnEvent", function(self)
	self:UnregisterAllEvents()
	C_Timer.After(5, function() R:TakeSnapshot(L["Al entrar"], true, true) end)
end)
