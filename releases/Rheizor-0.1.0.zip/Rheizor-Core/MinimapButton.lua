-- Icono de Rheizor en el borde del minimapa: clic para abrir el gestor (/rz),
-- se arrastra alrededor del mapa. También puede ir en el menú de addons de
-- Blizzard (el botón que agrupa los iconos de addons).
-- Si el minimapa es cuadrado (GetMinimapShape, la convención de LibDBIcon que
-- usa Rheizor-Minimap) el icono sigue el borde cuadrado.

local R = Rheizor:Namespace(...)
local L = R.L

local ICON = "Interface\\Icons\\INV_Misc_Gear_01"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local DEFAULT_ANGLE = 225

local RIGHT_CLICK = {
	{ "editmode", "Modo edición de Rheizor" },
	{ "reload", "Recargar la interfaz" },
	{ "none", "Nada" },
}

local M = R:RegisterModule("minimapicon", {
	title = "Icono del minimapa",
	defaults = {
		show = true,
		locked = false,
		angle = DEFAULT_ANGLE,
		size = 31,
		style = "classic",
		onHover = false,
		rightClick = "editmode",
		compartment = true,
		tooltip = true,
	},
	options = {
		{ type = "header", text = "Icono" },
		{ type = "toggle", key = "show", name = "Mostrar el icono en el minimapa",
		  desc = "Clic izquierdo abre este gestor. Si lo quitas, sigues teniendo /rz (y el menú de addons, si lo dejas activado abajo)." },
		{ type = "toggle", key = "onHover", name = "Solo al pasar el ratón por el minimapa",
		  desc = "El icono queda invisible hasta que pones el ratón encima del minimapa." },
		{ type = "dropdown", key = "style", name = "Estilo",
		  values = { { "classic", "Clásico (aro dorado)" }, { "flat", "Plano (color de Rheizor)" } },
		  desc = "Plano usa el color de la ventana del gestor y queda mejor con el minimapa cuadrado." },
		{ type = "slider", key = "size", name = "Tamaño", min = 20, max = 44, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "tooltip", name = "Mostrar ayuda al pasar el ratón" },

		{ type = "header", text = "Posición" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueado, el icono se arrastra alrededor del borde del minimapa." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end,
		  desc = "Vuelve a ponerlo abajo a la izquierda del minimapa." },

		{ type = "header", text = "Clics" },
		{ type = "dropdown", key = "rightClick", name = "Clic derecho", values = RIGHT_CLICK,
		  desc = "El clic izquierdo siempre abre el gestor." },

		{ type = "header", text = "Menú de addons" },
		{ type = "toggle", key = "compartment", name = "Mostrar en el menú de addons", reload = true,
		  desc = "Añade Rheizor a la lista del botón de addons de Blizzard (junto al minimapa). Quitarlo necesita /reload." },
	},
})

local button

local function accentRGB()
	local hex = R.db and R.db.manager and R.db.manager.accent or "33ccff"
	local ok, r, g, b = pcall(R.HexToRGB, hex)
	if ok and r then return r, g, b end
	return 0.2, 0.8, 1
end

----------------------------------------------------------------------
-- Acciones
----------------------------------------------------------------------

local function rightClickLabel()
	for _, v in ipairs(RIGHT_CLICK) do
		if v[1] == M.db.rightClick then return v[2] end
	end
end

local function onClick(which)
	if which == "RightButton" then
		local action = M.db.rightClick
		if action == "editmode" and R.modules.editmode then
			R.modules.editmode:Toggle()
		elseif action == "reload" then
			ReloadUI()
		end
	elseif R.OpenManager then
		R:OpenManager()
	end
end

local function showTooltip(owner)
	if not M.db.tooltip then return end
	GameTooltip:SetOwner(owner, "ANCHOR_LEFT")
	GameTooltip:AddLine("Rheizor", accentRGB())
	GameTooltip:AddLine(L["|cffffffffClic:|r abrir el gestor"], 0.8, 0.8, 0.8)
	if M.db.rightClick ~= "none" then
		GameTooltip:AddLine(L["|cffffffffClic derecho:|r %s"]:format(rightClickLabel() or ""), 0.8, 0.8, 0.8)
	end
	if owner == button and not M.db.locked and not button.rzCollected then
		GameTooltip:AddLine(L["|cffffffffArrastrar:|r mover el icono"], 0.8, 0.8, 0.8)
	end
	GameTooltip:Show()
end

----------------------------------------------------------------------
-- Posición en el borde del minimapa (como LibDBIcon)
----------------------------------------------------------------------

local function place()
	-- rzCollected: Rheizor-MinimapButtons lo ha metido en su panel
	if not button or button.rzCollected then return end
	local rad = math.rad(M.db.angle or DEFAULT_ANGLE)
	local x, y = math.cos(rad), math.sin(rad)
	local w = Minimap:GetWidth() / 2 + 5
	local h = Minimap:GetHeight() / 2 + 5
	local shape = GetMinimapShape and GetMinimapShape() or "ROUND"
	if shape == "SQUARE" then
		-- Proyecta sobre el cuadrado: la coordenada mayor toca el borde
		local m = math.max(math.abs(x), math.abs(y))
		x, y = x / m * w, y / m * h
	else
		x, y = x * w, y * h
	end
	button:ClearAllPoints()
	button:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function angleFromCursor()
	local mx, my = Minimap:GetCenter()
	local px, py = GetCursorPosition()
	local scale = Minimap:GetEffectiveScale()
	px, py = px / scale, py / scale
	return math.deg(math.atan2(py - my, px - mx)) % 360
end

----------------------------------------------------------------------
-- Botón
----------------------------------------------------------------------

-- Solo al pasar el ratón: se mira unas veces por segundo si está encima
local hoverWatch
local function updateHover()
	if not button or button.rzCollected then return end
	local visible = not M.db.onHover or button.dragging
		or Minimap:IsMouseOver() or button:IsMouseOver()
	button:SetAlpha(visible and 1 or 0)
end

local function create()
	button = CreateFrame("Button", "RheizorMinimapButton", Minimap)
	button:SetFrameStrata("MEDIUM")
	button:SetFrameLevel(Minimap:GetFrameLevel() + 8)
	button:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	button:RegisterForDrag("LeftButton")
	button:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")

	button.bg = button:CreateTexture(nil, "BACKGROUND")
	button.icon = button:CreateTexture(nil, "ARTWORK")
	button.ring = button:CreateTexture(nil, "OVERLAY")
	-- Estilo plano: fondo oscuro y un borde fino del color de acento
	button.flat = CreateFrame("Frame", nil, button, "BackdropTemplate")
	button.flat:SetAllPoints()
	button.flat:SetFrameLevel(button:GetFrameLevel())
	button.flat:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })

	button:SetScript("OnClick", function(self, which)
		GameTooltip:Hide()
		onClick(which)
	end)
	button:SetScript("OnEnter", showTooltip)
	button:SetScript("OnLeave", function() GameTooltip:Hide() end)
	button:SetScript("OnDragStart", function(self)
		if M.db.locked or self.rzCollected then return end
		self.dragging = true
		GameTooltip:Hide()
		self:SetScript("OnUpdate", function()
			M.db.angle = angleFromCursor()
			place()
		end)
	end)
	button:SetScript("OnDragStop", function(self)
		self.dragging = nil
		self:SetScript("OnUpdate", nil)
	end)

	hoverWatch = CreateFrame("Frame", nil, button)
	local elapsed = 0
	hoverWatch:SetScript("OnUpdate", function(_, dt)
		elapsed = elapsed + dt
		if elapsed < 0.15 then return end
		elapsed = 0
		updateHover()
	end)

	-- Si Rheizor-Minimap cambia la forma o el tamaño del mapa
	Minimap:HookScript("OnSizeChanged", place)
end

local function applyStyle()
	local size = M.db.size
	button:SetSize(size, size)
	local flat = M.db.style == "flat"
	local icon = button.icon
	icon:SetTexture(ICON)
	icon:ClearAllPoints()
	if flat then
		icon:SetPoint("TOPLEFT", 2, -2)
		icon:SetPoint("BOTTOMRIGHT", -2, 2)
		icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		button.bg:Hide()
		button.ring:Hide()
		button.flat:Show()
		button.flat:SetBackdropColor(0.05, 0.05, 0.07, 0.9)
		button.flat:SetBackdropBorderColor(accentRGB())
		button:GetHighlightTexture():SetAlpha(0)
	else
		-- Las medidas clásicas de un botón de minimapa (31 px), a escala
		local k = size / 31
		icon:SetSize(20 * k, 20 * k)
		icon:SetPoint("CENTER", 0, 0)
		icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		button.bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
		button.bg:SetSize(24 * k, 24 * k)
		button.bg:ClearAllPoints()
		button.bg:SetPoint("CENTER")
		button.bg:Show()
		button.ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
		button.ring:SetSize(53 * k, 53 * k)
		button.ring:ClearAllPoints()
		button.ring:SetPoint("TOPLEFT")
		button.ring:Show()
		button.flat:Hide()
		button:GetHighlightTexture():SetAlpha(1)
	end
end

function M:Apply()
	if not self.db.show then
		if button then button:Hide() end
		return
	end
	if not button then create() end
	applyStyle()
	place()
	updateHover()
	button:Show()
end

function M:ResetPosition()
	self.db.angle = DEFAULT_ANGLE
	place()
end

----------------------------------------------------------------------
-- Menú de addons de Blizzard
----------------------------------------------------------------------

-- No se puede quitar de la lista sin recargar: solo se añade una vez
local registered = false
local function registerCompartment()
	local frame = AddonCompartmentFrame
	if registered or not (frame and frame.RegisterAddon) then return end
	registered = pcall(frame.RegisterAddon, frame, {
		text = "Rheizor",
		icon = ICON,
		notCheckable = true,
		registerForAnyClick = true,
		func = function(_, input)
			local which = type(input) == "table" and input.buttonName or "LeftButton"
			onClick(which)
		end,
		funcOnEnter = function(item) showTooltip(item) end,
		funcOnLeave = function() GameTooltip:Hide() end,
	})
end

function M:OnEnable()
	self:Apply()
	if self.db.compartment then registerCompartment() end
end

function M:OnOptionChanged(key, value)
	if key == "compartment" then
		if value then registerCompartment() end
		return
	end
	self:Apply()
end
