-- Tanques y amenaza: quién es tanque (tú y tu grupo) y en qué situación de
-- amenaza estás con un enemigo. Lo usan las placas (Rheizor-Nameplates) y el
-- marco de objetivo (Rheizor-UnitFrames).
--
-- Para los módulos:
--   R:IsPlayerTank()           ¿eres tanque ahora?
--   R:GroupTankUnits()         unidades de tu grupo que son tanque (sin ti)
--   R.ThreatUnit(mob)          otro nombre del mismo enemigo con la amenaza en claro
--   R:ThreatLevel(mob[, tank]) "ok", "warn", "danger", "offtank" o nil; y el
--                              estado del juego (0-3, o secreto) y la unidad leída
--   R:OnTanksChanged(fn)       fn() al cambiar quién es tanque o estas opciones
--
-- Quién es tanque sale de tres sitios, cada uno se puede apagar:
--   · el papel de tanque del grupo (UnitGroupRolesAssigned)
--   · los tanques principales de la banda (GetPartyAssignment)
--   · los compañeros con Rheizor, que avisan por mensaje de addon
-- Y para ti, además, la actitud defensiva, la forma de oso o Furia recta.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local PREFIX = "RZTank"
local RIGHTEOUS_FURY = 25780

-- (las opciones se leen de R.db: T aún no existe al crear la tabla)
local function notAuto()
	local d = R.db and R.db.tanks
	if d and d.myRole ~= "auto" then return L["Solo en automático."] end
end

local T = R:RegisterModule("tanks", {
	title = "Tanques y amenaza",
	defaults = {
		myRole = "auto",
		autoStance = true,
		autoRole = true,
		autoMainTank = true,
		otherRole = true,
		otherMainTank = true,
		otherAddon = true,
		share = true,
		offtank = true,
		offtankDps = false,
	},
	options = {
		{ type = "header", text = "Tu papel" },
		{ type = "dropdown", key = "myRole", name = "Eres",
		  values = {
			{ "auto", "Automático" },
			{ "tank", "Siempre tanque" },
			{ "dps", "Siempre daño o sanador" },
		  },
		  desc = "Lo usan los colores de amenaza de las placas y la amenaza del marco de objetivo cuando están en «Automático»." },
		{ type = "toggle", key = "autoStance", name = "Tanque en actitud defensiva, forma de oso o con Furia recta",
		  disabled = notAuto },
		{ type = "toggle", key = "autoRole", name = "Tanque si tienes el papel de tanque en el grupo",
		  disabled = notAuto },
		{ type = "toggle", key = "autoMainTank", name = "Tanque si eres tanque principal de la banda",
		  disabled = notAuto },

		{ type = "header", text = "Otros tanques de tu grupo" },
		{ type = "toggle", key = "otherRole", name = "Los que tienen el papel de tanque" },
		{ type = "toggle", key = "otherMainTank", name = "Los tanques principales de la banda",
		  desc = "Clic derecho en el marco de banda > Tanque principal." },
		{ type = "toggle", key = "otherAddon", name = "Los que avisan con Rheizor",
		  desc = "Compañeros con Rheizor y «Avisar a tu grupo» activado. Es lo más fiable: cada uno sabe si está en actitud defensiva o en oso." },
		{ type = "toggle", key = "share", name = "Avisar a tu grupo cuando eres tanque",
		  desc = "Manda un mensaje de addon al grupo o banda al cambiar de papel. Dentro de mazmorras y bandas el juego puede bloquear los mensajes en combate: se manda al salir." },
		{ type = "button", name = "Tanques detectados", text = "Mostrar en el chat", func = function(mod) mod:Report() end },

		{ type = "header", text = "Otro tanque tiene el agro" },
		{ type = "toggle", key = "offtank", name = "Distinguirlo siendo tanque",
		  desc = "Si el enemigo va a por otro tanque, en vez de «peligro» sale su propio color (azul, como en Plater). El color se elige en cada addon." },
		{ type = "toggle", key = "offtankDps", name = "Distinguirlo también siendo daño o sanador",
		  desc = "Los enemigos que lleva un tanque salen en ese color en vez de como «bien»." },
	},
})

local db
local listeners = {}
local myTank = false
local tankUnits = {}          -- unidades del grupo que son tanque (sin ti)
local byAddon = {}            -- nombre -> true/false, según sus mensajes
local myRealm = GetNormalizedRealmName and GetNormalizedRealmName() or ""

function R:OnTanksChanged(fn)
	listeners[#listeners + 1] = fn
end

local function notify()
	for _, fn in ipairs(listeners) do pcall(fn) end
end

----------------------------------------------------------------------
-- Quién es tanque
----------------------------------------------------------------------

local function stanceTank()
	local class = R:PlayerClass()
	if class == "WARRIOR" then
		return GetShapeshiftForm() == 2      -- actitud defensiva
	elseif class == "DRUID" then
		local id = GetShapeshiftFormID and GetShapeshiftFormID()
		return id == 5 or id == 8             -- oso, oso temible
	elseif class == "PALADIN" and C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID then
		local ok, aura = pcall(C_UnitAuras.GetPlayerAuraBySpellID, RIGHTEOUS_FURY)
		return ok and aura ~= nil
	end
	return false
end

local function roleTank(unit)
	return UnitGroupRolesAssigned and NS(UnitGroupRolesAssigned(unit)) == "TANK"
end

local function mainTank(unit)
	if not (IsInRaid() and GetPartyAssignment) then return false end
	local ok, is = pcall(GetPartyAssignment, "MAINTANK", unit)
	return ok and NS(is) and true or false
end

local function computeMine()
	if not db then return false end
	if db.myRole ~= "auto" then return db.myRole == "tank" end
	if db.autoStance and stanceTank() then return true end
	if db.autoRole and roleTank("player") then return true end
	if db.autoMainTank and mainTank("player") then return true end
	return false
end

function R:IsPlayerTank()
	return myTank
end

-- "Nombre-Reino" -> "Nombre" si es tu reino (así llegan los mensajes)
local function normalize(name)
	name = NS(name)
	if type(name) ~= "string" then return end
	local short, realm = name:match("^(.-)%-(.+)$")
	if short and (realm == myRealm or realm == "") then return short end
	return name
end

local function groupUnits()
	local list = {}
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do list[#list + 1] = "raid" .. i end
	elseif IsInGroup() then
		for i = 1, GetNumSubgroupMembers() do list[#list + 1] = "party" .. i end
	end
	return list
end

local function isMe(unit)
	local same = NS(UnitIsUnit(unit, "player"))
	if same ~= nil then return same and true or false end
	local guid = NS(UnitGUID(unit))
	return guid ~= nil and guid == NS(UnitGUID("player"))
end

-- Por qué es tanque (para el informe); nil si no lo es
local function tankReason(unit)
	if db.otherAddon then
		local v = byAddon[normalize(GetUnitName(unit, true)) or ""]
		if v then return L["avisa con Rheizor"] end
	end
	if db.otherRole and roleTank(unit) then return L["papel de tanque"] end
	if db.otherMainTank and mainTank(unit) then return L["tanque principal"] end
end

local function rebuild()
	wipe(tankUnits)
	if not db then return end
	for _, unit in ipairs(groupUnits()) do
		if UnitExists(unit) and not isMe(unit) and tankReason(unit) then tankUnits[#tankUnits + 1] = unit end
	end
end

function R:GroupTankUnits()
	return tankUnits
end

----------------------------------------------------------------------
-- Mensajes entre compañeros con Rheizor
----------------------------------------------------------------------

local lastSent, lastValue = 0, nil
local sendPending = false

local function channel()
	if IsInRaid() then return "RAID" end
	if IsInGroup(LE_PARTY_CATEGORY_INSTANCE or 2) then return "INSTANCE_CHAT" end
	if IsInGroup() then return "PARTY" end
end

local function lockedDown()
	if not (C_ChatInfo and C_ChatInfo.InChatMessagingLockdown) then return false end
	local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
	return ok and NS(locked) == true
end

local function send(force)
	if not (db and db.share and C_ChatInfo and C_ChatInfo.SendAddonMessage) then return end
	local ch = channel()
	if not ch or lockedDown() then return end
	if not force and lastValue == myTank then return end
	if pcall(C_ChatInfo.SendAddonMessage, PREFIX, myTank and "T1" or "T0", ch) then
		lastSent, lastValue = GetTime(), myTank
	end
end

-- Se agrupan los cambios: como mucho un mensaje cada 3 segundos
local function scheduleSend(force)
	if sendPending then return end
	sendPending = true
	local wait = math.max(1, 3 - (GetTime() - lastSent))
	C_Timer.After(wait, function()
		sendPending = false
		send(force)
	end)
end

local function onMessage(prefix, text, _, sender)
	if prefix ~= PREFIX or not db then return end
	local name = normalize(sender)
	if not name or name == normalize(GetUnitName("player", true)) then return end
	local value = text:sub(1, 2)
	if value == "T1" or value == "T0" then
		local tank = value == "T1"
		if byAddon[name] ~= tank then
			byAddon[name] = tank
			rebuild()
			notify()
		end
	end
end

----------------------------------------------------------------------
-- Amenaza
----------------------------------------------------------------------

-- En Forever la amenaza leída desde la placa ("nameplate3") llega secreta,
-- pero la del mismo enemigo como "target" no. Se busca el mismo enemigo con
-- otro nombre: tu objetivo, foco, ratón, el objetivo de tu mascota o el de
-- tus compañeros. Para no repetir la búsqueda en cada placa, cada 0,2 s se
-- hace una tabla GUID -> nombre legible.
local ALT_TOKENS = { "target", "focus", "mouseover", "pettarget" }
local PARTY_TARGETS, RAID_TARGETS = {}, {}
for i = 1, 4 do PARTY_TARGETS[i] = "party" .. i .. "target" end
for i = 1, 40 do RAID_TARGETS[i] = "raid" .. i .. "target" end

function R.ThreatSecret(mob)
	if not (C_Secrets and C_Secrets.ShouldUnitThreatValuesBeSecret) then return false end
	local ok, secret = pcall(C_Secrets.ShouldUnitThreatValuesBeSecret, "player", mob)
	if not ok then return false end
	return NS(secret) ~= false
end

local function sameUnit(a, b)
	local same = NS(UnitIsUnit(a, b))
	if same ~= nil then return same and true or false end
	local ga, gb = NS(UnitGUID(a)), NS(UnitGUID(b))
	return ga ~= nil and ga == gb
end

local readable, readableAt = {}, 0

local function refreshReadable()
	local now = GetTime()
	if now - readableAt < 0.2 then return end
	readableAt = now
	wipe(readable)
	local function add(list)
		for _, token in ipairs(list) do
			if UnitExists(token) and not R.ThreatSecret(token) then
				local guid = NS(UnitGUID(token))
				if guid and not readable[guid] then readable[guid] = token end
			end
		end
	end
	add(ALT_TOKENS)
	add(IsInRaid() and RAID_TARGETS or PARTY_TARGETS)
end

function R.ThreatUnit(mob)
	if not R.ThreatSecret(mob) then return mob end
	refreshReadable()
	local guid = NS(UnitGUID(mob))
	if guid then return readable[guid] or mob end
	-- Sin GUID legible: comparar uno a uno
	for _, list in ipairs({ ALT_TOKENS, IsInRaid() and RAID_TARGETS or PARTY_TARGETS }) do
		for _, token in ipairs(list) do
			if UnitExists(token) and sameUnit(mob, token) and not R.ThreatSecret(token) then return token end
		end
	end
	return mob
end

-- ¿Va el enemigo a por otro tanque de tu grupo?
local function otherTankHas(mob)
	for _, unit in ipairs(tankUnits) do
		local ok, tanking = pcall(UnitDetailedThreatSituation, unit, mob)
		local t = ok and NS(tanking)
		if t then return true end
		-- Sin dato (o secreto): a quién apunta el enemigo
		if t == nil then
			local target = mob .. "target"
			if UnitExists(target) and sameUnit(target, unit) then return true end
		end
	end
	return false
end

-- status del juego: 0 sin agro y poca amenaza, 1 más amenaza que quien lo
-- tiene pero aún no va a por ti, 2 agro pero otro te supera, 3 agro seguro
function R:ThreatLevel(mob, tank)
	if not (mob and UnitExists(mob)) then return end
	if tank == nil then tank = myTank end
	local via = R.ThreatUnit(mob)
	local ok, status = pcall(UnitThreatSituation, "player", via)
	if not ok then return end
	local s = NS(status)
	if s == nil then return nil, status, via end
	local off = db and (tank and db.offtank or (not tank and db.offtankDps))
	if tank then
		if s == 3 then return "ok", status, via end
		if s == 2 then return "warn", status, via end
		if off and otherTankHas(via) then return "offtank", status, via end
		return s == 1 and "warn" or "danger", status, via
	end
	if s == 0 then
		if off and otherTankHas(via) then return "offtank", status, via end
		return "ok", status, via
	end
	if s == 1 then return "warn", status, via end
	return "danger", status, via
end

----------------------------------------------------------------------

function T:Report()
	rebuild()
	R:Print(L["Tú: %s"]:format(myTank and L["tanque"] or L["daño o sanador"]))
	if #tankUnits == 0 then
		R:Print(L["No se ha detectado ningún otro tanque en tu grupo."])
	end
	for _, unit in ipairs(tankUnits) do
		R:Print(("%s — %s"):format(NS(GetUnitName(unit, true)) or unit, tankReason(unit) or "?"))
	end
end

local function refresh(forceSend)
	local was = myTank
	myTank = computeMine()
	rebuild()
	if was ~= myTank or forceSend then scheduleSend(forceSend) end
	notify()
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, ...)
	if event == "CHAT_MSG_ADDON" then
		onMessage(...)
	elseif event == "UNIT_AURA" then
		-- Solo importa para Furia recta: se mira si ha cambiado
		if computeMine() ~= myTank then refresh() end
	elseif event == "GROUP_ROSTER_UPDATE" then
		-- Alguien nuevo: que sepa lo que eres
		refresh(true)
	elseif event == "PLAYER_REGEN_ENABLED" then
		-- Lo que no se pudo mandar en combate
		if lastValue ~= myTank then scheduleSend() end
	else
		refresh()
	end
end)

function T:OnEnable()
	db = self.db
	myRealm = GetNormalizedRealmName and GetNormalizedRealmName() or myRealm
	if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX) end
	for _, e in ipairs({ "CHAT_MSG_ADDON", "GROUP_ROSTER_UPDATE", "PLAYER_ROLES_ASSIGNED", "UPDATE_SHAPESHIFT_FORM",
		"UPDATE_SHAPESHIFT_FORMS", "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED" }) do
		pcall(events.RegisterEvent, events, e)
	end
	if R:PlayerClass() == "PALADIN" then pcall(events.RegisterUnitEvent, events, "UNIT_AURA", "player") end
	refresh(true)
end

function T:OnOptionChanged(key)
	if key == "share" and db.share then
		lastValue = nil
		scheduleSend(true)
	end
	refresh()
end
