-- Modo edición de Rheizor (como el de Blizzard o /moveui de ElvUI): desbloquea
-- a la vez todo lo que se puede mover del addon, dibuja una cuadrícula y, al
-- soltar un elemento, lo ajusta a la línea más cercana.
--
-- /rz mover, el botón de su página de opciones, o automáticamente al abrir el
-- Modo edición de Blizzard. Se cierra solo al entrar en combate.

local R = Rheizor:Namespace(...)

local M = R:RegisterModule("editmode", {
	title = "Modo edición",
	defaults = {
		grid = true,
		snap = true,
		gridSize = 32,
		withBlizzard = true,
	},
	options = {
		{ type = "header", text = "Colocar los elementos de Rheizor" },
		{ type = "button", name = "Modo edición", text = "Entrar / salir", func = function(mod) mod:Toggle() end,
		  desc = "Muestra todos los elementos de Rheizor para arrastrarlos. También con /rz mover." },
		{ type = "toggle", key = "withBlizzard", name = "Abrir con el Modo edición de Blizzard",
		  desc = "Al entrar en Esc > Modo edición también se desbloquea Rheizor, y al salir se bloquea." },
		{ type = "header", text = R.L["Cuadrícula"] },
		{ type = "toggle", key = "grid", name = "Mostrar cuadrícula" },
		{ type = "toggle", key = "snap", name = R.L["Ajustar a la cuadrícula"],
		  desc = "Al soltar un elemento, su borde o su centro (lo que quede más cerca) se pega a la línea más próxima." },
		{ type = "slider", key = "gridSize", name = "Tamaño de la cuadrícula", min = 8, max = 128, step = 4,
		  format = R.fmt.int },
	},
})

local db
local active = false
local saved = {}        -- módulo -> valor de bloqueo que tenía antes de entrar
local grid, panel

----------------------------------------------------------------------
-- Cuadrícula
----------------------------------------------------------------------

local function line(i)
	local t = grid.lines[i]
	if not t then
		t = grid:CreateTexture(nil, "BACKGROUND")
		grid.lines[i] = t
	end
	t:ClearAllPoints()
	t:Show()
	return t
end

function M:DrawGrid()
	if not grid then
		grid = CreateFrame("Frame", nil, UIParent)
		grid:SetAllPoints()
		grid:SetFrameStrata("BACKGROUND")
		grid.lines = {}
	end
	for _, t in ipairs(grid.lines) do t:Hide() end
	grid:SetShown(active and db.grid)
	if not grid:IsShown() then return end

	local g = db.gridSize
	local w, h = UIParent:GetSize()
	local cx, cy = w / 2, h / 2
	local n = 0
	local function add(vertical, offset, center)
		n = n + 1
		local t = line(n)
		if center then
			t:SetColorTexture(1, 0.2, 0.2, 0.6)
		else
			t:SetColorTexture(0, 0, 0, 0.45)
		end
		if vertical then
			t:SetSize(1, h)
			t:SetPoint("TOP", UIParent, "TOPLEFT", cx + offset, 0)
		else
			t:SetSize(w, 1)
			t:SetPoint("LEFT", UIParent, "BOTTOMLEFT", 0, cy + offset)
		end
	end
	-- Desde el centro hacia fuera, así el centro siempre es una línea
	add(true, 0, true)
	add(false, 0, true)
	for off = g, cx, g do add(true, off) add(true, -off) end
	for off = g, cy, g do add(false, off) add(false, -off) end
end

----------------------------------------------------------------------
-- Ajuste al soltar (lo llama el núcleo desde R:RegisterMovable)
----------------------------------------------------------------------

local function nearest(values, origin, g)
	local best
	for _, v in ipairs(values) do
		local d = (math.floor((v - origin) / g + 0.5) * g + origin) - v
		if not best or math.abs(d) < math.abs(best) then best = d end
	end
	return best
end

function R:OnMovableDropped(f)
	if not (active and db.snap) or not f:GetLeft() then return end
	if InCombatLockdown() and f:IsProtected() then return end
	local ui = UIParent
	local s = f:GetEffectiveScale() / ui:GetEffectiveScale()
	local l, r, t, b = f:GetLeft() * s, f:GetRight() * s, f:GetTop() * s, f:GetBottom() * s
	local g = db.gridSize
	local w, h = ui:GetSize()
	local dx = nearest({ l, (l + r) / 2, r }, w / 2, g)
	local dy = nearest({ b, (b + t) / 2, t }, h / 2, g)
	f:ClearAllPoints()
	f:SetPoint("BOTTOMLEFT", ui, "BOTTOMLEFT", (l + dx) / s, (b + dy) / s)
end

----------------------------------------------------------------------
-- Panel de control
----------------------------------------------------------------------

local function checkbox(parent, label, key, x, y)
	local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
	cb:SetSize(24, 24)
	cb:SetPoint("TOPLEFT", x, y)
	cb.label = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	cb.label:SetPoint("LEFT", cb, "RIGHT", 2, 0)
	cb.label:SetText(label)
	cb:SetScript("OnClick", function(self)
		db[key] = self:GetChecked() and true or false
		M:DrawGrid()
	end)
	cb.key = key
	return cb
end

local function createPanel()
	panel = CreateFrame("Frame", "RheizorEditPanel", UIParent, "BackdropTemplate")
	panel:SetSize(300, 118)
	panel:SetPoint("TOP", 0, -60)
	panel:SetFrameStrata("DIALOG")
	panel:SetClampedToScreen(true)
	panel:SetMovable(true)
	panel:EnableMouse(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
	panel:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	panel:SetBackdropColor(0.05, 0.05, 0.07, 0.92)
	panel:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)

	local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	title:SetPoint("TOP", 0, -8)
	title:SetText(R.L["|cff33ccffRheizor|r · Modo edición"])

	local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("TOP", title, "BOTTOM", 0, -3)
	hint:SetText(R.L["Arrastra los recuadros azules. Se cierra al entrar en combate."])

	panel.checks = {
		checkbox(panel, R.L["Cuadrícula"], "grid", 12, -38),
		checkbox(panel, R.L["Ajustar a la cuadrícula"], "snap", 130, -38),
	}

	-- Tamaño de la cuadrícula con - / +
	local sizeLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	sizeLabel:SetPoint("TOPLEFT", 16, -72)
	sizeLabel:SetText(R.L["Tamaño:"])
	local value = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	value:SetPoint("LEFT", sizeLabel, "RIGHT", 34, 0)
	value:SetWidth(30)
	panel.sizeValue = value
	local function step(delta)
		db.gridSize = math.max(8, math.min(128, db.gridSize + delta))
		value:SetText(db.gridSize)
		M:DrawGrid()
	end
	local minus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	minus:SetSize(24, 20)
	minus:SetPoint("LEFT", sizeLabel, "RIGHT", 6, 0)
	minus:SetText("-")
	minus:SetScript("OnClick", function() step(-4) end)
	local plus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	plus:SetSize(24, 20)
	plus:SetPoint("LEFT", value, "RIGHT", 2, 0)
	plus:SetText("+")
	plus:SetScript("OnClick", function() step(4) end)

	local done = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	done:SetSize(96, 24)
	done:SetPoint("BOTTOMRIGHT", -10, 10)
	done:SetText(R.L["Terminar"])
	done:SetScript("OnClick", function() M:Exit() end)
end

----------------------------------------------------------------------
-- Entrar / salir
----------------------------------------------------------------------

-- Módulos con opción de bloqueo: "locked" (true = bloqueado) o "unlocked"
local function lockKey(mod)
	if mod.defaults.locked ~= nil then return "locked", false end
	if mod.defaults.unlocked ~= nil then return "unlocked", true end
end

local function setUnlocked(mod, key, value)
	if mod.db[key] == value then return end
	mod.db[key] = value
	R:OptionChanged(mod, key)
end

function M:Enter()
	if active then return end
	if InCombatLockdown() then
		R:Print(R.L["No se puede mover nada en combate."])
		return
	end
	active = true
	for _, mod in ipairs(R.order) do
		local key, unlockedValue = lockKey(mod)
		if key and mod.db then
			saved[mod] = mod.db[key]
			pcall(setUnlocked, mod, key, unlockedValue)
		end
	end
	if not panel then createPanel() end
	for _, cb in ipairs(panel.checks) do cb:SetChecked(db[cb.key]) end
	panel.sizeValue:SetText(db.gridSize)
	panel:Show()
	self:DrawGrid()
end

function M:Exit()
	if not active then return end
	active = false
	for mod, value in pairs(saved) do
		local key = lockKey(mod)
		pcall(setUnlocked, mod, key, value)
	end
	wipe(saved)
	if panel then panel:Hide() end
	self:DrawGrid()
end

function M:Toggle()
	if active then self:Exit() else self:Enter() end
end

function M:OnEnable()
	db = self.db

	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("UI_SCALE_CHANGED")
	events:RegisterEvent("DISPLAY_SIZE_CHANGED")
	events:SetScript("OnEvent", function(_, event)
		if event == "PLAYER_REGEN_DISABLED" then
			if active then
				M:Exit()
				R:Print(R.L["Modo edición cerrado por entrar en combate."])
			end
		elseif active then
			M:DrawGrid()
		end
	end)

	-- Junto al Modo edición de Blizzard
	if EventRegistry and EventRegistry.RegisterCallback then
		EventRegistry:RegisterCallback("EditMode.Enter", function()
			if db.withBlizzard then M:Enter() end
		end, M)
		EventRegistry:RegisterCallback("EditMode.Exit", function()
			if db.withBlizzard then M:Exit() end
		end, M)
	end
end

function M:OnOptionChanged()
	if panel and active then
		for _, cb in ipairs(panel.checks) do cb:SetChecked(db[cb.key]) end
		panel.sizeValue:SetText(db.gridSize)
	end
	self:DrawGrid()
end
