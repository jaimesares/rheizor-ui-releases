-- Modo edición de Rheizor (como el de Blizzard o /moveui de ElvUI): desbloquea
-- a la vez todo lo que se puede mover del addon, dibuja una cuadrícula y, al
-- soltar un elemento, lo ajusta a la línea más cercana.
--
-- /rz mover, el botón de su página de opciones, o automáticamente al abrir el
-- Modo edición de Blizzard. Se cierra solo al entrar en combate.

local R = Rheizor:Namespace(...)

local M = R:RegisterModule("editmode", {
	title = "Modo edición",
	defaults = {
		grid = true,
		snap = true,
		gridSize = 32,
		withBlizzard = true,
		glue = false,
		glueGap = 2,
		links = {},   -- clave del elemento -> { parent = clave del otro, x, y }
	},
	options = {
		{ type = "header", text = "Colocar los elementos de Rheizor" },
		{ type = "button", name = "Modo edición", text = "Entrar / salir", func = function(mod) mod:Toggle() end,
		  desc = "Muestra todos los elementos de Rheizor para arrastrarlos. También con /rz mover." },
		{ type = "toggle", key = "withBlizzard", name = "Abrir con el Modo edición de Blizzard",
		  desc = "Al entrar en Esc > Modo edición también se desbloquea Rheizor, y al salir se bloquea." },
		{ type = "header", text = R.L["Cuadrícula"] },
		{ type = "toggle", key = "grid", name = "Mostrar cuadrícula" },
		{ type = "toggle", key = "snap", name = R.L["Ajustar a la cuadrícula"],
		  desc = "Al soltar un elemento, su borde o su centro (lo que quede más cerca) se pega a la línea más próxima." },
		{ type = "slider", key = "gridSize", name = "Tamaño de la cuadrícula", min = 8, max = 128, step = 4,
		  format = R.fmt.int },
		{ type = "header", text = R.L["Pegamento"] },
		{ type = "toggle", key = "glue", name = R.L["Pegamento"],
		  desc = "Al soltar un elemento junto al borde de otro, se pega a él (borde con borde) y desde entonces lo sigue cuando mueves el otro. Para despegarlo, arrástralo lejos." },
		{ type = "slider", key = "glueGap", name = R.L["Separación al pegar"], min = 0, max = 20, step = 1, format = R.fmt.int,
		  desc = "Píxeles entre dos elementos pegados. Con 0 quedan tocándose." },
		{ type = "button", name = "Despegar todos los elementos", text = "Despegar todo", func = function(mod) mod:UnglueAll() end },
	},
})

local db
local active = false
local only              -- addon cuyo modo edición está abierto (nil = todos)
local saved = {}        -- módulo -> valor de bloqueo que tenía antes de entrar
local grid, panel

----------------------------------------------------------------------
-- Cuadrícula
----------------------------------------------------------------------

local function line(i)
	local t = grid.lines[i]
	if not t then
		t = grid:CreateTexture(nil, "BACKGROUND")
		grid.lines[i] = t
	end
	t:ClearAllPoints()
	t:Show()
	return t
end

function M:DrawGrid()
	if not grid then
		grid = CreateFrame("Frame", nil, UIParent)
		grid:SetAllPoints()
		grid:SetFrameStrata("BACKGROUND")
		grid.lines = {}
	end
	for _, t in ipairs(grid.lines) do t:Hide() end
	grid:SetShown(active and db.grid)
	if not grid:IsShown() then return end

	local g = db.gridSize
	local w, h = UIParent:GetSize()
	local cx, cy = w / 2, h / 2
	local n = 0
	local function add(vertical, offset, center)
		n = n + 1
		local t = line(n)
		if center then
			t:SetColorTexture(1, 0.2, 0.2, 0.6)
		else
			t:SetColorTexture(0, 0, 0, 0.45)
		end
		if vertical then
			t:SetSize(1, h)
			t:SetPoint("TOP", UIParent, "TOPLEFT", cx + offset, 0)
		else
			t:SetSize(w, 1)
			t:SetPoint("LEFT", UIParent, "BOTTOMLEFT", 0, cy + offset)
		end
	end
	-- Desde el centro hacia fuera, así el centro siempre es una línea
	add(true, 0, true)
	add(false, 0, true)
	for off = g, cx, g do add(true, off) add(true, -off) end
	for off = g, cy, g do add(false, off) add(false, -off) end
end

----------------------------------------------------------------------
-- Ajuste al soltar (lo llama el núcleo desde R:RegisterMovable)
----------------------------------------------------------------------

local function nearest(values, origin, g)
	local best
	for _, v in ipairs(values) do
		local d = (math.floor((v - origin) / g + 0.5) * g + origin) - v
		if not best or math.abs(d) < math.abs(best) then best = d end
	end
	return best
end

----------------------------------------------------------------------
-- Pegamento. Al soltar un elemento junto al borde de otro se coloca borde
-- con borde (y alineado, si está cerca) y queda pegado: cuando se mueve el
-- otro, lo sigue. Arrastrarlo lejos lo despega. Solo los elementos con
-- recuadro de R:CreateMover (tienen clave estable y guardan su posición).
-- db.links[clave] = { parent = clave del otro, x, y }: dónde queda su
-- esquina inferior izquierda respecto a la del otro, en medidas de UIParent.
----------------------------------------------------------------------

local GLUE_DIST = 12
local GLUED_EDGE = { 0.3, 1, 0.4 }
local NORMAL_EDGE = { 0.2, 0.8, 1 }

local function infoOf(f) return R.moverInfo and R.moverInfo[f] end
local function frameOf(key) return R.moverByKey and R.moverByKey[key] end

-- Borde del marco en medidas de UIParent (y su escala relativa)
local function rect(f)
	if not f:GetLeft() then return end
	local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
	return f:GetLeft() * s, f:GetRight() * s, f:GetTop() * s, f:GetBottom() * s, s
end

-- ¿key sigue (directa o indirectamente) a other? Para no hacer círculos
local function follows(key, other)
	local seen = {}
	while key and not seen[key] do
		seen[key] = true
		local link = db.links[key]
		if not link then return false end
		if link.parent == other then return true end
		key = link.parent
	end
	return false
end

local function hasChildren(key)
	for _, link in pairs(db.links) do
		if link.parent == key then return true end
	end
	return false
end

-- Guarda la posición como al soltarlo: el OnDragStop del recuadro (cada
-- módulo guarda a su manera), sin el ajuste a la cuadrícula
local function saveMover(mover)
	local was = R.nudging
	R.nudging = true
	if ExecuteFrameScript then
		pcall(ExecuteFrameScript, mover, "OnDragStop")
	else
		local fn = mover:GetScript("OnDragStop")
		if fn then pcall(fn, mover) end
	end
	R.nudging = was
end

-- Coloca los elementos pegados a key (y los pegados a esos). save: guardar
-- sus posiciones (al soltar); sin él, solo mientras se arrastra
local function placeChildren(key, save)
	local pf = frameOf(key)
	if not pf then return end
	local pl, _, _, pb = rect(pf)
	if not pl then return end
	for childKey, link in pairs(db.links) do
		if link.parent == key then
			local cf = frameOf(childKey)
			local ci = cf and infoOf(cf)
			if ci and not (InCombatLockdown() and cf:IsProtected()) then
				local s = cf:GetEffectiveScale() / UIParent:GetEffectiveScale()
				cf:ClearAllPoints()
				cf:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (pl + link.x) / s, (pb + link.y) / s)
				if save then
					saveMover(ci.mover)    -- y su StopMovingOrSizing coloca los suyos
				else
					placeChildren(childKey, false)
				end
			end
		end
	end
end

-- Verde y con "pegado a..." los que siguen a otro
function M:RefreshGlue()
	if not db then return end
	for f, i in pairs(R.moverInfo or {}) do
		local link = db.links[i.key]
		local parent = link and frameOf(link.parent)
		local pi = parent and infoOf(parent)
		local glued = pi and db.glue
		-- Solo los recuadros de R:CreateMover (los demás tienen su propio aspecto)
		if i.base then
			local c = glued and GLUED_EDGE or NORMAL_EDGE
			i.mover:SetBackdropBorderColor(c[1], c[2], c[3], 0.9)
			local text = i.base
			if glued then text = text .. " |cff66ff77" .. R.L["(pegado a %s)"]:format(pi.label) .. "|r" end
			i.mover.text:SetText(text)
		end
	end
end

local function unglue(key)
	if db.links[key] then
		db.links[key] = nil
		M:RefreshGlue()
	end
end

function M:UnglueAll()
	wipe(db.links)
	self:RefreshGlue()
	R:Print(R.L["Todos los elementos despegados."])
end

-- Intenta pegar f al elemento más cercano. true si lo ha pegado
local function glue(f)
	local i = infoOf(f)
	local l, r, t, b, s = rect(f)
	if not (i and l) then return false end
	local gap = tonumber(db.glueGap) or 0
	local best, bestD, dx, dy, axis
	for g, gi in pairs(R.moverInfo) do
		-- Solo los que se ven en el modo edición, y nunca uno que ya sigue a f
		if g ~= f and gi.mover:IsVisible() and not follows(gi.key, i.key) then
			local gl, gr, gt, gb = rect(g)
			if gl then
				local function consider(d, x, y, ax)
					if math.abs(d) <= GLUE_DIST and (not bestD or math.abs(d) < bestD) then
						best, bestD, dx, dy, axis = g, math.abs(d), x, y, ax
					end
				end
				-- Uno al lado del otro (se solapan en vertical) o uno encima del
				-- otro, con la separación elegida entre los dos
				if b < gt and t > gb then
					consider(gr + gap - l, gr + gap - l, 0, "h")   -- a su derecha
					consider(gl - gap - r, gl - gap - r, 0, "h")   -- a su izquierda
				end
				if l < gr and r > gl then
					consider(gb - gap - t, 0, gb - gap - t, "v")   -- debajo
					consider(gt + gap - b, 0, gt + gap - b, "v")   -- encima
				end
			end
		end
	end
	if not best then return false end

	-- Alineados en el otro eje si están cerca: bordes o centros
	local gl, gr, gt, gb = rect(best)
	local function align(options)
		local pick
		for _, d in ipairs(options) do
			if math.abs(d) <= GLUE_DIST and (not pick or math.abs(d) < math.abs(pick)) then pick = d end
		end
		return pick or 0
	end
	if axis == "h" then
		dy = align({ gt - t, gb - b, (gt + gb) / 2 - (t + b) / 2 })
	else
		dx = align({ gl - l, gr - r, (gl + gr) / 2 - (l + r) / 2 })
	end

	f:ClearAllPoints()
	f:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", (l + dx) / s, (b + dy) / s)
	db.links[i.key] = { parent = infoOf(best).key, x = l + dx - gl, y = b + dy - gb }
	M:RefreshGlue()
	return true
end

-- Mientras se arrastra uno, los pegados lo siguen
local follower = CreateFrame("Frame")
follower:Hide()
follower:SetScript("OnUpdate", function(self)
	if self.key then placeChildren(self.key, false) end
end)

function R:OnMovableStart(f)
	local i = infoOf(f)
	if active and db.glue and i and hasChildren(i.key) then
		follower.key = i.key
		follower:Show()
	end
end

function R:OnMovableMoved(f)
	follower:Hide()
	follower.key = nil
	local i = db and infoOf(f)
	if not i then return end
	-- Movido con las flechas (o al colocarlo el pegamento): sigue pegado a
	-- lo mismo, con su nueva distancia
	local link = db.links[i.key]
	local parent = link and R.nudging and frameOf(link.parent)
	if parent then
		local l, _, _, b = rect(f)
		local pl, _, _, pb = rect(parent)
		if l and pl then link.x, link.y = l - pl, b - pb end
	end
	if db.glue then placeChildren(i.key, true) end
end

function R:OnMovableDropped(f)
	if not active or not f:GetLeft() then return end
	if InCombatLockdown() and f:IsProtected() then return end
	local i = infoOf(f)
	if i then
		if db.glue and glue(f) then return end
		-- Soltado lejos de todo: se despega
		unglue(i.key)
	end
	if not db.snap then return end
	local ui = UIParent
	local s = f:GetEffectiveScale() / ui:GetEffectiveScale()
	local l, r, t, b = f:GetLeft() * s, f:GetRight() * s, f:GetTop() * s, f:GetBottom() * s
	local g = db.gridSize
	local w, h = ui:GetSize()
	local dx = nearest({ l, (l + r) / 2, r }, w / 2, g)
	local dy = nearest({ b, (b + t) / 2, t }, h / 2, g)
	f:ClearAllPoints()
	f:SetPoint("BOTTOMLEFT", ui, "BOTTOMLEFT", (l + dx) / s, (b + dy) / s)
end

----------------------------------------------------------------------
-- Panel de control
----------------------------------------------------------------------

local function checkbox(parent, label, key, x, y)
	local cb = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
	cb:SetSize(24, 24)
	cb:SetPoint("TOPLEFT", x, y)
	cb.label = cb:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	cb.label:SetPoint("LEFT", cb, "RIGHT", 2, 0)
	cb.label:SetText(label)
	cb:SetScript("OnClick", function(self)
		db[key] = self:GetChecked() and true or false
		M:DrawGrid()
		M:RefreshGlue()
	end)
	cb.key = key
	return cb
end

local function createPanel()
	panel = CreateFrame("Frame", "RheizorEditPanel", UIParent, "BackdropTemplate")
	panel:SetSize(300, 118)
	panel:SetPoint("TOP", 0, -60)
	panel:SetFrameStrata("DIALOG")
	panel:SetClampedToScreen(true)
	panel:SetMovable(true)
	panel:EnableMouse(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
	panel:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	panel:SetBackdropColor(0.05, 0.05, 0.07, 0.92)
	panel:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)

	local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	title:SetPoint("TOP", 0, -8)
	title:SetText(R.L["|cff33ccffRheizor|r · Modo edición"])
	panel.title = title

	local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("TOP", title, "BOTTOM", 0, -3)
	hint:SetText(R.L["Arrastra los recuadros azules. Se cierra al entrar en combate."])

	panel.checks = {
		checkbox(panel, R.L["Cuadrícula"], "grid", 12, -38),
		checkbox(panel, R.L["Ajustar a la cuadrícula"], "snap", 130, -38),
	}

	-- Tamaño de la cuadrícula con - / +
	local sizeLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	sizeLabel:SetPoint("TOPLEFT", 16, -72)
	sizeLabel:SetText(R.L["Tamaño:"])
	local value = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	value:SetPoint("LEFT", sizeLabel, "RIGHT", 34, 0)
	value:SetWidth(30)
	panel.sizeValue = value
	local function step(delta)
		db.gridSize = math.max(8, math.min(128, db.gridSize + delta))
		value:SetText(db.gridSize)
		M:DrawGrid()
	end
	local minus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	minus:SetSize(24, 20)
	minus:SetPoint("LEFT", sizeLabel, "RIGHT", 6, 0)
	minus:SetText("-")
	minus:SetScript("OnClick", function() step(-4) end)
	local plus = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	plus:SetSize(24, 20)
	plus:SetPoint("LEFT", value, "RIGHT", 2, 0)
	plus:SetText("+")
	plus:SetScript("OnClick", function() step(4) end)

	-- Pegamento, al lado del tamaño
	local glueCheck = checkbox(panel, R.L["Pegamento"], "glue", 180, -66)
	table.insert(panel.checks, glueCheck)
	glueCheck:HookScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(R.L["Pegamento"], 1, 1, 1)
		GameTooltip:AddLine(R.L["Suelta un elemento junto al borde de otro para pegarlo: después lo sigue cuando mueves el otro. Arrástralo lejos para despegarlo."], nil, nil, nil, true)
		GameTooltip:Show()
	end)
	glueCheck:HookScript("OnLeave", GameTooltip_Hide)

	local unglueAll = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	unglueAll:SetSize(110, 24)
	unglueAll:SetPoint("BOTTOMLEFT", 10, 10)
	unglueAll:SetText(R.L["Despegar todo"])
	unglueAll:SetScript("OnClick", function() M:UnglueAll() end)

	local done = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	done:SetSize(96, 24)
	done:SetPoint("BOTTOMRIGHT", -10, 10)
	done:SetText(R.L["Terminar"])
	done:SetScript("OnClick", function() M:Exit() end)
end

----------------------------------------------------------------------
-- Entrar / salir
----------------------------------------------------------------------

-- Módulos con opción de bloqueo: "locked" (true = bloqueado) o "unlocked"
local function lockKey(mod)
	if mod.defaults.locked ~= nil then return "locked", false end
	if mod.defaults.unlocked ~= nil then return "unlocked", true end
end

local function setUnlocked(mod, key, value)
	if mod.db[key] == value then return end
	mod.db[key] = value
	R:OptionChanged(mod, key)
end

-- addon: solo los elementos de ese addon (botón "Mover" de la lista de
-- addons); sin él, todos
function M:Enter(addon)
	if active then return end
	if InCombatLockdown() then
		R:Print(R.L["No se puede mover nada en combate."])
		return
	end
	active = true
	only = addon
	for _, mod in ipairs(R.order) do
		local key, unlockedValue = lockKey(mod)
		if key and mod.db and (not addon or mod.addon == addon) then
			saved[mod] = mod.db[key]
			pcall(setUnlocked, mod, key, unlockedValue)
		end
	end
	if not panel then createPanel() end
	for _, cb in ipairs(panel.checks) do cb:SetChecked(db[cb.key]) end
	panel.sizeValue:SetText(db.gridSize)
	local title = R.L["|cff33ccffRheizor|r · Modo edición"]
	if addon then
		local name = (C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata)(addon, "Title") or addon
		title = title .. " · " .. (name:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):match("·%s*(.+)$") or addon)
	end
	panel.title:SetText(title)
	panel:Show()
	self:DrawGrid()
	self:RefreshGlue()
end

-- ¿Tiene ese addon elementos que se puedan mover (módulos con bloqueo)?
function M:HasMovers(addon)
	for _, mod in ipairs(R.order) do
		if mod.addon == addon and lockKey(mod) and R:IsModuleRunning(mod) then return true end
	end
	return false
end

-- ¿Está abierto el modo edición solo para ese addon?
function M:IsActiveFor(addon)
	return active and only == addon
end

-- Abre o cierra el modo edición de un solo addon
function M:ToggleFor(addon)
	if active and only == addon then
		self:Exit()
		return
	end
	if active then self:Exit() end
	self:Enter(addon)
end

function M:Exit()
	if not active then return end
	active = false
	only = nil
	for mod, value in pairs(saved) do
		local key = lockKey(mod)
		pcall(setUnlocked, mod, key, value)
	end
	wipe(saved)
	if panel then panel:Hide() end
	self:DrawGrid()
end

function M:Toggle()
	if active then self:Exit() else self:Enter() end
end

function M:OnEnable()
	db = self.db

	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("UI_SCALE_CHANGED")
	events:RegisterEvent("DISPLAY_SIZE_CHANGED")
	events:SetScript("OnEvent", function(_, event)
		if event == "PLAYER_REGEN_DISABLED" then
			if active then
				M:Exit()
				R:Print(R.L["Modo edición cerrado por entrar en combate."])
			end
		elseif active then
			M:DrawGrid()
		end
	end)

	-- Junto al Modo edición de Blizzard
	if EventRegistry and EventRegistry.RegisterCallback then
		EventRegistry:RegisterCallback("EditMode.Enter", function()
			if db.withBlizzard then M:Enter() end
		end, M)
		EventRegistry:RegisterCallback("EditMode.Exit", function()
			if db.withBlizzard then M:Exit() end
		end, M)
	end
end

function M:OnOptionChanged()
	if panel and active then
		for _, cb in ipairs(panel.checks) do cb:SetChecked(db[cb.key]) end
		panel.sizeValue:SetText(db.gridSize)
	end
	self:DrawGrid()
	self:RefreshGlue()
end
