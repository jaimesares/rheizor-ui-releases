-- Avisa si hay otro addon cargado que hace lo mismo que uno de Rheizor
-- (dos addons cambiando las mismas placas, barras, etc. suelen pelearse).

local R = Rheizor:Namespace(...)
local L = R.L

-- Addon de Rheizor -> addons que hacen lo mismo (nombre de su carpeta)
local KNOWN = {
	["Rheizor-UnitFrames"] = { "ElvUI", "ShadowedUnitFrames", "PitBull4", "XPerl", "ZPerl", "UnhaltedUnitFrames" },
	["Rheizor-Nameplates"] = { "Plater", "Platynator", "Kui_Nameplates", "TidyPlates", "TidyPlates_ThreatPlates", "NeatPlates", "ElvUI" },
	["Rheizor-Threat"]     = { "Omen", "ThreatClassic2", "TinyThreat" },
	["Rheizor-Bars"]       = { "Bartender4", "Dominos", "ElvUI" },
	["Rheizor-ActionBars"] = { "Bartender4", "Dominos", "ElvUI" },
	["Rheizor-Bags"]       = { "Bagnon", "AdiBags", "ArkInventory", "Baganator", "BetterBags", "ElvUI" },
	["Rheizor-Chat"]       = { "Prat-3.0", "Chatter", "ElvUI" },
	["Rheizor-Minimap"]    = { "SexyMap", "BasicMinimap", "ElvUI" },
	["Rheizor-MinimapButtons"] = { "MBB", "MinimapButtonButton", "MinimapButtonBag", "HidingBar", "SexyMap" },
	["Rheizor-CastBars"]   = { "Quartz", "Gnosis", "ElvUI" },
	["Rheizor-Swing"]      = { "WeaponSwingTimer", "Quartz" },
	["Rheizor-CombatText"] = { "MikScrollingBattleText", "Parrot", "xCT+", "NameplateSCT" },
	["Rheizor-Totems"]     = { "TotemTimers" },
	["Rheizor-Loot"]       = { "XLoot" },
	["Rheizor-Automation"] = { "Leatrix_Plus" },
	["Rheizor-Stats"]      = { "CharacterStatsClassic", "CharacterStatsTBC", "DejaCharacterStats" },
	["Rheizor-Characters"] = { "Altoholic", "BagSync", "DataStore", "Syndicator" },
	["Rheizor-Tooltip"]    = { "TipTac", "TinyTooltip", "TinyTooltip-Reforged", "CowTip", "ElvUI" },
	["Rheizor-Gear"]       = { "ItemRack", "Outfitter", "ClosetGnome", "GearQuipper", "GearQuipper-TBC", "EquipmentSets" },
	["Rheizor-ComboPoints"] = { "NugComboBar", "ComboPointsRedux" },
	["Rheizor-Flight"]     = { "InFlight", "InFlight_Load", "FlightHUD" },
	["Rheizor-CC"]         = { "Diminish", "DRTracker", "LoseControl" },
	["Rheizor-Mouse"]      = { "CursorTrail", "UltimateMouseCursor", "MouseCursorPlus", "CursorRing", "CursorMod" },
	["Rheizor-Cooldowns"]  = { "EllesmereUICooldownManager", "EllesmereUI_CooldownManager", "EllesmereUICDM", "CooldownManagerCentered", "ArcUI", "TellMeWhen", "WeakAuras" },
}

local C = R:RegisterModule("conflicts", {
	title = "Conflictos",
	defaults = {
		warn = true,
	},
	options = {
		{ type = "header", text = "Addons que hacen lo mismo" },
		{ type = "toggle", key = "warn", name = "Avisar en el chat al entrar",
		  desc = "Si hay otro addon cargado que cambia lo mismo que un addon de Rheizor, lo dice en el chat al entrar al juego. En el gestor (/rz) se marcan con un signo de exclamación." },
	},
})

local A = C_AddOns or {}
local function api(name) return A[name] or _G[name] end

local function isLoaded(name)
	local fn = api("IsAddOnLoaded")
	return fn and fn(name) and true or false
end

local function titleOf(name)
	local _, title = api("GetAddOnInfo")(name)
	title = (title or name):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
	return title
end

-- Títulos de los addons cargados que chocan con el addon de Rheizor indicado
function R:FindConflicts(addon)
	local list = {}
	if not isLoaded(addon) or not R:IsAddonActive(addon) then return list end
	for _, other in ipairs(KNOWN[addon] or {}) do
		if isLoaded(other) then list[#list + 1] = titleOf(other) end
	end
	return list
end

function C:OnEnable()
	if not self.db.warn then return end
	-- Un poco después de entrar, para que no se pierda entre los mensajes de carga
	C_Timer.After(8, function()
		for addon in pairs(KNOWN) do
			local list = R:FindConflicts(addon)
			if #list > 0 then
				R:Print(L["|cffff8800Posible conflicto:|r %s y %s cambian lo mismo. Desactiva uno de los dos en /rz."]:format(titleOf(addon), table.concat(list, ", ")))
			end
		end
	end)
end
