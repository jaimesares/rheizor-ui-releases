-- Rheizor-Core: núcleo compartido por todos los addons de Rheizor.
-- Cada módulo (en su propio addon, que depende de este) empieza con
--   local R = Rheizor:Namespace(...)
-- y se registra con R:RegisterModule declarando sus valores por defecto y
-- opciones; el núcleo se encarga de la base de datos, eventos y comandos.
-- La configuración de todos los módulos se guarda en RheizorDB (de este addon).

local ADDON, R = ...
_G.Rheizor = R

R.ADDON = ADDON

-- Asistente de instalación y plantillas de distribución: el código sigue
-- ahí, pero apagado. Con false no se pueden abrir (ni /rz asistente, ni el
-- gestor, ni solos en una instalación nueva) y ninguna plantilla se aplica
-- sola. Poner true para recuperarlos.
R.SETUP_ENABLED = false

R.modules = {}
R.order = {}
R.missing = {}

-- Lo llama cada archivo de módulo con su "...": devuelve el núcleo y apunta de
-- qué addon vienen los módulos que se registren a continuación
function R:Namespace(addon)
	self.current = addon
	return self
end

----------------------------------------------------------------------
-- Idioma: el texto se escribe en español y sirve de clave. Cada addon trae
-- un Locale.lua (el primero de su .toc) con
--   Rheizor:AddTranslations("en", { ["Texto en español"] = "English text", ... })
-- En clientes en español se ve tal cual; en cualquier otro idioma, en inglés.
-- Lo que no tenga traducción se muestra en español.
----------------------------------------------------------------------

local lang = (GetLocale() or "enUS"):sub(1, 2)
R.locale = (lang == "es") and "es" or "en"

local translations = {}
R.L = setmetatable({}, {
	__index = function(_, text) return translations[text] or text end,
	__newindex = function() end,
})

function R:AddTranslations(locale, list)
	if locale ~= self.locale then return end
	for es, other in pairs(list) do translations[es] = other end
end

-- Traduce un texto si es texto (deja números, nil, etc. como vienen)
function R.T(text)
	if type(text) ~= "string" then return text end
	return translations[text] or text
end

local combatQueue = {}

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

function R:Print(...)
	print("|cff33ccffRheizor|r:", ...)
end

local function copyDefaults(src, dst)
	for k, v in pairs(src) do
		if type(v) == "table" then
			if type(dst[k]) ~= "table" then dst[k] = {} end
			copyDefaults(v, dst[k])
		elseif dst[k] == nil then
			dst[k] = v
		end
	end
end

function R.DeepCopy(v)
	if type(v) ~= "table" then return v end
	local t = {}
	for k, x in pairs(v) do t[k] = R.DeepCopy(x) end
	return t
end

-- El motor 12.x puede devolver valores "secretos" que no se pueden comparar
-- ni operar. Devuelve el valor si es utilizable, o nil si es secreto.
function R.NotSecret(value)
	if issecretvalue and issecretvalue(value) then return nil end
	return value
end

----------------------------------------------------------------------
-- Nombres. En WoW Forever los personajes tienen apellido ("Rheizor Ele",
-- "Rheizor Palakaidas") y UnitName("player") da solo el nombre de pila, así
-- que varios personajes tuyos pueden compartirlo. GetUnitName(unit, true) da
-- el nombre completo. Para identificar al personaje hay que usar esto (o su
-- GUID), nunca UnitName solo.
----------------------------------------------------------------------

local surnames
-- true si el juego usa apellidos (el nombre completo lleva un espacio,
-- cosa imposible en un nombre normal de WoW)
function R.HasSurnames()
	if surnames == nil then
		local full = GetUnitName and R.NotSecret(GetUnitName("player", true))
		-- Aún no se sabe (al cargar puede llegar "Unknown"): se vuelve a mirar
		if not full or full == UNKNOWNOBJECT or full == "Unknown" then return false end
		surnames = full:find(" ", 1, true) ~= nil
	end
	return surnames
end

-- Nombre para mostrar e identificar (con apellido si lo hay) y reino
function R.UnitFullName(unit)
	if R.HasSurnames() and GetUnitName then
		local full = R.NotSecret(GetUnitName(unit, true))
		if full then return full end
	end
	local name, realm = UnitName(unit)
	return R.NotSecret(name), R.NotSecret(realm)
end

function R.PlayerFullName()
	return R.UnitFullName("player") or UnitName("player") or "?"
end

-- Para las funciones de WoW que piden un personaje (activar addons…): el
-- GUID es único aunque varios personajes compartan nombre de pila
function R.CharacterID()
	return R.NotSecret(UnitGUID("player")) or UnitName("player")
end

-- Clave comparable de un nombre que llega de fuera (chat, mensajes de
-- addons): sin reino en WoW normal; con apellidos, el guion pasa a espacio
function R.NameKey(name)
	if not name then return end
	if R.HasSurnames() then return (name:gsub("%-", " ")) end
	return Ambiguate and Ambiguate(name, "short") or name:match("^[^%-]+")
end

function R.IsMyName(name)
	return name ~= nil and R.NameKey(name) == R.NameKey(R.PlayerFullName())
end

-- Dinero con iconos de oro/plata/cobre (la función cambió de sitio entre versiones)
function R.Money(copper)
	if C_CurrencyInfo and C_CurrencyInfo.GetCoinTextureString then
		return C_CurrencyInfo.GetCoinTextureString(copper)
	elseif GetMoneyString then
		return GetMoneyString(copper, true)
	elseif GetCoinTextureString then
		return GetCoinTextureString(copper)
	end
	return tostring(copper)
end

function R:PlayerClass()
	return select(2, UnitClass("player"))
end

-- Convierte "MinimapCluster.Tracking" en el objeto correspondiente (o nil)
function R:Resolve(path)
	local obj = _G
	for part in path:gmatch("[^%.]+") do
		if type(obj) ~= "table" then return nil end
		obj = obj[part]
	end
	return obj
end

-- Ejecuta fn ahora, o al salir de combate si estamos en combate
function R:RunOutOfCombat(fn)
	if InCombatLockdown() then
		table.insert(combatQueue, fn)
	else
		fn()
	end
end

-- Formatos para las etiquetas de los deslizadores
R.fmt = {
	percent = function(v) return string.format("%d%%", v * 100 + 0.5) end,
	int     = function(v) return string.format("%d", v + 0.5) end,
	dec1    = function(v) return string.format("%.1f", v) end,
	dec2    = function(v) return string.format("%.2f", v) end,
	ms      = function(v) return string.format("%d ms", v + 0.5) end,
}

-- Paleta de colores para desplegables (valor hex, texto ya coloreado)
R.COLORS = {
	{ "ffffff", "|cffffffffBlanco|r" },
	{ "bbbbbb", "|cffbbbbbbGris|r" },
	{ "ffff00", "|cffffff00Amarillo|r" },
	{ "ffff99", "|cffffff99Amarillo claro|r" },
	{ "ffd100", "|cffffd100Dorado|r" },
	{ "ff8000", "|cffff8000Naranja|r" },
	{ "ff3333", "|cffff3333Rojo|r" },
	{ "b00000", "|cffb00000Rojo oscuro|r" },
	{ "ff4da6", "|cffff4da6Rosa|r" },
	{ "ff80ff", "|cffff80ffMagenta|r" },
	{ "a080ff", "|cffa080ffMorado|r" },
	{ "4080ff", "|cff4080ffAzul|r" },
	{ "80ffff", "|cff80ffffCeleste|r" },
	{ "33ff33", "|cff33ff33Verde|r" },
	{ "00b050", "|cff00b050Verde veneno|r" },
	{ "a0ff40", "|cffa0ff40Verde lima|r" },
}

-- Fuentes del juego además de las cuatro clásicas (Friz, Arial Narrow,
-- Skurri, Morpheus): { clave, archivo, nombre }. Vienen con el juego para
-- los idiomas asiáticos pero tienen letras latinas. Si en algún cliente
-- faltara el archivo, cada módulo vuelve a la fuente del juego.
R.EXTRA_FONTS = {
	{ "2002", "Fonts\\2002.TTF", "2002" },
	{ "2002b", "Fonts\\2002B.TTF", "2002 Bold" },
	{ "arhei", "Fonts\\ARHei.ttf", "AR Hei (negrita moderna)" },
	{ "arkai", "Fonts\\ARKai_T.ttf", "AR Kai (pincel)" },
	{ "mok", "Fonts\\K_Damage.ttf", "MoK (números de daño)" },
}

function R.HexToRGB(hex)
	hex = hex or "ffffff"
	return tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255
end

-- Texturas de barra incluidas en el juego
R.TEXTURES = {
	{ "Interface\\TargetingFrame\\UI-StatusBar", "Blizzard" },
	{ "Interface\\Buttons\\WHITE8X8", "Plana" },
	{ "Interface\\RaidFrame\\Raid-Bar-Hp-Fill", "Banda" },
	{ "Interface\\TargetingFrame\\BarFill2", "Suave" },
}

-- Registro de marcos que se pueden arrastrar. Al soltarlos se avisa a
-- R:OnMovableDropped (el modo edición lo usa para ajustar a la cuadrícula)
-- justo antes de que el módulo guarde la posición.
R.movables = {}
function R:RegisterMovable(frame)
	if self.movables[frame] then return end
	self.movables[frame] = true
	hooksecurefunc(frame, "StopMovingOrSizing", function(f)
		if R.OnMovableDropped and not R.nudging then R:OnMovableDropped(f) end
	end)
end

-- Flechas para mover píxel a píxel. Al pasar el ratón por un recuadro de mover
-- sale una barrita con ← ↑ ↓ → debajo (o encima, si no cabe); mientras el
-- ratón esté en el recuadro o en la barrita, las flechas del teclado también
-- lo mueven. Mayús = 10 píxeles. Tras cada paso se ejecuta el OnDragStop del
-- recuadro (con sus ganchos), así cada módulo guarda la posición como siempre.
local nudge
local ARROWS = {
	{ "LEFT", -1, 0, "Interface\\Buttons\\UI-SpellbookIcon-PrevPage" },
	{ "UP", 0, 1, "Interface\\ChatFrame\\UI-ChatIcon-ScrollUp" },
	{ "DOWN", 0, -1, "Interface\\ChatFrame\\UI-ChatIcon-ScrollDown" },
	{ "RIGHT", 1, 0, "Interface\\Buttons\\UI-SpellbookIcon-NextPage" },
}

local function onePixel(frame)
	local _, h = GetPhysicalScreenSize()
	local s = frame:GetEffectiveScale()
	if not h or h <= 0 or not s or s <= 0 then return 1 end
	return 768 / h / s
end

local function nudgeText()
	local frame = nudge.frame
	local _, _, _, x, y = frame:GetPoint(1)
	if x then
		nudge.coords:SetFormattedText("%.1f, %.1f", x, y)
	else
		nudge.coords:SetText("")
	end
end

local function nudgeBy(dx, dy)
	local frame, mover = nudge.frame, nudge.mover
	if not frame or (InCombatLockdown() and frame:IsProtected()) then return end
	local point, rel, relPoint, x, y
	if frame:GetNumPoints() == 1 then
		point, rel, relPoint, x, y = frame:GetPoint(1)
	elseif frame:GetLeft() then
		point, rel, relPoint, x, y = "BOTTOMLEFT", UIParent, "BOTTOMLEFT", frame:GetLeft(), frame:GetBottom()
	end
	if not point then return end
	local step = onePixel(frame) * (IsShiftKeyDown() and 10 or 1)
	frame:ClearAllPoints()
	frame:SetPoint(point, rel, relPoint, x + dx * step, y + dy * step)
	-- Guardar como al soltarlo (sin el ajuste a la cuadrícula)
	R.nudging = true
	if ExecuteFrameScript then
		pcall(ExecuteFrameScript, mover, "OnDragStop")
	else
		local fn = mover:GetScript("OnDragStop")
		if fn then pcall(fn, mover) end
	end
	R.nudging = false
	nudgeText()
end

local function nudgeKeyboard()
	-- En combate el juego no deja decidir qué teclas se quedan: sin teclado
	local on = nudge:IsShown() and not InCombatLockdown()
	nudge:EnableKeyboard(on)
	if on then nudge:SetPropagateKeyboardInput(true) end
end

local function createNudge()
	nudge = CreateFrame("Frame", "RheizorNudge", UIParent, "BackdropTemplate")
	nudge:SetSize(150, 24)
	nudge:SetFrameStrata("FULLSCREEN_DIALOG")
	nudge:SetClampedToScreen(true)
	nudge:EnableMouse(true)
	nudge:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	nudge:SetBackdropColor(0.05, 0.05, 0.07, 0.92)
	nudge:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	nudge:Hide()

	local function tooltip(owner)
		GameTooltip:SetOwner(owner, "ANCHOR_TOP")
		GameTooltip:SetText(R.L["Mover píxel a píxel"], 1, 1, 1)
		GameTooltip:AddLine(R.L["Clic: 1 píxel. Con Mayús: 10."], nil, nil, nil, true)
		GameTooltip:AddLine(R.L["Con el ratón encima del recuadro también se mueve con las flechas del teclado."], nil, nil, nil, true)
		GameTooltip:Show()
	end

	local prev
	for _, a in ipairs(ARROWS) do
		local b = CreateFrame("Button", nil, nudge)
		b:SetSize(20, 20)
		if prev then
			b:SetPoint("LEFT", prev, "RIGHT", 1, 0)
		else
			b:SetPoint("LEFT", 3, 0)
		end
		b:SetNormalTexture(a[4] .. "-Up")
		b:SetPushedTexture(a[4] .. "-Down")
		b:SetDisabledTexture(a[4] .. "-Disabled")
		b:SetHighlightTexture("Interface\\Buttons\\UI-Common-MouseHilight", "ADD")
		b:RegisterForClicks("LeftButtonDown")
		-- Mantener pulsado repite
		b:SetScript("OnClick", function(self)
			nudgeBy(a[2], a[3])
			self.held = -0.35
		end)
		b:SetScript("OnMouseUp", function(self) self.held = nil end)
		b:SetScript("OnHide", function(self) self.held = nil end)
		b:SetScript("OnUpdate", function(self, elapsed)
			if not self.held then return end
			if not IsMouseButtonDown("LeftButton") then self.held = nil return end
			self.held = self.held + elapsed
			if self.held >= 0.05 then
				self.held = 0
				nudgeBy(a[2], a[3])
			end
		end)
		b:SetScript("OnEnter", tooltip)
		b:SetScript("OnLeave", function() GameTooltip:Hide() end)
		prev = b
	end

	nudge.coords = nudge:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	nudge.coords:SetPoint("LEFT", prev, "RIGHT", 6, 0)
	nudge.coords:SetPoint("RIGHT", -4, 0)
	nudge.coords:SetJustifyH("CENTER")

	nudge:SetScript("OnKeyDown", function(self, key)
		for _, a in ipairs(ARROWS) do
			if key == a[1] then
				if not InCombatLockdown() then self:SetPropagateKeyboardInput(false) end
				nudgeBy(a[2], a[3])
				return
			end
		end
		if not InCombatLockdown() then self:SetPropagateKeyboardInput(true) end
	end)

	-- Se va al dejar el recuadro y la barrita (con un pequeño margen para
	-- pasar de uno a otra)
	local away = 0
	nudge:SetScript("OnUpdate", function(self, elapsed)
		local mover = self.mover
		if not (mover and mover:IsVisible()) then self:Hide() return end
		if mover:IsMouseOver() or self:IsMouseOver() then
			away = 0
		else
			away = away + elapsed
			if away > 0.4 then self:Hide() end
		end
	end)
	nudge:SetScript("OnShow", function() away = 0 nudgeKeyboard() end)
	nudge:SetScript("OnHide", function(self)
		self:EnableKeyboard(false)
		self.mover, self.frame = nil, nil
	end)
	nudge:RegisterEvent("PLAYER_REGEN_DISABLED")
	nudge:RegisterEvent("PLAYER_REGEN_ENABLED")
	nudge:SetScript("OnEvent", nudgeKeyboard)
end

local function showNudge(mover, frame)
	if not nudge then createNudge() end
	nudge.mover, nudge.frame = mover, frame
	nudge:ClearAllPoints()
	local bottom = mover:GetBottom()
	local s = mover:GetEffectiveScale() / UIParent:GetEffectiveScale()
	if bottom and bottom * s > 40 then
		nudge:SetPoint("TOP", mover, "BOTTOM", 0, -2)
	else
		-- Encima, dejando sitio al nombre del recuadro
		nudge:SetPoint("BOTTOM", mover, "TOP", 0, 18)
	end
	nudgeText()
	if nudge:IsShown() then nudgeKeyboard() else nudge:Show() end
end

-- mover: el recuadro que se arrastra; frame: el marco que se mueve (puede ser
-- el mismo). El recuadro debe guardar la posición en su OnDragStop.
function R:AddNudge(mover, frame)
	if mover.rzNudge then return end
	mover.rzNudge = true
	mover:HookScript("OnEnter", function() showNudge(mover, frame or mover) end)
	mover:HookScript("OnDragStop", function()
		if nudge and nudge.mover == mover and not R.nudging then nudgeText() end
	end)
end

-- Hace arrastrable un marco con un recuadro azul que aparece al desbloquear.
-- La posición se guarda en db[pointKey] como { punto, puntoRelativo, x, y }.
function R:CreateMover(frame, label, db, pointKey, default)
	frame:SetMovable(true)
	frame:SetClampedToScreen(true)
	self:RegisterMovable(frame)

	local mover = CreateFrame("Frame", nil, frame, "BackdropTemplate")
	mover:SetPoint("TOPLEFT", -4, 4)
	mover:SetPoint("BOTTOMRIGHT", 4, -4)
	mover:SetFrameLevel(frame:GetFrameLevel() + 30)
	mover:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	mover:SetBackdropColor(0.1, 0.5, 0.8, 0.25)
	mover:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	mover:EnableMouse(true)
	mover:RegisterForDrag("LeftButton")
	mover.text = mover:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	mover.text:SetPoint("BOTTOM", mover, "TOP", 0, 2)
	mover.text:SetText("|cff33ccffRheizor|r · " .. R.T(label))
	mover:SetScript("OnDragStart", function()
		if not InCombatLockdown() or not frame:IsProtected() then frame:StartMoving() end
	end)
	mover:SetScript("OnDragStop", function()
		frame:StopMovingOrSizing()
		frame:SetUserPlaced(false)
		local point, _, relPoint, x, y = frame:GetPoint()
		db[pointKey] = { point, relPoint, x, y }
	end)
	self:AddNudge(mover, frame)
	mover:Hide()

	-- Engranaje para abrir la configuración de ese elemento. Por defecto la
	-- página del módulo al que pertenece db; un módulo puede poner su propia
	-- acción en mover.configure (p. ej. un editor)
	local function ownerModule()
		for _, mod in ipairs(R.order) do
			if mod.db == db then return mod end
		end
		for _, mod in ipairs(R.order) do
			if type(mod.db) == "table" then
				for _, v in pairs(mod.db) do
					if v == db then return mod end
				end
			end
		end
	end
	local gear = CreateFrame("Button", nil, mover)
	gear:SetSize(16, 16)
	gear:SetPoint("TOPRIGHT", -2, -2)
	gear:SetFrameLevel(mover:GetFrameLevel() + 2)
	local icon = gear:CreateTexture(nil, "ARTWORK")
	icon:SetAllPoints()
	if not (icon.SetAtlas and pcall(icon.SetAtlas, icon, "QuestLog-icon-setting") and icon:GetAtlas()) then
		icon:SetTexture("Interface\\Buttons\\UI-OptionsButton")
	end
	icon:SetVertexColor(0.85, 0.85, 0.85)
	gear:SetScript("OnEnter", function(self)
		icon:SetVertexColor(1, 1, 1)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(R.L["Abrir su configuración"], 1, 1, 1)
		GameTooltip:Show()
	end)
	gear:SetScript("OnLeave", function()
		icon:SetVertexColor(0.85, 0.85, 0.85)
		GameTooltip:Hide()
	end)
	gear:SetScript("OnClick", function()
		GameTooltip:Hide()
		if mover.configure then
			mover.configure()
		else
			local mod = ownerModule()
			if mod and R.OpenModuleOptions then R:OpenModuleOptions(mod) end
		end
	end)
	-- Solo si hay algo que abrir
	mover:HookScript("OnShow", function()
		gear:SetShown(mover.configure ~= nil or (R.OpenModuleOptions ~= nil and ownerModule() ~= nil))
	end)

	function mover:Place()
		local p = db[pointKey] or default
		frame:ClearAllPoints()
		frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	end
	mover:Place()
	return mover
end

-- Equivale a /console cvar valor (esperando a salir de combate si hace falta)
-- Algunas CVars no las deja cambiar a los addons (el juego lo ignora sin
-- avisar): se vuelve a leer y, si no ha cambiado, se dice qué escribir
local rejected = {}
function R:SetCVar(cvar, value)
	value = tostring(value)
	self:RunOutOfCombat(function()
		pcall(C_CVar.SetCVar, cvar, value)
		local now = C_CVar.GetCVar(cvar)
		local a, b = tonumber(now), tonumber(value)
		if now ~= nil and now ~= value and not (a and b and math.abs(a - b) < 0.001) then
			if rejected[cvar] ~= value then
				rejected[cvar] = value
				self:Print(R.L["El juego no deja a los addons cambiar este ajuste. Escríbelo tú en el chat: %s"]:format(
					"|cffffff00/console " .. cvar .. " " .. value .. "|r"))
			end
		else
			rejected[cvar] = nil
		end
	end)
end

function R:NeedReload()
	self:Print(R.L["Cambio guardado. Escribe |cffffff00/reload|r para restaurar el elemento."])
end

----------------------------------------------------------------------
-- Hasta dónde se puede llevar el chat principal contra el borde de la
-- pantalla. El modo edición reserva siempre el mismo margen (32 debajo
-- para la caja de texto, 32 a la izquierda para los botones), aunque la
-- caja se mueva arriba o los botones se oculten, y el chat no se puede
-- pegar al borde. Se recalcula con lo que de verdad hay alrededor.
-- Lo usan Rheizor-Chat (caja de texto) y Rheizor-Interface (botones).
----------------------------------------------------------------------

local CHAT_AROUND = { "ChatFrameMenuButton", "ChatFrameChannelButton", "QuickJoinToastButton" }
local clampHooked = false

function R:UpdateChatClamp()
	local frame = ChatFrame1
	if not (frame and frame.UpdateClampOffsets and frame.SetClampRectInsets) then return end
	if not clampHooked then
		clampHooked = true
		-- Blizzard lo recalcula con su margen fijo (al entrar en el modo
		-- edición, al cambiar de tamaño...): se corrige justo después
		hooksecurefunc(frame, "UpdateClampOffsets", function() R:UpdateChatClamp() end)
		if FCF_SetButtonSide then hooksecurefunc("FCF_SetButtonSide", function() R:UpdateChatClamp() end) end
	end
	local l, r, t, b = frame:GetLeft(), frame:GetRight(), frame:GetTop(), frame:GetBottom()
	if not l then return end
	local scale = frame:GetEffectiveScale()
	local minL, maxR, maxT, minB = l, r, t, b
	local function add(obj, onlyShown)
		if type(obj) ~= "table" or not obj.GetLeft then return false end
		if onlyShown and not obj:IsShown() then return true end
		local ol, orr, ot, ob = obj:GetLeft(), obj:GetRight(), obj:GetTop(), obj:GetBottom()
		if not ol then return false end
		local k = obj:GetEffectiveScale() / scale
		minL, maxR = math.min(minL, ol * k), math.max(maxR, orr * k)
		maxT, minB = math.max(maxT, ot * k), math.min(minB, ob * k)
		return true
	end
	local name = frame:GetName()
	add(frame.Background)
	add(_G[name .. "Tab"])
	add(frame.ScrollBar, true)
	add(frame.buttonFrame, true)
	for _, key in ipairs(CHAT_AROUND) do add(_G[key], true) end
	-- La caja de texto cuenta aunque esté oculta (aparece al escribir). Si
	-- el juego aún no sabe dónde va, se deja el margen de Blizzard debajo
	if not add(frame.editBox or _G[name .. "EditBox"]) then minB = math.min(minB, b - 32) end
	frame:SetClampRectInsets(minL - l, maxR - r, maxT - t, minB - b)
end

----------------------------------------------------------------------
-- Ocultar marcos de Blizzard
----------------------------------------------------------------------

local hooked = {}

local function safeHide(frame)
	if frame.IsProtected and frame:IsProtected() and InCombatLockdown() then
		R:RunOutOfCombat(function() frame:Hide() end)
	else
		frame:Hide()
	end
end

-- Mantiene ocultos los marcos indicados mientras predicate() devuelva true.
-- Si Blizzard los vuelve a mostrar, se ocultan de nuevo.
function R:KeepHidden(paths, predicate, label)
	local found = false
	for _, path in ipairs(paths) do
		local f = self:Resolve(path)
		if type(f) == "table" and f.Hide then
			found = true
			if not hooked[f] then
				hooked[f] = true
				local function enforce(frame)
					if predicate() then safeHide(frame) end
				end
				if f.HasScript and f:HasScript("OnShow") then
					f:HookScript("OnShow", enforce)
				else
					hooksecurefunc(f, "Show", enforce)
				end
			end
			if predicate() then safeHide(f) end
		end
	end
	self.missing[label] = (not found) and table.concat(paths, " / ") or nil
	return found
end

-- Añade a un módulo opciones de "ocultar X" a partir de una tabla
-- { opcion = { "Marco", "Otro.Marco", addon = "Blizzard_Algo" } }
function R:AttachHiders(mod, targets)
	local function apply(key)
		local t = targets[key]
		local run = function()
			R:KeepHidden(t, function() return mod.db[key] end, mod.title .. ": " .. key)
		end
		if t.addon and EventUtil and EventUtil.ContinueOnAddOnLoaded then
			EventUtil.ContinueOnAddOnLoaded(t.addon, run)
		else
			run()
		end
	end

	local onEnable, onChanged = mod.OnEnable, mod.OnOptionChanged
	mod.OnEnable = function(self)
		for key in pairs(targets) do
			if self.db[key] then apply(key) end
		end
		if onEnable then onEnable(self) end
	end
	mod.OnOptionChanged = function(self, key, value)
		if targets[key] then
			if value then apply(key) else R:NeedReload() end
		elseif onChanged then
			onChanged(self, key, value)
		end
	end
end

----------------------------------------------------------------------
-- Módulos
----------------------------------------------------------------------

local function initModule(mod)
	R.db[mod.key] = R.db[mod.key] or {}
	copyDefaults(mod.defaults, R.db[mod.key])
	mod.db = R.db[mod.key]
end

-- Tras cambiar R.db de perfil antes de encender los módulos (FixCharKey)
function R:RebindModules()
	for _, mod in ipairs(self.order) do initModule(mod) end
end

-- Los textos de las opciones se traducen aquí, así los módulos no tienen que
-- envolverlos (pero sí tienen que estar en su Locale.lua)
local translatedValues = {}
local function translateOptions(mod)
	mod.title = R.T(mod.title)
	mod.group = R.T(mod.group)
	-- Lo que el módulo no puede hacer en WoW Forever (se lista al final de su página)
	for i, text in ipairs(mod.unsupported or {}) do mod.unsupported[i] = R.T(text) end
	for _, opt in ipairs(mod.options or {}) do
		opt.text = R.T(opt.text)
		opt.name = R.T(opt.name)
		opt.desc = R.T(opt.desc)
		-- Las listas de valores pueden estar compartidas entre opciones
		if type(opt.values) == "table" and not translatedValues[opt.values] then
			translatedValues[opt.values] = true
			for _, v in ipairs(opt.values) do v[2] = R.T(v[2]) end
		end
	end
end

function R:RegisterModule(key, mod)
	translateOptions(mod)
	mod.key = key
	mod.addon = mod.addon or self.current or ADDON
	mod.defaults = mod.defaults or {}
	self.modules[key] = mod
	table.insert(self.order, mod)
	-- Los addons de módulos cargan después del núcleo: su base de datos ya está
	if self.db then initModule(mod) end
	return mod
end

-- Qué addons de Rheizor están activados en Rheizor (aparte de que WoW los
-- cargue): un addon cargado pero desactivado aquí se puede configurar, pero no
-- hace nada. Se guarda en el perfil: db.__addons[nombre]; si un addon no
-- tiene valor manda db.__addons.default (y si tampoco hay, activado).
function R:IsAddonActive(addon)
	if not addon or addon == ADDON then return true end
	local t = self.db and self.db.__addons
	if type(t) ~= "table" then return true end
	local v = t[addon]
	if v == nil then v = t.default end
	return v ~= false
end

function R:SetAddonActive(addon, on, db)
	db = db or self.db
	if type(db.__addons) ~= "table" then db.__addons = {} end
	db.__addons[addon] = on and true or false
end

-- Cómo estaba cada addon al entrar (para saber si hay que recargar)
R.activeAtLogin = {}

-- ¿Se puede usar ya el código del módulo? No si está apagado en Rheizor o
-- si se ha encendido sin recargar (su OnEnable no ha llegado a ejecutarse):
-- sus marcos aún no existen y tocarlos daría errores
function R:IsModuleRunning(mod)
	return mod.started == true and self:IsAddonActive(mod.addon)
end

-- Para los botones de las opciones: ejecuta la acción solo si el módulo está
-- en marcha; si no, explica por qué no pasa nada
function R:RunModuleAction(mod, func)
	if not self:IsModuleRunning(mod) then
		self:Print(self.L["%s está desactivado o se acaba de activar: recarga la interfaz (|cffffff00/reload|r) para usar esto."]:format(mod.title or mod.key))
		return
	end
	func(mod)
end

function R:OptionChanged(mod, key)
	-- El valor ya está guardado; se aplicará al recargar
	if not self:IsModuleRunning(mod) then return end
	if mod.OnOptionChanged then
		mod:OnOptionChanged(key, mod.db[key])
	end
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(self, event, arg1)
	if event == "ADDON_LOADED" and arg1 == ADDON then
		R:LoadProfile()
		for _, mod in ipairs(R.order) do
			if not mod.db then initModule(mod) end
		end
		self:UnregisterEvent("ADDON_LOADED")

	elseif event == "PLAYER_LOGIN" then
		-- Si al cargar el nombre aún no se sabía, se corrige ahora
		if R.FixCharKey then xpcall(R.FixCharKey, geterrorhandler(), R) end
		-- Que WoW cargue en este personaje los addons que su perfil tiene activados
		if R.SyncAddonsWithProfile then xpcall(R.SyncAddonsWithProfile, geterrorhandler(), R) end
		-- Aquí ya han cargado todos los addons de Rheizor
		if R.BuildOptions then
			xpcall(R.BuildOptions, geterrorhandler(), R)
		end
		for _, mod in ipairs(R.order) do
			local active = R:IsAddonActive(mod.addon)
			R.activeAtLogin[mod.addon] = active
			if active and mod.OnEnable then
				-- started: el módulo se ha preparado (marcos, eventos…) y ya se
				-- puede llamar a su código desde las opciones
				mod.started = xpcall(mod.OnEnable, geterrorhandler(), mod)
			else
				mod.started = active
			end
		end

	elseif event == "PLAYER_REGEN_ENABLED" then
		local queue = combatQueue
		combatQueue = {}
		for _, fn in ipairs(queue) do
			xpcall(fn, geterrorhandler())
		end
	end
end)

----------------------------------------------------------------------
-- Comandos: /rz o /rheizor
----------------------------------------------------------------------

SLASH_RHEIZOR1 = "/rz"
SLASH_RHEIZOR2 = "/rheizor"
SlashCmdList.RHEIZOR = function(msg)
	local L = R.L
	msg = strtrim(msg or ""):lower()
	if msg == "reset" then
		-- Solo el perfil actual; los demás perfiles no se tocan
		if R.TakeSnapshot then R:TakeSnapshot(L["Antes de /rz reset"], true) end
		wipe(R.db)
		ReloadUI()
	elseif msg == "diag" and R.BarsDiagnostic and R.ShowText then
		R:ShowText(L["Diagnóstico de la interfaz"], R:BarsDiagnostic())
	elseif msg == "debug" then
		local any = false
		for label, paths in pairs(R.missing) do
			R:Print(L["|cffff5555No encontrado|r %s -> %s"]:format(label, paths))
			any = true
		end
		if not any then R:Print(L["Todos los marcos activos se han encontrado."]) end
	-- Los comandos de un módulo solo si está en marcha (si no, explica por qué)
	elseif (msg == "discos" or msg == "discs") and R.modules.discs then
		R:RunModuleAction(R.modules.discs, function(m) m:OpenEditor() end)
	elseif (msg == "personajes" or msg == "pj" or msg == "chars" or msg == "characters" or msg == "alts") and R.modules.characters then
		R:RunModuleAction(R.modules.characters, function(m) m:Toggle() end)
	elseif (msg == "hermandad" or msg == "guild" or msg == "profesiones" or msg == "professions") and R.modules.guild then
		R:RunModuleAction(R.modules.guild, function(m) m:Toggle() end)
	elseif (msg == "marcos" or msg == "frames") and R.modules.unitframes then
		R:RunModuleAction(R.modules.unitframes, function(m) m:ToggleTest() end)
	elseif (msg == "mover" or msg == "editar" or msg == "edit" or msg == "move") and R.modules.editmode then
		R.modules.editmode:Toggle()
	elseif (msg == "asistente" or msg == "instalar" or msg == "wizard" or msg == "install" or msg == "setup") and R.OpenWizard and R.SETUP_ENABLED then
		R:OpenWizard()
	elseif (msg == "exportar" or msg == "export") and R.ShowTransfer then
		R:ShowTransfer("export")
	elseif (msg == "importar" or msg == "import") and R.ShowTransfer then
		R:ShowTransfer("import")
	elseif msg == "auras" and R.DiagnoseAuras then
		R:DiagnoseAuras()
	elseif msg == "blizzard" or msg == "opciones" or msg == "options" then
		R:OpenOptions()
	elseif msg == "help" or msg == "ayuda" then
		local es = R.locale == "es"
		R:Print(L["/rz - abrir el gestor de Rheizor (addons y opciones)"])
		R:Print(es and "/rz opciones - abrir las opciones en Opciones > AddOns" or "/rz options - open the options in Options > AddOns")
		R:Print(L["/rz auras - qué auras del objetivo se pueden leer ahora"])
		R:Print(es and "/rz discos - editor de discos de acción" or "/rz discs - action disc editor")
		R:Print(es and "/rz mover - modo edición: mover todo con cuadrícula" or "/rz move - edit mode: move everything with a grid")
		R:Print(es and "/rz marcos - modo prueba de los marcos de unidad" or "/rz frames - unit frame test mode")
		if R.modules.characters then
			R:Print(es and "/rz personajes - oro, descanso y objetos de tus personajes" or "/rz chars - gold, rested XP and items of your characters")
		end
		if R.modules.guild then
			R:Print(es and "/rz hermandad - profesiones de la gente de tu hermandad" or "/rz guild - your guild members' professions")
		end
		if R.SETUP_ENABLED then
			R:Print(es and "/rz asistente - asistente de instalación (addons, plantilla y ajustes)" or "/rz setup - setup wizard (addons, layout and settings)")
		end
		R:Print(es and "/rz exportar | importar - copiar la configuración con un texto" or "/rz export | import - copy the settings as text")
		R:Print(L["/rz debug - listar marcos que no se encontraron en esta versión"])
		R:Print(L["/rz reset - borrar la configuración del perfil actual y recargar"])
		if R.SETUP_ENABLED then
			R:Print(L["/rz diag - dónde están las barras y marcos (para ajustar las plantillas)"])
		end
	elseif R.OpenManager then
		R:OpenManager()
	else
		R:OpenOptions()
	end
end

----------------------------------------------------------------------
-- Bloqueo de la varita / disparo automático
----------------------------------------------------------------------
-- En Classic cada disparo de varita (y el disparo repetido de arcos,
-- armas de fuego y arrojadizas) pone todos los hechizos en reutilización
-- durante la velocidad del arma, y el juego NO lo marca como reutilización
-- global (isOnGCD). Para los addons parecería que todo está en
-- reutilización propia. R:InRangedLockout() dice si ahora puede pasar eso;
-- R:CastRecently(id) si acabas de lanzar ese hechizo (entonces su
-- reutilización sí es suya).

local AUTO_RANGED = {
	[5019] = true,   -- Disparar (varita)
	[3018] = true,   -- Disparar (arco, fusil, ballesta)
	[2764] = true,   -- Lanzar (arrojadizas)
	[75] = true,     -- Disparo automático
}
local autoRepeat = false
local lockUntil = 0
local lastCast = {}

local function rangedSpeed()
	local speed = UnitRangedDamage and R.NotSecret(UnitRangedDamage("player"))
	if type(speed) ~= "number" or speed <= 0 then speed = 2.5 end
	return math.min(math.max(speed, 1), 4)
end

function R:InRangedLockout()
	return autoRepeat or GetTime() < lockUntil
end

-- Avisar al acabar el bloqueo (para volver a mirar las reutilizaciones)
local lockEndCallbacks = {}
function R:OnRangedLockEnd(fn)
	lockEndCallbacks[#lockEndCallbacks + 1] = fn
end

local function checkLockEnd()
	if R:InRangedLockout() then return end
	for _, fn in ipairs(lockEndCallbacks) do xpcall(fn, geterrorhandler()) end
end

local function lockFor(seconds)
	lockUntil = math.max(lockUntil, GetTime() + seconds)
	C_Timer.After(lockUntil - GetTime() + 0.05, checkLockEnd)
end

function R:CastRecently(spellID, window)
	local t = spellID and lastCast[spellID]
	return t ~= nil and GetTime() - t < (window or 1)
end

local lockEvents = CreateFrame("Frame")
pcall(lockEvents.RegisterEvent, lockEvents, "START_AUTOREPEAT_SPELL")
pcall(lockEvents.RegisterEvent, lockEvents, "STOP_AUTOREPEAT_SPELL")
pcall(lockEvents.RegisterUnitEvent, lockEvents, "UNIT_SPELLCAST_SUCCEEDED", "player")
lockEvents:SetScript("OnEvent", function(_, event, _, _, spellID)
	if event == "START_AUTOREPEAT_SPELL" then
		autoRepeat = true
	elseif event == "STOP_AUTOREPEAT_SPELL" then
		-- El último disparo sigue bloqueando hasta la velocidad del arma
		autoRepeat = false
		lockFor(rangedSpeed() + 0.3)
	else
		spellID = R.NotSecret(spellID)
		if not spellID then return end
		lastCast[spellID] = GetTime()
		if AUTO_RANGED[spellID] then lockFor(rangedSpeed() + 0.3) end
	end
end)


----------------------------------------------------------------------
-- Enlaces para copiar (un addon no puede abrir el navegador): cuadro con
-- el texto ya seleccionado, Ctrl+C y Esc. R:ShowCopyBox(título, texto)
----------------------------------------------------------------------

local copyBox

function R:ShowCopyBox(title, text)
	if not copyBox then
		copyBox = CreateFrame("Frame", "RheizorCopyBox", UIParent, "BackdropTemplate")
		copyBox:SetSize(420, 86)
		copyBox:SetPoint("CENTER", 0, 150)
		copyBox:SetFrameStrata("FULLSCREEN_DIALOG")
		copyBox:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
		copyBox:SetBackdropColor(0.05, 0.05, 0.07, 0.97)
		copyBox:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
		copyBox:EnableMouse(true)
		table.insert(UISpecialFrames, "RheizorCopyBox")
		copyBox.title = copyBox:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		copyBox.title:SetPoint("TOPLEFT", 12, -10)
		copyBox.title:SetPoint("RIGHT", -30, 0)
		copyBox.title:SetJustifyH("LEFT")
		copyBox.title:SetWordWrap(false)
		local close = CreateFrame("Button", nil, copyBox, "UIPanelCloseButton")
		close:SetPoint("TOPRIGHT", 2, 2)
		local edit = CreateFrame("EditBox", nil, copyBox, "InputBoxTemplate")
		edit:SetSize(390, 22)
		edit:SetPoint("TOPLEFT", 18, -32)
		edit:SetAutoFocus(true)
		-- Si se escribe, vuelve el texto: solo sirve para copiar
		edit:SetScript("OnTextChanged", function(self, user)
			if user then self:SetText(copyBox.text); self:HighlightText() end
		end)
		edit:SetScript("OnEscapePressed", function() copyBox:Hide() end)
		edit:SetScript("OnEnterPressed", function() copyBox:Hide() end)
		copyBox.edit = edit
		local hint = copyBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		hint:SetPoint("TOPLEFT", 14, -62)
		hint:SetText(R.L["Ctrl+C para copiar y pégalo en el navegador. Esc para cerrar."])
	end
	copyBox.text = text
	copyBox.title:SetText(title or "")
	copyBox:Show()
	copyBox.edit:SetText(text)
	copyBox.edit:SetFocus()
	copyBox.edit:HighlightText()
end

-- Enlace de Wowhead. kind = "item" o "spell"; site = "classic" o "retail"
function R.WowheadURL(kind, id, site, spanish)
	local path = site == "retail" and "" or "classic/"
	if spanish then path = path .. "es/" end
	return "https://www.wowhead.com/" .. path .. kind .. "=" .. id
end