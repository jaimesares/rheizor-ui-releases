-- Asistente de instalación: sale solo la primera vez que se instala Rheizor
-- (y cuando quieras con /rz asistente o desde el gestor). Pasos:
--   1. Bienvenida   2. Addons de Rheizor (activar/desactivar)
--   3. Plantilla de distribución   4. Ajustes rápidos   5. Terminar (recarga)
-- Los cambios de addons, plantilla y escala se aplican al terminar; los
-- ajustes rápidos son las opciones normales y se guardan al momento.

local R = Rheizor:Namespace(...)
local L = R.L

local WZ = R:RegisterModule("wizard", {
	title = "Asistente de instalación",
	defaults = {
		layout = "centered",
	},
	-- Sin opciones (y sin página en el gestor) mientras esté apagado
	options = R.SETUP_ENABLED and {
		{ type = "header", text = "Asistente de instalación" },
		{ type = "button", name = "Volver a pasar el asistente", text = "Abrir asistente",
		  desc = "Elegir addons, plantilla de distribución y ajustes básicos otra vez. También con /rz asistente.",
		  func = function() R:OpenWizard() end },
	} or nil,
})

local W, H = 740, 530
local CANVAS_W = 680
local WHITE = "Interface\\Buttons\\WHITE8X8"

local STEPS = { "Bienvenida", "Addons", "Plantilla", "Ajustes rápidos", "Listo" }

-- Addons que solo sirven a algunas clases
local ONLY_FOR = {
	["Rheizor-Totems"] = { classes = { SHAMAN = true }, note = "solo chamanes" },
	["Rheizor-Swing"]  = { classes = { WARRIOR = true, ROGUE = true, PALADIN = true, HUNTER = true, SHAMAN = true, DRUID = true, DEATHKNIGHT = true },
	                       note = "cuerpo a cuerpo y cazadores" },
}

-- Ajustes rápidos: { módulo, clave } o { módulo, cvar = "..." }, por secciones
local QUICK = {
	{ header = "Interfaz" },
	{ "plates", "enabled" },
	{ "plates", "threat" },
	{ "plates", cvar = "nameplateShowEnemies" },
	{ "castbars", "enabled" },
	{ "sct", "enabled" },
	{ header = "Comodidad" },
	{ "auto", cvar = "autoLootDefault" },
	{ "bags", "autoSell" },
	{ "bags", "autoRepair" },
	{ "auto", "quests" },
	{ "errors", "mode" },
	{ header = "Cámara y chat" },
	{ "camera", cvar = "cameraDistanceMaxZoomFactor" },
	{ "chat", cvar = "showTimestamps" },
	{ "chatmod", "classColor" },
}

local wiz          -- la ventana
local state        -- lo elegido en esta pasada del asistente

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local function ui() return R.UI end

local function findOption(entry)
	local mod = R.modules[entry[1]]
	if not (mod and mod.options and mod.db) then return end
	for _, opt in ipairs(mod.options) do
		if (entry[2] and opt.key == entry[2]) or (entry.cvar and opt.cvar == entry.cvar) then
			return mod, opt
		end
	end
end

local function addonList()
	local list = {}
	for _, a in ipairs(ui().CollectAddons()) do
		if not a.core then list[#list + 1] = a end
	end
	return list
end

-- Cómo está ahora: activado en Rheizor (o, si no usa el núcleo, cargado en WoW)
local function current(a)
	local U = ui()
	if U.HasSwitch(a) then return U.IsActive(a.name) end
	return U.IsEnabled(a.name)
end

local function wanted(a)
	local v = state.addons[a.name]
	if v == nil then return current(a) end
	return v
end

local function suitsClass(name)
	local only = ONLY_FOR[name]
	return not only or only.classes[R:PlayerClass()] or false
end

----------------------------------------------------------------------
-- Pasos
----------------------------------------------------------------------

local render = {}

render[1] = function(y)
	local U = ui()
	y = y + U.Text(y, L["¡Bienvenido a Rheizor!"], GameFontNormalHuge or GameFontNormalLarge)
	y = y + 6
	y = y + U.Text(y, L["En unos pocos pasos eliges qué addons de Rheizor usar, cómo quieres la pantalla y los ajustes más importantes. Todo se puede cambiar después en /rz."])
	y = y + 10
	if R.freshInstall then
		y = y + U.Text(y, L["|cff33ff33Ya está todo configurado con la plantilla recomendada.|r Si no quieres tocar nada, pulsa «Usar lo recomendado»."], GameFontHighlight)
	else
		y = y + U.Text(y, L["|cffff8800Tu configuración actual se mantiene|r salvo lo que cambies aquí. La plantilla solo se aplica si eliges una."], GameFontHighlight)
	end
	y = y + 16
	y = y + U.Button(y, L["Configurar paso a paso"], L["Empezar"], function() wiz:Go(2) end)
	y = y + U.Button(y, L["Sin preguntas"], L["Usar lo recomendado"], function()
		state.layoutPicked = state.layoutPicked or R.freshInstall
		R:FinishWizard()
	end, L["Deja los addons como están, usa la plantilla elegida (la recomendada si es la primera vez) y recarga la interfaz."])
	y = y + U.Button(y, L["Ir poco a poco"], L["Sin tocar la interfaz"], function()
		state.layout = "none"
		state.layoutPicked = true
		R:FinishWizard()
	end, L["Instala Rheizor sin cambiar nada de la interfaz: lo visual empieza apagado y lo vas activando en /rz."])
	return y
end

render[2] = function(y)
	local U = ui()
	y = y + U.Text(y, L["Addons de Rheizor instalados. Desmarca los que no quieras usar; se aplica al terminar."])
	y = y + U.Toggle(y, L["Aplicar a todos mis personajes"], state.allChars, function(v) state.allChars = v end,
		L["Si lo desmarcas, solo cambia en el perfil de este personaje."])
	y = y + U.Button(y, L["Marcar"], L["Todos"], function()
		for _, a in ipairs(addonList()) do state.addons[a.name] = true end
		wiz:Render()
	end)
	y = y + U.Button(y, "", L["Los recomendados para tu clase"], function()
		for _, a in ipairs(addonList()) do state.addons[a.name] = suitsClass(a.name) end
		wiz:Render()
	end)
	y = y + U.Button(y, "", L["Ninguno"], function()
		for _, a in ipairs(addonList()) do state.addons[a.name] = false end
		wiz:Render()
	end)
	y = y + 4
	y = y + U.Header(y, L["Addons"])
	for _, a in ipairs(addonList()) do
		local label = a.short
		local only = ONLY_FOR[a.name]
		if only then
			local color = suitsClass(a.name) and "|cff888888" or "|cffff8800"
			label = label .. "  " .. color .. "(" .. L[only.note] .. ")|r"
		end
		local conflicts = R.FindConflicts and R:FindConflicts(a.name) or {}
		local desc = a.notes or ""
		if #conflicts > 0 then
			label = label .. "  |cffff8800!|r"
			desc = desc .. "\n\n" .. L["|cffff8800Puede chocar con:|r %s. Los dos cambian lo mismo; deja activado solo uno."]:format(table.concat(conflicts, ", "))
		end
		y = y + U.Toggle(y, label, wanted(a), function(v) state.addons[a.name] = v end, desc)
	end
	return y
end

-- Tarjetas de plantilla (se crean una vez; no son controles del gestor)
local COLORS = {
	static = { 0.28, 0.28, 0.3 }, bar = { 0.6, 0.6, 0.65 }, micro = { 0.3, 0.55, 1 },
	group = { 0.7, 0.4, 1 }, unit = { 0.2, 0.85, 0.3 }, cast = { 1, 0.82, 0 },
	threat = { 1, 0.3, 0.3 }, swing = { 1, 0.55, 0.1 }, blizz = { 0.55, 0.5, 0.35 },
	xp = { 0.85, 0.45, 0.95 },
}
local CARD_W, CARD_H, PREV_W, PREV_H = 128, 128, 118, 66

local function createCards(parent)
	local cards = {}
	for i, t in ipairs(R.LAYOUTS) do
		local c = CreateFrame("Button", nil, parent, "BackdropTemplate")
		c:SetSize(CARD_W, CARD_H)
		c:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		c:SetBackdropColor(0, 0, 0, 0.5)
		local hl = c:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(1, 1, 1, 0.05)

		local screen = CreateFrame("Frame", nil, c, "BackdropTemplate")
		screen:SetSize(PREV_W, PREV_H)
		screen:SetPoint("TOP", 0, -6)
		screen:SetBackdrop({ bgFile = WHITE })
		screen:SetBackdropColor(0.1, 0.12, 0.16, 1)
		for _, r in ipairs(R:LayoutPreview(t.id)) do
			local tex = screen:CreateTexture(nil, "ARTWORK")
			local col = COLORS[r[1]] or COLORS.static
			tex:SetColorTexture(col[1], col[2], col[3], 0.9)
			tex:SetPoint("BOTTOMLEFT", r[2] * PREV_W, r[3] * PREV_H)
			tex:SetSize(math.max(1, r[4] * PREV_W), math.max(1, r[5] * PREV_H))
		end

		c.name = c:CreateFontString(nil, "OVERLAY", "GameFontNormal")
		c.name:SetPoint("TOP", screen, "BOTTOM", 0, -8)
		c.name:SetText(t.name)
		c.tag = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		c.tag:SetPoint("TOP", c.name, "BOTTOM", 0, -4)

		c:SetScript("OnClick", function()
			state.layout = t.id
			state.layoutPicked = true
			wiz:Render()
		end)
		ui().Tooltip(c, t.name, t.desc)
		c.id = t.id
		cards[i] = c
	end
	return cards
end

render[3] = function(y)
	local U = ui()
	y = y + U.Text(y, L["Elige cómo quieres la pantalla. Las plantillas colocan y activan los marcos de Rheizor; luego puedes moverlo todo con /rz mover. «Sin cambios» deja la interfaz de Blizzard como está."])
	y = y + 6
	wiz.cards = wiz.cards or createCards(wiz.body.child)
	for i, c in ipairs(wiz.cards) do
		c:ClearAllPoints()
		c:SetPoint("TOPLEFT", (i - 1) * (CARD_W + 10), -y)
		c:Show()
		local selected = c.id == state.layout
		c:SetBackdropBorderColor(selected and 0.2 or 1, selected and 0.8 or 1, 1, selected and 1 or 0.15)
		local current = c.id == R.db.wizard.layout
		c.tag:SetText(selected and ("|cff33ccff" .. L["Elegida"] .. "|r") or (current and ("|cff888888" .. L["La que tienes"] .. "|r") or ""))
	end
	y = y + CARD_H + 10

	local t = R:GetLayout(state.layout)
	y = y + U.Text(y, "|cff33ccff" .. t.name .. "|r  " .. t.desc)
	y = y + 4
	if t.untouched then
		y = y + U.Text(y, L["|cff888888Se desactivan los marcos, barras de lanzamiento, placas, texto de combate, amenaza, swing timer, tótems, apariencia, chat y herramientas de banda de Rheizor. Actívalos cuando quieras en /rz.|r"], GameFontHighlightSmall, 4)
	elseif R:CanLayoutBlizzard() then
		y = y + U.Toggle(y, L["Colocar también las barras de Blizzard"], state.blizzard, function(v) state.blizzard = v end,
			L["Crea un diseño en Esc > Modo edición con las barras de acción, el micromenú y las bolsas en su sitio, y lo activa. Tus otros diseños no se tocan."])
	else
		y = y + U.Text(y, L["|cff888888Este cliente no permite colocar las barras de Blizzard desde un addon: colócalas en Esc > Modo edición.|r"], GameFontHighlightSmall, 4)
	end
	if not state.layoutPicked and not R.freshInstall then
		y = y + U.Text(y, L["|cff888888Si no pulsas ninguna, tus posiciones actuales no cambian.|r"], GameFontHighlightSmall, 4)
	end
	return y
end

render[4] = function(y)
	local U = ui()
	y = y + U.Text(y, L["Lo más importante, en un sitio. Se guarda al momento; el resto está en /rz."])

	-- Escala de la interfaz (se aplica al terminar para no redimensionar esta ventana mientras arrastras)
	if C_CVar.GetCVar("uiScale") then
		y = y + U.Header(y, L["Tamaño de la interfaz"])
		y = y + U.Option({ db = {} }, {
			type = "slider", name = L["Escala de la interfaz"], min = 0.64, max = 1.15, step = 0.01, format = R.fmt.dec2,
			desc = L["Se aplica al terminar el asistente."],
			get = function() return state.uiScale or tonumber(C_CVar.GetCVar("uiScale")) or 1 end,
			set = function(v) state.uiScale = v end,
		}, y)
	end

	for _, entry in ipairs(QUICK) do
		if entry.header then
			y = y + U.Header(y, L[entry.header])
		else
			local mod, opt = findOption(entry)
			if mod then
				local ok, h = pcall(U.Option, mod, opt, y)
				if ok then y = y + (h or 0) end
			end
		end
	end
	return y
end

render[5] = function(y)
	local U = ui()
	y = y + U.Text(y, L["Esto es lo que se va a aplicar al terminar:"])
	y = y + 6

	local on, off = {}, {}
	for _, a in ipairs(addonList()) do
		local want = wanted(a)
		if want ~= current(a) then
			if want then on[#on + 1] = a.short else off[#off + 1] = a.short end
		end
	end
	local who = state.allChars and L["en todos tus personajes"] or L["en este personaje"]
	if #on > 0 then y = y + U.Text(y, "|cff33ff33+|r " .. L["Activar (%s): %s"]:format(who, table.concat(on, ", "))) end
	if #off > 0 then y = y + U.Text(y, "|cffff5555-|r " .. L["Desactivar (%s): %s"]:format(who, table.concat(off, ", "))) end
	if #on == 0 and #off == 0 then y = y + U.Text(y, "|cff888888" .. L["Addons: sin cambios."] .. "|r") end

	if state.layoutPicked or R.freshInstall then
		local t = R:GetLayout(state.layout)
		y = y + U.Text(y, L["Plantilla: %s"]:format(t.name))
		if t.untouched then
			y = y + U.Text(y, "|cff888888" .. L["La interfaz de Blizzard no se toca; lo visual de Rheizor queda apagado."] .. "|r", GameFontHighlightSmall, 4)
		elseif state.blizzard and R:CanLayoutBlizzard() then
			y = y + U.Text(y, "|cff888888" .. L["Las barras de Blizzard se colocan con un diseño nuevo del Modo edición."] .. "|r", GameFontHighlightSmall, 4)
		end
	else
		y = y + U.Text(y, "|cff888888" .. L["Plantilla: sin cambios."] .. "|r")
	end
	if state.uiScale then
		y = y + U.Text(y, L["Escala de la interfaz: %.2f"]:format(state.uiScale))
	end
	y = y + 10
	y = y + U.Text(y, L["La interfaz se recargará. Puedes volver a este asistente con /rz asistente o desde el gestor (/rz)."], GameFontHighlightSmall)
	return y
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

local function createWindow()
	local U = ui()
	wiz = CreateFrame("Frame", "RheizorWizard", UIParent, "BackdropTemplate")
	wiz:SetSize(W, H)
	wiz:SetPoint("CENTER")
	wiz:SetFrameStrata("DIALOG")
	wiz:SetToplevel(true)
	wiz:SetClampedToScreen(true)
	wiz:SetMovable(true)
	wiz:EnableMouse(true)
	wiz:RegisterForDrag("LeftButton")
	wiz:SetScript("OnDragStart", wiz.StartMoving)
	wiz:SetScript("OnDragStop", wiz.StopMovingOrSizing)
	U.SetBackdrop(wiz, 0.97)
	wiz:Hide()

	local title = wiz:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 16, -12)
	title:SetText("|cff33ccffRheizor|r · " .. L["Asistente de instalación"])

	local close = CreateFrame("Button", nil, wiz, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() wiz:Hide() end)
	-- Cerrarlo (con la X o Esc) = no volver a preguntar; se abre con /rz asistente
	table.insert(UISpecialFrames, "RheizorWizard")
	wiz:SetScript("OnHide", function()
		R.store.setup.done = true
		ui().ClosePopup()
	end)

	-- Pasos arriba
	wiz.pills = {}
	for i, name in ipairs(STEPS) do
		local p = wiz:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		if i == 1 then p:SetPoint("TOPLEFT", 16, -40) else p:SetPoint("LEFT", wiz.pills[i - 1], "RIGHT", 14, 0) end
		p.label = i .. ". " .. L[name]
		wiz.pills[i] = p
	end

	local line = wiz:CreateTexture(nil, "ARTWORK")
	line:SetColorTexture(1, 1, 1, 0.12)
	line:SetHeight(1)
	line:SetPoint("TOPLEFT", 12, -58)
	line:SetPoint("TOPRIGHT", -12, -58)

	wiz.body = U.MakeScroll(wiz)
	wiz.body:SetPoint("TOPLEFT", 18, -68)
	wiz.body:SetPoint("BOTTOMRIGHT", -14, 50)
	wiz.body.child:SetWidth(CANVAS_W + 10)

	local function footer(text, width)
		local b = CreateFrame("Button", nil, wiz, "UIPanelButtonTemplate")
		b:SetSize(width, 26)
		b:SetText(text)
		return b
	end
	wiz.back = footer(L["Atrás"], 110)
	wiz.back:SetPoint("BOTTOMLEFT", 14, 14)
	wiz.back:SetScript("OnClick", function() wiz:Go(wiz.step - 1) end)
	wiz.next = footer(L["Siguiente"], 160)
	wiz.next:SetPoint("BOTTOMRIGHT", -14, 14)
	wiz.next:SetScript("OnClick", function()
		if wiz.step < #STEPS then wiz:Go(wiz.step + 1) else R:FinishWizard() end
	end)

	function wiz:Go(step)
		self.step = math.max(1, math.min(#STEPS, step))
		self:Render()
		self.body:ScrollTo(0)
	end

	function wiz:Render()
		local U2 = ui()
		U2.ClosePopup()
		U2.Release("wizard")
		if self.cards then
			for _, c in ipairs(self.cards) do c:Hide() end
		end
		U2.Use({ pool = "wizard", canvas = self.body.child, width = CANVAS_W })
		local y = render[self.step](0)
		self.body.child:SetHeight(math.max(1, y + 16))
		self.body:ScrollTo(self.body:GetVerticalScroll())

		for i, p in ipairs(self.pills) do
			if i == self.step then p:SetText("|cff33ccff" .. p.label .. "|r")
			elseif i < self.step then p:SetText("|cffaaaaaa" .. p.label .. "|r")
			else p:SetText("|cff666666" .. p.label .. "|r") end
		end
		self.back:SetShown(self.step > 1)
		self.next:SetShown(self.step > 1)
		self.next:SetText(self.step == #STEPS and L["Terminar y recargar"] or L["Siguiente"])
	end
end

function R:OpenWizard()
	if not self.SETUP_ENABLED then return end   -- apagado (Core.lua)
	if not self.UI then
		self:Print(L["El asistente necesita el gestor de Rheizor (Manager.lua)."])
		return
	end
	if InCombatLockdown() then
		self:Print(L["El asistente no se puede usar en combate."])
		return
	end
	if not wiz then createWindow() end
	state = {
		addons = {},
		allChars = true,
		layout = (R.db.wizard and R.db.wizard.layout) or R.DEFAULT_LAYOUT,
		layoutPicked = false,
		blizzard = true,
	}
	if not self:GetLayout(state.layout) then state.layout = R.DEFAULT_LAYOUT end
	wiz:Show()
	wiz:Go(1)
end

function R:FinishWizard()
	if not self.SETUP_ENABLED then return end
	if InCombatLockdown() then
		self:Print(L["El asistente no se puede usar en combate."])
		return
	end
	local U = self.UI
	-- Por si el resultado no gusta: se puede volver atrás desde el historial
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes del asistente"], true) end
	-- Addons
	local who = not state.allChars and self.CharacterID() or nil
	local A = C_AddOns or {}
	local enable, disable = A.EnableAddOn or EnableAddOn, A.DisableAddOn or DisableAddOn
	-- Los de Rheizor se activan o desactivan en Rheizor (en el perfil de este
	-- personaje, o en todos los perfiles) y siguen cargados en WoW para poder
	-- configurarlos; los que no usan el núcleo, en WoW
	for _, a in ipairs(addonList()) do
		local want = wanted(a)
		if U.HasSwitch(a) then
			if state.allChars then
				for _, profile in pairs(self.store.profiles) do
					if type(profile) == "table" then self:SetAddonActive(a.name, want, profile) end
				end
			else
				self:SetAddonActive(a.name, want)
			end
			if want and (not U.IsEnabled(a.name) or state.allChars) then enable(a.name, who) end
		elseif want ~= U.IsEnabled(a.name) or state.allChars then
			if want then enable(a.name, who) else disable(a.name, who) end
		end
	end
	-- Plantilla (en una instalación nueva ya está puesta; falta la parte de Blizzard)
	local layout = (state.layoutPicked or self.freshInstall) and state.layout
	if layout then
		self:ApplyLayoutToDB(layout, self.db)
		if state.blizzard then self:ApplyBlizzardLayout(layout) end
	end
	if state.uiScale and C_CVar.GetCVar("uiScale") then
		C_CVar.SetCVar("useUiScale", "1")
		C_CVar.SetCVar("uiScale", tostring(state.uiScale))
	end
	self.store.setup.done = true
	if not layout or self:GetLayout(layout).untouched then
		ReloadUI()
		return
	end
	-- Se espera a que el Modo edición coloque las barras para medir dónde
	-- han quedado y poner lo de Rheizor justo encima
	if wiz then wiz:Hide() end
	self:Print(L["Colocando la plantilla..."])
	C_Timer.After(1.5, function()
		self:FitLayoutToBars(layout, self.db)
		ReloadUI()
	end)
end

function WZ:OnEnable()
	R:AfterCleanStart()
	if not R.SETUP_ENABLED then return end
	-- Instalación nueva, o se ha empezado de nuevo en este personaje
	if R.store.setup.done and not R.freshInstall then return end
	-- Un momento después de entrar, para no taparlo con las pantallas de carga
	C_Timer.After(3, function()
		if not InCombatLockdown() and not (wiz and wiz:IsShown()) then R:OpenWizard() end
	end)
end
