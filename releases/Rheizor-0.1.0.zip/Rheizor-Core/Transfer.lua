-- Exportar e importar la configuración de Rheizor como un texto que se puede
-- copiar y pegar (en otro personaje, otra cuenta o para pasárselo a alguien).
-- Incluye la configuración de los módulos (RheizorDB) y los valores de las
-- CVars que manejan sus opciones (/console). Al importar solo se aceptan CVars
-- que aparezcan en las opciones de algún módulo cargado.

local R = Rheizor:Namespace(...)
local L = R.L

local WHITE = "Interface\\Buttons\\WHITE8X8"
local FORMAT = 1

----------------------------------------------------------------------
-- Serializar: formato propio y sencillo (nunca se ejecuta el texto importado)
--   T ... E  tabla (pares clave, valor)   S<len>:<bytes>  texto
--   N<num>;  número                       B1 / B0         verdadero / falso
----------------------------------------------------------------------

local function serialize(value, out, depth)
	local t = type(value)
	if t == "string" then
		out[#out + 1] = "S" .. #value .. ":" .. value
	elseif t == "number" then
		if value ~= value or value == math.huge or value == -math.huge then return false end
		out[#out + 1] = "N" .. string.format("%.17g", value) .. ";"
	elseif t == "boolean" then
		out[#out + 1] = value and "B1" or "B0"
	elseif t == "table" then
		if depth > 30 then return false end
		out[#out + 1] = "T"
		for k, v in pairs(value) do
			local kt = type(k)
			if kt == "string" or kt == "number" or kt == "boolean" then
				-- Si el valor no se puede guardar (función, etc.) se quita el par entero
				local mark = #out
				if not (serialize(k, out, depth + 1) and serialize(v, out, depth + 1)) then
					for i = #out, mark + 1, -1 do out[i] = nil end
				end
			end
		end
		out[#out + 1] = "E"
	else
		return false
	end
	return true
end

local function deserialize(s)
	local pos, len = 1, #s
	local read

	read = function(depth)
		if depth > 32 or pos > len then return nil, false end
		local c = s:sub(pos, pos)
		if c == "S" then
			local colon = s:find(":", pos + 1, true)
			local n = colon and tonumber(s:sub(pos + 1, colon - 1))
			if not n or colon + n > len then return nil, false end
			local v = s:sub(colon + 1, colon + n)
			pos = colon + n + 1
			return v, true
		elseif c == "N" then
			local semi = s:find(";", pos + 1, true)
			local v = semi and tonumber(s:sub(pos + 1, semi - 1))
			if not v then return nil, false end
			pos = semi + 1
			return v, true
		elseif c == "B" then
			local b = s:sub(pos + 1, pos + 1)
			if b ~= "1" and b ~= "0" then return nil, false end
			pos = pos + 2
			return b == "1", true
		elseif c == "T" then
			pos = pos + 1
			local tbl = {}
			while true do
				if pos > len then return nil, false end
				if s:sub(pos, pos) == "E" then
					pos = pos + 1
					return tbl, true
				end
				local k, ok = read(depth + 1)
				if not ok or k == nil then return nil, false end
				local v, ok2 = read(depth + 1)
				if not ok2 then return nil, false end
				tbl[k] = v
			end
		end
		return nil, false
	end

	local value, ok = read(0)
	if not ok or pos ~= len + 1 then return nil end
	return value
end

----------------------------------------------------------------------
-- Base64 (propio, para no depender de qué funciones traiga el cliente)
----------------------------------------------------------------------

local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
local B64CHAR, B64VAL = {}, {}
for i = 1, 64 do
	local ch = B64:sub(i, i)
	B64CHAR[i - 1] = ch
	B64VAL[ch:byte()] = i - 1
end

local floor = math.floor

local function encode64(s)
	local out = {}
	for i = 1, #s, 3 do
		local a, b, c = s:byte(i, i + 2)
		local n = a * 65536 + (b or 0) * 256 + (c or 0)
		out[#out + 1] = B64CHAR[floor(n / 262144) % 64] .. B64CHAR[floor(n / 4096) % 64]
			.. (b and B64CHAR[floor(n / 64) % 64] or "=")
			.. (c and B64CHAR[n % 64] or "=")
	end
	return table.concat(out)
end

local function decode64(s)
	-- Se ignoran espacios y saltos de línea que se cuelen al copiar
	local vals = {}
	for i = 1, #s do
		local v = B64VAL[s:byte(i)]
		if v then vals[#vals + 1] = v end
	end
	local out = {}
	for i = 1, #vals, 4 do
		local a, b, c, d = vals[i], vals[i + 1], vals[i + 2], vals[i + 3]
		if not b then break end
		local n = a * 262144 + b * 4096 + (c or 0) * 64 + (d or 0)
		out[#out + 1] = string.char(floor(n / 65536) % 256)
		if c then out[#out + 1] = string.char(floor(n / 256) % 256) end
		if d then out[#out + 1] = string.char(n % 256) end
	end
	return table.concat(out)
end

-- Comprimir si el cliente trae C_EncodingUtil (el texto queda mucho más corto)
local E = C_EncodingUtil
local function compress(s)
	if E and E.CompressString then
		local ok, packed = pcall(E.CompressString, s)
		if ok and type(packed) == "string" and packed ~= "" then return packed end
	end
end

local function decompress(s)
	if E and E.DecompressString then
		local ok, raw = pcall(E.DecompressString, s)
		if ok and type(raw) == "string" then return raw end
	end
end

-- Para otros addons de Rheizor (notas compartidas): mismo formato, que
-- nunca ejecuta lo que llega
function R.Serialize(value)
	local out = {}
	if serialize(value, out, 0) then return table.concat(out) end
end
R.Deserialize = deserialize
R.Encode64, R.Decode64 = encode64, decode64
R.Compress, R.Decompress = compress, decompress

-- Prefijos: !RZ1! sin comprimir, !RZ2! comprimido
local function encodeConfig(data)
	local out = {}
	if not serialize(data, out, 0) then return nil end
	local raw = table.concat(out)
	local packed = compress(raw)
	if packed then return "!RZ2!" .. encode64(packed) end
	return "!RZ1!" .. encode64(raw)
end

local function decodeConfig(text)
	text = (text or ""):gsub("%s", "")
	local kind, body = text:match("^!RZ(%d)!(.+)$")
	if not kind then return nil, L["No es un texto de Rheizor."] end
	local raw = decode64(body)
	if kind == "2" then
		raw = decompress(raw)
		if not raw then return nil, L["Este cliente no puede descomprimir el texto."] end
	elseif kind ~= "1" then
		return nil, L["Texto de una versión más nueva de Rheizor."]
	end
	local data = deserialize(raw)
	if type(data) ~= "table" or type(data.db) ~= "table" then
		return nil, L["El texto está incompleto o dañado. Cópialo entero otra vez."]
	end
	if (tonumber(data.v) or 0) > FORMAT then
		return nil, L["Texto de una versión más nueva de Rheizor."]
	end
	return data
end

----------------------------------------------------------------------
-- Qué se exporta
----------------------------------------------------------------------

-- CVars que manejan las opciones de los módulos cargados (del addon indicado o de todos)
local function moduleCVars(addon)
	local list = {}
	for _, mod in ipairs(R.order) do
		if not addon or mod.addon == addon then
			for _, opt in ipairs(mod.options or {}) do
				-- Con get propio solo si es una CVar de verdad (exportCVar)
				if opt.cvar and (not opt.get or opt.exportCVar) then list[opt.cvar] = true end
			end
		end
	end
	return list
end

local deepCopy = R.DeepCopy

-- Devuelve el texto para copiar. addon = nil exporta todo
function R:ExportConfig(addon)
	local data = { v = FORMAT, db = {}, cvars = {}, addon = addon, date = date("%Y-%m-%d") }
	if addon then
		for _, mod in ipairs(self.order) do
			if mod.addon == addon and type(self.db[mod.key]) == "table" then
				data.db[mod.key] = self.db[mod.key]
			end
		end
	else
		-- También lo guardado de módulos que ahora no están instalados
		for key, value in pairs(self.db) do
			if type(value) == "table" then data.db[key] = value end
		end
	end
	for cvar in pairs(moduleCVars(addon)) do
		local value = C_CVar.GetCVar(cvar)
		if value ~= nil then data.cvars[cvar] = value end
	end
	return encodeConfig(data)
end

local function sectionTitle(key)
	if key == "__addons" then return L["Addons activados"] end
	local mod = R.modules[key]
	if mod then return mod.title or key end
	return key .. L[" |cff888888(no instalado)|r"]
end

-- Lo que se va a cambiar al importar, para enseñarlo antes
local function describe(data)
	local names, nCVars, allowed = {}, 0, moduleCVars()
	for key, value in pairs(data.db) do
		if type(key) == "string" and type(value) == "table" then names[#names + 1] = sectionTitle(key) end
	end
	table.sort(names)
	for cvar, value in pairs(data.cvars or {}) do
		if allowed[cvar] and type(value) == "string" then nCVars = nCVars + 1 end
	end
	return names, nCVars
end

-- Foto del perfil actual (módulos + CVars de sus opciones) para el historial
function R:CaptureConfig()
	local cvars = {}
	for cvar in pairs(moduleCVars()) do
		local value = C_CVar.GetCVar(cvar)
		if value ~= nil then cvars[cvar] = value end
	end
	return { db = deepCopy(self.db), cvars = cvars }
end

-- Deja el perfil actual exactamente como en la foto (sin recargar)
function R:RestoreConfig(data)
	wipe(self.db)
	for key, value in pairs(data.db or {}) do self.db[key] = deepCopy(value) end
	local allowed = moduleCVars()
	for cvar, value in pairs(data.cvars or {}) do
		if allowed[cvar] and type(value) == "string" then pcall(C_CVar.SetCVar, cvar, value) end
	end
end

-- Sustituye la configuración de cada módulo incluido y recarga
function R:ApplyImport(data)
	if InCombatLockdown() then
		self:Print(L["No se puede importar en combate."])
		return
	end
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes de importar"], true) end
	for key, value in pairs(data.db) do
		if type(key) == "string" and type(value) == "table" then
			self.db[key] = deepCopy(value)
		end
	end
	local allowed = moduleCVars()
	for cvar, value in pairs(data.cvars or {}) do
		if allowed[cvar] and type(value) == "string" then
			pcall(C_CVar.SetCVar, cvar, value)
		end
	end
	ReloadUI()
end

-- Borra la configuración de los módulos de un addon (vuelven a sus valores por defecto)
function R:ResetAddonConfig(addon)
	if InCombatLockdown() then return end
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes de restablecer un addon"], true) end
	for _, mod in ipairs(self.order) do
		if mod.addon == addon then self.db[mod.key] = nil end
	end
	ReloadUI()
end

----------------------------------------------------------------------
-- Ventana para copiar o pegar el texto
----------------------------------------------------------------------

local dlg

local function button(parent, text, width, onClick)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width, 24)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	return b
end

local function createDialog()
	dlg = CreateFrame("Frame", "RheizorTransfer", UIParent, "BackdropTemplate")
	dlg:SetSize(560, 400)
	dlg:SetPoint("CENTER")
	dlg:SetFrameStrata("FULLSCREEN_DIALOG")
	dlg:SetToplevel(true)
	dlg:SetClampedToScreen(true)
	dlg:SetMovable(true)
	dlg:EnableMouse(true)
	dlg:RegisterForDrag("LeftButton")
	dlg:SetScript("OnDragStart", dlg.StartMoving)
	dlg:SetScript("OnDragStop", dlg.StopMovingOrSizing)
	dlg:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	dlg:SetBackdropColor(0.05, 0.05, 0.07, 0.97)
	dlg:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	dlg:Hide()
	table.insert(UISpecialFrames, "RheizorTransfer")

	dlg.title = dlg:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	dlg.title:SetPoint("TOPLEFT", 14, -10)
	dlg.hint = dlg:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	dlg.hint:SetPoint("TOPLEFT", 14, -32)
	dlg.hint:SetPoint("RIGHT", -14, 0)
	dlg.hint:SetJustifyH("LEFT")

	local close = CreateFrame("Button", nil, dlg, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)

	-- Caja de texto con desplazamiento
	local box = CreateFrame("Frame", nil, dlg, "BackdropTemplate")
	box:SetPoint("TOPLEFT", 12, -52)
	box:SetPoint("BOTTOMRIGHT", -12, 44)
	box:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	box:SetBackdropColor(0, 0, 0, 0.6)
	box:SetBackdropBorderColor(1, 1, 1, 0.15)

	local sf = CreateFrame("ScrollFrame", nil, box)
	sf:SetPoint("TOPLEFT", 6, -6)
	sf:SetPoint("BOTTOMRIGHT", -6, 6)
	local eb = CreateFrame("EditBox", nil, sf)
	eb:SetMultiLine(true)
	eb:SetAutoFocus(false)
	eb:SetMaxLetters(0)
	eb:SetFontObject(ChatFontSmall or GameFontHighlightSmall)
	eb:SetWidth(520)
	eb:SetScript("OnEscapePressed", function() dlg:Hide() end)
	eb:SetScript("OnCursorChanged", function(self, _, y, _, h)
		-- Mantener visible la línea del cursor
		local top = sf:GetVerticalScroll()
		y = -y
		if y < top then sf:SetVerticalScroll(y)
		elseif y + h > top + sf:GetHeight() then sf:SetVerticalScroll(y + h - sf:GetHeight()) end
	end)
	eb:SetScript("OnTextChanged", function(self, user)
		if dlg.mode == "export" and user then
			-- En modo exportar el texto no se puede cambiar
			self:SetText(dlg.text or "")
			self:HighlightText()
		elseif dlg.mode == "import" and user then
			dlg.parsed = nil
			dlg.action:SetText(L["Comprobar"])
			dlg.hint:SetText(L["Pega el texto (Ctrl+V) y pulsa Comprobar."])
		end
	end)
	sf:SetScrollChild(eb)
	sf:EnableMouseWheel(true)
	sf:SetScript("OnMouseWheel", function(self, delta)
		local v = self:GetVerticalScroll() - delta * 40
		self:SetVerticalScroll(math.max(0, math.min(self:GetVerticalScrollRange(), v)))
	end)
	box:EnableMouse(true)
	box:SetScript("OnMouseDown", function() eb:SetFocus() end)
	dlg.edit = eb

	dlg.action = button(dlg, "", 170, function() dlg:OnAction() end)
	dlg.action:SetPoint("BOTTOMRIGHT", -12, 12)
	local cancel = button(dlg, L["Cerrar"], 100, function() dlg:Hide() end)
	cancel:SetPoint("RIGHT", dlg.action, "LEFT", -6, 0)

	function dlg:OnAction()
		if self.mode == "export" then
			self.edit:SetFocus()
			self.edit:HighlightText()
			return
		end
		if self.parsed then
			R:ApplyImport(self.parsed)
			return
		end
		local data, err = decodeConfig(self.edit:GetText())
		if not data then
			self.hint:SetText("|cffff5555" .. err .. "|r")
			return
		end
		local names, nCVars = describe(data)
		if #names == 0 and nCVars == 0 then
			self.hint:SetText("|cffff5555" .. L["El texto no contiene ninguna configuración."] .. "|r")
			return
		end
		self.parsed = data
		local summary = table.concat(names, ", ")
		if nCVars > 0 then
			summary = summary .. (summary ~= "" and " · " or "") .. L["%d opciones de /console"]:format(nCVars)
		end
		self.hint:SetText("|cff33ff33" .. L["Se sustituirá:"] .. "|r " .. summary)
		self.action:SetText(L["Importar y recargar"])
	end
end

-- Enseña un texto para copiarlo (por ejemplo, el diagnóstico)
function R:ShowText(title, text)
	if not dlg then createDialog() end
	dlg.mode, dlg.parsed, dlg.text = "export", nil, text
	dlg.title:SetText(title)
	dlg.hint:SetText(L["Copia el texto con Ctrl+C."])
	dlg.action:SetText(L["Seleccionar todo"])
	dlg:Show()
	dlg.edit:SetText(text)
	dlg.edit:SetFocus()
	dlg.edit:HighlightText()
	dlg.edit:GetParent():SetVerticalScroll(0)
end

-- mode = "export" (addon opcional) o "import"
function R:ShowTransfer(mode, addon)
	if not dlg then createDialog() end
	dlg.mode, dlg.parsed = mode, nil
	local eb = dlg.edit
	if mode == "export" then
		local text = self:ExportConfig(addon)
		if not text then
			self:Print(L["No se ha podido exportar la configuración."])
			return
		end
		dlg.text = text
		dlg.title:SetText(addon and L["Exportar: %s"]:format(addon) or L["Exportar toda la configuración"])
		dlg.hint:SetText(L["Copia el texto con Ctrl+C y guárdalo o pásalo. Se importa desde /rz."])
		dlg.action:SetText(L["Seleccionar todo"])
		dlg:Show()
		eb:SetText(text)
		eb:SetFocus()
		eb:HighlightText()
	else
		dlg.text = nil
		dlg.title:SetText(L["Importar configuración"])
		dlg.hint:SetText(L["Pega el texto (Ctrl+V) y pulsa Comprobar."])
		dlg.action:SetText(L["Comprobar"])
		dlg:Show()
		eb:SetText("")
		eb:SetFocus()
	end
	dlg.edit:GetParent():SetVerticalScroll(0)
end
