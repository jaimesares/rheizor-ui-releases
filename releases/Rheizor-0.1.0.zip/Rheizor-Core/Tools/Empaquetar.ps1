﻿# Crea un .zip con Rheizor-Core y los addons de Rheizor que elijas, listo para
# pasárselo a alguien: se descomprime tal cual dentro de Interface\AddOns.
# Se abre con "Empaquetar Rheizor.bat" (doble clic). No cambia nada del juego.

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$core = Split-Path -Parent $PSScriptRoot          # ...\AddOns\Rheizor-Core
$addons = Split-Path -Parent $core                # ...\AddOns
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Toc($dir) {
    $name = Split-Path -Leaf $dir
    $toc = Join-Path $dir "$name.toc"
    if (-not (Test-Path -LiteralPath $toc)) { return $null }
    $info = @{ Name = $name; Title = $name; Notes = ""; Version = ""; Deps = @() }
    foreach ($line in [IO.File]::ReadAllLines($toc, $utf8)) {
        if ($line -match '^##\s*Title-esES:\s*(.+)$') { $info.Title = $Matches[1] }
        elseif ($line -match '^##\s*Notes-esES:\s*(.+)$') { $info.Notes = $Matches[1] }
        elseif ($line -match '^##\s*Version:\s*(.+)$') { $info.Version = $Matches[1].Trim() }
        elseif ($line -match '^##\s*(Dependencies|RequiredDeps):\s*(.+)$') {
            $info.Deps = @($Matches[2].Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
        }
    }
    # Quitar los códigos de color del título
    $info.Title = ($info.Title -replace '\|c[0-9a-fA-F]{8}', '') -replace '\|r', ''
    return $info
}

$list = @()
foreach ($d in Get-ChildItem -LiteralPath $addons -Directory | Where-Object { $_.Name -like 'Rheizor-*' }) {
    $info = Read-Toc $d.FullName
    if ($info -and $info.Name -ne 'Rheizor-Core') { $list += $info }
}
$list = @($list | Sort-Object { $_.Title })
$coreInfo = Read-Toc $core

# ---------------------------------------------------------------- ventana
$form = New-Object System.Windows.Forms.Form
$form.Text = "Empaquetar Rheizor"
$form.Size = New-Object System.Drawing.Size(520, 560)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font("Segoe UI", 9)

$label = New-Object System.Windows.Forms.Label
$label.Text = "Rheizor-Core $($coreInfo.Version) va siempre incluido. Marca los addons que quieres añadir:"
$label.Location = New-Object System.Drawing.Point(12, 12)
$label.Size = New-Object System.Drawing.Size(480, 34)
$form.Controls.Add($label)

$box = New-Object System.Windows.Forms.CheckedListBox
$box.Location = New-Object System.Drawing.Point(12, 50)
$box.Size = New-Object System.Drawing.Size(480, 330)
$box.CheckOnClick = $true
foreach ($a in $list) { [void]$box.Items.Add("$($a.Title)   ($($a.Name))", $true) }
$form.Controls.Add($box)

$notes = New-Object System.Windows.Forms.Label
$notes.Location = New-Object System.Drawing.Point(12, 385)
$notes.Size = New-Object System.Drawing.Size(480, 36)
$notes.ForeColor = [System.Drawing.Color]::DimGray
$form.Controls.Add($notes)
$box.Add_SelectedIndexChanged({ if ($box.SelectedIndex -ge 0) { $notes.Text = $list[$box.SelectedIndex].Notes } })

function New-Button($text, $x, $width) {
    $b = New-Object System.Windows.Forms.Button
    $b.Text = $text
    $b.Location = New-Object System.Drawing.Point($x, 430)
    $b.Size = New-Object System.Drawing.Size($width, 28)
    $form.Controls.Add($b)
    return $b
}
$all = New-Button "Todos" 12 80
$none = New-Button "Ninguno" 98 80
$make = New-Button "Crear zip..." 352 140
$all.Add_Click({ for ($i = 0; $i -lt $box.Items.Count; $i++) { $box.SetItemChecked($i, $true) } })
$none.Add_Click({ for ($i = 0; $i -lt $box.Items.Count; $i++) { $box.SetItemChecked($i, $false) } })

$status = New-Object System.Windows.Forms.Label
$status.Location = New-Object System.Drawing.Point(12, 468)
$status.Size = New-Object System.Drawing.Size(480, 40)
$form.Controls.Add($status)

$make.Add_Click({
    # Addons elegidos y lo que necesiten (si un addon depende de otro de Rheizor, va también)
    $names = New-Object System.Collections.Generic.List[string]
    $names.Add('Rheizor-Core')
    for ($i = 0; $i -lt $box.Items.Count; $i++) {
        if ($box.GetItemChecked($i)) { $names.Add($list[$i].Name) }
    }
    $added = @()
    $i = 0
    while ($i -lt $names.Count) {
        $info = Read-Toc (Join-Path $addons $names[$i])
        foreach ($dep in $info.Deps) {
            if ($dep -like 'Rheizor-*' -and -not $names.Contains($dep) -and (Test-Path -LiteralPath (Join-Path $addons $dep))) {
                $names.Add($dep); $added += $dep
            }
        }
        $i++
    }

    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Filter = "Archivo zip (*.zip)|*.zip"
    $save.InitialDirectory = Join-Path $env:USERPROFILE "Downloads"
    $save.FileName = "Rheizor-$($coreInfo.Version)-$(Get-Date -Format 'yyyy-MM-dd').zip"
    if ($save.ShowDialog() -ne "OK") { return }
    $target = $save.FileName

    try {
        if (Test-Path -LiteralPath $target) { [IO.File]::Delete($target) }
        $zip = [IO.Compression.ZipFile]::Open($target, [IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($n in $names) {
                $root = Join-Path $addons $n
                foreach ($f in Get-ChildItem -LiteralPath $root -Recurse -File) {
                    $rel = $n + '/' + $f.FullName.Substring($root.Length + 1).Replace('\', '/')
                    [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $f.FullName, $rel, [IO.Compression.CompressionLevel]::Optimal)
                }
            }
        } finally { $zip.Dispose() }
        $msg = "Creado con $($names.Count) addons: " + [IO.Path]::GetFileName($target)
        if ($added.Count -gt 0) { $msg += "  (añadidos por dependencia: " + ($added -join ', ') + ")" }
        $status.ForeColor = [System.Drawing.Color]::DarkGreen
        $status.Text = $msg
        Start-Process explorer.exe "/select,`"$target`""
    } catch {
        $status.ForeColor = [System.Drawing.Color]::DarkRed
        $status.Text = "No se ha podido crear: " + $_.Exception.Message
    }
})

[void]$form.ShowDialog()
