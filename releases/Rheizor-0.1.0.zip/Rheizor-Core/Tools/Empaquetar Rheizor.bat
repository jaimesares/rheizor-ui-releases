@echo off
rem Abre la ventana para crear un zip con Rheizor-Core y los addons que elijas
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -STA -File "%~dp0Empaquetar.ps1"
