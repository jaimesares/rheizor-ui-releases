-- Panel de opciones en Opciones > AddOns > Rheizor, generado a partir de
-- la tabla "options" de cada módulo.
--
-- Tipos de opción:
--   header   { text }
--   button   { name, text, func(mod), desc }
--   toggle   { key | cvar, name, desc, invert, reload }
--   slider   { key | cvar, name, min, max, step, format, desc }
--   dropdown { key | cvar, name, values = { {valor, "Texto"}, ... }, desc }
--   color    { key, name, desc }  valor "rrggbb"; solo en el gestor (/rz)
--   text     { key, name, desc, maxLetters }  texto libre; solo en el gestor (/rz)
-- Con "key" el valor se guarda en RheizorDB; con "cvar" se lee y escribe
-- directamente la variable de consola del juego (lo mismo que /console).
-- También se puede dar get/set/default propios en lugar de cvar.
-- optional = true: si la CVar no existe en este cliente, la opción no sale.
-- available = función: si devuelve falso, la opción no sale.
-- disabled = función: si devuelve un texto (el motivo), la opción sale
--   atenuada y no se puede cambiar.
-- refresh = true: al cambiarla se redibuja la página del gestor (para
--   opciones de las que dependen otras).
--   note     { text, available }  aviso en naranja; solo en el gestor (/rz)

local _, R = ...

local function onChange(setting, callback)
	if setting.SetValueChangedCallback then
		setting:SetValueChangedCallback(callback)
	else
		Settings.SetOnValueChangedCallback(setting:GetVariable(), callback)
	end
end

local varTypes = {
	toggle = "Boolean",
	slider = "Number",
}

----------------------------------------------------------------------
-- Conversión entre valores del panel y CVars (siempre texto)
----------------------------------------------------------------------

local function fromCVar(opt, str)
	if opt.type == "toggle" then
		local on = str ~= nil and str ~= "0"
		if opt.invert then on = not on end
		return on
	elseif opt.type == "slider" then
		return tonumber(str) or opt.min
	end
	return str
end

local function toCVar(opt, value)
	if opt.type == "toggle" then
		if opt.invert then value = not value end
		return value and "1" or "0"
	elseif opt.type == "slider" then
		value = math.floor(value / opt.step + 0.5) * opt.step
		return string.format("%g", value)
	end
	return value
end

-- Devuelve getter, setter y valor por defecto, o nil si la CVar no existe
local function cvarAccessors(opt)
	if opt.get then
		return opt.get, opt.set, opt.default
	end
	local cvar = opt.cvar
	if C_CVar.GetCVar(cvar) == nil then return end
	local getter = function() return fromCVar(opt, C_CVar.GetCVar(cvar)) end
	local setter = function(value) R:SetCVar(cvar, toCVar(opt, value)) end
	local default = C_CVar.GetCVarDefault and C_CVar.GetCVarDefault(cvar)
	return getter, setter, fromCVar(opt, default or C_CVar.GetCVar(cvar))
end
R.OptionAccessors = cvarAccessors   -- también lo usa el gestor (Manager.lua)

----------------------------------------------------------------------
-- Controles
----------------------------------------------------------------------

-- disabled = función que devuelve el motivo: la opción sale gris y no se toca
local function disableWhen(initializer, opt)
	if not (opt.disabled and initializer and initializer.AddModifyPredicate) then return end
	initializer:AddModifyPredicate(function() return not opt.disabled() end)
end

local function createControl(category, setting, opt, tooltip)
	if opt.type == "toggle" then
		local create = Settings.CreateCheckbox or Settings.CreateCheckBox
		return create(category, setting, tooltip)
	elseif opt.type == "slider" then
		local sliderOptions = Settings.CreateSliderOptions(opt.min, opt.max, opt.step)
		sliderOptions:SetLabelFormatter(MinimalSliderWithSteppersMixin.Label.Right, opt.format or R.fmt.percent)
		return Settings.CreateSlider(category, setting, sliderOptions, tooltip)
	elseif opt.type == "dropdown" then
		local create = Settings.CreateDropdown or Settings.CreateDropDown
		local function getOptions()
			local container = Settings.CreateControlTextContainer()
			for _, v in ipairs(opt.values) do container:Add(v[1], v[2]) end
			return container:GetData()
		end
		return create(category, setting, getOptions, tooltip)
	end
end

local function addOption(mod, category, layout, opt)
	-- Los colores, los textos y las notas solo salen en el gestor (/rz)
	if opt.type == "color" or opt.type == "text" or opt.type == "note" then return end
	if opt.available and not opt.available() then return end
	if opt.type == "header" then
		layout:AddInitializer(CreateSettingsListSectionHeaderInitializer(opt.text))
		return
	end

	if opt.type == "button" then
		if CreateSettingsButtonInitializer then
			local init = CreateSettingsButtonInitializer(opt.name, opt.text,
				function() R:RunModuleAction(mod, opt.func) end, opt.desc, true)
			disableWhen(init, opt)
			layout:AddInitializer(init)
		end
		return
	end

	local tooltip = opt.desc
	if opt.reload then
		tooltip = (tooltip and (tooltip .. "\n\n") or "") .. R.L["|cffff8800Para volver a mostrarlo hace falta /reload.|r"]
	end
	local varType = Settings.VarType[varTypes[opt.type] or "String"]
	local setting

	if opt.cvar or opt.get then
		if not Settings.RegisterProxySetting then return end
		local getter, setter, default = cvarAccessors(opt)
		local label = mod.title .. ": " .. (opt.cvar or opt.name)
		if not getter then
			if opt.optional then return end
			R.missing[label] = "CVar " .. opt.cvar
			return
		end
		-- Con el módulo: la misma CVar puede salir en dos páginas (chatStyle en
		-- Chat y en Consola) y Blizzard no deja registrar dos veces un nombre
		local variable = "Rheizor_cvar_" .. mod.key .. "_" .. (opt.id or opt.cvar)
		if opt.cvar and tooltip then
			tooltip = tooltip .. "\n\n|cff888888/console " .. opt.cvar .. "|r"
		elseif opt.cvar then
			tooltip = "|cff888888/console " .. opt.cvar .. "|r"
		end
		setting = Settings.RegisterProxySetting(category, variable, varType, opt.name, default, getter, setter)
	else
		local variable = "Rheizor_" .. mod.key .. "_" .. opt.key
		setting = Settings.RegisterAddOnSetting(category, variable, opt.key, mod.db, varType, opt.name, mod.defaults[opt.key])
		onChange(setting, function() R:OptionChanged(mod, opt.key) end)
	end

	disableWhen(createControl(category, setting, opt, tooltip), opt)
end

----------------------------------------------------------------------

function R:BuildOptions()
	if not (Settings and Settings.RegisterVerticalLayoutCategory and Settings.RegisterAddOnSetting) then
		return
	end

	local main, mainLayout = Settings.RegisterVerticalLayoutCategory("Rheizor")
	self.category = main

	mainLayout:AddInitializer(CreateSettingsListSectionHeaderInitializer("Rheizor"))
	if CreateSettingsButtonInitializer then
		mainLayout:AddInitializer(CreateSettingsButtonInitializer(R.L["Gestor de Rheizor"], R.L["Abrir"],
			function() if SettingsPanel then HideUIPanel(SettingsPanel) end R:OpenManager() end,
			R.L["Ventana propia con todos los addons de Rheizor instalados y sus opciones. También con /rz."], true))
		mainLayout:AddInitializer(CreateSettingsButtonInitializer(R.L["Recargar interfaz"], "/reload", ReloadUI,
			R.L["Necesario para volver a mostrar elementos que hayas ocultado."], true))
	end

	-- Los módulos con "group" comparten una misma sección; el resto tiene la suya
	local groups = {}
	for _, mod in ipairs(self.order) do
		-- Sin opciones (secciones que solo existen en el gestor, como Perfiles) no hay página
		if mod.options and #mod.options > 0 then
			local sub, layout
			if mod.group then
				local g = groups[mod.group]
				if not g then
					g = { Settings.RegisterVerticalLayoutSubcategory(main, mod.group) }
					groups[mod.group] = g
				end
				sub, layout = g[1], g[2]
				layout:AddInitializer(CreateSettingsListSectionHeaderInitializer("|cff33ccff" .. mod.title:upper() .. "|r"))
			else
				sub, layout = Settings.RegisterVerticalLayoutSubcategory(main, mod.title)
			end
			for _, opt in ipairs(mod.options) do
				local ok, err = pcall(addOption, mod, sub, layout, opt)
				if not ok then
					R.missing[mod.title .. ": " .. (opt.cvar or opt.key or opt.name or "?")] = tostring(err)
				end
			end
		end
	end

	Settings.RegisterAddOnCategory(main)
end

function R:OpenOptions()
	if self.category and Settings and Settings.OpenToCategory then
		Settings.OpenToCategory(self.category:GetID())
	else
		self:Print(R.L["El panel de opciones no está disponible en esta versión. Escribe /rz help."])
	end
end
