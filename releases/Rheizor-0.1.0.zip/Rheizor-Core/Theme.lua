-- Tema de la interfaz: Clásico (el arte de Blizzard) u Oscuro (fondos lisos
-- oscuros y bordes finos). Lo siguen las ventanas de Rheizor-Interface y, al
-- cambiarlo, también el estilo de los módulos que tienen uno propio (barras de
-- acción, tooltips, icono del minimapa), que luego se puede cambiar en cada uno.
--
-- Para los módulos:
--   R:GetTheme()            "classic" o "dark"
--   R:ThemeColors()         fondo r, g, b, a y borde r, g, b del tema oscuro
--   R:OnThemeChanged(fn)    fn(tema) al cambiar el tema o sus colores

local R = Rheizor:Namespace(...)
local L = R.L

local THEMES = {
	{ "classic", "Clásico de Blizzard" },
	{ "dark", "Oscuro" },
}

-- Estilo de otros módulos que va con cada tema: { módulo, opción, por tema }
local LINKS = {
	{ "actionbars", "style", classic = "blizzard", dark = "clean" },
	{ "tooltipStyle", "border", classic = "classic", dark = "flat" },
	{ "minimapicon", "style", classic = "classic", dark = "flat" },
	{ "minimapbuttons", "style", classic = "classic", dark = "flat" },
}

local T = R:RegisterModule("theme", {
	title = "Tema",
	defaults = {
		theme = "classic",
		bg = "101014",
		bgAlpha = 0.92,
		border = "2c2c33",
		accentBorder = false,
	},
	options = {
		{ type = "header", text = "Tema de la interfaz" },
		{ type = "dropdown", key = "theme", name = "Tema", values = THEMES,
		  desc = "Clásico: el aspecto de Blizzard. Oscuro: fondos lisos oscuros y bordes finos, como ElvUI.\nAl cambiarlo también se cambia el estilo de las barras de acción, los tooltips y el icono del minimapa; después puedes cambiarlo en cada uno." },
		{ type = "button", name = "Estilo de los demás módulos", text = "Aplicar el tema",
		  desc = "Vuelve a poner en las barras de acción, los tooltips y el icono del minimapa el estilo que va con el tema, por si lo cambiaste en alguno.",
		  func = function(mod) mod:ApplyLinks(true) end },

		{ type = "header", text = "Colores del tema oscuro" },
		{ type = "color", key = "bg", name = "Color del fondo" },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0.3, max = 1, step = 0.05 },
		{ type = "color", key = "border", name = "Color del borde" },
		{ type = "toggle", key = "accentBorder", name = "Borde con el color de Rheizor",
		  desc = "Usa el color de la ventana del gestor (/rz) en lugar del color del borde." },
	},
})

function R:GetTheme()
	local db = T.db
	return (db and db.theme == "dark") and "dark" or "classic"
end

function R:ThemeColors()
	local db = T.db or T.defaults
	local r, g, b = R.HexToRGB(db.bg)
	local er, eg, eb
	if db.accentBorder then
		er, eg, eb = R.HexToRGB(R.db and R.db.manager and R.db.manager.accent or "33ccff")
	else
		er, eg, eb = R.HexToRGB(db.border)
	end
	return r, g, b, db.bgAlpha or 0.92, er, eg, eb
end

local callbacks = {}
function R:OnThemeChanged(fn)
	callbacks[#callbacks + 1] = fn
end

local function notify()
	local theme = R:GetTheme()
	for _, fn in ipairs(callbacks) do
		xpcall(fn, geterrorhandler(), theme)
	end
end

-- Pone en cada módulo enlazado el estilo del tema (solo los que están cargados)
function T:ApplyLinks(verbose)
	local theme = R:GetTheme()
	local changed = {}
	for _, link in ipairs(LINKS) do
		local mod = R.modules[link[1]]
		local value = link[theme]
		if mod and mod.db and value ~= nil and mod.db[link[2]] ~= value then
			mod.db[link[2]] = value
			R:OptionChanged(mod, link[2])
			changed[#changed + 1] = mod.group and (mod.group .. " · " .. mod.title) or mod.title
		end
	end
	if verbose and #changed == 0 then
		R:Print(L["Todos los módulos ya tienen el estilo del tema."])
	elseif #changed > 0 then
		R:Print(L["Estilo del tema aplicado a: %s."]:format(table.concat(changed, ", ")))
	end
	local manager = R.modules.manager
	if manager and manager.Refresh then manager:Refresh() end
end

function T:OnOptionChanged(key)
	if key == "theme" then self:ApplyLinks() end
	notify()
end
