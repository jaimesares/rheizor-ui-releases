-- Diseño de Blizzard en el perfil: lo que coloca el Modo edición del juego
-- (barras de acción, marcos, minimapa, bolsas…) se guarda en el perfil de
-- Rheizor y se pone igual en todos los personajes que lo usan.
--   db.layout = { preset = n }   uno de los de Blizzard (Moderno, Clásico…)
--             = { data = "..." } el texto que da "Copiar al portapapeles"
-- Se guarda al salir del Modo edición y se aplica al entrar. Como va en el
-- perfil, las copias de seguridad, exportar y copiar perfil lo incluyen.

local R = Rheizor:Namespace(...)
local L = R.L

local M = R:RegisterModule("blizzlayout", {
	title = "Diseño de Blizzard",
	group = "Perfiles",
	defaults = {
		sync = true,
	},
	options = {
		{ type = "header", text = "Modo edición de Blizzard" },
		{ type = "toggle", key = "sync", name = "Guardar el diseño de Blizzard en el perfil",
		  desc = "Al salir de Esc > Modo edición, la posición de las barras, marcos y demás elementos de Blizzard se guarda en este perfil. Al entrar con otro personaje que use el mismo perfil, se le pone igual." },
		{ type = "button", name = "Guardar el diseño que tienes puesto", text = "Guardar",
		  func = function(mod) mod:Capture(true) end,
		  desc = "Lo guarda ahora en el perfil, sin pasar por el Modo edición." },
		{ type = "button", name = "Poner el diseño del perfil", text = "Aplicar",
		  func = function(mod) mod:Apply(true) end,
		  desc = "Vuelve a poner el diseño guardado en el perfil, por si lo has cambiado sin querer." },
	},
})

local synced = false     -- ya se ha aplicado al entrar (antes no se guarda nada)

local function available()
	return R:CanLayoutBlizzard() and C_EditMode.ConvertLayoutInfoToString and C_EditMode.ConvertStringToLayoutInfo
		and Enum.EditModeLayoutType and true or false
end

local function numPresets()
	return #EditModePresetLayoutManager:GetCopyOfPresetLayouts()
end

-- Texto de un diseño sin su nombre ni su tipo, para poder compararlos
local function toText(layout)
	local copy = R.DeepCopy(layout)
	copy.layoutName = "Rheizor"
	copy.layoutType = Enum.EditModeLayoutType.Account
	local ok, text = pcall(C_EditMode.ConvertLayoutInfoToString, copy)
	if ok and type(text) == "string" and text ~= "" then return text end
end

-- El diseño que tiene puesto este personaje
local function current()
	local info = C_EditMode.GetLayouts()
	local presets = numPresets()
	local active = info.activeLayout or 1
	if active <= presets then return { preset = active } end
	local layout = info.layouts[active - presets]
	local text = layout and toText(layout)
	if text then return { data = text } end
end

local function same(a, b)
	if not (a and b) then return false end
	if a.preset or b.preset then return a.preset == b.preset end
	return a.data == b.data
end

-- Nombre del diseño que crea Rheizor (si el del perfil no vale, uno fijo)
local function layoutName()
	local name = "Rheizor " .. R:ProfileLabel(R.profile)
	if C_EditMode.IsValidLayoutName and not C_EditMode.IsValidLayoutName(name) then name = "Rheizor" end
	return name
end

-- Guarda en el perfil el diseño puesto. manual = desde el botón (avisa)
function M:Capture(manual)
	if not available() then
		if manual then R:Print(L["Este cliente no deja a los addons leer el Modo edición."]) end
		return
	end
	if not manual and not (self.db.sync and synced) then return end
	local ok, now = pcall(current)
	if not ok or not now then
		if manual then R:Print(L["No se ha podido leer el diseño de Blizzard."]) end
		return
	end
	if not same(self.db.layout, now) then
		self.db.layout = now
		if not manual then R:Print(L["Diseño de Blizzard guardado en el perfil."]) end
	end
	if manual then R:Print(L["Diseño de Blizzard guardado en el perfil."]) end
end

-- Pone el diseño del perfil. Devuelve true si ha cambiado algo
local function apply(want)
	local now = current()
	if same(want, now) then return false end
	if want.preset then
		C_EditMode.SetActiveLayout(math.min(want.preset, numPresets()))
		return true
	end

	local info = C_EditMode.GetLayouts()
	local presets = numPresets()
	-- Si ya hay uno igual (de otro personaje, o el de Rheizor), se usa ese
	for i, layout in ipairs(info.layouts) do
		if toText(layout) == want.data then
			C_EditMode.SetActiveLayout(presets + i)
			return true
		end
	end

	local layout = C_EditMode.ConvertStringToLayoutInfo(want.data)
	if type(layout) ~= "table" then error("layout") end
	local name = layoutName()
	layout.layoutName = name
	layout.layoutType = Enum.EditModeLayoutType.Account
	-- Sustituye al de Rheizor con ese nombre; si no hay, va detrás de los de
	-- cuenta (Blizzard los ordena así: primero cuenta, luego personaje)
	local pos
	for i = #info.layouts, 1, -1 do
		if info.layouts[i].layoutName == name then
			table.remove(info.layouts, i)
			pos = i
		end
	end
	if not pos then
		pos = 1
		for i, l in ipairs(info.layouts) do
			if l.layoutType == Enum.EditModeLayoutType.Account then pos = i + 1 end
		end
	end
	table.insert(info.layouts, pos, layout)
	info.activeLayout = presets + pos
	C_EditMode.SaveLayouts(info)
	C_EditMode.SetActiveLayout(info.activeLayout)
	return true
end

function M:Apply(manual)
	local want = self.db.layout
	if not available() or type(want) ~= "table" then
		if manual then R:Print(L["Este perfil aún no tiene un diseño de Blizzard guardado."]) end
		return
	end
	if InCombatLockdown() then
		if manual then R:Print(L["Se pondrá el diseño de Blizzard al salir de combate."]) end
		R:RunOutOfCombat(function() self:Apply(manual) end)
		return
	end
	local ok, changed = pcall(apply, want)
	if not ok then
		R:Print(L["No se ha podido poner el diseño de Blizzard del perfil (%s). Colócalo en Esc > Modo edición."]:format(tostring(changed)))
	elseif changed then
		R:Print(L["Diseño de Blizzard del perfil puesto."])
	elseif manual then
		R:Print(L["Ya tienes puesto el diseño de Blizzard del perfil."])
	end
end

-- ¿Es un diseño creado por esto? (para volver al de Blizzard al empezar de cero)
function R:IsProfileBlizzardLayout(name)
	return type(name) == "string" and name:find("^Rheizor") ~= nil
end

-- Al entrar: si el perfil ya tiene diseño se pone; si no, se guarda el que
-- haya. Los diseños llegan un poco después de PLAYER_LOGIN
-- (EDIT_MODE_LAYOUTS_UPDATED), así que se espera a que estén.
local function onLogin()
	if synced then return end
	synced = true
	if not (M.db.sync and available()) then return end
	if M.db.layout then
		M:Apply(false)
	else
		M:Capture(false)
	end
end

function M:OnEnable()
	if not available() then return end
	local events = CreateFrame("Frame")
	events:RegisterEvent("EDIT_MODE_LAYOUTS_UPDATED")
	events:SetScript("OnEvent", function(f)
		f:UnregisterAllEvents()
		C_Timer.After(3, onLogin)
	end)
	-- Por si ya habían llegado antes de encender los módulos
	if EditModeManagerFrame and EditModeManagerFrame.layoutInfo then
		events:UnregisterAllEvents()
		C_Timer.After(3, onLogin)
	end
	if EventRegistry and EventRegistry.RegisterCallback then
		EventRegistry:RegisterCallback("EditMode.Exit", function() self:Capture(false) end, self)
	end
end

function M:OnOptionChanged(key)
	if key == "sync" and self.db.sync then
		synced = true
		if self.db.layout then self:Apply(false) else self:Capture(false) end
	end
end
