-- Perfiles: cada personaje usa uno (por defecto, "Default"). RheizorDB queda así:
--   RheizorDB.profiles[nombre] = { [clave del módulo] = { ... }, ... }
--   RheizorDB.chars["Personaje - Reino"] = nombre del perfil
-- R.db apunta al perfil del personaje, así que los módulos no se enteran.
-- Cambiar de perfil recarga la interfaz (los módulos leen su db al activarse).

local R = Rheizor:Namespace(...)
local L = R.L

R.DEFAULT_PROFILE = "Default"
local MAX_NAME = 32

-- Sección "Perfiles" del gestor (/rz): el contenido lo dibuja Manager.lua
-- (comparte página con el diseño de Blizzard, BlizzardLayout.lua)
R:RegisterModule("profiles", {
	title = "Perfiles",
	group = "Perfiles",
	panel = "profiles",
	options = {},
})

-- Instalación desde cero: además de la plantilla recomendada, lo que conviene
-- tener activado aunque el módulo, por prudencia, venga apagado
local FRESH = {
	plates = { enabled = true },
	bags = { autoSell = true, autoRepair = true, junkDim = true, ilvl = true },
	castbars = { locked = true },
	swing = { locked = true },
	totems = { locked = true },
	raidtools = { locked = true },
}

local function canReload()
	if InCombatLockdown() then
		R:Print(L["No se puede cambiar de perfil en combate."])
		return false
	end
	return true
end

-- Addons de Rheizor instalados que dependen del núcleo (cargados o no)
local function installedAddons()
	local A = C_AddOns or {}
	local count, info = A.GetNumAddOns or GetNumAddOns, A.GetAddOnInfo or GetAddOnInfo
	local deps = A.GetAddOnDependencies or GetAddOnDependencies
	local list = {}
	if not (count and info) then return list end
	for i = 1, count() do
		local name = info(i)
		if name and name ~= R.ADDON and name:lower():find("^rheizor") then
			local uses = not deps
			for _, dep in ipairs(deps and { deps(name) } or {}) do
				if dep == R.ADDON then uses = true end
			end
			if uses then list[#list + 1] = name end
		end
	end
	return list
end

-- Un addon sin registro en el perfil sale desactivado (__addons.default =
-- false), así quien instala un addon nuevo lo activa él en /rz. Los perfiles
-- de antes no tenían «default» (sin registro = activado): la primera vez se
-- apunta como activado todo lo instalado que no estaba apagado, para no
-- apagar nada que ya se use, y desde ahí rige lo nuevo.
local function ensureAddonDefault(db)
	if type(db.__addons) ~= "table" then db.__addons = {} end
	local t = db.__addons
	if t.default ~= nil then return end
	for _, name in ipairs(installedAddons()) do
		if t[name] == nil then t[name] = true end
	end
	t.default = false
end

function R:ApplyFreshDefaults(db)
	-- La plantilla solo si el asistente y las plantillas están encendidos (Core.lua)
	if self.SETUP_ENABLED and self.ApplyLayoutToDB then self:ApplyLayoutToDB(self.DEFAULT_LAYOUT, db) end
	for mod, values in pairs(FRESH) do
		db[mod] = type(db[mod]) == "table" and db[mod] or {}
		for k, v in pairs(values) do db[mod][k] = v end
	end
end

-- Lo llama el núcleo en su ADDON_LOADED, antes de preparar los módulos
function R:LoadProfile()
	local fresh = type(RheizorDB) ~= "table" or next(RheizorDB) == nil
	RheizorDB = type(RheizorDB) == "table" and RheizorDB or {}
	local store = RheizorDB
	if type(store.profiles) ~= "table" then
		-- Antes de los perfiles todo estaba en la raíz: pasa a ser el perfil por defecto
		local old = {}
		for k, v in pairs(store) do old[k] = v end
		wipe(store)
		store.profiles = { [self.DEFAULT_PROFILE] = old }
	end
	if type(store.chars) ~= "table" then store.chars = {} end

	local realm = " - " .. (GetRealmName() or "?")
	self.charKey = self.PlayerFullName() .. realm
	-- Al cargar el juego a veces aún no sabe el nombre ("Unknown"): se usa
	-- el perfil por defecto y se corrige al entrar (FixCharKey)
	local first = UnitName("player")
	self.nameUnknown = not first or first == UNKNOWNOBJECT or first == "Unknown"
	-- Restos de entradas con el nombre sin saber: no son ningún personaje
	store.chars["Unknown" .. realm] = nil
	if UNKNOWNOBJECT then store.chars[UNKNOWNOBJECT .. realm] = nil end
	if self.nameUnknown then store.chars[self.charKey] = nil end
	-- Antes la clave era solo el nombre de pila, compartido por todos los
	-- personajes con apellido: esa entrada se aparta y cada personaje hereda
	-- de ella su perfil la primera vez que entra
	local oldKey = (UnitName("player") or "?") .. realm
	if oldKey ~= self.charKey and not self.nameUnknown then
		if type(store.oldChars) ~= "table" then store.oldChars = {} end
		if store.chars[oldKey] ~= nil then
			store.oldChars[oldKey] = store.chars[oldKey]
			store.chars[oldKey] = nil
		end
		if store.chars[self.charKey] == nil then store.chars[self.charKey] = store.oldChars[oldKey] end
	end
	local name = store.chars[self.charKey]
	if type(name) ~= "string" or type(store.profiles[name]) ~= "table" then
		name = self.DEFAULT_PROFILE
	end
	if type(store.profiles[name]) ~= "table" then store.profiles[name] = {} end
	if not self.nameUnknown then store.chars[self.charKey] = name end

	self.store = store
	self.profile = name
	self.db = store.profiles[name]

	-- El asistente sale solo en una instalación nueva (quien ya tenía
	-- configuración puede abrirlo con /rz asistente)
	if type(store.setup) ~= "table" then store.setup = { done = not fresh } end
	if fresh then
		self:ApplyFreshDefaults(self.db)
		-- Instalación nueva: todos los addons desactivados en Rheizor, y aviso
		-- en el chat al entrar (AfterCleanStart) de que se activan en /rz
		self.db.__addons = { default = false }
		if type(store.setup.cleanNotice) ~= "table" then store.setup.cleanNotice = {} end
		store.setup.cleanNotice[self.charKey] = true
	end
	ensureAddonDefault(self.db)
	-- "Empezar de nuevo" en este personaje: su perfil ya viene preparado
	local freshChars = store.setup.freshChars
	if fresh or (type(freshChars) == "table" and freshChars[self.charKey]) then
		self.freshInstall = true
		if type(freshChars) == "table" then freshChars[self.charKey] = nil end
	end
end

-- Si al cargar no se sabía el nombre, al entrar se busca el perfil de este
-- personaje. Si es otro, se cambia aquí mismo: aún no se ha encendido ningún
-- módulo, así que basta con apuntar sus datos al perfil correcto (recargar
-- desde PLAYER_LOGIN puede no llegar a hacerse y dejaba todo sin arrancar)
function R:FixCharKey()
	if not self.nameUnknown then return end
	self.nameUnknown = nil
	local store = self.store
	store.chars["Unknown - " .. (GetRealmName() or "?")] = nil
	local realm = " - " .. (GetRealmName() or "?")
	self.charKey = self.PlayerFullName() .. realm
	-- La entrada antigua (solo el nombre de pila) aún puede estar en chars si
	-- este es el primer personaje que entra desde el cambio: se aparta igual
	-- que en LoadProfile para que herede su perfil
	local oldKey = (UnitName("player") or "?") .. realm
	if oldKey ~= self.charKey then
		if type(store.oldChars) ~= "table" then store.oldChars = {} end
		if store.chars[oldKey] ~= nil then
			store.oldChars[oldKey] = store.chars[oldKey]
			store.chars[oldKey] = nil
		end
	end
	local want = store.chars[self.charKey]
	if want == nil and type(store.oldChars) == "table" then
		want = store.oldChars[oldKey]
	end
	if type(want) ~= "string" or type(store.profiles[want]) ~= "table" then
		-- Personaje sin perfil asignado: se queda con el que ya está cargado
		store.chars[self.charKey] = self.profile
		return
	end
	if want ~= self.profile then
		self.profile = want
		self.db = store.profiles[want]
		ensureAddonDefault(self.db)
		if self.RebindModules then self:RebindModules() end
	end
end

-- Los addons de Rheizor se dejan cargados en WoW (si no, no se podrían
-- configurar); lo que los apaga es el interruptor de Rheizor
-- (who = GUID del personaje, o nil para todos)
local function loadModules(who)
	local A = C_AddOns or {}
	local count, info, enable = A.GetNumAddOns or GetNumAddOns, A.GetAddOnInfo or GetAddOnInfo, A.EnableAddOn or EnableAddOn
	if not (count and info and enable) then return end
	for i = 1, count() do
		local name = info(i)
		if name and name ~= R.ADDON and name:lower():find("^rheizor") then enable(name, who) end
	end
end

-- WoW guarda qué addons carga cada personaje, pero el interruptor de Rheizor
-- está en el perfil. Si el perfil tiene un addon activado y WoW no lo carga en
-- este personaje (se activó desde otro, o se instaló después), se activa en
-- WoW para él y se pide recargar. Lo llama el núcleo al entrar.
StaticPopupDialogs.RHEIZOR_PROFILE_ADDONS = {
	text = "%s",
	button1 = RELOADUI or "Reload",
	button2 = LATER or CANCEL,
	OnAccept = function() ReloadUI() end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

local function usesCore(A, name)
	local deps = A.GetAddOnDependencies or GetAddOnDependencies
	if not deps then return true end
	for _, dep in ipairs({ deps(name) }) do
		if dep == R.ADDON then return true end
	end
	return false
end

function R:SyncAddonsWithProfile()
	local A = C_AddOns or {}
	local count, info = A.GetNumAddOns or GetNumAddOns, A.GetAddOnInfo or GetAddOnInfo
	local loaded, enable = A.IsAddOnLoaded or IsAddOnLoaded, A.EnableAddOn or EnableAddOn
	if not (count and info and loaded and enable) then return end
	local who = self.CharacterID()
	local names = {}
	for i = 1, count() do
		local name, title, _, _, reason = info(i)
		-- Solo los que no cargan por estar desactivados (no por versión o dependencias)
		if name and name ~= self.ADDON and name:lower():find("^rheizor") and not loaded(name)
			and (reason == nil or reason == "DISABLED") and usesCore(A, name) and self:IsAddonActive(name) then
			enable(name, who)
			local plain = (title or name):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
			names[#names + 1] = plain:match("·%s*(.+)$") or plain
		end
	end
	if #names == 0 then return end
	table.sort(names)
	local text = L["Tu perfil (%s) tiene activados addons que este personaje no cargaba:\n\n%s\n\nYa están activados. Recarga para usarlos."]
		:format(self:ProfileLabel(self.profile), table.concat(names, ", "))
	self:Print((text:gsub("\n\n", " ")))
	StaticPopup_Show("RHEIZOR_PROFILE_ADDONS", text)
end

-- Perfil en blanco: todos los addons de Rheizor desactivados en Rheizor
-- (también los que se instalen más adelante) y sin plantilla
local function blankProfile()
	return { __addons = { default = false } }
end

-- Empezar de cero: sin plantilla, con la interfaz de Blizzard y todos los
-- módulos desactivados en Rheizor; el jugador los activa uno a uno en /rz.
-- Borra toda la configuración de Rheizor de la cuenta (todos los perfiles).
function R:ResetAll()
	if not canReload() then return end
	-- Los demás personajes que usaban Rheizor vuelven al diseño de Blizzard al entrar
	local pending = {}
	for char in pairs(self.store.chars) do
		if char ~= self.charKey then pending[char] = true end
	end
	loadModules(nil)
	self:RestoreBlizzardLayout()
	-- El historial de copias se conserva (para poder volver atrás)
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes de borrar todo"], true) end
	RheizorDB = {
		profiles = { [self.DEFAULT_PROFILE] = blankProfile() },
		chars = {},
		setup = { done = true, cleanNotice = { [self.charKey] = true }, restoreBlizzard = pending },
		snapshots = self.store.snapshots,
		snapshotSeq = self.store.snapshotSeq,
	}
	ReloadUI()
end

-- Solo este personaje: perfil nuevo y vacío (con su nombre), módulos
-- desactivados para él e interfaz de Blizzard. Los demás no cambian.
function R:ResetCharacter()
	if not canReload() then return end
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes de empezar de nuevo"], true) end
	local store = self.store
	store.profiles[self.charKey] = blankProfile()
	store.chars[self.charKey] = self.charKey
	if type(store.setup.freshChars) == "table" then store.setup.freshChars[self.charKey] = nil end
	if type(store.setup.cleanNotice) ~= "table" then store.setup.cleanNotice = {} end
	store.setup.cleanNotice[self.charKey] = true
	loadModules(self.CharacterID())
	self:RestoreBlizzardLayout()
	ReloadUI()
end

-- Tras empezar de cero: aviso en el chat y, en los demás personajes, vuelta
-- al diseño de Blizzard. Lo llama el asistente al activarse.
function R:AfterCleanStart()
	local setup = self.store.setup
	local restore, notice = setup.restoreBlizzard, setup.cleanNotice
	if type(restore) == "table" and restore[self.charKey] then
		restore[self.charKey] = nil
		if next(restore) == nil then setup.restoreBlizzard = nil end
		C_Timer.After(2, function() self:RestoreBlizzardLayout() end)
	end
	if type(notice) == "table" and notice[self.charKey] then
		notice[self.charKey] = nil
		if next(notice) == nil then setup.cleanNotice = nil end
		C_Timer.After(3, function()
			self:Print(self.SETUP_ENABLED
				and L["Rheizor está en blanco: interfaz de Blizzard y módulos desactivados. Actívalos uno a uno en /rz, o usa /rz asistente."]
				or L["Rheizor está en blanco: interfaz de Blizzard y módulos desactivados. Actívalos uno a uno en /rz."])
		end)
	end
end

function R:ProfileLabel(name)
	if name == self.DEFAULT_PROFILE then return L["Por defecto"] end
	return name
end

function R:GetProfiles()
	local list = {}
	for name, value in pairs(self.store.profiles) do
		if type(value) == "table" then list[#list + 1] = name end
	end
	table.sort(list, function(a, b)
		if (a == self.DEFAULT_PROFILE) ~= (b == self.DEFAULT_PROFILE) then return a == self.DEFAULT_PROFILE end
		return a:lower() < b:lower()
	end)
	return list
end

-- Personajes que usan un perfil (sin el reino si es el mismo que el tuyo)
function R:ProfileUsers(name)
	local realm = " - " .. (GetRealmName() or "?")
	local list = {}
	for char, profile in pairs(self.store.chars) do
		if profile == name then
			if char:sub(-#realm) == realm then char = char:sub(1, -#realm - 1) end
			list[#list + 1] = char
		end
	end
	table.sort(list)
	return list
end

function R:SetProfile(name)
	if type(self.store.profiles[name]) ~= "table" or not canReload() then return end
	self.store.chars[self.charKey] = name
	ReloadUI()
end

-- Crea un perfil (vacío o copia del actual) y lo usa
function R:NewProfile(name, copyCurrent)
	name = strtrim(name or "")
	if name == "" then
		self:Print(L["Escribe un nombre para el perfil."])
		return
	end
	if #name > MAX_NAME then
		self:Print(L["El nombre es demasiado largo."])
		return
	end
	if self.store.profiles[name] then
		self:Print(L["Ya existe un perfil con ese nombre."])
		return
	end
	if not canReload() then return end
	local profile = copyCurrent and self.DeepCopy(self.db) or {}
	if not copyCurrent then
		self:ApplyFreshDefaults(profile)
		-- Perfil vacío: los addons empiezan desactivados en Rheizor
		profile.__addons = { default = false }
	end
	self.store.profiles[name] = profile
	self.store.chars[self.charKey] = name
	ReloadUI()
end

-- Sustituye el perfil actual por una copia de otro
function R:CopyProfile(from)
	local src = self.store.profiles[from]
	if type(src) ~= "table" or from == self.profile or not canReload() then return end
	local copy = self.DeepCopy(src)
	if self.TakeSnapshot then self:TakeSnapshot(L["Antes de copiar otro perfil"], true) end
	wipe(self.db)
	for k, v in pairs(copy) do self.db[k] = v end
	ReloadUI()
end

-- Borra otro perfil; los personajes que lo usaban vuelven al perfil por defecto
function R:DeleteProfile(name)
	if name == self.profile or not self.store.profiles[name] then return end
	self.store.profiles[name] = nil
	-- Sus copias se quedan: salen en el historial por si hay que recuperarlo
	for char, profile in pairs(self.store.chars) do
		if profile == name then self.store.chars[char] = nil end
	end
	self:Print(L["Perfil borrado: %s"]:format(self:ProfileLabel(name)))
end
