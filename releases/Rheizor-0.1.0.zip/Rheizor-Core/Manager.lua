-- Gestor de Rheizor (/rz): ventana propia con todos los addons de Rheizor
-- instalados, para activarlos o desactivarlos, y las opciones de cada módulo
-- dibujadas por nosotros (son las mismas que en Opciones > AddOns > Rheizor).

local R = Rheizor:Namespace(...)
local L = R.L

local ACCENT = "33ccff"

local M = R:RegisterModule("manager", {
	title = "Gestor",
	defaults = {
		scale = 1,
		alpha = 1,
		accent = ACCENT,
	},
	options = {
		{ type = "header", text = "Gestor de Rheizor (/rz)" },
		{ type = "slider", key = "scale", name = "Escala", min = 0.7, max = 1.3, step = 0.05 },
		{ type = "slider", key = "alpha", name = "Opacidad", min = 0.4, max = 1, step = 0.05 },
		{ type = "color", key = "accent", name = "Color de la ventana", default = ACCENT,
		  desc = "Color de los detalles: interruptores, títulos, selección y barras." },
		{ type = "button", name = "Posición y tamaño", text = "Restablecer", func = function(mod) mod:ResetPosition() end,
		  desc = "Vuelve a centrar la ventana con su tamaño de siempre. También se agranda o se encoge arrastrando la esquina de abajo a la derecha, y con doble clic en la barra del título se maximiza." },
	},
})

local WHITE = "Interface\\Buttons\\WHITE8X8"
local W, H = 980, 660            -- tamaño por defecto (se puede cambiar arrastrando la esquina)
local MIN_W, MIN_H = 720, 440
local LEFT_W = 230
local MAX_PAGE_W = 780           -- más ancho, las líneas largas se leen mal
local PAGE_W = W - LEFT_W - 60   -- ancho de la página antes de que exista la ventana

----------------------------------------------------------------------
-- Colores y letras
----------------------------------------------------------------------

-- Color de acento (opción "accent"): cada pieza que lo usa se apunta con
-- onAccent y se vuelve a pintar al cambiarlo
local AR, AG, AB = 0.2, 0.8, 1
local painters = {}
local function onAccent(fn)
	painters[#painters + 1] = fn
	fn(AR, AG, AB)
end
local function setAccent(hex)
	local ok, r, g, b = pcall(R.HexToRGB, hex or ACCENT)
	if not ok or not r then r, g, b = R.HexToRGB(ACCENT) end
	AR, AG, AB = r, g, b
	for _, fn in ipairs(painters) do fn(r, g, b) end
end
local function accentCode()
	return string.format("|cff%02x%02x%02x", math.floor(AR * 255 + 0.5), math.floor(AG * 255 + 0.5), math.floor(AB * 255 + 0.5))
end

-- Fondos
local BG_WIN   = { 0.055, 0.058, 0.07 }
local BG_BAR   = { 0.085, 0.09, 0.11 }
local BG_SIDE  = { 0.04, 0.042, 0.052 }
local BG_FIELD = { 0.02, 0.02, 0.03 }
local EDGE     = { 0.22, 0.23, 0.27 }

local function newFont(name, size, r, g, b)
	local f = CreateFont(name)
	local file = GameFontNormal:GetFont()
	f:SetFont(file, size, "")
	f:SetShadowOffset(1, -1)
	f:SetShadowColor(0, 0, 0, 0.9)
	f:SetTextColor(r or 1, g or 1, b or 1)
	return f
end
local FONT_TITLE   = newFont("RheizorManagerFontTitle", 19)
local FONT_HEADER  = newFont("RheizorManagerFontHeader", 13)
local FONT_LOGO    = newFont("RheizorManagerFontLogo", 17)
onAccent(function(r, g, b)
	FONT_HEADER:SetTextColor(r, g, b)
	FONT_LOGO:SetTextColor(r, g, b)
end)

local db
local win, tree, page, popup
local sel = {}          -- { addon = nombre, page = título }
local expanded = {}
local lastShown
local armed             -- botón peligroso que espera un segundo clic para confirmar
local profileTarget     -- perfil elegido para copiar o borrar
local snapshotTarget    -- copia de seguridad elegida para restaurar o borrar
local query = ""        -- texto del buscador ya normalizado
-- Dónde se dibujan los controles: la página del gestor o la del asistente
local target = { pool = "page", width = PAGE_W }

----------------------------------------------------------------------
-- Addons instalados (C_AddOns en clientes nuevos, funciones sueltas en viejos)
----------------------------------------------------------------------

local A = C_AddOns or {}
local function api(name) return A[name] or _G[name] end

local function isLoaded(name)
	local fn = api("IsAddOnLoaded")
	return fn and fn(name) and true or false
end

local function isEnabled(name)
	local me = R.CharacterID()
	if A.GetAddOnEnableState then
		local ok, state = pcall(A.GetAddOnEnableState, name, me)
		if ok and type(state) == "number" then return state > 0 end
	elseif GetAddOnEnableState then
		local ok, state = pcall(GetAddOnEnableState, me, name)
		if ok and type(state) == "number" then return state > 0 end
	end
	local _, _, _, loadable = api("GetAddOnInfo")(name)
	return loadable and true or false
end

local function setEnabled(name, on)
	local fn = api(on and "EnableAddOn" or "DisableAddOn")
	if fn then fn(name, R.CharacterID()) end
end

local function metadata(name, field)
	local fn = api("GetAddOnMetadata")
	return fn and fn(name, field)
end

local function usesCore(name)
	local fn = api("GetAddOnDependencies")
	if not fn then return true end
	for _, dep in ipairs({ fn(name) }) do
		if dep == R.ADDON then return true end
	end
	return false
end

local function plainTitle(t)
	t = (t or ""):gsub("|c%x%x%x%x%x%x%x%x", "")
	t = t:gsub("|r", "")
	return t
end

local function collectAddons()
	local list = {}
	for i = 1, api("GetNumAddOns")() do
		local name, title, notes, _, reason = api("GetAddOnInfo")(i)
		if name and name:lower():find("^rheizor") then
			local plain = plainTitle(title or name)
			list[#list + 1] = {
				name = name, title = title or name, notes = notes, reason = reason,
				short = plain:match("·%s*(.+)$") or plain,
				core = name == R.ADDON,
			}
		end
	end
	table.sort(list, function(a, b)
		if a.core ~= b.core then return a.core end
		return a.short:lower() < b.short:lower()
	end)
	return list
end

-- Activado en Rheizor (el interruptor de Rheizor, aparte de que WoW lo cargue).
-- Los addons que no usan el núcleo y el propio núcleo no tienen interruptor.
local function hasSwitch(a)
	return not a.core and usesCore(a.name)
end

local function isActive(name)
	return isEnabled(name) and R:IsAddonActive(name)
end

-- Activarlo también hace que WoW lo cargue; desactivarlo lo deja cargado
-- para poder seguir configurándolo
local function setActive(name, on)
	R:SetAddonActive(name, on)
	if on and not isEnabled(name) then setEnabled(name, true) end
end

-- ¿Ha cambiado el interruptor de Rheizor desde que se entró?
local function switchPending(a)
	if not hasSwitch(a) or not isLoaded(a.name) then return false end
	return R:IsAddonActive(a.name) ~= (R.activeAtLogin[a.name] ~= false)
end

-- Texto y color del estado de un addon
local function status(a)
	local loaded, enabled = isLoaded(a.name), isEnabled(a.name)
	if hasSwitch(a) then
		if not R:IsAddonActive(a.name) then
			if switchPending(a) then return L["Se desactivará al recargar"], 1, 0.6, 0.1 end
			return L["Desactivado"], 0.5, 0.5, 0.5
		end
		if loaded and enabled and switchPending(a) then return L["Se activará al recargar"], 1, 0.6, 0.1 end
	end
	if loaded and enabled then return L["Cargado"], 0.3, 1, 0.3 end
	if loaded then return L["Se desactivará al recargar"], 1, 0.6, 0.1 end
	if enabled then
		local _, _, _, _, reason = api("GetAddOnInfo")(a.name)
		if reason == "INTERFACE_VERSION" then return L["Versión de interfaz antigua"], 1, 0.3, 0.3 end
		if reason == "DEP_MISSING" then return L["Falta el núcleo (Rheizor-Core)"], 1, 0.3, 0.3 end
		return L["Se cargará al recargar"], 1, 0.6, 0.1
	end
	return L["Desactivado"], 0.5, 0.5, 0.5
end

local function anyPending()
	for _, a in ipairs(collectAddons()) do
		if switchPending(a) then return true end
		-- Uno desactivado en Rheizor da igual que WoW lo cargue o no
		if isLoaded(a.name) ~= isEnabled(a.name) and (not hasSwitch(a) or R:IsAddonActive(a.name)) then return true end
	end
	return false
end

-- Secciones de un addon: un módulo suelto, o varios que comparten "group"
local function pagesFor(addon)
	local pages, groups = {}, {}
	for _, mod in ipairs(R.order) do
		if mod.addon == addon and mod.options then
			if mod.group then
				local g = groups[mod.group]
				if not g then
					g = { title = mod.group, mods = {} }
					groups[mod.group] = g
					pages[#pages + 1] = g
				end
				table.insert(g.mods, mod)
			else
				pages[#pages + 1] = { title = mod.title, mods = { mod } }
			end
		end
	end
	return pages
end

----------------------------------------------------------------------
-- Piezas reutilizables
----------------------------------------------------------------------

local function setBackdrop(f, alpha)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.05, 0.05, 0.07, alpha or 0.95)
	onAccent(function(r, g, b) f:SetBackdropBorderColor(r, g, b, 0.9) end)
end

-- Fondo liso con borde fino (sin color de acento)
local function flatBackdrop(f, bg, edge, alpha)
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(bg[1], bg[2], bg[3], alpha or 1)
	f:SetBackdropBorderColor(edge[1], edge[2], edge[3], 1)
end

-- Botón plano: borde gris que se ilumina con el color de acento
local function flatButton(parent, width, height)
	local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
	b:SetSize(width or 120, height or 22)
	flatBackdrop(b, { 0.11, 0.115, 0.14 }, EDGE)
	local fs = b:CreateFontString(nil, "OVERLAY")
	fs:SetPoint("LEFT", 6, 0)
	fs:SetPoint("RIGHT", -6, 0)
	fs:SetWordWrap(false)
	b:SetFontString(fs)
	b:SetNormalFontObject(GameFontHighlightSmall)
	b:SetHighlightFontObject(GameFontHighlightSmall)
	b:SetDisabledFontObject(GameFontDisableSmall)
	b:SetScript("OnEnter", function(self)
		if not self:IsEnabled() then return end
		self:SetBackdropColor(AR * 0.25, AG * 0.25, AB * 0.25, 1)
		self:SetBackdropBorderColor(AR, AG, AB, 1)
	end)
	b:SetScript("OnLeave", function(self)
		self:SetBackdropColor(0.11, 0.115, 0.14, 1)
		self:SetBackdropBorderColor(EDGE[1], EDGE[2], EDGE[3], 1)
	end)
	b:SetScript("OnMouseDown", function(self) if self:IsEnabled() then fs:SetPoint("LEFT", 7, -1) end end)
	b:SetScript("OnMouseUp", function() fs:SetPoint("LEFT", 6, 0) end)
	return b
end

local function tooltip(frame, title, text)
	frame.ttTitle, frame.ttText = title, text
	if frame.ttHooked then return end
	frame.ttHooked = true
	frame:HookScript("OnEnter", function(self)
		if not self.ttText then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:SetText(self.ttTitle or "", 1, 1, 1)
		GameTooltip:AddLine(self.ttText, nil, nil, nil, true)
		GameTooltip:Show()
	end)
	frame:HookScript("OnLeave", GameTooltip_Hide)
end

-- Grupos de marcos que se reutilizan al redibujar ("tree" y "page")
local pools = {}
local lastAcquired      -- el último marco dado (para atenuar opciones desactivadas)
local function acquire(group, kind, parent, create)
	local g = pools[group] or {}
	pools[group] = g
	local p = g[kind] or { n = 0 }
	g[kind] = p
	p.n = p.n + 1
	local w = p[p.n]
	if not w then
		w = create(parent)
		p[p.n] = w
	end
	w:ClearAllPoints()
	w:Show()
	-- Puede venir de una opción desactivada
	if w.rzDisabled then
		w.rzDisabled = nil
		w:SetAlpha(1)
		w.blocker:Hide()
	end
	lastAcquired = w
	return w
end

-- Opción que se ve pero no se puede tocar: atenuada, con una capa encima que
-- se come los clics y explica por qué en su descripción emergente
local function setDisabled(w, title, reason)
	w.rzDisabled = true
	w:SetAlpha(0.4)
	if not w.blocker then
		w.blocker = CreateFrame("Frame", nil, w)
		w.blocker:SetAllPoints()
		w.blocker:EnableMouse(true)
	end
	w.blocker:SetFrameLevel(w:GetFrameLevel() + 30)
	tooltip(w.blocker, title, type(reason) == "string" and reason or nil)
	w.blocker:Show()
end

local function release(group)
	for _, p in pairs(pools[group] or {}) do
		for i = 1, #p do p[i]:Hide() end
		p.n = 0
	end
end

-- Zona con rueda del ratón y una barrita que indica la posición
local function makeScroll(parent)
	local sf = CreateFrame("ScrollFrame", nil, parent)
	local child = CreateFrame("Frame", nil, sf)
	child:SetSize(1, 1)
	sf:SetScrollChild(child)
	sf.child = child

	local bar = sf:CreateTexture(nil, "OVERLAY")
	onAccent(function(r, g, b) bar:SetColorTexture(r, g, b, 0.5) end)
	bar:SetWidth(3)
	function sf:UpdateBar()
		local range = self:GetVerticalScrollRange()
		if range <= 0 then bar:Hide() return end
		local h = self:GetHeight()
		local bh = math.max(20, h * h / (h + range))
		bar:SetHeight(bh)
		bar:ClearAllPoints()
		bar:SetPoint("TOPRIGHT", self, "TOPRIGHT", 0, -(h - bh) * self:GetVerticalScroll() / range)
		bar:Show()
	end
	function sf:ScrollTo(v)
		v = math.max(0, math.min(self:GetVerticalScrollRange(), v))
		self:SetVerticalScroll(v)
		self:UpdateBar()
	end
	sf:EnableMouseWheel(true)
	sf:SetScript("OnMouseWheel", function(self, delta) self:ScrollTo(self:GetVerticalScroll() - delta * 40) end)
	sf:SetScript("OnScrollRangeChanged", function(self) self:ScrollTo(self:GetVerticalScroll()) end)
	return sf
end

----------------------------------------------------------------------
-- Lista desplegable propia (sin depender del menú de Blizzard)
----------------------------------------------------------------------

local function closePopup()
	if popup then popup:Hide() end
end

local function openPopup(owner, values, current, onPick)
	if not popup then
		popup = CreateFrame("Frame", nil, UIParent, "BackdropTemplate")
		popup:SetFrameStrata("FULLSCREEN_DIALOG")
		popup:SetClampedToScreen(true)
		popup:EnableMouse(true)
		setBackdrop(popup, 0.98)
		popup.buttons = {}
	end
	if popup:IsShown() and popup.owner == owner then
		popup:Hide()
		return
	end
	popup.owner = owner
	popup:SetScale(owner:GetEffectiveScale() / UIParent:GetEffectiveScale())

	local widest = 0
	for i, v in ipairs(values) do
		local b = popup.buttons[i]
		if not b then
			b = CreateFrame("Button", nil, popup)
			b:SetHeight(18)
			local hl = b:CreateTexture(nil, "HIGHLIGHT")
			hl:SetAllPoints()
			onAccent(function(r, g, bb) hl:SetColorTexture(r, g, bb, 0.25) end)
			b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			b.text:SetPoint("LEFT", 6, 0)
			popup.buttons[i] = b
		end
		b:ClearAllPoints()
		b:SetPoint("TOPLEFT", 4, -4 - (i - 1) * 18)
		b:SetPoint("RIGHT", popup, "RIGHT", -4, 0)
		b.text:SetText((v[1] == current and (accentCode() .. "> |r") or "   ") .. v[2])
		widest = math.max(widest, b.text:GetStringWidth())
		b:SetScript("OnClick", function()
			popup:Hide()
			onPick(v[1], v[2])
		end)
		b:Show()
	end
	for i = #values + 1, #popup.buttons do popup.buttons[i]:Hide() end

	popup:SetSize(math.max(owner:GetWidth(), widest + 24), #values * 18 + 8)
	popup:ClearAllPoints()
	popup:SetPoint("TOPLEFT", owner, "BOTTOMLEFT", 0, -2)
	popup:Show()
end

----------------------------------------------------------------------
-- Controles de la página
----------------------------------------------------------------------

local function newText(parent)
	local f = CreateFrame("Frame", nil, parent)
	f.text = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.text:SetPoint("TOPLEFT")
	f.text:SetJustifyH("LEFT")
	f.text:SetJustifyV("TOP")
	f.text:SetWordWrap(true)
	return f
end

local function newHeader(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(28)
	f.text = f:CreateFontString(nil, "OVERLAY")
	f.text:SetFontObject(FONT_HEADER)
	f.text:SetPoint("BOTTOMLEFT", 2, 6)
	local line = f:CreateTexture(nil, "ARTWORK")
	line:SetHeight(1)
	line:SetPoint("BOTTOMLEFT")
	line:SetPoint("BOTTOMRIGHT")
	-- Degradado del color de acento a transparente
	onAccent(function(r, g, b)
		line:SetColorTexture(1, 1, 1, 1)
		if line.SetGradient and CreateColor then
			line:SetGradient("HORIZONTAL", CreateColor(r, g, b, 0.6), CreateColor(r, g, b, 0))
		else
			line:SetColorTexture(r, g, b, 0.3)
		end
	end)
	return f
end

-- Fila que se ilumina al pasar el ratón por encima
local function hoverRow(f)
	local hl = f:CreateTexture(nil, "BACKGROUND")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.035)
	hl:Hide()
	f:SetScript("OnEnter", function() hl:Show() end)
	f:SetScript("OnLeave", function() hl:Hide() end)
end

-- Interruptor deslizante (es un CheckButton: SetChecked/GetChecked/Click)
local function newSwitch(parent)
	local cb = CreateFrame("CheckButton", nil, parent)
	cb:SetSize(32, 16)
	local track = cb:CreateTexture(nil, "BACKGROUND")
	track:SetAllPoints()
	local knob = cb:CreateTexture(nil, "ARTWORK")
	knob:SetSize(12, 12)
	knob:SetColorTexture(1, 1, 1)
	local function update()
		local on = cb:GetChecked()
		knob:ClearAllPoints()
		if on then
			knob:SetPoint("RIGHT", -2, 0)
			track:SetColorTexture(AR, AG, AB, 0.95)
			knob:SetAlpha(1)
		else
			knob:SetPoint("LEFT", 2, 0)
			track:SetColorTexture(0.24, 0.25, 0.29, 1)
			knob:SetAlpha(0.65)
		end
	end
	local setChecked = cb.SetChecked
	function cb:SetChecked(v)
		setChecked(self, v)
		update()
	end
	cb.Update = update
	onAccent(update)
	return cb
end

local function newToggle(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(28)
	f:EnableMouse(true)
	hoverRow(f)
	f.cb = newSwitch(f)
	f.cb:SetPoint("LEFT", 4, 0)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("LEFT", f.cb, "RIGHT", 10, 0)
	f.label:SetJustifyH("LEFT")
	f.label:SetWordWrap(false)
	f.cb:SetScript("OnClick", function(self)
		self.Update()
		if f.set then f.set(self:GetChecked() and true or false) end
	end)
	f:SetScript("OnMouseUp", function() f.cb:Click() end)
	return f
end

local function snap(f, v)
	v = math.floor((v - f.min) / f.step + 0.5) * f.step + f.min
	return math.max(f.min, math.min(f.max, v))
end

local function newSlider(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(46)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("TOPLEFT", 4, 0)

	local s = CreateFrame("Slider", nil, f, "BackdropTemplate")
	s:SetOrientation("HORIZONTAL")
	s:SetSize(260, 12)
	s:SetPoint("TOPLEFT", 36, -22)
	flatBackdrop(s, BG_FIELD, EDGE)
	s:SetThumbTexture(WHITE)
	s:GetThumbTexture():SetSize(10, 18)
	onAccent(function(r, g, b) s:GetThumbTexture():SetVertexColor(r, g, b) end)
	-- Parte ya recorrida, rellena con el color de acento
	local fill = s:CreateTexture(nil, "ARTWORK")
	fill:SetPoint("TOPLEFT", 1, -1)
	fill:SetPoint("BOTTOMLEFT", 1, 1)
	fill:SetPoint("RIGHT", s:GetThumbTexture(), "CENTER")
	onAccent(function(r, g, b) fill:SetColorTexture(r, g, b, 0.35) end)
	if s.SetObeyStepOnDrag then s:SetObeyStepOnDrag(true) end
	s:EnableMouse(true)
	f.slider = s

	local function stepButton(text, delta)
		local b = flatButton(f, 22, 20)
		b:SetText(text)
		b:SetScript("OnClick", function() s:SetValue(snap(f, s:GetValue() + delta * f.step)) end)
		return b
	end
	stepButton("-", -1):SetPoint("RIGHT", s, "LEFT", -6, 0)
	local plus = stepButton("+", 1)
	plus:SetPoint("LEFT", s, "RIGHT", 6, 0)

	f.value = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.value:SetPoint("LEFT", plus, "RIGHT", 8, 0)

	s:SetScript("OnValueChanged", function(_, v)
		if f.updating then return end
		v = snap(f, v)
		f.value:SetText(f.format(v))
		if f.set and v ~= f.last then
			f.last = v
			f.set(v)
		end
	end)
	return f
end

local function newDropdown(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(48)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("TOPLEFT", 4, 0)

	local b = CreateFrame("Button", nil, f, "BackdropTemplate")
	b:SetSize(260, 22)
	b:SetPoint("TOPLEFT", 8, -18)
	flatBackdrop(b, BG_FIELD, EDGE)
	b:SetScript("OnEnter", function(self) self:SetBackdropBorderColor(AR, AG, AB, 1) end)
	b:SetScript("OnLeave", function(self) self:SetBackdropBorderColor(EDGE[1], EDGE[2], EDGE[3], 1) end)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.04)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	b.text:SetPoint("LEFT", 6, 0)
	b.text:SetPoint("RIGHT", -18, 0)
	b.text:SetJustifyH("LEFT")
	local arrow = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	arrow:SetPoint("RIGHT", -6, 0)
	arrow:SetText("v")
	b:SetScript("OnClick", function()
		openPopup(b, f.values, f.get(), function(value, text)
			-- Primero el texto: set() puede redibujar la página y reutilizar este control
			b.text:SetText(text)
			f.set(value)
		end)
	end)
	f.button = b
	return f
end

local function newButton(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(30)
	f:EnableMouse(true)
	hoverRow(f)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("LEFT", 4, 0)
	f.label:SetWidth(250)
	f.label:SetJustifyH("LEFT")
	f.btn = flatButton(f, 170, 22)
	f.btn:SetPoint("LEFT", 260, 0)
	f.btn:SetScript("OnClick", function(self)
		if self.onClick then xpcall(self.onClick, geterrorhandler()) end
	end)
	return f
end

-- Fila de la lista de addons: interruptor, nombre, estado y botones rápidos
local function newAddonRow(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(28)
	f:EnableMouse(true)
	hoverRow(f)
	f.cb = newSwitch(f)
	f.cb:SetPoint("LEFT", 4, 0)
	f.cb:SetScript("OnClick", function(self)
		self.Update()
		if f.set then f.set(self:GetChecked() and true or false) end
	end)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("LEFT", f.cb, "RIGHT", 10, 0)
	f.label:SetJustifyH("LEFT")
	f.label:SetWordWrap(false)
	f.state = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.state:SetJustifyH("LEFT")
	f.state:SetWordWrap(false)
	f.opts = flatButton(f, 84, 20)
	f.opts:SetPoint("RIGHT", -4, 0)
	f.move = flatButton(f, 84, 20)
	f.move:SetPoint("RIGHT", f.opts, "LEFT", -4, 0)
	for _, b in ipairs({ f.opts, f.move }) do
		b:SetScript("OnClick", function(self)
			if self.onClick then xpcall(self.onClick, geterrorhandler()) end
		end)
	end
	return f
end

-- Color guardado como texto "rrggbb". Abre el selector de color de Blizzard.
local function toHex(r, g, b)
	return string.format("%02x%02x%02x", math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5))
end

local function pickColor(hex, onChange)
	local picker = ColorPickerFrame
	if not picker then return end
	local r, g, b = R.HexToRGB(hex)
	local function current() return toHex(picker:GetColorRGB()) end
	picker:SetFrameStrata("FULLSCREEN_DIALOG")
	if picker.SetupColorPickerAndShow then
		picker:SetupColorPickerAndShow({
			r = r, g = g, b = b, hasOpacity = false,
			swatchFunc = function() onChange(current()) end,
			cancelFunc = function() onChange(hex) end,
		})
	else
		picker.hasOpacity = false
		picker.previousValues = { r, g, b }
		picker.func = function() onChange(current()) end
		picker.cancelFunc = function() onChange(hex) end
		picker:SetColorRGB(r, g, b)
		ShowUIPanel(picker)
	end
end

local function newColor(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(28)
	f:EnableMouse(true)
	hoverRow(f)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("LEFT", 42, 0)
	f.label:SetJustifyH("LEFT")
	f.label:SetWordWrap(false)
	local b = CreateFrame("Button", nil, f, "BackdropTemplate")
	b:SetSize(26, 16)
	b:SetPoint("LEFT", 4, 0)
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
	b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	b:SetScript("OnClick", function(_, button)
		local function set(hex)
			f.hex = hex
			b:SetBackdropColor(R.HexToRGB(hex))
			if f.set then f.set(hex) end
		end
		if button == "RightButton" then
			if f.default then set(f.default) end
		else
			pickColor(f.hex, set)
		end
	end)
	f.swatch = b
	return f
end

-- Casilla de texto con uno o dos botones (para el nombre de un perfil nuevo)
local function newInput(parent)
	local f = CreateFrame("Frame", nil, parent)
	f:SetHeight(30)
	f.label = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.label:SetPoint("LEFT", 4, 0)
	f.label:SetWidth(110)
	f.label:SetJustifyH("LEFT")

	local e = CreateFrame("EditBox", nil, f, "BackdropTemplate")
	e:SetSize(170, 22)
	e:SetPoint("LEFT", 120, 0)
	flatBackdrop(e, BG_FIELD, EDGE)
	e:SetScript("OnEditFocusGained", function(self) self:SetBackdropBorderColor(AR, AG, AB, 1) end)
	e:SetScript("OnEditFocusLost", function(self) self:SetBackdropBorderColor(EDGE[1], EDGE[2], EDGE[3], 1) end)
	e:SetFontObject(GameFontHighlightSmall)
	e:SetTextInsets(6, 6, 0, 0)
	e:SetAutoFocus(false)
	e:SetMaxLetters(32)
	e:SetScript("OnEscapePressed", e.ClearFocus)
	e:SetScript("OnEnterPressed", function() f.btn1:Click() end)
	f.edit = e

	local function btn(onClickKey)
		local b = flatButton(f, 100, 22)
		b:SetScript("OnClick", function()
			local fn = f[onClickKey]
			if fn then xpcall(fn, geterrorhandler(), e:GetText()) end
		end)
		return b
	end
	f.btn1 = btn("onClick1")
	f.btn1:SetWidth(130)
	f.btn1:SetPoint("LEFT", e, "RIGHT", 8, 0)
	f.btn2 = btn("onClick2")
	f.btn2:SetWidth(80)
	f.btn2:SetPoint("LEFT", f.btn1, "RIGHT", 4, 0)
	return f
end

----------------------------------------------------------------------
-- Buscador: sin mayúsculas, tildes ni códigos de color
----------------------------------------------------------------------

local FOLD = {
	["á"] = "a", ["à"] = "a", ["ä"] = "a", ["â"] = "a", ["Á"] = "a", ["À"] = "a", ["Ä"] = "a", ["Â"] = "a",
	["é"] = "e", ["è"] = "e", ["ë"] = "e", ["ê"] = "e", ["É"] = "e", ["È"] = "e", ["Ë"] = "e", ["Ê"] = "e",
	["í"] = "i", ["ì"] = "i", ["ï"] = "i", ["î"] = "i", ["Í"] = "i", ["Ì"] = "i", ["Ï"] = "i", ["Î"] = "i",
	["ó"] = "o", ["ò"] = "o", ["ö"] = "o", ["ô"] = "o", ["Ó"] = "o", ["Ò"] = "o", ["Ö"] = "o", ["Ô"] = "o",
	["ú"] = "u", ["ù"] = "u", ["ü"] = "u", ["û"] = "u", ["Ú"] = "u", ["Ù"] = "u", ["Ü"] = "u", ["Û"] = "u",
	["ñ"] = "n", ["Ñ"] = "n", ["ç"] = "c", ["Ç"] = "c",
}

local function normalize(s)
	s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
	s = s:gsub("\195[\128-\191]", FOLD)
	return (s:lower())
end

local function matches(q, ...)
	for i = 1, select("#", ...) do
		local s = select(i, ...)
		if type(s) == "string" and normalize(s):find(q, 1, true) then return true end
	end
	return false
end

local function optionMatches(q, opt)
	if matches(q, opt.name, opt.desc, opt.text, opt.cvar) then return true end
	if type(opt.values) == "table" then
		for _, v in ipairs(opt.values) do
			if matches(q, v[2]) then return true end
		end
	end
	return false
end

----------------------------------------------------------------------
-- Dibujar opciones
----------------------------------------------------------------------

local function addText(y, text, font, indent)
	local f = acquire(target.pool, "text", target.canvas, newText)
	f:SetPoint("TOPLEFT", indent or 0, -y)
	f:SetWidth(target.width - (indent or 0))
	f.text:SetFontObject(font or GameFontHighlight)
	f.text:SetWidth(target.width - (indent or 0))
	f.text:SetText(text)
	local h = f.text:GetStringHeight() + 6
	f:SetHeight(h)
	return h
end

local function addHeader(y, text)
	local h = acquire(target.pool, "header", target.canvas, newHeader)
	h:SetPoint("TOPLEFT", 0, -(y + 4))
	h:SetWidth(target.width)
	h.text:SetText(text)
	return 38
end

-- Dónde empieza el control de una fila con texto a la izquierda
local function controlX()
	return math.max(220, math.min(340, math.floor(target.width * 0.45)))
end

local function addButton(y, label, text, onClick, desc)
	local f = acquire(target.pool, "button", target.canvas, newButton)
	f:SetPoint("TOPLEFT", 0, -y)
	f:SetWidth(target.width)
	local x = controlX()
	f.label:SetWidth(x - 14)
	f.label:SetText(label or "")
	f.btn:ClearAllPoints()
	f.btn:SetPoint("LEFT", x, 0)
	f.btn:SetWidth(math.min(240, math.max(170, target.width - x - 10)))
	f.btn:SetText(text or "")
	f.btn.onClick = onClick
	tooltip(f.btn, label, desc)
	return 32
end

local function addToggle(y, label, value, set, desc)
	local f = acquire(target.pool, "toggle", target.canvas, newToggle)
	f:SetPoint("TOPLEFT", 0, -y)
	f:SetWidth(target.width)
	f.label:SetWidth(target.width - 50)
	f.label:SetText(label)
	f.cb:SetChecked(value and true or false)
	f.set = set
	tooltip(f, label, desc)
	tooltip(f.cb, label, desc)
	return 28
end

-- Anchura de la casilla de una lista desplegable o de un deslizador
local function fieldWidth()
	return math.max(200, math.min(360, target.width - 150))
end

-- Lista desplegable que no es una opción de módulo (valores = { {valor, texto}, ... })
local function addChoice(y, label, values, current, onPick, desc)
	local f = acquire(target.pool, "dropdown", target.canvas, newDropdown)
	f:SetPoint("TOPLEFT", 0, -y)
	f:SetWidth(target.width)
	f.label:SetText(label)
	f.button:SetWidth(fieldWidth())
	f.values = values
	f.get = function() return current end
	f.set = onPick
	local text
	for _, v in ipairs(values) do
		if v[1] == current then text = v[2] break end
	end
	f.button.text:SetText(text or "")
	tooltip(f.button, label, desc)
	return 50
end

local function addInput(y, label, text1, onClick1, text2, onClick2, desc)
	local f = acquire(target.pool, "input", target.canvas, newInput)
	f:SetPoint("TOPLEFT", 0, -y)
	f:SetWidth(target.width)
	f.label:SetText(label)
	-- El marco puede venir de una opción de texto (más ancho y más largo)
	f.edit:SetMaxLetters(32)
	f.edit:SetWidth(170)
	f.btn1:SetWidth(130)
	f.edit:SetText("")
	f.btn1:SetText(text1)
	f.btn2:SetText(text2 or "")
	f.btn2:SetShown(text2 ~= nil)
	f.onClick1, f.onClick2 = onClick1, onClick2
	tooltip(f.edit, label, desc)
	return 32
end

-- Una fila de la lista de addons (página de Rheizor-Core)
local function addAddonRow(y, a)
	local f = acquire(target.pool, "addonrow", target.canvas, newAddonRow)
	f:SetPoint("TOPLEFT", 0, -y)
	f:SetWidth(target.width)

	f.cb:SetShown(hasSwitch(a))
	f.cb:SetChecked(isActive(a.name))
	f.set = function(on)
		setActive(a.name, on)
		M:Refresh()
	end
	tooltip(f.cb, a.short, L["Desactivado, puedes configurarlo pero no hace nada. Se guarda en el perfil y se aplica al recargar la interfaz (/reload)."])

	local x = math.max(150, math.floor(target.width * 0.3))
	f.label:SetWidth(x - 50)
	f.label:SetText(a.short)
	local text, r, g, b = status(a)
	f.state:ClearAllPoints()
	f.state:SetPoint("LEFT", x, 0)
	f.state:SetPoint("RIGHT", f.move, "LEFT", -8, 0)
	f.state:SetText(text)
	f.state:SetTextColor(r, g, b)

	-- Mover solo sus elementos
	local edit = R.modules.editmode
	local canMove = edit and isLoaded(a.name) and R:IsAddonActive(a.name) and edit:HasMovers(a.name)
	f.move:SetText(edit and edit:IsActiveFor(a.name) and L["Bloquear"] or L["Mover"])
	f.move:SetEnabled(canMove and true or false)
	f.move.onClick = function()
		edit:ToggleFor(a.name)
		if edit:IsActiveFor(a.name) then win:Hide() else M:RenderPage() end
	end
	tooltip(f.move, L["Mover"], canMove and L["Desbloquea solo los elementos de este addon para colocarlos. «Terminar» en el panel los vuelve a bloquear."]
		or L["Este addon no tiene nada que mover, o no está activo."])

	-- Ir a sus opciones
	local hasPages = #pagesFor(a.name) > 0
	f.opts:SetText(L["Opciones"])
	f.opts:SetEnabled(true)
	f.opts.onClick = function()
		sel.addon, sel.page = a.name, nil
		expanded[a.name] = true
		M:Refresh()
	end
	tooltip(f.opts, L["Opciones"], hasPages and L["Abre la página de este addon."] or L["Abre la página de este addon (actívalo y recarga para ver sus opciones)."])
	return 30
end

-- Botón que pide un segundo clic antes de hacer algo que no se puede deshacer
local function addConfirmButton(y, id, label, text, onConfirm, desc)
	local isArmed = armed == id
	return addButton(y, label, isArmed and L["|cffff5555¿Seguro? Pulsa otra vez|r"] or text, function()
		if armed == id then
			armed = nil
			onConfirm()
		else
			armed = id
		end
		M:RenderPage()
	end, desc)
end

-- Cómo leer y guardar una opción: en la base de datos del módulo, o en una CVar
local function accessors(mod, opt)
	local get, set
	if opt.cvar or opt.get then
		if not R.OptionAccessors then return end
		get, set = R.OptionAccessors(opt)
	else
		get, set = function() return mod.db[opt.key] end,
			function(value)
				mod.db[opt.key] = value
				R:OptionChanged(mod, opt.key)
			end
	end
	-- refresh = true: otras opciones dependen de esta (se activan o desactivan)
	if set and opt.refresh then
		local raw = set
		set = function(value)
			raw(value)
			C_Timer.After(0, function() M:RenderPage() end)
		end
	end
	return get, set
end

local drawOption
local function addOption(mod, opt, y)
	local t = opt.type
	if t == "note" then
		if opt.available and not opt.available() then return 0 end
		return addText(y, "|cffff8800" .. (opt.text or "") .. "|r", GameFontHighlightSmall, 4)
	end
	lastAcquired = nil
	local h = drawOption(mod, opt, y)
	if t ~= "header" and h > 0 and lastAcquired and opt.disabled then
		local reason = opt.disabled()
		if reason then setDisabled(lastAcquired, opt.name, reason) end
	end
	return h
end

drawOption = function(mod, opt, y)
	local t = opt.type
	if t == "header" then
		return addHeader(y, opt.text)
	elseif t == "button" then
		return addButton(y, opt.name, opt.text, function() R:RunModuleAction(mod, opt.func) end, opt.desc)
	end

	if opt.available and not opt.available() then return 0 end
	local get, set = accessors(mod, opt)
	if not get then
		if opt.optional then return 0 end
		return addText(y, "|cff888888" .. (opt.name or "?") .. L[": no disponible en esta versión|r"], GameFontHighlightSmall, 4)
	end

	local desc = opt.desc
	if opt.reload then
		desc = (desc and (desc .. "\n\n") or "") .. L["|cffff8800Para volver a mostrarlo hace falta /reload.|r"]
	end
	if opt.cvar then
		desc = (desc and (desc .. "\n\n") or "") .. "|cff888888/console " .. opt.cvar .. "|r"
	end

	if t == "toggle" then
		return addToggle(y, opt.name, get(), set, desc)

	elseif t == "slider" then
		local f = acquire(target.pool, "slider", target.canvas, newSlider)
		f:SetPoint("TOPLEFT", 0, -y)
		f:SetWidth(target.width)
		f.label:SetText(opt.name)
		f.slider:SetWidth(fieldWidth())
		f.min, f.max, f.step = opt.min, opt.max, opt.step
		f.format = opt.format or R.fmt.percent
		local value = snap(f, tonumber(get()) or opt.min)
		f.updating = true
		f.slider:SetMinMaxValues(opt.min, opt.max)
		f.slider:SetValueStep(opt.step)
		f.slider:SetValue(value)
		f.updating = false
		f.last = value
		f.value:SetText(f.format(value))
		f.set = set
		tooltip(f.slider, opt.name, desc)
		return 48

	elseif t == "dropdown" then
		local f = acquire(target.pool, "dropdown", target.canvas, newDropdown)
		f:SetPoint("TOPLEFT", 0, -y)
		f:SetWidth(target.width)
		f.label:SetText(opt.name)
		f.button:SetWidth(fieldWidth())
		f.values, f.get, f.set = opt.values, get, set
		local current, text = get(), nil
		for _, v in ipairs(opt.values) do
			if v[1] == current then text = v[2] break end
		end
		f.button.text:SetText(text or tostring(current or ""))
		tooltip(f.button, opt.name, desc)
		return 50

	elseif t == "color" then
		local f = acquire(target.pool, "color", target.canvas, newColor)
		f:SetPoint("TOPLEFT", 0, -y)
		f:SetWidth(target.width)
		f.label:SetWidth(target.width - 40)
		f.label:SetText(opt.name)
		f.hex = get() or opt.default or "ffffff"
		f.default = opt.default or (mod.defaults and opt.key and mod.defaults[opt.key])
		f.set = set
		f.swatch:SetBackdropColor(R.HexToRGB(f.hex))
		tooltip(f.swatch, opt.name, (desc and (desc .. "\n\n") or "") .. L["Clic: elegir color · Clic derecho: el de por defecto"])
		return 28

	elseif t == "text" then
		-- Texto libre: se guarda con el botón o con Intro
		local f = acquire(target.pool, "input", target.canvas, newInput)
		f:SetPoint("TOPLEFT", 0, -y)
		f:SetWidth(target.width)
		f.label:SetText(opt.name)
		f.edit:SetMaxLetters(opt.maxLetters or 255)
		f.edit:SetWidth(math.max(170, target.width - 120 - 100))
		f.edit:SetText(get() or "")
		f.edit:SetCursorPosition(0)
		f.btn1:SetWidth(90)
		f.btn1:SetText(L["Guardar"])
		f.btn2:Hide()
		f.onClick1 = function(text)
			f.edit:ClearFocus()
			set(strtrim(text or ""))
		end
		f.onClick2 = nil
		tooltip(f.edit, opt.name, desc)
		return 32
	end
	return 0
end

----------------------------------------------------------------------
-- Páginas
----------------------------------------------------------------------

local function findAddon(name)
	for _, a in ipairs(collectAddons()) do
		if a.name == name then return a end
	end
end

local function findPage(addon, title)
	for _, p in ipairs(pagesFor(addon)) do
		if p.title == title then return p end
	end
end

-- Opciones de una sección (más abajo); con una sola sección van en la
-- página del addon, sin subentrada en el árbol
local renderMods

local function renderAddon(a)
	local y = 0
	y = y + addText(y, a.title, FONT_TITLE)
	local version = metadata(a.name, "Version")
	y = y + addText(y, "|cff888888" .. a.name .. (version and L["  ·  versión %s"]:format(version) or "") .. "|r", GameFontHighlightSmall)
	local text, r, g, b = status(a)
	y = y + addText(y, string.format("|cff%02x%02x%02x%s|r", r * 255, g * 255, b * 255, text))
	if a.notes and a.notes ~= "" then
		y = y + 4
		y = y + addText(y, a.notes, GameFontHighlightSmall)
	end
	y = y + 8

	if hasSwitch(a) then
		y = y + addToggle(y, L["Activado"], isActive(a.name), function(on)
			setActive(a.name, on)
			M:Refresh()
		end, L["Desactivado, puedes configurarlo pero no hace nada. Se guarda en el perfil y se aplica al recargar la interfaz (/reload)."])
	else
		y = y + addToggle(y, L["Activado en este personaje"], isEnabled(a.name), function(on)
			setEnabled(a.name, on)
			M:Refresh()
		end, L["Se aplica al recargar la interfaz (/reload)."])
	end

	local conflicts = R.FindConflicts and R:FindConflicts(a.name) or {}
	if #conflicts > 0 then
		y = y + 4
		y = y + addText(y, L["|cffff8800Puede chocar con:|r %s. Los dos cambian lo mismo; deja activado solo uno."]:format(table.concat(conflicts, ", ")), GameFontHighlightSmall, 4)
	end

	if a.core then
		y = y + addText(y, L["|cffff8800Sin el núcleo no se carga ningún addon de Rheizor.|r"], GameFontHighlightSmall, 4)
	elseif not usesCore(a.name) then
		y = y + addText(y, L["|cff888888No usa Rheizor-Core: sus opciones están en su propio panel.|r"], GameFontHighlightSmall, 4)
	end

	local pages = pagesFor(a.name)
	if #pages == 1 then
		y = y + 6
		y = y + renderMods(a, pages[1], y)
	elseif #pages > 1 then
		y = y + 6
		y = y + addHeader(y, L["Secciones"])
		for _, p in ipairs(pages) do
			y = y + addButton(y, p.title, L["Abrir"], function()
				sel.page = p.title
				expanded[a.name] = true
				M:Refresh()
			end)
		end
	elseif usesCore(a.name) and not isLoaded(a.name) then
		y = y + 6
		y = y + addText(y, L["Actívalo y recarga la interfaz para configurarlo."], GameFontHighlightSmall, 4)
	end

	-- Lista de todos los addons con botones rápidos: activar, mover solo sus
	-- elementos e ir a sus opciones
	if a.core then
		y = y + 6
		y = y + addHeader(y, L["Addons de Rheizor"])
		y = y + addText(y, L["El interruptor los activa o desactiva (al recargar). «Mover» desbloquea solo los elementos de ese addon."], GameFontHighlightSmall, 4)
		for _, other in ipairs(collectAddons()) do
			if not other.core then y = y + addAddonRow(y, other) end
		end
	end

	-- Activar o desactivar todos los addons de Rheizor de golpe (solo el
	-- interruptor de Rheizor en este perfil: su configuración no se toca)
	if a.core then
		y = y + 6
		y = y + addHeader(y, L["Todos los addons de Rheizor"])
		y = y + addText(y, L["Solo los enciende o apaga en este perfil; su configuración y la plantilla no cambian. Se aplica al recargar la interfaz."], GameFontHighlightSmall, 4)
		local function setAll(on)
			if R.TakeSnapshot then R:TakeSnapshot(on and L["Antes de activar todos"] or L["Antes de desactivar todos"], true) end
			for _, other in ipairs(collectAddons()) do
				if hasSwitch(other) then setActive(other.name, on) end
			end
			M:Refresh()
		end
		y = y + addConfirmButton(y, "alloff", L["Apagarlos todos"], L["Desactivar todos"], function() setAll(false) end,
			L["Desactiva en Rheizor todos sus addons. Siguen cargados en WoW, así que puedes seguir configurándolos."])
		y = y + addButton(y, L["Encenderlos todos"], L["Activar todos"], function() setAll(true) end,
			L["Activa en Rheizor todos sus addons instalados."])
	end

	if a.core and R.OpenWizard and R.SETUP_ENABLED then
		y = y + 6
		y = y + addHeader(y, L["Asistente de instalación"])
		y = y + addButton(y, L["Addons, plantilla y ajustes básicos"], L["Abrir asistente"], function()
			win:Hide()
			R:OpenWizard()
		end, L["Elegir addons, plantilla de distribución y ajustes básicos otra vez. También con /rz asistente."])
	end

	-- Borrar la configuración y volver a empezar con el asistente
	if a.core and R.ResetAll then
		y = y + 6
		y = y + addHeader(y, L["Empezar de nuevo"])
		y = y + addText(y, L["Deja Rheizor en blanco: interfaz de Blizzard y todos los módulos desactivados, para activarlos uno a uno cuando quieras. Consejo: exporta antes tu configuración si quieres poder recuperarla."], GameFontHighlightSmall, 4)
		y = y + addConfirmButton(y, "resetchar", L["Solo este personaje"], L["Empezar de nuevo"], function()
			R:ResetCharacter()
		end, L["Este personaje pasa a tener su propio perfil vacío y sus módulos se desactivan. Los demás personajes y perfiles no cambian."])
		y = y + addConfirmButton(y, "resetall", L["Toda la cuenta"], L["Borrar todo"], function()
			R:ResetAll()
		end, L["Borra todos los perfiles y toda la configuración de Rheizor en esta cuenta y desactiva todos sus módulos en todos los personajes. No deshace los ajustes del juego (/console)."])
	elseif #pages > 0 and R.ShowTransfer then
		y = y + 6
		y = y + addHeader(y, L["Configuración"])
		y = y + addButton(y, L["Solo este addon"], L["Exportar"], function()
			R:ShowTransfer("export", a.name)
		end, L["Crea un texto con la configuración de este addon. Se importa desde la página de Rheizor-Core."])
		y = y + addConfirmButton(y, "reset:" .. a.name, L["Valores por defecto"], L["Restablecer"], function()
			R:ResetAddonConfig(a.name)
		end, L["Borra la configuración de este addon (solo en el perfil actual) y recarga la interfaz."])
	end
	return y
end

-- Contenido propio de algunas secciones (módulos con "panel"), además de
-- sus opciones normales

-- Perfiles (sección "Perfiles" de Rheizor-Core)
local function renderProfiles(y)
	local y0 = y
	if R.GetProfiles then
		y = y + addText(y, L["Cada personaje usa un perfil con toda la configuración de Rheizor. Al cambiar de perfil se recarga la interfaz."], GameFontHighlightSmall, 4)
		local values, others = {}, {}
		for _, name in ipairs(R:GetProfiles()) do
			local v = { name, R:ProfileLabel(name) }
			values[#values + 1] = v
			if name ~= R.profile then others[#others + 1] = v end
		end
		y = y + addChoice(y, L["Perfil de este personaje"], values, R.profile, function(name)
			if name ~= R.profile then R:SetProfile(name) end
		end)
		local users = R:ProfileUsers(R.profile)
		if #users > 0 then
			y = y + addText(y, "|cff888888" .. L["Lo usan: %s"]:format(table.concat(users, ", ")) .. "|r", GameFontHighlightSmall, 4)
		end
		y = y + 4
		y = y + addInput(y, L["Perfil nuevo"], L["Copia del actual"], function(text) R:NewProfile(text, true) end,
			L["Vacío"], function(text) R:NewProfile(text, false) end,
			L["Escribe un nombre. «Copia del actual» empieza con tu configuración de ahora; «Vacío», con los valores por defecto. El personaje pasa a usarlo."])

		if #others > 0 then
			local valid = false
			for _, v in ipairs(others) do
				if v[1] == profileTarget then valid = true end
			end
			if not valid then profileTarget = others[1][1] end
			y = y + 4
			y = y + addChoice(y, L["Otro perfil"], others, profileTarget, function(name)
				profileTarget = name
				armed = nil
				M:RenderPage()
			end)
			-- Se dice con nombres qué perfil se machaca: es fácil pensar que va al revés
			local mine, theirs = R:ProfileLabel(R.profile), R:ProfileLabel(profileTarget)
			y = y + addConfirmButton(y, "copy", L["Sustituir «%s» por una copia de «%s»"]:format(mine, theirs), L["Copiar"], function()
				R:CopyProfile(profileTarget)
			end, L["Todo lo de «%s» (el perfil de este personaje) se borra y queda igual que «%s». «%s» no cambia. Antes se guarda una copia de seguridad."]:format(mine, theirs, theirs))
			y = y + addConfirmButton(y, "delete", L["Borrar ese perfil"], L["Borrar"], function()
				R:DeleteProfile(profileTarget)
				profileTarget = nil
			end, L["Los personajes que lo usaban pasan al perfil por defecto."])
		end
	end
	return y - y0
end

-- Copias de seguridad, exportar e importar (sección "Copias de seguridad")
local function renderBackups(y)
	local y0 = y
	if R.GetSnapshotList then
		y = y + addHeader(y, L["Historial"])
		y = y + addText(y, L["Historial de este perfil para volver atrás si algo sale mal. Se guarda una copia sola al entrar (si algo ha cambiado) y antes de importar, restablecer, usar el asistente o restaurar."], GameFontHighlightSmall, 4)
		y = y + addInput(y, L["Copia nueva"], L["Guardar"], function(text)
			R:SaveSnapshot(text)
			M:RenderPage()
		end, nil, nil, L["Escribe un nombre (opcional) y pulsa Guardar."])
		local snaps = R:GetSnapshotList()
		if #snaps == 0 then
			y = y + addText(y, "|cff888888" .. L["Todavía no hay copias."] .. "|r", GameFontHighlightSmall, 4)
		else
			local values, valid = {}, false
			for _, e in ipairs(snaps) do
				values[#values + 1] = { e.snap.id, R:SnapshotLabel(e) }
				if e.snap.id == snapshotTarget then valid = true end
			end
			if not valid then snapshotTarget = values[1][1] end
			y = y + 4
			y = y + addChoice(y, L["Copia"], values, snapshotTarget, function(id)
				snapshotTarget = id
				armed = nil
				M:RenderPage()
			end)
			y = y + addConfirmButton(y, "snaprestore", L["Volver a esta copia"], L["Restaurar"], function()
				R:RestoreSnapshot(snapshotTarget)
			end, L["Deja el perfil actual como estaba en esa copia y recarga la interfaz. Antes se guarda una copia de cómo está ahora."])
			y = y + addConfirmButton(y, "snapdelete", L["Borrar esta copia"], L["Borrar"], function()
				R:DeleteSnapshot(snapshotTarget)
				snapshotTarget = nil
			end)
		end
	end

	-- Copiar la configuración a otro personaje o cuenta
	if R.ShowTransfer then
		y = y + 6
		y = y + addHeader(y, L["Exportar e importar"])
		y = y + addButton(y, L["Toda la configuración"], L["Exportar"], function()
			R:ShowTransfer("export")
		end, L["Crea un texto con la configuración de todos los addons de Rheizor para copiarlo en otro personaje, otra cuenta o pasárselo a alguien."])
		y = y + addButton(y, L["Pegar un texto exportado"], L["Importar"], function()
			R:ShowTransfer("import")
		end, L["Sustituye la configuración de los addons que incluya el texto y recarga la interfaz."])
	end
	return y - y0 + 6
end

local PANELS = { profiles = renderProfiles, backups = renderBackups }

local function renderPage(a, p)
	local y = 0
	y = y + addText(y, p.title, FONT_TITLE)
	y = y + addText(y, "|cff888888" .. a.short .. "|r", GameFontHighlightSmall)
	y = y + 4
	if hasSwitch(a) and not R:IsAddonActive(a.name) then
		y = y + addText(y, L["|cffff8800Desactivado en Rheizor:|r puedes configurarlo, pero no se aplica hasta que lo actives."], GameFontHighlightSmall, 4)
		y = y + addButton(y, "", L["Activar"], function()
			setActive(a.name, true)
			M:Refresh()
		end)
		y = y + 4
	end
	return y + renderMods(a, p, y)
end

-- Devuelve la altura que ocupa, empezando en y
function renderMods(a, p, y)
	local y0 = y
	for _, mod in ipairs(p.mods) do
		if #p.mods > 1 then
			y = y + 6
			y = y + addText(y, accentCode() .. mod.title .. "|r", GameFontNormal)
		end
		-- Contenido propio de la sección (perfiles, copias…), antes de sus opciones
		local panel = mod.panel and PANELS[mod.panel]
		if panel then
			local ok, h = pcall(panel, y)
			if ok then
				y = y + (h or 0)
			else
				y = y + addText(y, "|cffff5555" .. tostring(h) .. "|r", GameFontHighlightSmall, 4)
			end
		end
		for _, opt in ipairs(mod.options) do
			local ok, h = pcall(addOption, mod, opt, y)
			if ok then
				y = y + (h or 0)
			else
				y = y + addText(y, "|cffff5555" .. (opt.name or opt.key or "?") .. ": " .. tostring(h) .. "|r", GameFontHighlightSmall, 4)
			end
		end
		-- Lo que no se puede hacer en WoW Forever, para que nadie lo busque
		if type(mod.unsupported) == "table" and #mod.unsupported > 0 then
			y = y + 6
			y = y + addHeader(y, L["No disponible en WoW Forever"])
			for _, text in ipairs(mod.unsupported) do
				y = y + addText(y, "|cff999999• " .. text .. "|r", GameFontHighlightSmall, 4)
			end
		end
	end
	return y - y0
end

local function openPage(addon, title)
	-- Con una sola sección, sus opciones están en la página del addon
	if #pagesFor(addon) <= 1 then title = nil end
	sel.addon, sel.page = addon, title
	expanded[addon] = true
	if win.search:GetText() ~= "" then
		win.search:SetText("")   -- su OnTextChanged ya redibuja
		win.search:ClearFocus()
	end
	M:Refresh()
end

-- Opciones de todos los addons cargados que contienen el texto buscado
local function renderSearch(q)
	local y = 0
	y = y + addText(y, L["Resultados de «%s»"]:format(strtrim(win.search:GetText())), FONT_TITLE)
	local found = 0
	for _, a in ipairs(collectAddons()) do
		for _, p in ipairs(pagesFor(a.name)) do
			local pageHit = matches(q, p.title, a.short)
			local shown = false
			for _, mod in ipairs(p.mods) do
				local modHit = pageHit or matches(q, mod.title)
				for _, opt in ipairs(mod.options) do
					if opt.type ~= "header" and (modHit or optionMatches(q, opt)) then
						if not shown then
							shown = true
							y = y + 8
							y = y + addButton(y, accentCode() .. a.short .. " · " .. p.title .. "|r", L["Ir a la sección"], function()
								openPage(a.name, p.title)
							end)
						end
						local ok, h = pcall(addOption, mod, opt, y)
						if ok then y = y + (h or 0) end
						found = found + 1
					end
				end
			end
		end
	end
	if found == 0 then
		y = y + addText(y, L["No hay ninguna opción con ese texto en los addons cargados."], GameFontHighlightSmall, 4)
	end
	return y
end

-- Ancho útil de la página: sigue al tamaño de la ventana, con un tope para
-- que las líneas largas se sigan leyendo bien
local function pageWidth()
	local w = page and page:GetWidth() or 0
	if not w or w < 100 then return PAGE_W end
	return math.floor(math.min(MAX_PAGE_W, w - 24))
end

function M:RenderPage()
	release("page")
	closePopup()
	local width = pageWidth()
	page.child:SetWidth(width + 10)
	target = { pool = "page", canvas = page.child, width = width }
	if query ~= "" then
		local key = "search\001" .. query
		if key ~= lastShown then armed = nil end
		page.child:SetHeight(math.max(1, renderSearch(query) + 16))
		if key ~= lastShown then
			lastShown = key
			page:ScrollTo(0)
		else
			page:ScrollTo(page:GetVerticalScroll())
		end
		return
	end
	local a = sel.addon and findAddon(sel.addon)
	if not a then
		local list = collectAddons()
		a = list[1]
		if not a then return end
		sel.addon, sel.page = a.name, nil
	end
	local p = sel.page and #pagesFor(a.name) > 1 and findPage(a.name, sel.page)
	if sel.page and not p then sel.page = nil end

	local key = a.name .. "\001" .. (sel.page or "")
	if key ~= lastShown then armed = nil end

	local y = p and renderPage(a, p) or renderAddon(a)
	page.child:SetHeight(math.max(1, y + 16))

	if key ~= lastShown then
		lastShown = key
		page:ScrollTo(0)
	else
		page:ScrollTo(page:GetVerticalScroll())
	end
end

----------------------------------------------------------------------
-- Árbol de la izquierda
----------------------------------------------------------------------

local function newRow(parent)
	local b = CreateFrame("Button", nil, parent)
	b:SetHeight(20)
	-- Seleccionada: fondo suave y una raya a la izquierda del color de acento
	b.sel = b:CreateTexture(nil, "BACKGROUND")
	b.sel:SetAllPoints()
	local bar = b:CreateTexture(nil, "ARTWORK")
	bar:SetPoint("TOPLEFT")
	bar:SetPoint("BOTTOMLEFT")
	bar:SetWidth(3)
	onAccent(function(r, g, bb)
		b.sel:SetColorTexture(r, g, bb, 0.16)
		bar:SetColorTexture(r, g, bb, 1)
	end)
	hooksecurefunc(b.sel, "SetShown", function(_, shown) bar:SetShown(shown) end)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	b.dot = b:CreateTexture(nil, "ARTWORK")
	b.dot:SetSize(8, 8)
	b.dot:SetPoint("LEFT", 6, 0)
	b.dot:SetTexture(WHITE)
	b.arrow = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	b.arrow:SetPoint("RIGHT", -8, 0)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	b.text:SetJustifyH("LEFT")
	b.text:SetWordWrap(false)
	b:SetScript("OnClick", function(self) if self.onClick then self.onClick() end end)
	return b
end

function M:RenderTree()
	release("tree")
	local child = tree.child
	local width = LEFT_W - 14
	local y = 0
	for _, a in ipairs(collectAddons()) do
		local pages = pagesFor(a.name)
		local text, r, g, b = status(a)
		local row = acquire("tree", "row", child, newRow)
		row:SetPoint("TOPLEFT", 0, -y)
		row:SetWidth(width)
		row:SetHeight(24)
		row.dot:Show()
		row.dot:SetVertexColor(r, g, b)
		row.text:SetFontObject(GameFontNormal)
		row.text:ClearAllPoints()
		row.text:SetPoint("LEFT", 20, 0)
		row.text:SetPoint("RIGHT", -18, 0)
		local conflicts = R.FindConflicts and R:FindConflicts(a.name) or {}
		row.text:SetText(a.short .. (#conflicts > 0 and " |cffff8800!|r" or ""))
		-- Subentradas solo si hay más de una sección
		local sub = #pages > 1
		row.arrow:SetText(sub and (expanded[a.name] and "-" or "+") or "")
		row.sel:SetShown(query == "" and sel.addon == a.name and not sel.page)
		local tip = text .. (a.notes and ("\n" .. a.notes) or "")
		if #conflicts > 0 then
			tip = tip .. "\n\n" .. L["|cffff8800Puede chocar con:|r %s. Los dos cambian lo mismo; deja activado solo uno."]:format(table.concat(conflicts, ", "))
		end
		tooltip(row, a.short, tip)
		row.onClick = function()
			if query ~= "" then
				openPage(a.name, nil)
				return
			end
			if sel.addon == a.name and not sel.page then
				expanded[a.name] = not expanded[a.name]
			else
				expanded[a.name] = true
			end
			sel.addon, sel.page = a.name, nil
			M:Refresh()
		end
		y = y + 24

		if sub and expanded[a.name] then
			for _, p in ipairs(pages) do
				local pr = acquire("tree", "row", child, newRow)
				pr:SetPoint("TOPLEFT", 0, -y)
				pr:SetWidth(width)
				pr:SetHeight(20)
				pr.dot:Hide()
				pr.text:SetFontObject(GameFontHighlightSmall)
				pr.text:ClearAllPoints()
				pr.text:SetPoint("LEFT", 28, 0)
				pr.text:SetPoint("RIGHT", -6, 0)
				pr.text:SetText(p.title)
				pr.arrow:SetText("")
				pr.sel:SetShown(query == "" and sel.addon == a.name and sel.page == p.title)
				tooltip(pr, nil, nil)
				pr.onClick = function() openPage(a.name, p.title) end
				y = y + 20
			end
		end
	end
	child:SetHeight(math.max(1, y))
	tree:ScrollTo(tree:GetVerticalScroll())
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

function M:Refresh()
	if not (win and win:IsShown()) then return end
	self:RenderTree()
	self:RenderPage()
	win.pending:SetShown(anyPending())
end

local function footerButton(text, width, onClick)
	local b = flatButton(win, width, 24)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	return b
end

local function savePlace()
	win:SetUserPlaced(false)
	local point, _, relPoint, x, y = win:GetPoint()
	db.point = { point, relPoint, x, y }
end

local function saveSize()
	db.size = { math.floor(win:GetWidth() + 0.5), math.floor(win:GetHeight() + 0.5) }
end

-- Tamaño que cabe en pantalla (con la escala de la ventana)
local function fitSize(w, h)
	local scale = win:GetScale()
	local maxW = UIParent:GetWidth() / scale - 20
	local maxH = UIParent:GetHeight() / scale - 20
	return math.max(MIN_W, math.min(maxW, w)), math.max(MIN_H, math.min(maxH, h))
end

-- Doble clic en el título: casi toda la pantalla, o vuelta al tamaño de antes
local function toggleMaximized()
	if db.maximized then
		db.maximized = nil
		M:Apply()
	else
		db.maximized = true
		win:ClearAllPoints()
		win:SetPoint("CENTER")
		local scale = win:GetScale()
		win:SetSize(fitSize(UIParent:GetWidth() / scale * 0.92, UIParent:GetHeight() / scale * 0.9))
	end
end

-- Botón plano pequeño de la barra del título (cerrar, maximizar)
local function titleButton(parent, text, onClick, danger)
	-- Hijo de la barra del título y por encima: si no, la barra (que también
	-- es un botón, para arrastrar la ventana) se quedaba con el clic
	local b = CreateFrame("Button", nil, parent)
	b:SetFrameLevel(parent:GetFrameLevel() + 5)
	b:RegisterForClicks("LeftButtonUp")
	b:SetSize(26, 26)
	local bg = b:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(1, 1, 1, 0)
	local fs = b:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	fs:SetPoint("CENTER")
	fs:SetText(text)
	fs:SetTextColor(0.7, 0.7, 0.75)
	b:SetScript("OnEnter", function()
		if danger then bg:SetColorTexture(0.8, 0.15, 0.15, 0.8) else bg:SetColorTexture(1, 1, 1, 0.1) end
		fs:SetTextColor(1, 1, 1)
	end)
	b:SetScript("OnLeave", function()
		bg:SetColorTexture(1, 1, 1, 0)
		fs:SetTextColor(0.7, 0.7, 0.75)
	end)
	b:SetScript("OnClick", onClick)
	return b
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorManager", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:SetResizable(true)
	if win.SetResizeBounds then
		win:SetResizeBounds(MIN_W, MIN_H)
	elseif win.SetMinResize then
		win:SetMinResize(MIN_W, MIN_H)
	end
	win:EnableMouse(true)
	flatBackdrop(win, BG_WIN, { 0, 0, 0 }, 0.97)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorManager")   -- se cierra con Esc

	-- Barra de título: se arrastra para mover, doble clic para maximizar
	local bar = CreateFrame("Button", nil, win, "BackdropTemplate")
	bar:SetPoint("TOPLEFT", 1, -1)
	bar:SetPoint("TOPRIGHT", -1, -1)
	bar:SetHeight(40)
	bar:SetBackdrop({ bgFile = WHITE })
	bar:SetBackdropColor(BG_BAR[1], BG_BAR[2], BG_BAR[3], 1)
	bar:RegisterForDrag("LeftButton")
	bar:SetScript("OnDragStart", function() win:StartMoving() end)
	bar:SetScript("OnDragStop", function()
		win:StopMovingOrSizing()
		db.maximized = nil
		savePlace()
	end)
	bar:SetScript("OnDoubleClick", toggleMaximized)
	local line = bar:CreateTexture(nil, "ARTWORK")
	line:SetPoint("BOTTOMLEFT")
	line:SetPoint("BOTTOMRIGHT")
	line:SetHeight(2)
	onAccent(function(r, g, b) line:SetColorTexture(r, g, b, 0.85) end)

	local logo = bar:CreateTexture(nil, "ARTWORK")
	logo:SetSize(4, 18)
	logo:SetPoint("LEFT", 14, 0)
	onAccent(function(r, g, b) logo:SetColorTexture(r, g, b, 1) end)
	local title = bar:CreateFontString(nil, "OVERLAY")
	title:SetFontObject(FONT_LOGO)
	title:SetPoint("LEFT", logo, "RIGHT", 8, 0)
	title:SetText("RHEIZOR")
	local sub = bar:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	sub:SetPoint("LEFT", title, "RIGHT", 10, -1)
	sub:SetText(L["Gestor de addons y opciones  ·  núcleo %s"]:format(metadata(R.ADDON, "Version") or ""))

	local close = titleButton(bar, "X", function() win:Hide() end, true)
	close:SetPoint("RIGHT", bar, "RIGHT", -8, 0)
	local maxBtn = titleButton(bar, "[ ]", toggleMaximized)
	maxBtn:SetPoint("RIGHT", close, "LEFT", -4, 0)
	tooltip(maxBtn, L["Maximizar"], L["Agranda la ventana a casi toda la pantalla, o la devuelve a su tamaño. También con doble clic en la barra del título."])

	-- Columna izquierda: addons y sus secciones
	local left = CreateFrame("Frame", nil, win, "BackdropTemplate")
	left:SetPoint("TOPLEFT", 1, -42)
	left:SetPoint("BOTTOMLEFT", 1, 49)
	left:SetWidth(LEFT_W)
	left:SetBackdrop({ bgFile = WHITE })
	left:SetBackdropColor(BG_SIDE[1], BG_SIDE[2], BG_SIDE[3], 1)
	local divider = win:CreateTexture(nil, "ARTWORK")
	divider:SetPoint("TOPLEFT", left, "TOPRIGHT")
	divider:SetPoint("BOTTOMLEFT", left, "BOTTOMRIGHT")
	divider:SetWidth(1)
	divider:SetColorTexture(1, 1, 1, 0.07)
	-- Buscador de opciones
	local search = CreateFrame("EditBox", nil, left, "BackdropTemplate")
	search:SetPoint("TOPLEFT", 10, -10)
	search:SetPoint("TOPRIGHT", -10, -10)
	search:SetHeight(24)
	flatBackdrop(search, BG_FIELD, EDGE)
	search:SetFontObject(GameFontHighlightSmall)
	search:SetTextInsets(24, 6, 0, 0)
	search:SetAutoFocus(false)
	search:SetMaxLetters(40)
	search:SetScript("OnEditFocusGained", function(self) self:SetBackdropBorderColor(AR, AG, AB, 1) end)
	search:SetScript("OnEditFocusLost", function(self) self:SetBackdropBorderColor(EDGE[1], EDGE[2], EDGE[3], 1) end)
	local glass = search:CreateTexture(nil, "OVERLAY")
	glass:SetSize(14, 14)
	glass:SetPoint("LEFT", 6, 0)
	glass:SetTexture("Interface\\Common\\UI-Searchbox-Icon")
	glass:SetVertexColor(0.6, 0.6, 0.65)
	local hint = search:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("LEFT", 24, 0)
	hint:SetText(L["Buscar opción..."])
	search:SetScript("OnTextChanged", function(self)
		local text = strtrim(self:GetText())
		hint:SetShown(self:GetText() == "")
		-- Con una sola letra saldría casi todo
		local q = #text >= 2 and normalize(text) or ""
		if q ~= query then
			query = q
			M:Refresh()
		end
	end)
	search:SetScript("OnEscapePressed", function(self)
		if self:GetText() ~= "" then self:SetText("") else self:ClearFocus() end
	end)
	search:SetScript("OnEnterPressed", search.ClearFocus)
	win.search = search

	tree = makeScroll(left)
	tree:SetPoint("TOPLEFT", 4, -44)
	tree:SetPoint("BOTTOMRIGHT", -4, 6)
	tree.child:SetWidth(LEFT_W - 8)

	-- Derecha: la página seleccionada
	local right = CreateFrame("Frame", nil, win)
	right:SetPoint("TOPLEFT", left, "TOPRIGHT", 1, 0)
	right:SetPoint("BOTTOMRIGHT", -1, 49)
	page = makeScroll(right)
	page:SetPoint("TOPLEFT", 24, -18)
	page:SetPoint("BOTTOMRIGHT", -8, 10)
	page.child:SetWidth(PAGE_W + 10)

	-- Pie
	local foot = CreateFrame("Frame", nil, win, "BackdropTemplate")
	foot:SetPoint("BOTTOMLEFT", 1, 1)
	foot:SetPoint("BOTTOMRIGHT", -1, 1)
	foot:SetHeight(48)
	foot:SetBackdrop({ bgFile = WHITE })
	foot:SetBackdropColor(BG_BAR[1], BG_BAR[2], BG_BAR[3], 1)
	local footLine = foot:CreateTexture(nil, "ARTWORK")
	footLine:SetPoint("TOPLEFT")
	footLine:SetPoint("TOPRIGHT")
	footLine:SetHeight(1)
	footLine:SetColorTexture(1, 1, 1, 0.07)

	local edit = footerButton(L["Modo edición"], 130, function()
		if R.modules.editmode then
			win:Hide()
			R.modules.editmode:Enter()
		end
	end)
	edit:SetPoint("BOTTOMLEFT", 12, 12)
	local blizz = footerButton(L["Opciones de Blizzard"], 160, function()
		win:Hide()
		R:OpenOptions()
	end)
	blizz:SetPoint("LEFT", edit, "RIGHT", 6, 0)

	local reload = footerButton(L["Recargar interfaz"], 150, ReloadUI)
	reload:SetPoint("BOTTOMRIGHT", -26, 12)
	win.pending = win:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	win.pending:SetPoint("RIGHT", reload, "LEFT", -10, 0)
	win.pending:SetText(L["|cffff8800Hay cambios que se aplican al recargar|r"])

	-- Esquina para cambiar el tamaño
	local grip = CreateFrame("Button", nil, win)
	grip:SetSize(16, 16)
	grip:SetPoint("BOTTOMRIGHT", -3, 3)
	grip:SetFrameLevel(foot:GetFrameLevel() + 5)
	grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
	grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
	grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
	grip:SetScript("OnMouseDown", function(_, button)
		if button == "LeftButton" then
			closePopup()
			win:StartSizing("BOTTOMRIGHT")
		end
	end)
	grip:SetScript("OnMouseUp", function()
		win:StopMovingOrSizing()
		db.maximized = nil
		saveSize()
		savePlace()
		M:RenderPage()
	end)
	tooltip(grip, L["Tamaño"], L["Arrastra para agrandar o encoger la ventana."])

	-- Al cambiar de tamaño, la página se vuelve a dibujar con el ancho nuevo
	-- (como mucho cada décima de segundo mientras se arrastra)
	local resizePending
	win:SetScript("OnSizeChanged", function()
		if resizePending or not win:IsShown() then return end
		resizePending = true
		C_Timer.After(0.1, function()
			resizePending = nil
			if win:IsShown() then M:RenderPage() end
		end)
	end)

	win:SetScript("OnShow", function() M:Refresh() end)
	win:SetScript("OnHide", closePopup)
end

function M:Apply()
	if not win then return end
	-- Si el arranque falló antes de su OnEnable, el gestor tiene que abrirse igual
	db = db or M.db
	setAccent(db.accent)
	win:SetScale(db.scale)
	win:SetAlpha(db.alpha)
	win:ClearAllPoints()
	if db.maximized then
		db.maximized = nil
		toggleMaximized()
		return
	end
	local s = db.size
	if type(s) == "table" and tonumber(s[1]) and tonumber(s[2]) then
		win:SetSize(fitSize(s[1], s[2]))
	else
		win:SetSize(fitSize(W, H))
	end
	local p = db.point
	if p then
		win:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	else
		win:SetPoint("CENTER")
	end
end

function M:ResetPosition()
	db.point, db.size, db.maximized = nil, nil, nil
	self:Apply()
end

function M:Toggle()
	if not win then
		createWindow()
		self:Apply()
	end
	if win:IsShown() then
		win:Hide()
	else
		if not sel.addon then
			sel.addon = R.ADDON
			expanded[R.ADDON] = true
		end
		win:Show()
	end
end

function R:OpenManager()
	M:Toggle()
end

-- Abre el gestor en la página de un módulo (el engranaje de los recuadros de mover)
function R:OpenModuleOptions(mod)
	if not win then
		createWindow()
		M:Apply()
	end
	local title = mod.group or mod.title
	sel.addon = mod.addon
	sel.page = #pagesFor(mod.addon) > 1 and title or nil
	expanded[mod.addon] = true
	if win.search:GetText() ~= "" then
		win.search:SetText("")
		win.search:ClearFocus()
	end
	if win:IsShown() then M:Refresh() else win:Show() end
end

function M:OnEnable()
	db = self.db
	setAccent(db.accent)
end

-- Piezas que usa también el asistente de instalación (Wizard.lua)
R.UI = {
	-- Dibujar en otro sitio: { pool = "nombre", canvas = marco, width = ancho }
	Use = function(t) target = t end,
	Release = release,
	ClosePopup = closePopup,
	-- Lista desplegable: (dueño, { {valor, texto}, … }, actual, function(valor, texto))
	OpenPopup = openPopup,
	MakeScroll = makeScroll,
	SetBackdrop = setBackdrop,
	Tooltip = tooltip,
	Text = addText,
	Header = addHeader,
	Button = addButton,
	Toggle = addToggle,
	Choice = addChoice,
	Option = addOption,
	-- Addons instalados
	CollectAddons = collectAddons,
	IsLoaded = isLoaded,
	IsEnabled = isEnabled,
	IsActive = isActive,
	SetActive = setActive,
	HasSwitch = hasSwitch,
	Status = status,
	UsesCore = usesCore,
}

function M:OnOptionChanged(key)
	-- Sin redibujar la página: se puede estar arrastrando el deslizador
	if key == "accent" then
		setAccent(db.accent)
		-- El icono del minimapa en estilo plano también lleva este color
		local icon = R.modules.minimapicon
		if icon and R:IsModuleRunning(icon) then icon:Apply() end
		return
	end
	if not win then return end
	win:SetScale(db.scale)
	win:SetAlpha(db.alpha)
end
