-- Barras: seguimiento (experiencia/reputación), grifos, micromenú y bolsas,
-- y barras de acción que solo se ven al pasar el ratón por encima.

local R = Rheizor:Namespace(...)
local L = R.L

-- Barras que se pueden poner "al pasar el ratón" (se prueba cada nombre en orden)
local FADE_BARS = {
	{ key = "fadeMain",   name = "Barra principal (1)",   frames = { "MainActionBar", "MainMenuBar" } },
	{ key = "fadeBar2",   name = "Barra 2 (abajo izquierda)", frames = { "MultiBarBottomLeft" } },
	{ key = "fadeBar3",   name = "Barra 3 (abajo derecha)",   frames = { "MultiBarBottomRight" } },
	{ key = "fadeBar4",   name = "Barra 4 (derecha)",     frames = { "MultiBarRight" } },
	{ key = "fadeBar5",   name = "Barra 5 (derecha 2)",   frames = { "MultiBarLeft" } },
	{ key = "fadeBar6",   name = "Barra 6",               frames = { "MultiBar5" } },
	{ key = "fadeBar7",   name = "Barra 7",               frames = { "MultiBar6" } },
	{ key = "fadeBar8",   name = "Barra 8",               frames = { "MultiBar7" } },
	{ key = "fadeStance", name = "Barra de posturas/formas", frames = { "StanceBar", "StanceBarFrame" } },
	{ key = "fadePet",    name = "Barra de mascota",      frames = { "PetActionBar", "PetActionBarFrame" } },
	{ key = "fadeMicro",  name = "Micromenú",             frames = { "MicroMenuContainer" } },
	{ key = "fadeBags",   name = "Barra de bolsas",       frames = { "BagsBar" } },
	-- Estas no tienen botones fijos: se mira el ratón 5 veces por segundo, solo si están marcadas
	{ key = "fadeXP",     name = "Barra de experiencia",  frames = { "MainStatusTrackingBarContainer", "MainMenuExpBar" }, poll = true },
	{ key = "fadeXP2",    name = "Barra secundaria (reputación)", frames = { "SecondaryStatusTrackingBarContainer", "ReputationWatchBar" }, poll = true },
	{ key = "fadeQuests", name = "Seguimiento de misiones", frames = { "ObjectiveTrackerFrame", "QuestWatchFrame", "WatchFrame" }, poll = true },
	{ key = "fadeQuestie", name = "Seguimiento de Questie", frames = { "Questie_BaseFrame", "QuestieTrackerBaseFrame" }, poll = true,
	  desc = "Solo si usas el addon Questie." },
}

local defaults = {
	hideMainTracking = false,
	hideSecondaryTracking = false,
	hideGryphons = false,
	hideMicroMenu = false,
	hideBagsBar = false,
	fadeAlpha = 0,
	fadeCombat = false,
	fadeTogether = false,
	dmHover = "off",   -- medidor de daño (DamageMeter.lua)
}
for _, b in ipairs(FADE_BARS) do defaults[b.key] = false end

-- La posición, el tamaño y el número de botones de las barras se cambian en
-- el Modo edición del juego; aquí solo se ocultan adornos y se atenúan barras
local options = {
	{ type = "header", text = "Ocultar elementos" },
	{ type = "toggle", key = "hideMainTracking", name = "Ocultar barra de experiencia", reload = true,
	  desc = "Oculta la barra de seguimiento principal (experiencia; al nivel máximo muestra la reputación vigilada)." },
	{ type = "toggle", key = "hideSecondaryTracking", name = "Ocultar barra secundaria", reload = true,
	  desc = "Oculta la segunda barra de seguimiento (normalmente la reputación vigilada mientras subes de nivel)." },
	{ type = "toggle", key = "hideGryphons", name = "Ocultar grifos", reload = true,
	  desc = "Oculta los adornos (grifos/wyverns) a los lados de la barra de acción principal. El Modo edición del juego también puede ocultarlos uno a uno." },
	{ type = "toggle", key = "hideMicroMenu", name = "Ocultar micromenú", reload = true,
	  desc = "Oculta los botones de personaje, hechizos, talentos, etc. Los atajos de teclado siguen funcionando." },
	{ type = "toggle", key = "hideBagsBar", name = "Ocultar barra de bolsas", reload = true,
	  desc = "Oculta los iconos de bolsas. La tecla B sigue abriéndolas." },

	{ type = "header", text = "Ver al pasar el ratón" },
	{ type = "slider", key = "fadeAlpha", name = "Opacidad sin ratón", min = 0, max = 0.8, step = 0.05,
	  desc = "0% = invisibles del todo. Aun invisibles, los botones se pueden pulsar y sus teclas funcionan." },
	{ type = "toggle", key = "fadeCombat", name = "Mostrarlas siempre en combate" },
	{ type = "toggle", key = "fadeTogether", name = "Mostrar todas a la vez",
	  desc = "Al pasar el ratón por una de estas barras aparecen todas las que tengas marcadas." },

	{ type = "header", text = "Barras que se ocultan hasta pasar el ratón" },
}
for _, b in ipairs(FADE_BARS) do
	options[#options + 1] = { type = "toggle", key = b.key, name = b.name, desc = b.desc }
end
options[#options + 1] = { type = "dropdown", key = "dmHover", name = "Medidor de daño de Blizzard",
	values = {
		{ "off", "Siempre visible" },
		{ "header", "Solo la cabecera (engranaje y menús)" },
		{ "window", "Toda la ventana" },
	},
	desc = "Qué parte del medidor de daño se oculta hasta pasar el ratón. Con un menú del medidor abierto o en el Modo edición se ve siempre." }

local M = R:RegisterModule("bars", {
	title = "Barras",
	defaults = defaults,
	options = options,
})

local db
local bars = {}        -- { conf, frame, alpha, target }
local hovered = {}     -- barra -> true mientras el ratón está encima
local inCombat, dragging, editing = false, false, false
local busy = false
local FADE_TIME = 0.2

-- Los ganchos no se pueden quitar: con el addon apagado en Rheizor siguen
-- llamándose, pero no hacen nada (y las barras vuelven a verse del todo)
local started
local function running()
	return started and R:IsAddonActive(M.addon)
end

----------------------------------------------------------------------
-- Fundido (un único OnUpdate que solo corre mientras algo se anima)
----------------------------------------------------------------------

local fader = CreateFrame("Frame")
fader:Hide()

local function setAlpha(b, a)
	b.alpha = a
	busy = true
	b.frame:SetAlpha(a)
	busy = false
end

fader:SetScript("OnUpdate", function(self, elapsed)
	local step = elapsed / FADE_TIME
	local moving = false
	for _, b in ipairs(bars) do
		if b.alpha ~= b.target then
			local a = b.alpha < b.target and math.min(b.target, b.alpha + step) or math.max(b.target, b.alpha - step)
			setAlpha(b, a)
			moving = true
		end
	end
	if not moving then self:Hide() end
end)

local lastBar            -- última barra en la que estuvo el ratón
local checkLater

-- true si el ratón está sobre la barra; el segundo valor indica que no está
-- sobre un botón (hueco entre botones, menú desplegable) y hay que volver a mirar
local function mouseOn(b)
	if hovered[b] then return true end
	if b.frame:IsMouseOver() then return true, true end
	-- Menú desplegable de hechizos (portales, tótems...) abierto desde esta barra
	local flyout = SpellFlyout
	if b == lastBar and flyout and flyout:IsShown() and flyout:IsMouseOver() then return true, true end
	return false
end

-- Las barras de experiencia y reputación se funden con animaciones propias de
-- Blizzard (al cambiar de barra, al entrar al mundo…), que no pasan por
-- SetAlpha: al terminar se quedaban visibles hasta pasar el ratón
local function blizzAnimating(frame)
	if not frame.GetAnimationGroups then return false end
	for _, g in ipairs({ frame:GetAnimationGroups() }) do
		if g:IsPlaying() then return true end
	end
	return false
end

function M:Evaluate()
	local recheck = false
	local anyHover = false
	local active = running()
	if active and db.fadeTogether then
		for _, b in ipairs(bars) do
			if db[b.conf.key] then
				local on, loose = mouseOn(b)
				if on then anyHover = true recheck = recheck or loose end
			end
		end
	end
	for _, b in ipairs(bars) do
		local target = 1
		if active and db[b.conf.key] then
			local over, loose = mouseOn(b)
			recheck = recheck or loose
			-- En el Modo edición del juego se ven todas, para poder colocarlas
			local show = dragging or editing or (db.fadeCombat and inCombat) or anyHover or over
			target = show and 1 or db.fadeAlpha
			-- Si Blizzard le cambió la opacidad por su cuenta, se parte de la real
			if b.alpha and not blizzAnimating(b.frame) then
				local real = b.frame:GetAlpha()
				if math.abs(real - b.alpha) > 0.01 then
					b.alpha = real
					fader:Show()
				end
			end
		end
		if b.target ~= target then
			b.target = target
			fader:Show()
		end
	end
	-- Sin botón debajo no hay OnLeave que nos avise: volvemos a mirar en un rato
	if recheck then checkLater() end
end

----------------------------------------------------------------------
-- Detectar el ratón con los propios botones (sin sondear)
----------------------------------------------------------------------

local pending = false
function checkLater()
	if pending then return end
	pending = true
	-- Pequeño margen para pasar de un botón a otro sin parpadeo
	C_Timer.After(0.25, function()
		pending = false
		M:Evaluate()
	end)
end

local function hookButtons(b, frame, depth)
	for _, child in ipairs({ frame:GetChildren() }) do
		if child.HookScript and child.IsMouseEnabled then
			if child:IsObjectType("Button") or child:IsObjectType("CheckButton") then
				child:HookScript("OnEnter", function()
					hovered[b] = true
					lastBar = b
					M:Evaluate()
				end)
				child:HookScript("OnLeave", function()
					hovered[b] = nil
					checkLater()
				end)
			elseif depth < 3 then
				hookButtons(b, child, depth + 1)
			end
		end
	end
end

----------------------------------------------------------------------

local missing = {}     -- barras aún no creadas (p. ej. Questie crea la suya más tarde)
local ticker

local function attach(conf)
	for _, name in ipairs(conf.frames) do
		local frame = R:Resolve(name)
		if type(frame) == "table" and frame.SetAlpha then
			local b = { conf = conf, frame = frame, alpha = frame:GetAlpha(), target = 1 }
			bars[#bars + 1] = b
			if not conf.poll then hookButtons(b, frame, 1) end
			-- Si Blizzard (u otro addon) le cambia la opacidad, recuperamos la nuestra
			hooksecurefunc(frame, "SetAlpha", function(f)
				if not busy and running() and db[conf.key] and b.alpha then
					busy = true
					f:SetAlpha(b.alpha)
					busy = false
				end
			end)
			return true
		end
	end
end

function M:UpdateTicker()
	local need = false
	for _, conf in ipairs(FADE_BARS) do
		if conf.poll and db[conf.key] then need = true end
	end
	if need and not ticker then
		ticker = C_Timer.NewTicker(0.2, function()
			for conf in pairs(missing) do
				if db[conf.key] and attach(conf) then missing[conf] = nil end
			end
			M:Evaluate()
		end)
	elseif not need and ticker then
		ticker:Cancel()
		ticker = nil
	end
end

function M:OnEnable()
	db = self.db
	started = true

	for _, conf in ipairs(FADE_BARS) do
		if not attach(conf) and conf.poll then missing[conf] = true end
	end
	self:UpdateTicker()

	local events = CreateFrame("Frame")
	events:RegisterEvent("PLAYER_REGEN_DISABLED")
	events:RegisterEvent("PLAYER_REGEN_ENABLED")
	events:RegisterEvent("ACTIONBAR_SHOWGRID")
	events:RegisterEvent("ACTIONBAR_HIDEGRID")
	events:SetScript("OnEvent", function(_, event)
		if event == "PLAYER_REGEN_DISABLED" then inCombat = true
		elseif event == "PLAYER_REGEN_ENABLED" then inCombat = false
		elseif event == "ACTIONBAR_SHOWGRID" then dragging = true
		elseif event == "ACTIONBAR_HIDEGRID" then dragging = false end
		M:Evaluate()
	end)
	inCombat = InCombatLockdown()

	-- Modo edición del juego (Esc > Modo edición)
	if EventRegistry and EventRegistry.RegisterCallback then
		EventRegistry:RegisterCallback("EditMode.Enter", function() editing = true M:Evaluate() end, M)
		EventRegistry:RegisterCallback("EditMode.Exit", function() editing = false M:Evaluate() end, M)
	end
	editing = EditModeManagerFrame and EditModeManagerFrame.IsEditModeActive and EditModeManagerFrame:IsEditModeActive() or false

	self:Evaluate()
end

function M:OnOptionChanged(key)
	if key:find("^fade") then
		for _, b in ipairs(bars) do
			-- Al desmarcar una barra vuelve a verse del todo
			if not db[b.conf.key] then b.target = nil end
		end
		self:UpdateTicker()
		self:Evaluate()
	end
end

R:AttachHiders(M, {
	hideMainTracking      = { "MainStatusTrackingBarContainer" },
	hideSecondaryTracking = { "SecondaryStatusTrackingBarContainer" },
	hideGryphons          = { "MainActionBar.EndCaps", "MainMenuBar.EndCaps" },
	hideMicroMenu         = { "MicroMenuContainer" },
	hideBagsBar           = { "BagsBar" },
})
