-- Medidor de daño de Blizzard "al pasar el ratón": la cabecera (engranaje y
-- menús) o la ventana entera se ocultan hasta poner el ratón encima. Usa la
-- "Opacidad sin ratón" y "Mostrarlas siempre en combate" de las barras.
-- Solo cambia la opacidad (sigue respondiendo al ratón). La de la ventana
-- entera se multiplica por la "Transparencia" del Modo edición.

local R = Rheizor:Namespace(...)
local M = R.modules.bars

local HEADER_KEYS = { "SessionTimer", "MinimizeButton", "SettingsDropdown", "SessionDropdown", "DamageMeterTypeDropdown" }
local DROPDOWNS = { "SettingsDropdown", "SessionDropdown", "DamageMeterTypeDropdown" }
local windows = {}   -- ventanas encontradas
local fade = {}      -- opacidad actual de cada ventana (0-1)
local touched = {}   -- ventanas a las que hemos cambiado algo
local started = false

local function mode()
	local db = M.db
	if not (started and db and R:IsAddonActive(M.addon)) then return "off" end
	return db.dmHover or "off"
end

-- Con el estilo oscuro de Rheizor-Interface la barra de la cabecera ya está
-- escondida: no se toca
local function darkSkin()
	local dm = R.modules.damagemeter
	return dm and dm.IsDark and dm:IsDark() or false
end

local function editMode()
	return EditModeManagerFrame and EditModeManagerFrame.IsEditModeActive and EditModeManagerFrame:IsEditModeActive()
end

local function hovering(win)
	if win:IsMouseOver() then return true end
	local c = win.MinimizeContainer
	local sw = c and c.SourceWindow
	if sw and sw:IsShown() and sw:IsMouseOver() then return true end
	for _, key in ipairs(DROPDOWNS) do
		local d = win[key]
		if d and d.IsMenuOpen and d:IsMenuOpen() then return true end
	end
	return win.IsResizing and win:IsResizing() or false
end

local function setAlpha(obj, a)
	if obj and math.abs(obj:GetAlpha() - a) > 0.005 then obj:SetAlpha(a) end
end

local function baseAlpha()
	return DamageMeter and DamageMeter.GetWindowAlpha and DamageMeter:GetWindowAlpha() or 1
end

local function applyFade(win, m, a)
	setAlpha(win, m == "window" and baseAlpha() * a or baseAlpha())
	local h = m == "header" and a or 1
	for _, key in ipairs(HEADER_KEYS) do setAlpha(win[key], h) end
	if not darkSkin() then setAlpha(win.Header, h) end
end

local function fadeWindow(win, dt)
	local m = win:IsShown() and mode() or "off"
	if m == "off" then
		if touched[win] then
			applyFade(win, "off", 1)
			touched[win], fade[win] = nil, nil
		end
		return
	end
	touched[win] = true
	local db = M.db
	local show = hovering(win) or editMode() or (db.fadeCombat and InCombatLockdown())
	local target = show and 1 or db.fadeAlpha
	local cur = fade[win] or 1
	-- Aparece rápido y se va un poco más despacio
	if cur < target then
		cur = math.min(target, cur + dt * 6)
	elseif cur > target then
		cur = math.max(target, cur - dt * 3)
	end
	fade[win] = cur
	applyFade(win, m, cur)
end

local driver = CreateFrame("Frame")
driver:Hide()
driver:SetScript("OnUpdate", function(self, elapsed)
	self.t = (self.t or 0) + elapsed
	if self.t < 0.05 then return end
	local dt = self.t
	self.t = 0
	for win in pairs(windows) do fadeWindow(win, dt) end
	if mode() == "off" and not next(touched) then self:Hide() end
end)

local function update()
	if mode() ~= "off" or next(touched) then driver:Show() end
end

local function scan()
	for i = 1, 3 do
		local win = _G["DamageMeterSessionWindow" .. i]
		if win then windows[win] = true end
	end
	update()
end

local function start()
	started = true
	local db = M.db
	-- Antes estaba en Rheizor-Interface > Medidor de daño
	if not db.dmMigrated then
		db.dmMigrated = true
		local old = R.db and R.db.damagemeter
		if type(old) == "table" and (old.hover == "header" or old.hover == "window") and db.dmHover == "off" then
			db.dmHover = old.hover
		end
	end
	local function onLoaded()
		if not DamageMeter then return end
		if DamageMeter.SetupSessionWindow then hooksecurefunc(DamageMeter, "SetupSessionWindow", scan) end
		scan()
	end
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_DamageMeter", onLoaded)
	else
		onLoaded()
	end
end

local onEnable, onChanged = M.OnEnable, M.OnOptionChanged
function M:OnEnable()
	if onEnable then onEnable(self) end
	start()
end
function M:OnOptionChanged(key, value)
	if onChanged then onChanged(self, key, value) end
	if key == "dmHover" or key == "fadeAlpha" or key == "fadeCombat" then update() end
end
