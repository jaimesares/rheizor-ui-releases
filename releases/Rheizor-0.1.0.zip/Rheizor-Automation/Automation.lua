-- Automatización: misiones (aceptar, seleccionar, entregar) y despojo
-- (tecla modificadora y despojo rápido), e invitar al grupo por susurro.
-- Las misiones, basadas en la lógica de Leatrix Plus.

local R = Rheizor:Namespace(...)
local L = R.L

local KEYS = { { "SHIFT", "Mayús (Shift)" }, { "CTRL", "Control" }, { "ALT", "Alt" } }

local M = R:RegisterModule("auto", {
	title = "Automatización",
	defaults = {
		quests = true,
		acceptRegular = true,
		acceptDaily = true,
		acceptWeekly = true,
		turnIn = true,
		selectGossip = true,
		questKey = "SHIFT",
		questKeyMode = "pause",
		fastLoot = false,
		fastLootDelay = 0.3,
		autoInvite = false,
		inviteWords = "inv, invite, +",
		inviteMatch = "exact",
		inviteGuild = true,
		inviteFriends = true,
		inviteBNet = true,
		inviteOthers = false,
		inviteConvert = false,
		inviteNotify = true,
		hideIssueReporter = true,
	},
	options = {
		{ type = "header", text = "Misiones" },
		{ type = "toggle", key = "quests", name = "Automatizar misiones",
		  desc = "Interruptor general de todo lo de este apartado." },
		{ type = "toggle", key = "acceptRegular", name = "Aceptar misiones normales" },
		{ type = "toggle", key = "acceptDaily", name = "Aceptar misiones diarias" },
		{ type = "toggle", key = "acceptWeekly", name = "Aceptar misiones semanales" },
		{ type = "toggle", key = "turnIn", name = "Entregar misiones completadas",
		  desc = "Si hay que elegir entre varias recompensas, se detiene para que elijas tú.\nNo entrega misiones que piden oro o monedas." },
		{ type = "toggle", key = "selectGossip", name = "Elegir la misión en el diálogo del PNJ",
		  desc = "Abre directamente la misión cuando el PNJ tiene misiones disponibles o completadas.\nNo lo hace si el diálogo tiene opciones especiales (en color o con <…>)." },

		{ type = "header", text = "Tecla modificadora de misiones" },
		{ type = "dropdown", key = "questKey", name = "Tecla", values = KEYS },
		{ type = "dropdown", key = "questKeyMode", name = "Al mantenerla pulsada",
		  values = {
			{ "pause", "NO automatizar (pausa)" },
			{ "require", "Automatizar (solo con la tecla)" },
		  } },

		{ type = "header", text = "Despojo" },
		{ type = "toggle", id = "auto_lootDefault", cvar = "autoLootDefault", name = "Despojo automático",
		  desc = "Al despojar se recoge todo sin tener que elegir en la ventana de botín. Es la misma opción que la del juego." },
		{ type = "dropdown", id = "auto_lootKey", name = "Tecla para invertir el despojo automático",
		  default = "SHIFT",
		  values = { { "SHIFT", "Mayús (Shift)" }, { "CTRL", "Control" }, { "ALT", "Alt" }, { "NONE", "Ninguna" } },
		  desc = "Con despojo automático activado, mantenla al despojar para abrir la ventana y elegir. Con él desactivado, mantenla para despojarlo todo.",
		  get = function() return GetModifiedClick("AUTOLOOTTOGGLE") or "NONE" end,
		  set = function(value)
			SetModifiedClick("AUTOLOOTTOGGLE", value)
			SaveBindings(GetCurrentBindingSet())
		  end },
		{ type = "toggle", key = "fastLoot", name = "Despojo rápido",
		  desc = "Recoge todo al instante, sin esperar a la animación de la ventana. Respeta la tecla de arriba." },
		{ type = "slider", key = "fastLootDelay", name = "Espera entre despojos", min = 0.1, max = 0.5, step = 0.05,
		  format = function(v) return string.format("%.2f s", v) end,
		  desc = "Más bajo es más rápido, pero puede fallar con mucha latencia. 0.3 es lo recomendado." },

		{ type = "header", text = "Invitar al grupo por susurro" },
		{ type = "toggle", key = "autoInvite", name = "Invitar cuando me susurran una palabra clave",
		  desc = "Solo si no tienes grupo o puedes invitar (eres el líder o ayudante de banda)." },
		{ type = "text", key = "inviteWords", name = "Palabras clave",
		  desc = "Separadas por comas. No distingue mayúsculas." },
		{ type = "dropdown", key = "inviteMatch", name = "Cómo tiene que ser el susurro",
		  values = {
			{ "exact", "Solo la palabra — «inv»" },
			{ "contains", "Que contenga la palabra — «me invitas? inv»" },
		  } },
		{ type = "toggle", key = "inviteGuild", name = "Invitar a los de mi hermandad" },
		{ type = "toggle", key = "inviteFriends", name = "Invitar a mis amigos" },
		{ type = "toggle", key = "inviteBNet", name = "Invitar a mis amigos de Battle.net",
		  desc = "También cuando te susurran por Battle.net, si están jugando a esta misma versión." },
		{ type = "toggle", key = "inviteOthers", name = "Invitar a cualquier otro",
		  desc = "Cualquiera que susurre la palabra, aunque no sea de tu hermandad ni amigo." },
		{ type = "toggle", key = "inviteConvert", name = "Pasar a banda si el grupo está lleno",
		  desc = "Solo si eres el líder." },
		{ type = "toggle", key = "inviteNotify", name = "Avisarme en el chat",
		  desc = "Un mensaje (solo para ti) con a quién se ha invitado o por qué no." },

		{ type = "header", text = "Interfaz" },
		{ type = "toggle", key = "hideIssueReporter", name = "Ocultar el botón «Issue Reporter»",
		  desc = "El recuadro flotante para informar de fallos que Blizzard pone en las versiones de prueba. Para volver a verlo, desmarca esta opción." },
	},
})

local db

----------------------------------------------------------------------
-- Misiones
----------------------------------------------------------------------

local KEY_CHECK = { SHIFT = IsShiftKeyDown, CTRL = IsControlKeyDown, ALT = IsAltKeyDown }

local function keyAllows()
	local down = (KEY_CHECK[db.questKey] or IsShiftKeyDown)()
	if db.questKeyMode == "require" then return down end
	return not down
end

local FREQ = Enum.QuestFrequency or { Default = 0, Daily = 1, Weekly = 2 }

local function frequencyAllowed(frequency)
	if frequency == FREQ.Daily then return db.acceptDaily end
	if frequency == FREQ.Weekly then return db.acceptWeekly end
	return db.acceptRegular
end

local function anyAccept()
	return db.acceptRegular or db.acceptDaily or db.acceptWeekly
end

local function requiresGold()
	local gold = GetQuestMoneyToGet and GetQuestMoneyToGet()
	return gold and gold > 0
end

local function requiresCurrency()
	for i = 1, 6 do
		local item = _G["QuestProgressItem" .. i]
		if item and item:IsShown() and item.type == "required" and item.objectType == "currency" then
			return true
		end
	end
end

-- No tocar diálogos con opciones especiales (saltar escenas, etc.)
local function gossipHasSpecialOptions()
	local options = C_GossipInfo.GetOptions() or {}
	for _, option in ipairs(options) do
		local text = option.name
		if text and (text:upper():find("|C") or text:find("<")) then return true end
	end
end

local handlers = {}

function handlers.QUEST_DETAIL()
	if not anyAccept() then return end
	local isDaily = QuestIsDaily and QuestIsDaily()
	local isWeekly = QuestIsWeekly and QuestIsWeekly()
	local frequency = (isDaily and FREQ.Daily) or (isWeekly and FREQ.Weekly) or FREQ.Default
	if not frequencyAllowed(frequency) then return end
	if QuestGetAutoAccept and QuestGetAutoAccept() then
		CloseQuest()
	else
		AcceptQuest()
	end
end

function handlers.QUEST_ACCEPT_CONFIRM()
	if not db.acceptRegular then return end
	ConfirmAcceptQuest()
	StaticPopup_Hide("QUEST_ACCEPT")
end

function handlers.QUEST_PROGRESS()
	if not db.turnIn or not IsQuestCompletable() then return end
	if requiresGold() or requiresCurrency() then return end
	CompleteQuest()
end

function handlers.QUEST_COMPLETE()
	if not db.turnIn or requiresGold() or requiresCurrency() then return end
	local choices = GetNumQuestChoices()
	if choices <= 1 then GetQuestReward(choices) end
end

function handlers.QUEST_AUTOCOMPLETE(questID)
	if not db.turnIn or not questID then return end
	local index = C_QuestLog.GetLogIndexForQuestID(questID)
	local info = index and C_QuestLog.GetInfo(index)
	if info and info.isAutoComplete then
		C_QuestLog.SetSelectedQuest(questID)
		ShowQuestComplete(questID)
	end
end

function handlers.QUEST_GREETING()
	if not db.selectGossip then return end
	if db.turnIn then
		for i = 1, GetNumActiveQuests() do
			local title, isComplete = GetActiveTitle(i)
			if title and isComplete then return SelectActiveQuest(i) end
		end
	end
	if anyAccept() then
		for i = 1, GetNumAvailableQuests() do
			local _, frequency = GetAvailableQuestInfo(i)
			if frequencyAllowed(frequency) then return SelectAvailableQuest(i) end
		end
	end
end

function handlers.GOSSIP_SHOW()
	if not db.selectGossip or gossipHasSpecialOptions() then return end
	if db.turnIn then
		for _, quest in ipairs(C_GossipInfo.GetActiveQuests() or {}) do
			if quest.isComplete and quest.questID then
				return C_GossipInfo.SelectActiveQuest(quest.questID)
			end
		end
	end
	if anyAccept() then
		for _, quest in ipairs(C_GossipInfo.GetAvailableQuests() or {}) do
			if quest.questID and frequencyAllowed(quest.frequency) then
				return C_GossipInfo.SelectAvailableQuest(quest.questID)
			end
		end
	end
end

local questFrame = CreateFrame("Frame")
questFrame:SetScript("OnEvent", function(_, event, ...)
	-- Apagado en Rheizor sin recargar: no se hace nada
	if not R:IsModuleRunning(M) or not keyAllows() then return end
	handlers[event](...)
end)

function M:UpdateQuestEvents()
	questFrame:UnregisterAllEvents()
	if not db.quests then return end
	for event in pairs(handlers) do pcall(questFrame.RegisterEvent, questFrame, event) end
end

----------------------------------------------------------------------
-- Despojo rápido
----------------------------------------------------------------------

local lootFrame = CreateFrame("Frame")
local lastLoot = 0

lootFrame:SetScript("OnEvent", function()
	if not R:IsModuleRunning(M) or GetTime() - lastLoot < db.fastLootDelay then return end
	lastLoot = GetTime()
	-- Despojo automático activo y la tecla no está pulsada (o al revés)
	if GetCVarBool("autoLootDefault") ~= IsModifiedClick("AUTOLOOTTOGGLE") then
		for i = GetNumLootItems(), 1, -1 do LootSlot(i) end
	end
end)

function M:UpdateLootEvents()
	if db.fastLoot then
		lootFrame:RegisterEvent("LOOT_READY")
	else
		lootFrame:UnregisterAllEvents()
	end
end

----------------------------------------------------------------------
-- Invitar al grupo por susurro
----------------------------------------------------------------------

local NS = R.NotSecret
local lastInvite = {}   -- nombre -> hora (no invitar dos veces seguidas)

local function notify(text)
	if db.inviteNotify then R:Print(text) end
end

local function wordMatches(msg)
	msg = strtrim(msg):lower()
	if msg == "" then return false end
	for part in (db.inviteWords or ""):gmatch("[^,]+") do
		local word = strtrim(part):lower()
		if word ~= "" then
			if msg == word then return true end
			if db.inviteMatch == "contains" then
				-- La palabra suelta, no dentro de otra ("inv" no encaja con "invierno")
				local s, e = msg:find(word, 1, true)
				while s do
					local before, after = msg:sub(s - 1, s - 1), msg:sub(e + 1, e + 1)
					if not before:find("[%w\128-\255]") and not after:find("[%w\128-\255]") then return true end
					s, e = msg:find(word, e + 1, true)
				end
			end
		end
	end
	return false
end

local function isGuildMate(name, guid)
	if not IsInGuild() then return false end
	if guid and IsGuildMember then
		local ok, yes = pcall(IsGuildMember, guid)
		if ok and NS(yes) ~= nil then return NS(yes) and true or false end
	end
	-- Sin GUID: se busca en la lista de la hermandad
	local short = Ambiguate(name, "none")
	for i = 1, (GetNumGuildMembers() or 0) do
		local member = NS(GetGuildRosterInfo(i))
		if member and (member == name or Ambiguate(member, "none") == short) then return true end
	end
	return false
end

local function isFriend(guid)
	if not guid or not (C_FriendList and C_FriendList.IsFriend) then return false end
	local ok, yes = pcall(C_FriendList.IsFriend, guid)
	return ok and NS(yes) and true or false
end

local function isBNetFriend(guid)
	if not guid or not (C_BattleNet and C_BattleNet.GetAccountInfoByGUID) then return false end
	local ok, info = pcall(C_BattleNet.GetAccountInfoByGUID, guid)
	return ok and type(info) == "table"
end

local function allowed(name, guid)
	if db.inviteOthers then return true end
	if db.inviteGuild and isGuildMate(name, guid) then return true end
	if db.inviteFriends and isFriend(guid) then return true end
	if db.inviteBNet and isBNetFriend(guid) then return true end
	return false
end

local function invite(name)
	local now = GetTime()
	if lastInvite[name] and now - lastInvite[name] < 10 then return end
	lastInvite[name] = now
	if UnitInParty(name) or UnitInRaid(name) then return end
	if IsInGroup() then
		local leader = UnitIsGroupLeader("player")
		if not leader and not (IsInRaid() and UnitIsGroupAssistant("player")) then
			notify(L["%s te ha pedido invitación, pero no eres el líder del grupo."]:format(name))
			return
		end
		if not IsInRaid() and GetNumGroupMembers() >= 5 then
			if db.inviteConvert and leader and C_PartyInfo and C_PartyInfo.ConvertToRaid then
				C_PartyInfo.ConvertToRaid()
			else
				notify(L["%s te ha pedido invitación, pero el grupo está lleno."]:format(name))
				return
			end
		end
	end
	local fn = (C_PartyInfo and C_PartyInfo.InviteUnit) or InviteUnit
	if fn and pcall(fn, name) then notify(L["Invitado al grupo: %s"]:format(name)) end
end

local inviteFrame = CreateFrame("Frame")
inviteFrame:SetScript("OnEvent", function(_, event, ...)
	if not R:IsModuleRunning(M) or not db.autoInvite then return end
	local msg, sender = NS((...)), NS((select(2, ...)))
	if type(msg) ~= "string" or not wordMatches(msg) then return end
	if event == "CHAT_MSG_BN_WHISPER" then
		if not db.inviteBNet then return end
		-- El personaje con el que juega tu amigo de Battle.net, si es de esta versión
		local bnID = NS((select(13, ...)))
		local ok, info = pcall(C_BattleNet.GetAccountInfoByID, bnID)
		local game = ok and type(info) == "table" and info.gameAccountInfo
		if not game or not game.isOnline or not game.characterName or game.characterName == "" then return end
		if game.wowProjectID and WOW_PROJECT_ID and game.wowProjectID ~= WOW_PROJECT_ID then return end
		local realm = game.realmName and game.realmName ~= "" and game.realmName:gsub("%s", "") or nil
		invite(realm and (game.characterName .. "-" .. realm) or game.characterName)
		return
	end
	if type(sender) ~= "string" or sender == "" then return end
	local guid = NS((select(12, ...)))
	if allowed(sender, guid) then invite(sender) end
end)

function M:UpdateInviteEvents()
	inviteFrame:UnregisterAllEvents()
	if not db.autoInvite then return end
	pcall(inviteFrame.RegisterEvent, inviteFrame, "CHAT_MSG_WHISPER")
	pcall(inviteFrame.RegisterEvent, inviteFrame, "CHAT_MSG_BN_WHISPER")
	-- Para encontrar a los de la hermandad por su nombre
	if IsInGuild() and C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
end

----------------------------------------------------------------------
-- Botón flotante "Issue Reporter" (Blizzard_PTRFeedback, solo en betas y
-- reinos de prueba). Es un marco normal, no protegido: basta con ocultarlo
-- y volver a ocultarlo si Blizzard lo enseña (al entrar, al cambiar de
-- pantalla...).
----------------------------------------------------------------------

local reporterHooked = false

local function hideReporter()
	return db and db.hideIssueReporter and R:IsModuleRunning(M)
end

function M:UpdateIssueReporter()
	local f = PTR_IssueReporter
	if type(f) ~= "table" or not f.Hide then return end
	if not reporterHooked then
		reporterHooked = true
		hooksecurefunc(f, "Show", function(self)
			if hideReporter() then self:Hide() end
		end)
	end
	if hideReporter() then
		f:Hide()
	elseif not f:IsShown() and f.Data and f.Data.IsLoaded then
		f:Show()
	end
end

local reporterFrame = CreateFrame("Frame")
reporterFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
reporterFrame:SetScript("OnEvent", function()
	-- Blizzard lo prepara en este mismo evento: justo después
	C_Timer.After(0, function() M:UpdateIssueReporter() end)
	C_Timer.After(2, function() M:UpdateIssueReporter() end)
end)

----------------------------------------------------------------------

function M:OnEnable()
	db = self.db
	self:UpdateQuestEvents()
	self:UpdateLootEvents()
	self:UpdateInviteEvents()
	self:UpdateIssueReporter()
end

function M:OnOptionChanged(key)
	if key == "quests" then
		self:UpdateQuestEvents()
	elseif key == "fastLoot" then
		self:UpdateLootEvents()
	elseif key == "autoInvite" then
		self:UpdateInviteEvents()
	elseif key == "hideIssueReporter" then
		self:UpdateIssueReporter()
	end
end
