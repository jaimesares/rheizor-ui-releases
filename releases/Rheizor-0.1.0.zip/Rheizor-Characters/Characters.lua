-- Personajes: oro, descanso, bolsas, banco y buzón de todos tus personajes.
--
-- Un addon solo puede leer el personaje con el que estás conectado, así que
-- cada personaje guarda sus datos en RheizorCharsDB (compartido por toda la
-- cuenta) mientras juegas con él, y desde cualquier otro se ve lo último que
-- se guardó. El banco y el buzón solo se pueden leer con ellos abiertos.
--
-- RheizorCharsDB es aparte de RheizorDB: cambiar de perfil o restablecer la
-- configuración de Rheizor no borra el historial de los personajes.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("characters", {
	title = "Personajes",
	defaults = {
		tooltip = true,
		tooltipSelf = true,
		allRealms = false,
		played = true,
		scale = 1,
		itemView = "grid",
	},
	options = {
		{ type = "button", name = "Panel de personajes", text = "Abrir",
		  desc = "Oro, descanso, bolsas, banco y buzón de todos tus personajes. También con /rz personajes.",
		  func = function(mod) mod:Toggle() end },
		{ type = "toggle", key = "allRealms", name = "Personajes de todos los reinos",
		  desc = "En el panel y en el tooltip. Desactivado, solo los del reino en el que estás (los objetos no se pueden pasar entre reinos). También se cambia desde el propio panel." },

		{ type = "header", text = "Tamaño y posición del panel" },
		{ type = "slider", key = "scale", name = "Tamaño del panel", min = 0.6, max = 1.5, step = 0.05, format = R.fmt.percent },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

		{ type = "header", text = "Tooltip de los objetos" },
		{ type = "toggle", key = "tooltip", name = "Mostrar quién tiene el objeto",
		  desc = "Al pasar el ratón por un objeto, cuántos tiene cada personaje y dónde: Pepe: 12 (bolsas 5, banco 7)." },
		{ type = "toggle", key = "tooltipSelf", name = "Incluir al personaje con el que juegas" },

		{ type = "header", text = "Tiempo jugado" },
		{ type = "toggle", key = "played", name = "Pedir el tiempo jugado al entrar",
		  desc = "Para mostrar el tiempo jugado de cada personaje. El mensaje del chat de /played no aparece al entrar." },
	},
})

local db            -- opciones del módulo (perfil)
local store         -- RheizorCharsDB
local me            -- datos del personaje actual
local myKey, myRealm

local GOLD = "|cff33ccff"

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local CI = C_Container or {}
local function numSlots(bag)
	local fn = CI.GetContainerNumSlots or GetContainerNumSlots
	if not fn then return 0 end
	local ok, n = pcall(fn, bag)
	return ok and tonumber(NS(n)) or 0
end

-- itemID, cantidad y enlace de una casilla
local function slotItem(bag, slot)
	if CI.GetContainerItemInfo then
		local info = CI.GetContainerItemInfo(bag, slot)
		if not info then return end
		return info.itemID, info.stackCount or 1, info.hyperlink, info.iconFileID
	elseif GetContainerItemInfo then
		local icon, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
		return id, count or 1, link, icon
	end
end

local function idFromLink(link)
	return link and tonumber(link:match("item:(%d+)"))
end

-- Nombre, icono y color de cada objeto visto (para el buscador)
local function remember(id, link, icon)
	if not id or not link then return end
	local it = store.items[id]
	local name = link:match("%[(.-)%]")
	if not name then return end
	if not it then
		it = {}
		store.items[id] = it
	end
	it.n = name
	it.c = link:match("|c(%x%x%x%x%x%x%x%x)") or it.c
	if icon then it.i = icon end
end

local function add(list, id, count)
	list[id] = (list[id] or 0) + count
end

-- into: itemID -> cantidad total. layout: una entrada por bolsa con su
-- tamaño y qué hay en cada hueco ({ size = 16, s = { [hueco] = { id, cantidad } } }),
-- para dibujarlas como en el juego
local function scanBags(bags, into, layout)
	wipe(into)
	if layout then wipe(layout) end
	local free, total = 0, 0
	for _, bag in ipairs(bags) do
		local n = numSlots(bag)
		total = total + n
		local box = layout and n > 0 and { size = n, s = {} }
		if box then layout[#layout + 1] = box end
		for slot = 1, n do
			local id, count, link, icon = slotItem(bag, slot)
			id = NS(id)
			if id then
				count = NS(count) or 1
				add(into, id, count)
				if box then box.s[slot] = { id, count } end
				remember(id, NS(link), NS(icon))
			else
				free = free + 1
			end
		end
	end
	return free, total
end

----------------------------------------------------------------------
-- Qué bolsas son de qué (cambian entre versiones del juego)
----------------------------------------------------------------------

local BI = Enum and Enum.BagIndex or {}

-- En WoW Forever (Enum.BagIndex): -3 y -2 son las pestañas de banco (como
-- bolsas), -1 el llavero, 0-4 las bolsas, 5 la de componentes y 6-14 las
-- pestañas del banco del personaje. En los clásicos antiguos -1 era el banco
-- y -2 el llavero: por eso se usan los nombres y no los números
local function bagList()
	local list = {}
	for bag = 0, NUM_BAG_SLOTS or 4 do list[#list + 1] = bag end
	if BI.ReagentBag then list[#list + 1] = BI.ReagentBag end
	local keyring = KEYRING_CONTAINER or BI.Keyring or -2
	if numSlots(keyring) > 0 then list[#list + 1] = keyring end
	return list
end

local function bankList()
	local seen, list = {}, {}
	local function push(bag)
		if bag and not seen[bag] and bag ~= BI.ReagentBag then
			seen[bag] = true
			list[#list + 1] = bag
		end
	end
	-- Motor nuevo: el banco va por pestañas (las no compradas tienen 0 huecos
	-- y no se guardan)
	if BI.CharacterBankTab_1 then
		for i = 1, 9 do push(BI["CharacterBankTab_" .. i]) end
		return list
	end
	-- Clásicos antiguos: el banco y sus bolsas, justo después de las equipadas
	push(BANK_CONTAINER or -1)
	local first = (NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) + 1
	for i = 0, (NUM_BANKBAGSLOTS or 7) - 1 do push(first + i) end
	return list
end

----------------------------------------------------------------------
-- Registro del personaje actual
----------------------------------------------------------------------

local function maxLevel()
	if GetMaxLevelForPlayerExpansion then return GetMaxLevelForPlayerExpansion() end
	if GetMaxPlayerLevel then return GetMaxPlayerLevel() end
	return MAX_PLAYER_LEVEL or 60
end

local function saveBasics()
	local level = NS(UnitLevel("player"))
	if level then me.level = level end
	me.maxLevel = maxLevel()
	-- Con la experiencia máxima a 0 los datos aún no han llegado (o ya se
	-- han ido): se conserva lo último bueno
	local xpMax = NS(UnitXPMax("player"))
	if xpMax and xpMax > 0 then
		me.xp = NS(UnitXP("player")) or me.xp
		me.xpMax = xpMax
		me.rested = NS(GetXPExhaustion()) or 0
	end
	me.resting = IsResting() and true or false
	me.money = NS(GetMoney()) or me.money
	me.zone = NS(GetRealZoneText and GetRealZoneText() or GetZoneText()) or me.zone
	me.lastSeen = time()
end

local function saveIdentity()
	local _, class = UnitClass("player")
	me.name = R.PlayerFullName()
	me.realm = myRealm
	me.class = class
	me.race = NS(UnitRace("player"))
	me.faction = NS(UnitFactionGroup("player"))
end

local function saveBags()
	me.bags = me.bags or {}
	me.bagLayout = me.bagLayout or {}
	me.bagFree, me.bagTotal = scanBags(bagList(), me.bags, me.bagLayout)
end

local bankOpen = false
local function saveBank()
	if not bankOpen then return end
	me.bank = me.bank or {}
	me.bankLayout = me.bankLayout or {}
	me.bankFree, me.bankTotal = scanBags(bankList(), me.bank, me.bankLayout)
	me.bankSeen = time()
end

local function saveEquipped()
	me.equipped = me.equipped or {}
	wipe(me.equipped)
	for slot = 0, 19 do
		local link = NS(GetInventoryItemLink("player", slot))
		local id = idFromLink(link)
		if id then
			add(me.equipped, id, 1)
			remember(id, link, NS(GetInventoryItemTexture("player", slot)))
		end
	end
end

local mailOpen = false
local function saveMail()
	if not mailOpen then return end
	me.mail = me.mail or {}
	wipe(me.mail)
	local money, expires, letters = 0, nil, 0
	local n = GetInboxNumItems() or 0
	for i = 1, n do
		local h = { GetInboxHeaderInfo(i) }
		local cash, cod, daysLeft, hasItem = h[5], h[6], h[7], h[8]
		letters = letters + 1
		if cash and cash > 0 then money = money + cash end
		if daysLeft and (not expires or daysLeft < expires) then expires = daysLeft end
		if hasItem and (not cod or cod == 0) then
			for a = 1, ATTACHMENTS_MAX_RECEIVE or 12 do
				-- Motor moderno (como MailFrame.lua de Blizzard): nombre, id, icono,
				-- cantidad, calidad, usable, moneda; antiguo: nombre, icono, cantidad.
				-- GetInboxItemLink puede no existir: el id sale de GetInboxItem
				local r = { GetInboxItem(i, a) }
				local modern = #r >= 6
				local link = GetInboxItemLink and GetInboxItemLink(i, a)
				local id = (modern and not r[7] and NS(r[2])) or idFromLink(link)
				if type(id) == "number" then
					local count = modern and r[4] or r[3]
					add(me.mail, id, tonumber(count) or 1)
					if not link and C_Item and C_Item.GetItemInfo then link = select(2, C_Item.GetItemInfo(id)) end
					remember(id, link, r[modern and 3 or 2])
				end
			end
		end
	end
	me.mailMoney = money
	me.mailLetters = letters
	-- Se guarda la fecha de caducidad en lugar de los días, para que cuente sola
	me.mailExpires = expires and (time() + expires * 86400) or nil
	me.mailSeen = time()
end

-- Profesiones: las primarias se pueden abandonar; cocina, primeros auxilios
-- y pesca son las secundarias
local SECONDARY = { 2550, 3273, 7620 }  -- cocina, primeros auxilios, pesca
local secondaryNames
local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return C_Spell.GetSpellName(id) end
	return GetSpellInfo and (GetSpellInfo(id))
end

-- Una línea de habilidad: nombre, cabecera, rango, máximo, abandonable.
-- WoW Forever solo tiene C_SkillInfo (devuelve una tabla); los clientes
-- clásicos antiguos, las funciones globales
local SK = C_SkillInfo
local function skillLine(i)
	if SK and SK.GetSkillLineInfo then
		local info = SK.GetSkillLineInfo(i)
		if type(info) ~= "table" then return end
		return info.name, info.isHeader, info.rank, info.maxRank, info.isAbandonable
	end
	local name, header, _, rank, _, _, maxRank, abandonable = GetSkillLineInfo(i)
	return name, header, rank, maxRank, abandonable
end

local function saveSkills()
	local numLines = (SK and SK.GetNumSkillLines) or GetNumSkillLines
	if not numLines or not ((SK and SK.GetSkillLineInfo) or GetSkillLineInfo) then return end
	if not secondaryNames then
		secondaryNames = {}
		for _, id in ipairs(SECONDARY) do
			local n = spellName(id)
			if n then secondaryNames[n] = true end
		end
	end
	local list, seen = {}, {}
	for i = 1, numLines() or 0 do
		local name, header, rank, maxRank, abandonable = skillLine(i)
		-- El juego puede dar la misma línea dos veces: una sola por nombre
		if name and not header and (abandonable or secondaryNames[name]) and not seen[name] then
			seen[name] = true
			list[#list + 1] = { n = name, r = rank, m = maxRank }
		end
	end
	if #list > 0 then me.skills = list end
end

-- Tiempo jugado: se pide al entrar sin que salga en el chat. Se quitan las
-- ventanas de chat del evento un momento en lugar de tocar funciones de Blizzard.
local muted = {}
local function unmuteChat()
	for f in pairs(muted) do f:RegisterEvent("TIME_PLAYED_MSG") end
	wipe(muted)
end

local function requestPlayed()
	if not RequestTimePlayed then return end
	for i = 1, NUM_CHAT_WINDOWS or 10 do
		local f = _G["ChatFrame" .. i]
		if f and f:IsEventRegistered("TIME_PLAYED_MSG") then
			f:UnregisterEvent("TIME_PLAYED_MSG")
			muted[f] = true
		end
	end
	RequestTimePlayed()
	C_Timer.After(10, unmuteChat)   -- por si la respuesta no llega
end

----------------------------------------------------------------------
-- Cálculos para mostrar
----------------------------------------------------------------------

local function isMe(c) return c == me end

-- Descanso ahora mismo: desde que salió sube un 5% de nivel cada 8 horas si
-- salió en una posada o ciudad (un cuarto fuera), hasta 1,5 niveles
local function restedNow(c)
	if not c.level or not c.xpMax or c.xpMax <= 0 then return end
	if c.maxLevel and c.level >= c.maxLevel then return end
	local r = c.rested or 0
	if not isMe(c) and c.lastSeen then
		local hours = math.max(0, time() - c.lastSeen) / 3600
		local rate = c.resting and 0.05 or 0.0125
		r = r + c.xpMax * rate * hours / 8
	end
	r = math.min(r, c.xpMax * 1.5)
	return r, r / c.xpMax
end

local function playedNow(c)
	if not c.played then return end
	if isMe(c) and c.playedAt then return c.played + (time() - c.playedAt) end
	return c.played
end

local function durationText(sec)
	sec = math.floor(sec)
	local d, h, m = math.floor(sec / 86400), math.floor(sec % 86400 / 3600), math.floor(sec % 3600 / 60)
	if d > 0 then return L["%d d %d h"]:format(d, h) end
	if h > 0 then return L["%d h %d min"]:format(h, m) end
	return L["%d min"]:format(m)
end

local function agoText(t)
	if not t then return "—" end
	local s = time() - t
	if s < 3600 then return L["hace %d min"]:format(math.max(1, math.floor(s / 60))) end
	if s < 86400 then return L["hace %d h"]:format(math.floor(s / 3600)) end
	return L["hace %d d"]:format(math.floor(s / 86400))
end

local function classColor(class)
	local c = class and (C_ClassColor and C_ClassColor.GetClassColor(class) or RAID_CLASS_COLORS[class])
	if c and c.GenerateHexColor then return c:GenerateHexColor() end
	if c then return string.format("ff%02x%02x%02x", c.r * 255, c.g * 255, c.b * 255) end
	return "ffffffff"
end

local function coloredName(c)
	return "|c" .. classColor(c.class) .. (c.name or "?") .. "|r"
end

-- Personajes que se ven con el filtro de reino, ordenados
local function characters()
	local list = {}
	for key, c in pairs(store.chars) do
		if db.allRealms or c.realm == myRealm then
			c.key = key
			list[#list + 1] = c
		end
	end
	table.sort(list, function(a, b)
		if a.realm ~= b.realm then
			if a.realm == myRealm then return true end
			if b.realm == myRealm then return false end
			return (a.realm or "") < (b.realm or "")
		end
		if (a.level or 0) ~= (b.level or 0) then return (a.level or 0) > (b.level or 0) end
		return (a.name or "") < (b.name or "")
	end)
	return list
end

local PLACES = {
	{ "bags", "bolsas" },
	{ "bank", "banco" },
	{ "mail", "buzón" },
	{ "equipped", "equipado" },
}

-- Cuántos tiene un personaje de un objeto: total y texto "(bolsas 5, banco 7)"
local function countFor(c, id)
	local total, parts = 0, {}
	for _, p in ipairs(PLACES) do
		local n = c[p[1]] and c[p[1]][id]
		if n and n > 0 then
			total = total + n
			parts[#parts + 1] = L[p[2]] .. " " .. n
		end
	end
	return total, parts
end

----------------------------------------------------------------------
-- Tooltip de los objetos
----------------------------------------------------------------------

local function addOwners(tooltip, id)
	-- El gancho del tooltip no se puede quitar: apagado en Rheizor, no hace nada
	if not R:IsModuleRunning(M) then return end
	if not db.tooltip or not id or not tooltip.AddDoubleLine then return end
	local lines, sum = {}, 0
	for _, c in ipairs(characters()) do
		if db.tooltipSelf or not isMe(c) then
			local n, parts = countFor(c, id)
			if n > 0 then
				sum = sum + n
				lines[#lines + 1] = { coloredName(c), n .. " |cffaaaaaa(" .. table.concat(parts, ", ") .. ")|r" }
			end
		end
	end
	if #lines == 0 then return end
	tooltip:AddLine(" ")
	for _, l in ipairs(lines) do tooltip:AddDoubleLine(l[1], l[2], 1, 1, 1, 1, 1, 1) end
	if #lines > 1 then tooltip:AddDoubleLine(L["Total"], tostring(sum), 0.2, 0.8, 1, 0.2, 0.8, 1) end
	-- Sin :Show(): con TooltipDataProcessor Blizzard lo muestra justo después
	-- (mostrarlo desde aquí, aún oculto, calcularía su tamaño desde un addon)
	return true
end

local function hookTooltips()
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
			if not store then return end
			local id = data and NS(data.id)
			if type(id) == "number" then addOwners(tooltip, id) end
		end)
	else
		local function onItem(tooltip)
			if not tooltip.GetItem then return end
			local ok, _, link = pcall(tooltip.GetItem, tooltip)
			-- Clientes antiguos: aquí sí hay que recolocarlo si ya se ve
			if ok and addOwners(tooltip, idFromLink(NS(link))) and tooltip:IsShown() then tooltip:Show() end
		end
		for _, tt in ipairs({ GameTooltip, ItemRefTooltip }) do
			if tt and tt:HasScript("OnTooltipSetItem") then tt:HookScript("OnTooltipSetItem", onItem) end
		end
	end
end

----------------------------------------------------------------------
-- Panel
----------------------------------------------------------------------

local UI = R.UI or {}
local W, H = 780, 470
local ROW_H = 22
local CHAR_W = 170
local win, tabs, body, list, header, footer, searchBox, emptyText
local charPanel, charScroll, viewButton
local rows, charButtons = {}, {}
local mode = "chars"   -- "chars" u "items"
local selectedKey      -- personaje cuyos objetos se ven en la pestaña Objetos

local function backdrop(f, alpha)
	if UI.SetBackdrop then return UI.SetBackdrop(f, alpha) end
	f:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	f:SetBackdropColor(0.05, 0.05, 0.07, alpha or 0.95)
	f:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
end

-- Columnas de la pestaña de personajes: { x, ancho, alineación }
local COLS = {
	name  = { 8, 170, "LEFT" },
	level = { 180, 40, "CENTER" },
	money = { 222, 140, "RIGHT" },
	rest  = { 378, 120 },
	zone  = { 510, 150, "LEFT" },
	seen  = { 664, 86, "RIGHT" },
}

local function cell(row, key)
	local c = COLS[key]
	local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	fs:SetPoint("LEFT", row, "LEFT", c[1], 0)
	fs:SetWidth(c[2])
	fs:SetJustifyH(c[3] or "LEFT")
	fs:SetWordWrap(false)
	return fs
end

local forget   -- se define más abajo

local function newRow(i)
	local row = CreateFrame("Button", nil, list.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", list.child, "RIGHT")
	row:RegisterForClicks("LeftButtonUp", "RightButtonUp")

	local bg = row:CreateTexture(nil, "BACKGROUND")
	bg:SetAllPoints()
	bg:SetColorTexture(1, 1, 1, i % 2 == 0 and 0.03 or 0)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(0.2, 0.8, 1, 0.12)

	-- Personajes
	row.name, row.level, row.money = cell(row, "name"), cell(row, "level"), cell(row, "money")
	row.zone, row.seen = cell(row, "zone"), cell(row, "seen")
	local bar = CreateFrame("StatusBar", nil, row)
	bar:SetPoint("LEFT", row, "LEFT", COLS.rest[1], 0)
	bar:SetSize(COLS.rest[2], 12)
	bar:SetStatusBarTexture("Interface\\Buttons\\WHITE8X8")
	bar:SetStatusBarColor(0.25, 0.5, 1)
	bar:SetMinMaxValues(0, 1.5)
	local barBg = bar:CreateTexture(nil, "BACKGROUND")
	barBg:SetAllPoints()
	barBg:SetColorTexture(0, 0, 0, 0.5)
	bar.text = bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	bar.text:SetPoint("CENTER")
	row.rest = bar

	-- Objetos
	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetSize(18, 18)
	row.icon:SetPoint("LEFT", 6, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	row.item = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.item:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
	row.item:SetWidth(250)
	row.item:SetJustifyH("LEFT")
	row.item:SetWordWrap(false)
	row.count = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.count:SetPoint("LEFT", 290, 0)
	row.count:SetWidth(40)
	row.count:SetJustifyH("RIGHT")
	row.where = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.where:SetPoint("LEFT", 344, 0)
	row.where:SetPoint("RIGHT", -6, 0)
	row.where:SetJustifyH("LEFT")
	row.where:SetWordWrap(false)

	row:SetScript("OnEnter", function(self)
		if not self.itemID and not self.char then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		if self.itemID then
			GameTooltip:SetItemByID(self.itemID)
		elseif self.char then
			M:CharTooltip(self.char)
		end
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	row:SetScript("OnClick", function(self, button)
		if not self.char then return end
		if button == "RightButton" then
			forget(self.char)
		else
			-- Clic en un personaje: sus objetos
			selectedKey = self.char.key
			mode = "items"
			searchBox:SetText("")
			M:Refresh()
		end
	end)
	rows[i] = row
	return row
end

local function getRow(i)
	local row = rows[i] or newRow(i)
	row:Show()
	return row
end

local function setRowMode(row, items)
	for _, k in ipairs({ "name", "level", "money", "zone", "seen", "rest" }) do row[k]:SetShown(not items) end
	for _, k in ipairs({ "icon", "item", "count", "where" }) do row[k]:SetShown(items) end
end

function M:CharTooltip(c)
	local tt = GameTooltip
	tt:SetText(coloredName(c) .. " |cffaaaaaa- " .. (c.realm or "") .. "|r")
	tt:AddLine(string.format("%s %s %s", L["Nivel"], c.level or "?", (c.race or "") .. " " .. (c.class and (LOCALIZED_CLASS_NAMES_MALE or {})[c.class] or "")), 1, 1, 1)
	local played = playedNow(c)
	if played then tt:AddDoubleLine(L["Tiempo jugado"], durationText(played), 1, 0.82, 0, 1, 1, 1) end
	if c.level and c.xpMax and c.xpMax > 0 and not (c.maxLevel and c.level >= c.maxLevel) then
		tt:AddDoubleLine(L["Experiencia"], string.format("%d%%", (c.xp or 0) * 100 / c.xpMax), 1, 0.82, 0, 1, 1, 1)
		local _, pct = restedNow(c)
		if pct then
			tt:AddDoubleLine(L["Descanso"], string.format("%d%% %s", pct * 100 + 0.5,
				c.resting and L["(salió descansando)"] or L["(salió fuera de posada)"]), 1, 0.82, 0, 1, 1, 1)
		end
	end
	if c.bagTotal then
		tt:AddDoubleLine(L["Bolsas"], L["%d libres de %d"]:format(c.bagFree or 0, c.bagTotal), 1, 0.82, 0, 1, 1, 1)
	end
	if c.bankSeen then
		tt:AddDoubleLine(L["Banco"], L["%d libres de %d"]:format(c.bankFree or 0, c.bankTotal or 0) .. " · " .. agoText(c.bankSeen), 1, 0.82, 0, 1, 1, 1)
	else
		tt:AddDoubleLine(L["Banco"], L["sin ver: abre el banco con este personaje"], 1, 0.82, 0, 0.6, 0.6, 0.6)
	end
	if c.mailSeen then
		local text = L["%d cartas"]:format(c.mailLetters or 0)
		if (c.mailMoney or 0) > 0 then text = text .. " · " .. R.Money(c.mailMoney) end
		tt:AddDoubleLine(L["Buzón"], text, 1, 0.82, 0, 1, 1, 1)
		if c.mailExpires and (c.mailLetters or 0) > 0 then
			local left = c.mailExpires - time()
			local r, g, b = 1, 1, 1
			if left < 3 * 86400 then r, g, b = 1, 0.3, 0.3 end
			tt:AddDoubleLine(" ", left > 0 and L["la primera carta caduca en %s"]:format(durationText(left)) or L["alguna carta ya ha caducado"], 1, 1, 1, r, g, b)
		end
	end
	if c.skills then
		tt:AddLine(" ")
		for _, s in ipairs(c.skills) do
			tt:AddDoubleLine(s.n, string.format("%d/%d", s.r or 0, s.m or 0), 1, 1, 1, 0.7, 0.7, 0.7)
		end
	end
	tt:AddLine(" ")
	tt:AddLine(L["Clic: ver sus objetos"], 0.6, 0.6, 0.6)
	if not isMe(c) then
		tt:AddLine(L["Clic derecho: olvidar este personaje"], 0.6, 0.6, 0.6)
	end
end

local function drawChars()
	local chars = characters()
	local total, realm = 0, nil
	local n = 0
	for _, c in ipairs(chars) do
		-- Separador por reino cuando se ven todos
		if db.allRealms and c.realm ~= realm then
			realm = c.realm
			n = n + 1
			local row = getRow(n)
			setRowMode(row, false)
			row.char, row.itemID = nil, nil
			row.name:SetText(GOLD .. (realm or "?") .. "|r")
			row.level:SetText(""); row.money:SetText(""); row.zone:SetText(""); row.seen:SetText("")
			row.rest:Hide()
		end
		n = n + 1
		local row = getRow(n)
		setRowMode(row, false)
		row.char, row.itemID = c, nil
		row.name:SetText((isMe(c) and "|cff33ff33>|r " or "") .. coloredName(c))
		row.level:SetText(c.level or "?")
		row.money:SetText(R.Money(c.money or 0))
		row.zone:SetText(c.zone or "")
		row.seen:SetText(isMe(c) and L["ahora"] or agoText(c.lastSeen))
		local _, pct = restedNow(c)
		if pct then
			row.rest:SetValue(pct)
			row.rest.text:SetFormattedText("%d%%", pct * 100 + 0.5)
			row.rest:SetStatusBarColor(c.resting and 0.25 or 0.6, c.resting and 0.5 or 0.35, c.resting and 1 or 0.8)
		else
			row.rest:SetValue(0)
			row.rest.text:SetText(c.level and "|cff888888" .. L["nivel máximo"] .. "|r" or "")
		end
		total = total + (c.money or 0)
	end
	footer:SetText(L["Oro total: %s"]:format(R.Money(total)) .. "   |cff888888" .. L["%d personajes"]:format(#chars) .. "|r")
	emptyText:SetShown(n == 0)
	emptyText:SetText(L["Todavía no hay datos. Entra con cada personaje una vez."])
	return n
end

local MAX_RESULTS = 200

local function normalize(s)
	return (s or ""):lower()
end

-- Lista de personajes a la izquierda de la pestaña Objetos
local function charButton(i)
	local b = charButtons[i]
	if not b then
		b = CreateFrame("Button", nil, charScroll.child)
		b:SetHeight(ROW_H)
		b:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
		b:SetPoint("RIGHT", charScroll.child, "RIGHT")
		b.sel = b:CreateTexture(nil, "BACKGROUND")
		b.sel:SetAllPoints()
		b.sel:SetColorTexture(0.2, 0.8, 1, 0.25)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(0.2, 0.8, 1, 0.12)
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		b.text:SetPoint("LEFT", 6, 0)
		b.text:SetPoint("RIGHT", -4, 0)
		b.text:SetJustifyH("LEFT")
		b.text:SetWordWrap(false)
		b:SetScript("OnClick", function(self)
			selectedKey = self.key
			searchBox:SetText("")
			M:Refresh()
		end)
		charButtons[i] = b
	end
	b:Show()
	return b
end

local function drawCharList(chars, selected)
	for i, c in ipairs(chars) do
		local b = charButton(i)
		b.key = c.key
		b.sel:SetShown(c == selected)
		local text = c.level and ("|cff888888" .. c.level .. "|r " .. coloredName(c)) or coloredName(c)
		if db.allRealms then text = text .. " |cff888888- " .. (c.realm or "") .. "|r" end
		b.text:SetText(text)
	end
	for i = #chars + 1, #charButtons do charButtons[i]:Hide() end
	charScroll.child:SetHeight(math.max(1, #chars * ROW_H))
	if charScroll.UpdateBar then charScroll:UpdateBar() end
end

local function itemName(id)
	local it = store.items[id]
	return it and it.n or ("item:" .. id)
end

-- Título de una sección: "Banco  12 libres de 48 · hace 2 d"
local function sectionTitle(c, key, label)
	local extra
	if key == "bags" and c.bagTotal then
		extra = L["%d libres de %d"]:format(c.bagFree or 0, c.bagTotal)
	elseif key == "bank" then
		extra = c.bankSeen and (L["%d libres de %d"]:format(c.bankFree or 0, c.bankTotal or 0) .. " · " .. agoText(c.bankSeen))
			or L["sin ver: abre el banco con este personaje"]
	elseif key == "mail" and c.mailSeen then
		extra = agoText(c.mailSeen)
	end
	local title = L[label]:gsub("^%l", string.upper)
	return GOLD .. title .. "|r" .. (extra and ("  |cff888888" .. extra .. "|r") or "")
end

local function sortedIds(items)
	local ids = {}
	for id, count in pairs(items or {}) do
		if count > 0 then ids[#ids + 1] = id end
	end
	table.sort(ids, function(a, b) return itemName(a) < itemName(b) end)
	return ids
end

----------------------------------------------------------------------
-- Vista de bolsa: cada hueco en su sitio, como en el juego
----------------------------------------------------------------------

local SLOT, GAP, BAG_GAP = 34, 3, 8
local slotButtons, gridTitles = {}, {}
local usedSlots, usedTitles = 0, 0

local function hideGrid()
	for i = 1, #slotButtons do slotButtons[i]:Hide() end
	for i = 1, #gridTitles do gridTitles[i]:Hide() end
	usedSlots, usedTitles = 0, 0
end

local function getSlot()
	usedSlots = usedSlots + 1
	local b = slotButtons[usedSlots]
	if not b then
		b = CreateFrame("Button", nil, list.child, "BackdropTemplate")
		b:SetSize(SLOT, SLOT)
		b:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
		b.icon = b:CreateTexture(nil, "ARTWORK")
		b.icon:SetPoint("TOPLEFT", 1, -1)
		b.icon:SetPoint("BOTTOMRIGHT", -1, 1)
		b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		b.count = b:CreateFontString(nil, "OVERLAY", "NumberFontNormal")
		b.count:SetPoint("BOTTOMRIGHT", -2, 2)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints(b.icon)
		hl:SetColorTexture(1, 1, 1, 0.15)
		b:SetScript("OnEnter", function(self)
			if not self.itemID then return end
			GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
			GameTooltip:SetItemByID(self.itemID)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", GameTooltip_Hide)
		slotButtons[usedSlots] = b
	end
	b:ClearAllPoints()
	b:Show()
	return b
end

local function fillSlot(b, id, count)
	b.itemID = id
	if not id then
		b.icon:Hide()
		b.count:SetText("")
		b:SetBackdropColor(0, 0, 0, 0.45)
		b:SetBackdropBorderColor(0.25, 0.25, 0.25, 0.8)
		return
	end
	local it = store.items[id] or {}
	b.icon:SetTexture(it.i or 134400)
	b.icon:Show()
	b.count:SetText(count and count > 1 and count or "")
	b:SetBackdropColor(0, 0, 0, 0.6)
	-- Borde del color de la calidad (los objetos blancos y grises, borde neutro)
	local hex = it.c and it.c:sub(3):lower()
	if hex and hex ~= "ffffff" and hex ~= "9d9d9d" then
		b:SetBackdropBorderColor(R.HexToRGB(hex))
	else
		b:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	end
end

local function getTitle()
	usedTitles = usedTitles + 1
	local fs = gridTitles[usedTitles]
	if not fs then
		fs = list.child:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		fs:SetJustifyH("LEFT")
		gridTitles[usedTitles] = fs
	end
	fs:ClearAllPoints()
	fs:Show()
	return fs
end

-- Devuelve la altura dibujada
local function drawGrid(c)
	local width = list.child:GetWidth()
	local cols = math.max(1, math.floor((width + GAP) / (SLOT + GAP)))
	local y, col = 0, 0

	local function title(text)
		local fs = getTitle()
		fs:SetPoint("TOPLEFT", list.child, "TOPLEFT", 2, -(y + 4))
		fs:SetText(text)
		y = y + 22
	end
	local function put(id, count)
		if col >= cols then
			col = 0
			y = y + SLOT + GAP
		end
		local b = getSlot()
		b:SetPoint("TOPLEFT", list.child, "TOPLEFT", col * (SLOT + GAP), -y)
		fillSlot(b, id, count)
		col = col + 1
	end
	local function endGrid(extra)
		if col > 0 then y = y + SLOT + GAP end
		col = 0
		y = y + (extra or 0)
	end
	-- Cada bolsa empieza en una fila nueva, con un pequeño hueco entre ellas
	local function layoutGrid(layout)
		for _, box in ipairs(layout) do
			for slot = 1, box.size do
				local s = box.s[slot]
				put(s and s[1], s and s[2])
			end
			endGrid(BAG_GAP - GAP)
		end
	end
	-- Sin posiciones guardadas (buzón, equipado o datos antiguos): uno detrás de otro
	local function plainGrid(items)
		for _, id in ipairs(sortedIds(items)) do put(id, items[id]) end
		endGrid(BAG_GAP - GAP)
	end

	for _, p in ipairs(PLACES) do
		local key, label = p[1], p[2]
		local layout = (key == "bags" and c.bagLayout) or (key == "bank" and c.bankLayout)
		local hasItems = next(c[key] or {}) ~= nil
		if key == "bank" or hasItems or (layout and #layout > 0) then
			title(sectionTitle(c, key, label))
			if layout and #layout > 0 then
				layoutGrid(layout)
			elseif hasItems then
				plainGrid(c[key])
			end
		end
	end
	return y
end

-- Lo que lleva un personaje, por secciones: bolsas, banco, buzón y equipado
local function drawInventory(c)
	footer:SetText(coloredName(c) .. "  " .. R.Money(c.money or 0))
	if db.itemView ~= "list" then
		emptyText:Hide()
		return 0, drawGrid(c)
	end
	local n = 0
	local function sectionRow(text)
		n = n + 1
		local row = getRow(n)
		setRowMode(row, true)
		row.char, row.itemID = nil, nil
		row.icon:Hide()
		row.item:SetText(text)
		row.count:SetText("")
		row.where:SetText("")
	end
	for _, p in ipairs(PLACES) do
		local key, label = p[1], p[2]
		local items = c[key]
		local ids = sortedIds(items)
		if #ids > 0 or key == "bank" then sectionRow(sectionTitle(c, key, label)) end
		for _, id in ipairs(ids) do
			local it = store.items[id] or {}
			n = n + 1
			local row = getRow(n)
			setRowMode(row, true)
			row.char, row.itemID = nil, id
			row.icon:SetTexture(it.i or 134400)
			row.item:SetText("|c" .. (it.c or "ffffffff") .. itemName(id) .. "|r")
			row.count:SetText(items[id])
			row.where:SetText("")
		end
	end
	emptyText:SetText(L["Sin objetos guardados. Entra con este personaje."])
	emptyText:SetShown(n == 0)
	return n
end

local function drawItems()
	local q = normalize(strtrim(searchBox:GetText() or ""))
	local chars = characters()

	-- Personaje elegido (el actual si no hay otro o ya no está en la lista)
	local selected
	for _, c in ipairs(chars) do
		if c.key == selectedKey then selected = c end
	end
	selected = selected or me
	selectedKey = selected.key
	drawCharList(chars, q == "" and selected or nil)
	if q == "" then return drawInventory(selected) end

	local results = {}
	do
		for id, it in pairs(store.items) do
			if it.n and normalize(it.n):find(q, 1, true) then
				local total, owners = 0, {}
				for _, c in ipairs(chars) do
					local n, parts = countFor(c, id)
					if n > 0 then
						total = total + n
						owners[#owners + 1] = coloredName(c) .. " " .. n .. " |cff888888(" .. table.concat(parts, ", ") .. ")|r"
					end
				end
				if total > 0 then
					results[#results + 1] = { id = id, it = it, total = total, where = table.concat(owners, "  ·  ") }
				end
			end
		end
		table.sort(results, function(a, b) return a.it.n < b.it.n end)
	end
	local n = math.min(#results, MAX_RESULTS)
	for i = 1, n do
		local r = results[i]
		local row = getRow(i)
		setRowMode(row, true)
		row.char, row.itemID = nil, r.id
		row.icon:SetTexture(r.it.i or 134400)
		row.item:SetText("|c" .. (r.it.c or "ffffffff") .. r.it.n .. "|r")
		row.count:SetText(r.total)
		row.where:SetText(r.where)
	end
	footer:SetText(#results > MAX_RESULTS and L["%d resultados (se muestran %d)"]:format(#results, MAX_RESULTS)
		or L["%d resultados"]:format(#results))
	emptyText:SetText(L["Ningún personaje tiene un objeto con ese nombre."])
	emptyText:SetShown(n == 0)
	return n
end

function M:Refresh()
	if not win or not win:IsShown() then return end
	if me then saveBasics() end
	local items = mode == "items"
	header:SetShown(not items)
	searchBox:SetShown(items)
	charPanel:SetShown(items)
	tabs.chars:SetEnabled(items)
	tabs.items:SetEnabled(not items)
	-- En Objetos la lista deja sitio a los personajes de la izquierda
	local left = items and (CHAR_W + 10) or 4
	list:ClearAllPoints()
	list:SetPoint("TOPLEFT", body, "TOPLEFT", left, -28)
	list:SetPoint("BOTTOMRIGHT", body, "BOTTOMRIGHT", -6, 4)
	list.child:SetWidth(W - 36 - (left - 4))
	viewButton:SetShown(items)
	viewButton:SetText(db.itemView == "list" and L["Ver como bolsa"] or L["Ver como lista"])
	hideGrid()
	local n, gridHeight
	if items then n, gridHeight = drawItems() else n = drawChars() end
	for i = n + 1, #rows do rows[i]:Hide() end
	list.child:SetHeight(math.max(1, gridHeight or n * ROW_H))
	if list.UpdateBar then list:UpdateBar() end
end

local function headerLabel(key, text)
	local c = COLS[key]
	local fs = header:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	fs:SetPoint("LEFT", header, "LEFT", c[1], 0)
	fs:SetWidth(c[2])
	fs:SetJustifyH(c[3] or "CENTER")
	fs:SetText(text)
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorCharacters", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	backdrop(win, 0.94)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorCharacters")   -- se cierra con Esc

	local drag = CreateFrame("Frame", nil, win)
	drag:SetPoint("TOPLEFT")
	drag:SetPoint("TOPRIGHT", -30, 0)
	drag:SetHeight(30)
	drag:EnableMouse(true)
	drag:RegisterForDrag("LeftButton")
	drag:SetScript("OnDragStart", function() win:StartMoving() end)
	drag:SetScript("OnDragStop", function()
		win:StopMovingOrSizing()
		win:SetUserPlaced(false)
		local point, _, relPoint, x, y = win:GetPoint()
		db.point = { point, relPoint, x, y }
	end)

	local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -9)
	title:SetText("|cff33ccffRheizor|r · " .. L["Personajes"])

	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() win:Hide() end)

	-- Pestañas
	tabs = {}
	local function tab(key, text, anchor)
		local b = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
		b:SetSize(120, 22)
		b:SetText(text)
		b:SetScript("OnClick", function()
			mode = key
			M:Refresh()
		end)
		if anchor then b:SetPoint("LEFT", anchor, "RIGHT", 4, 0) else b:SetPoint("TOPLEFT", 12, -36) end
		tabs[key] = b
		return b
	end
	local t1 = tab("chars", L["Personajes"])
	tab("items", L["Objetos"], t1)

	local realms = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
	realms:SetSize(22, 22)
	realms:SetPoint("TOPRIGHT", -150, -36)
	local realmsText = realms:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	realmsText:SetPoint("LEFT", realms, "RIGHT", 2, 0)
	realmsText:SetText(L["Todos los reinos"])
	realms:SetScript("OnShow", function(self) self:SetChecked(db.allRealms) end)
	realms:SetScript("OnClick", function(self)
		db.allRealms = self:GetChecked() and true or false
		M:Refresh()
	end)

	-- Cuerpo
	body = CreateFrame("Frame", nil, win, "BackdropTemplate")
	body:SetPoint("TOPLEFT", 10, -64)
	body:SetPoint("BOTTOMRIGHT", -10, 36)
	backdrop(body, 0.6)
	body:SetBackdropBorderColor(1, 1, 1, 0.1)

	header = CreateFrame("Frame", nil, body)
	header:SetPoint("TOPLEFT", 4, -4)
	header:SetPoint("TOPRIGHT", -4, -4)
	header:SetHeight(20)
	headerLabel("name", L["Personaje"])
	headerLabel("level", L["Nivel"])
	headerLabel("money", L["Oro"])
	headerLabel("rest", L["Descanso"])
	headerLabel("zone", L["Zona"])
	headerLabel("seen", L["Última vez"])

	searchBox = CreateFrame("EditBox", nil, body, "BackdropTemplate")
	searchBox:SetPoint("TOPLEFT", CHAR_W + 10, -4)
	searchBox:SetSize(300, 22)
	searchBox:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
	searchBox:SetBackdropColor(0, 0, 0, 0.6)
	searchBox:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	searchBox:SetFontObject(GameFontHighlightSmall)
	searchBox:SetTextInsets(6, 6, 0, 0)
	searchBox:SetAutoFocus(false)
	searchBox:SetMaxLetters(50)
	local hint = searchBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("LEFT", 7, 0)
	hint:SetText(L["Buscar objeto..."])
	searchBox:SetScript("OnTextChanged", function(self)
		hint:SetShown(self:GetText() == "")
		M:Refresh()
	end)
	searchBox:SetScript("OnEscapePressed", function(self)
		if self:GetText() ~= "" then self:SetText("") else self:ClearFocus() end
	end)
	searchBox:SetScript("OnEnterPressed", searchBox.ClearFocus)

	-- Bolsa o lista
	viewButton = CreateFrame("Button", nil, body, "UIPanelButtonTemplate")
	viewButton:SetSize(130, 22)
	viewButton:SetPoint("LEFT", searchBox, "RIGHT", 8, 0)
	viewButton:SetScript("OnClick", function()
		db.itemView = db.itemView == "list" and "grid" or "list"
		M:Refresh()
	end)

	if UI.MakeScroll then
		list = UI.MakeScroll(body)
	else
		list = CreateFrame("ScrollFrame", nil, body, "UIPanelScrollFrameTemplate")
		list.child = CreateFrame("Frame", nil, list)
		list:SetScrollChild(list.child)
	end
	list.child:SetSize(W - 36, 1)

	-- Personajes a la izquierda de la pestaña Objetos
	charPanel = CreateFrame("Frame", nil, body, "BackdropTemplate")
	charPanel:SetPoint("TOPLEFT", 4, -4)
	charPanel:SetPoint("BOTTOMLEFT", 4, 4)
	charPanel:SetWidth(CHAR_W)
	backdrop(charPanel, 0.4)
	charPanel:SetBackdropBorderColor(1, 1, 1, 0.08)
	if UI.MakeScroll then
		charScroll = UI.MakeScroll(charPanel)
	else
		charScroll = CreateFrame("ScrollFrame", nil, charPanel, "UIPanelScrollFrameTemplate")
		charScroll.child = CreateFrame("Frame", nil, charScroll)
		charScroll:SetScrollChild(charScroll.child)
	end
	charScroll:SetPoint("TOPLEFT", 2, -2)
	charScroll:SetPoint("BOTTOMRIGHT", -4, 2)
	charScroll.child:SetSize(CHAR_W - 8, 1)

	emptyText = body:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	emptyText:SetPoint("CENTER", list, "CENTER")

	footer = win:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	footer:SetPoint("BOTTOMLEFT", 16, 13)

	local note = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	note:SetPoint("BOTTOMRIGHT", -14, 14)
	note:SetText(L["El banco y el buzón se guardan al abrirlos con cada personaje."])

	win:SetScript("OnShow", function() M:Refresh() end)
	win:SetScript("OnHide", function() if searchBox then searchBox:ClearFocus() end end)
end

function M:ApplyWindow()
	if not win then return end
	win:SetScale(db.scale)
	win:ClearAllPoints()
	local p = db.point
	if p then win:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else win:SetPoint("CENTER") end
end

function M:ResetPosition()
	db.point = nil
	self:ApplyWindow()
end

function M:Toggle()
	if not store then return end
	if not win then
		createWindow()
		self:ApplyWindow()
	end
	win:SetShown(not win:IsShown())
end

-- Olvidar un personaje (borrado o transferido), con confirmación
StaticPopupDialogs["RHEIZOR_FORGET_CHARACTER"] = {
	text = "%s",
	button1 = YES,
	button2 = NO,
	OnAccept = function(_, key)
		store.chars[key] = nil
		M:Refresh()
	end,
	timeout = 0,
	whileDead = true,
	hideOnEscape = true,
}

function forget(c)
	if isMe(c) or not c.key then return end
	StaticPopup_Show("RHEIZOR_FORGET_CHARACTER",
		L["¿Olvidar a %s (%s)? Se borran sus datos guardados; vuelven a aparecer si entras con él."]:format(coloredName(c), c.realm or ""),
		nil, c.key)
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local pending = {}
local function later(what, fn)
	if pending[what] then return end
	pending[what] = true
	C_Timer.After(0.5, function()
		pending[what] = nil
		fn()
		M:Refresh()
	end)
end

local BANKER = Enum and Enum.PlayerInteractionType and Enum.PlayerInteractionType.Banker
local MAILBOX = Enum and Enum.PlayerInteractionType and Enum.PlayerInteractionType.MailInfo

local function bankShown(on)
	bankOpen = on
	if on then later("bank", saveBank) end
end

local function mailShown(on)
	mailOpen = on
	if on then later("mail", saveMail) end
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, arg1, arg2)
	-- Apagado en Rheizor (sin recargar aún): deja de apuntar datos
	if not R:IsModuleRunning(M) then
		if event == "TIME_PLAYED_MSG" then unmuteChat() end
		return
	end
	if event == "BAG_UPDATE_DELAYED" or event == "BAG_UPDATE" then
		later("bags", saveBags)
		if bankOpen then later("bank", saveBank) end
	elseif event == "PLAYERBANKSLOTS_CHANGED" or event == "BANK_TABS_CHANGED" then
		if bankOpen then later("bank", saveBank) end
	elseif event == "BANKFRAME_OPENED" then
		bankShown(true)
	elseif event == "BANKFRAME_CLOSED" then
		bankOpen = false
	elseif event == "MAIL_SHOW" then
		mailShown(true)
	elseif event == "MAIL_INBOX_UPDATE" then
		if mailOpen then later("mail", saveMail) end
	elseif event == "MAIL_CLOSED" then
		mailOpen = false
	elseif event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW" or event == "PLAYER_INTERACTION_MANAGER_FRAME_HIDE" then
		local on = event == "PLAYER_INTERACTION_MANAGER_FRAME_SHOW"
		if BANKER and arg1 == BANKER then bankShown(on) end
		if MAILBOX and arg1 == MAILBOX then mailShown(on) end
	elseif event == "PLAYER_EQUIPMENT_CHANGED" then
		later("equip", saveEquipped)
	elseif event == "SKILL_LINES_CHANGED" then
		later("skills", saveSkills)
	elseif event == "TIME_PLAYED_MSG" then
		me.played, me.playedAt = NS(arg1) or me.played, time()
		C_Timer.After(0.5, unmuteChat)
		M:Refresh()
	elseif event == "PLAYER_LOGOUT" then
		-- Al salir el juego ya da 0 en oro, experiencia y descanso (y "no
		-- descansando"): solo se apunta la hora; lo demás ya está guardado
		-- de los eventos anteriores
		me.lastSeen = time()
	else
		-- Dinero, experiencia, descanso, zona, nivel
		saveBasics()
		M:Refresh()
	end
end)

local EVENTS = {
	"PLAYER_MONEY", "PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "PLAYER_UPDATE_RESTING", "PLAYER_LEVEL_UP",
	"ZONE_CHANGED_NEW_AREA", "PLAYER_LOGOUT",
	"BAG_UPDATE_DELAYED", "PLAYERBANKSLOTS_CHANGED", "BANK_TABS_CHANGED",
	"BANKFRAME_OPENED", "BANKFRAME_CLOSED", "MAIL_SHOW", "MAIL_INBOX_UPDATE", "MAIL_CLOSED",
	"PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "PLAYER_INTERACTION_MANAGER_FRAME_HIDE",
	"PLAYER_EQUIPMENT_CHANGED", "SKILL_LINES_CHANGED", "TIME_PLAYED_MSG",
}

local function registerEvents()
	for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
	-- Sin el evento agrupado se usa el de cada bolsa (se agrupa igualmente)
	if not events:IsEventRegistered("BAG_UPDATE_DELAYED") then pcall(events.RegisterEvent, events, "BAG_UPDATE") end
end

function M:OnEnable()
	db = self.db
	RheizorCharsDB = type(RheizorCharsDB) == "table" and RheizorCharsDB or {}
	store = RheizorCharsDB
	store.version = 1
	store.chars = store.chars or {}
	store.items = store.items or {}

	myRealm = GetRealmName()
	-- Con nombre completo: en Forever varios personajes comparten nombre de pila
	myKey = R.PlayerFullName() .. " - " .. myRealm
	-- La clave antigua (solo el nombre de pila) mezclaba a esos personajes: se
	-- borra y cada uno se vuelve a guardar al entrar con él
	local oldKey = (NS(UnitName("player")) or "?") .. " - " .. myRealm
	if oldKey ~= myKey then store.chars[oldKey] = nil end
	store.chars[myKey] = store.chars[myKey] or {}
	me = store.chars[myKey]
	me.key = myKey

	saveIdentity()
	saveBasics()
	saveBags()
	saveEquipped()
	saveSkills()
	registerEvents()
	hookTooltips()

	-- Lo que tarda en llegar al entrar (bolsas y habilidades) se vuelve a leer
	C_Timer.After(3, function()
		saveBags()
		saveEquipped()
		saveSkills()
		if db.played and R:IsModuleRunning(M) then requestPlayed() end
	end)
end

function M:OnOptionChanged(key)
	if key == "scale" then self:ApplyWindow() end
	self:Refresh()
end
