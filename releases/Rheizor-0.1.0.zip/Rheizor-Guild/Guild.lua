-- Rheizor-Guild: las profesiones de tu hermandad y sus recetas destacadas.
--
-- En Classic el juego no da a los addons las profesiones de los demás (eso
-- llegó en Cataclysm). Aquí cada miembro que usa Rheizor envía las suyas
-- por el canal de addons de la hermandad (mensajes invisibles, no salen en
-- el chat): al entrar, al subir una profesión, al cambiar sus recetas
-- destacadas y cuando alguien las pide.
--
-- Recetas destacadas: cada uno marca las suyas buenas con una casilla en la
-- ventana de profesiones o en la pestaña «Mis recetas» (que lista las que
-- conoce: se apuntan al abrir la ventana de cada profesión). Luego se
-- buscan en la pestaña «Recetas», con quién las hace.
--
-- Todo va en RheizorGuildDB: lo recibido por hermandad y reino, y lo tuyo
-- (recetas conocidas y destacadas) por personaje. Ventana: /rzg.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local PREFIX = "RheizorGd"
local VERSION = "1"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local MAX_FEATURED = 60

-- Profesiones: id de su línea de habilidad, hechizo (para el icono) y nombre
local PROFS = {
	{ id = 171, spell = 2259, name = "Alquimia" },
	{ id = 164, spell = 2018, name = "Herrería" },
	{ id = 333, spell = 7411, name = "Encantamiento" },
	{ id = 202, spell = 4036, name = "Ingeniería" },
	{ id = 182, spell = 2366, name = "Herboristería", icon = 136065 },
	{ id = 165, spell = 2108, name = "Peletería" },
	{ id = 186, spell = 2575, name = "Minería", icon = 136248 },
	{ id = 393, spell = 8613, name = "Desuello", icon = 134366 },
	{ id = 197, spell = 3908, name = "Sastrería" },
	{ id = 185, spell = 2550, name = "Cocina" },
	{ id = 129, spell = 3273, name = "Primeros auxilios" },
	{ id = 356, spell = 7620, name = "Pesca" },
}
local BY_ID = {}
for _, p in ipairs(PROFS) do BY_ID[p.id] = p end

local M = R:RegisterModule("guild", {
	title = "Hermandad",
	defaults = {
		share = true,
		onlyOnline = false,
		forgetDays = 60,
		professionCheck = true,
		whButton = true,
		whCtrl = true,
		whTarget = "item",
		whSite = "classic",
		whSpanish = true,
	},
	options = {
		{ type = "header", text = "Profesiones de la hermandad" },
		{ type = "button", name = "Profesiones de la hermandad", text = "Abrir",
		  desc = "También con /rzg o /rz hermandad.", func = function(mod) mod:Toggle() end },
		{ type = "toggle", key = "share", name = "Compartir mis profesiones con la hermandad",
		  desc = "Tus profesiones y tus recetas destacadas. Se envían por el canal de addons de la hermandad (no sale nada en el chat). Solo las ven los que llevan Rheizor." },
		{ type = "toggle", key = "professionCheck", name = "Casilla «Destacar en la hermandad» en la ventana de profesiones",
		  desc = "Al elegir una receta que conoces, para marcarla como de las buenas." },
		{ type = "slider", key = "forgetDays", name = "Olvidar a quien no se vea en", min = 7, max = 365, step = 1,
		  format = function(v) return L["%d días"]:format(v) end,
		  desc = "Quien no haya enviado sus profesiones en este tiempo (o ya no esté en la hermandad) deja de salir." },
		{ type = "button", name = "Pedir las profesiones a los conectados", text = "Pedir",
		  func = function(mod) mod:Request(true) end },

		{ type = "header", text = "Wowhead" },
		{ type = "toggle", key = "whButton", name = "Botón de Wowhead en cada receta",
		  desc = "Un icono al final de cada receta del listado. Muestra su enlace de Wowhead para copiarlo." },
		{ type = "toggle", key = "whCtrl", name = "Ctrl+clic en una receta",
		  desc = "Muestra el enlace de Wowhead de esa receta para copiarlo." },
		{ type = "dropdown", key = "whTarget", name = "Qué abrir",
		  values = { { "item", "El objeto que fabrica" }, { "spell", "La receta" } },
		  desc = "En la página del objeto se ve con qué se fabrica. Si la receta no fabrica un objeto (encantamientos), se usa la receta." },
		{ type = "dropdown", key = "whSite", name = "Versión de Wowhead",
		  values = { { "classic", "Classic" }, { "retail", "Retail" } } },
		{ type = "toggle", key = "whSpanish", name = "Wowhead en español" },
	},
	unsupported = {
		"Solo salen los miembros que usan Rheizor: el juego no da a los addons las profesiones de los demás en Classic.",
		"Dentro de mazmorras y bandas el juego puede bloquear los mensajes entre addons: se envían al salir.",
	},
})

local db, store
local win

local function call(fn, ...)
	if not fn then return end
	local ok, a, b, c, d = pcall(fn, ...)
	if ok then return a, b, c, d end
end

local function spellName(id)
	if C_Spell and C_Spell.GetSpellName then return call(C_Spell.GetSpellName, id) end
	return (call(GetSpellInfo, id))
end

local function spellIcon(id)
	if C_Spell and C_Spell.GetSpellTexture then return call(C_Spell.GetSpellTexture, id) end
	return select(3, call(GetSpellInfo, id))
end

local function profIcon(p)
	return p.icon or spellIcon(p.spell) or 134400
end

local function iconTag(tex, size)
	return ("|T%s:%d:%d:0:0:64:64:5:59:5:59|t"):format(tex or 134400, size or 14, size or 14)
end

local function lockdown()
	return C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and call(C_ChatInfo.InChatMessagingLockdown) == true
end

----------------------------------------------------------------------
-- Datos guardados
----------------------------------------------------------------------

local function guildKey()
	local name = NS(call(GetGuildInfo, "player"))
	if not name then return end
	return name .. " - " .. (GetRealmName() or "?")
end

local function guildData()
	local k = guildKey()
	if not k then return end
	store.guilds = store.guilds or {}
	store.guilds[k] = store.guilds[k] or { members = {} }
	return store.guilds[k]
end

-- Lo de este personaje: recetas que conoce (por profesión) y destacadas
local function myData()
	store.chars = store.chars or {}
	local k = R.charKey or "?"
	store.chars[k] = store.chars[k] or { known = {}, featured = {} }
	local d = store.chars[k]
	d.known = d.known or {}
	d.featured = d.featured or {}
	return d
end

----------------------------------------------------------------------
-- Mis profesiones
----------------------------------------------------------------------

local SK = C_SkillInfo
local nameToID

-- Nombre de una profesión -> id (por el nombre traducido, el del hechizo de
-- la profesión y el que ponemos aquí)
local function lookup(name)
	if not name then return end
	if not nameToID then
		nameToID = {}
		for _, p in ipairs(PROFS) do
			nameToID[L[p.name]] = p.id
			nameToID[p.name] = p.id
			local s = spellName(p.spell)
			if s then nameToID[s] = p.id end
		end
	end
	return nameToID[name]
end

-- Una sola entrada por profesión (el juego puede dar la misma línea dos
-- veces): se queda la de más nivel, en el orden de PROFS
local function unique(list)
	local best = {}
	for _, s in ipairs(list or {}) do
		if s.k and (not best[s.k] or (s.r or 0) > (best[s.k].r or 0)) then best[s.k] = s end
	end
	local out = {}
	for _, p in ipairs(PROFS) do
		if best[p.id] then out[#out + 1] = best[p.id] end
	end
	return out
end

local function mySkills()
	local numLines = (SK and SK.GetNumSkillLines) or GetNumSkillLines
	if not numLines then return end
	local list = {}
	for i = 1, call(numLines) or 0 do
		local name, header, rank, maxRank, id
		if SK and SK.GetSkillLineInfo then
			local info = call(SK.GetSkillLineInfo, i)
			if type(info) == "table" then
				name, header, rank, maxRank = info.name, info.isHeader, info.rank, info.maxRank
				id = info.skillLineID or info.skillID
			end
		else
			local n, h, _, r, _, _, m = call(GetSkillLineInfo, i)
			name, header, rank, maxRank = n, h, r, m
		end
		if name and not header then
			id = (id and BY_ID[id] and id) or lookup(name)
			if id and rank then list[#list + 1] = { k = id, r = rank, m = maxRank or rank } end
		end
	end
	return unique(list)
end

local function myKey()
	return R.NameKey(R.PlayerFullName())
end

-- Mis destacadas como lista { {id, i, p} } ordenada
local function myFeaturedList()
	local list = {}
	for id, f in pairs(myData().featured) do
		list[#list + 1] = { id = id, i = f.i or 0, p = f.p }
	end
	table.sort(list, function(a, b) return a.id < b.id end)
	return list
end

-- Uno mismo también sale en la lista
local function saveMine()
	local g = guildData()
	local skills = mySkills()
	if not (g and skills) then return end
	local _, class = UnitClass("player")
	g.members[myKey()] = { class = class, level = UnitLevel("player"), skills = skills,
		recipes = myFeaturedList(), t = time() }
end

----------------------------------------------------------------------
-- Recetas que conozco (al abrir la ventana de cada profesión)
----------------------------------------------------------------------

local TS = C_TradeSkillUI

-- Es mi propia profesión (no la de otro enlazada ni la de un PNJ)
local function ownTradeSkill()
	if not TS then return false end
	if call(TS.IsTradeSkillLinked) or call(TS.IsTradeSkillGuild) or call(TS.IsNPCCrafting) then return false end
	return true
end

local function openProfession()
	for _, fn in ipairs({ TS and TS.GetChildProfessionInfo, TS and TS.GetBaseProfessionInfo }) do
		local info = call(fn)
		if type(info) == "table" then
			local id = (BY_ID[info.professionID] and info.professionID)
				or (BY_ID[info.parentProfessionID] and info.parentProfessionID)
				or lookup(info.professionName) or lookup(info.parentProfessionName)
			if id then return id end
		end
	end
end

local function outputItem(recipeID)
	local s = TS and call(TS.GetRecipeSchematic, recipeID, false)
	return type(s) == "table" and NS(s.outputItemID) or nil
end

local function scanRecipes()
	if not ownTradeSkill() then return end
	local prof = openProfession()
	if not prof then return end
	local ids = call(TS.GetAllRecipeIDs) or call(TS.GetFilteredRecipeIDs)
	if type(ids) ~= "table" then return end
	-- Se suman a las ya apuntadas: con un filtro o una búsqueda puesta en la
	-- ventana de profesiones el juego solo da parte de la lista
	local known = myData().known
	local list = known[prof] or {}
	local have = {}
	for _, r in ipairs(list) do have[r.id] = r end
	local catNames = {}
	for _, id in ipairs(ids) do
		local info = call(TS.GetRecipeInfo, id)
		if type(info) == "table" and info.learned and not info.isRecraft then
			-- Categoría de la ventana de profesiones y dificultad (color de
			-- la receta: naranja, amarilla, verde, gris); se actualizan en
			-- cada vistazo
			local cat = info.categoryID
			if cat and catNames[cat] == nil then
				local ci = call(TS.GetCategoryInfo, cat)
				catNames[cat] = type(ci) == "table" and ci.name or false
			end
			local r = have[id]
			if not r then
				r = { id = id, i = outputItem(id) or 0 }
				list[#list + 1] = r
				have[id] = r
			end
			r.c = cat and catNames[cat] or r.c
			r.d = NS(info.relativeDifficulty) or r.d
		end
	end
	if #list > 0 then known[prof] = list end
	if win and win:IsShown() then M:Refresh() end
end

local scanQueued = false
local function queueScan()
	if scanQueued then return end
	scanQueued = true
	C_Timer.After(1, function()
		scanQueued = false
		scanRecipes()
	end)
end

----------------------------------------------------------------------
-- Mensajes
----------------------------------------------------------------------

local lastShare, lastRequest = 0, 0
local retry

local function send(msg)
	if not (C_ChatInfo and C_ChatInfo.SendAddonMessage and IsInGuild()) then return false end
	if lockdown() then return false end
	local ok, res = pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, "GUILD")
	if not ok or res == false then return false end
	-- Clientes nuevos devuelven un código (0 = enviado)
	if type(res) == "number" and Enum and Enum.SendAddonMessageResult then
		return res == Enum.SendAddonMessageResult.Success
	end
	return true
end

-- Si no se puede ahora (mazmorra...), se vuelve a intentar en un rato
local function later(fn)
	if retry then return end
	retry = true
	C_Timer.After(30, function() retry = nil; fn() end)
end

-- Destacadas en trozos que quepan en un mensaje: F1|parte|total|id:objeto:prof,...
local function featuredMessages()
	local chunks, cur = {}, {}
	local len = 0
	for _, f in ipairs(myFeaturedList()) do
		local s = f.id .. ":" .. f.i .. ":" .. (f.p or 0)
		if len + #s + 1 > 220 and #cur > 0 then
			chunks[#chunks + 1] = cur
			cur, len = {}, 0
		end
		cur[#cur + 1] = s
		len = len + #s + 1
	end
	chunks[#chunks + 1] = cur
	local msgs = {}
	for i, c in ipairs(chunks) do
		msgs[i] = ("F%s|%d|%d|%s"):format(VERSION, i, #chunks, table.concat(c, ","))
	end
	return msgs
end

function M:Share(force)
	if not (db and db.share and IsInGuild()) then return end
	local now = GetTime()
	if not force and now - lastShare < 20 then return end
	local skills = mySkills()
	if not skills then return end
	saveMine()
	local parts = {}
	for _, s in ipairs(skills) do parts[#parts + 1] = s.k .. ":" .. s.r .. ":" .. s.m end
	local _, class = UnitClass("player")
	local msg = ("P%s|%s|%d|%s"):format(VERSION, class or "", UnitLevel("player") or 0, table.concat(parts, ","))
	if not send(msg) then
		later(function() M:Share(true) end)
		return
	end
	lastShare = now
	-- Las destacadas detrás, un poco espaciadas
	for i, m in ipairs(featuredMessages()) do
		C_Timer.After(0.3 * i, function() send(m) end)
	end
end

-- Al marcar o desmarcar varias seguidas: se envía una vez al acabar
local shareQueued = false
local function queueShare()
	saveMine()
	if shareQueued then return end
	shareQueued = true
	C_Timer.After(5, function()
		shareQueued = false
		M:Share(true)
	end)
end

function M:Request(user)
	if not IsInGuild() then
		if user then R:Print(L["No estás en ninguna hermandad."]) end
		return
	end
	local now = GetTime()
	if now - lastRequest < 10 then return end
	lastRequest = now
	if not send("Q") then
		if user then R:Print(L["Ahora el juego no deja enviar mensajes entre addons (mazmorra o banda): prueba al salir."]) end
		return
	end
	if user then R:Print(L["Pedidas las profesiones a los conectados que usan Rheizor."]) end
end

local replyQueued = false
local incoming = {}   -- remitente -> destacadas a medio llegar

local function onMessage(prefix, msg, channel, sender)
	if prefix ~= PREFIX or channel ~= "GUILD" or type(msg) ~= "string" then return end
	if R.IsMyName(sender) then return end
	if msg == "Q" then
		-- Cada uno responde con un pequeño retraso, para no llegar todos a la vez
		if db.share and not replyQueued then
			replyQueued = true
			C_Timer.After(1 + math.random() * 6, function()
				replyQueued = false
				M:Share(true)
			end)
		end
		return
	end
	local g = guildData()
	if not g then return end
	local key = R.NameKey(sender)

	local ver, class, level, list = msg:match("^P(%d+)|([%u]*)|(%d+)|(.*)$")
	if ver then
		local skills = {}
		for id, r, m in list:gmatch("(%d+):(%d+):(%d+)") do
			skills[#skills + 1] = { k = tonumber(id), r = tonumber(r), m = tonumber(m) }
		end
		local old = g.members[key]
		g.members[key] = { class = class ~= "" and class or nil, level = tonumber(level), skills = unique(skills),
			recipes = old and old.recipes, t = time() }
		if win and win:IsShown() then M:Refresh() end
		return
	end

	local part, total, rlist = msg:match("^F%d+|(%d+)|(%d+)|(.*)$")
	if part then
		part, total = tonumber(part), tonumber(total)
		if part == 1 then incoming[key] = {} end
		local acc = incoming[key]
		if not acc then return end
		for id, item, prof in rlist:gmatch("(%d+):(%d+):(%d+)") do
			acc[#acc + 1] = { id = tonumber(id), i = tonumber(item), p = tonumber(prof) }
		end
		if part >= total then
			incoming[key] = nil
			local m = g.members[key]
			if m then
				m.recipes = acc
				m.t = time()
			end
			if win and win:IsShown() then M:Refresh() end
		end
	end
end

----------------------------------------------------------------------
-- Destacar
----------------------------------------------------------------------

function M:IsFeatured(recipeID)
	return myData().featured[recipeID] ~= nil
end

function M:SetFeatured(recipeID, prof, item, on)
	local f = myData().featured
	if on then
		local n = 0
		for _ in pairs(f) do n = n + 1 end
		if not f[recipeID] and n >= MAX_FEATURED then
			R:Print(L["Como mucho %d recetas destacadas por personaje."]:format(MAX_FEATURED))
			return false
		end
		f[recipeID] = { p = prof, i = item or 0 }
	else
		f[recipeID] = nil
	end
	queueShare()
	if win and win:IsShown() then self:Refresh() end
	if self.UpdateStar then self:UpdateStar() end
	return true
end

----------------------------------------------------------------------
-- Casilla en la ventana de profesiones
----------------------------------------------------------------------

local star, starRecipe

function M:UpdateStar(recipeInfo)
	if not star then return end
	if recipeInfo then starRecipe = recipeInfo end
	local info = starRecipe
	local show = db.professionCheck and R:IsAddonActive(M.addon) and info and info.learned
		and not info.isRecraft and ownTradeSkill() and openProfession() ~= nil
	star:SetShown(show and true or false)
	if show then star:SetChecked(self:IsFeatured(info.recipeID)) end
end

local function setupStar()
	local page = ProfessionsFrame and ProfessionsFrame.CraftingPage
	local form = page and page.SchematicForm
	if not form or star then return end
	star = CreateFrame("CheckButton", nil, form, "UICheckButtonTemplate")
	star:SetSize(22, 22)
	star:SetPoint("TOPRIGHT", form, "TOPRIGHT", -8, -4)
	star:SetFrameLevel(form:GetFrameLevel() + 10)
	star.label = star:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	star.label:SetPoint("RIGHT", star, "LEFT", -2, 0)
	star.label:SetText(L["Destacar en la hermandad"])
	star:SetScript("OnClick", function(self)
		local info = starRecipe
		if not info then return end
		local ok = M:SetFeatured(info.recipeID, openProfession(), outputItem(info.recipeID), self:GetChecked())
		if not ok then self:SetChecked(false) end
	end)
	star:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:AddLine(L["Destacar en la hermandad"])
		GameTooltip:AddLine(L["La gente de tu hermandad con Rheizor la verá en la pestaña «Recetas» (/rzg) y sabrá que la haces tú."], 1, 1, 1, true)
		GameTooltip:Show()
	end)
	star:SetScript("OnLeave", GameTooltip_Hide)
	star:Hide()
	if form.Init then
		hooksecurefunc(form, "Init", function(_, recipeInfo) M:UpdateStar(recipeInfo) end)
	end
end

----------------------------------------------------------------------
-- Lista de la hermandad
----------------------------------------------------------------------

-- Quién está en la hermandad ahora y si está conectado
local roster = {}
local function readRoster()
	wipe(roster)
	local n = NS(call(GetNumGuildMembers)) or 0
	for i = 1, n do
		local name, _, _, level, _, _, note, _, online, _, class = call(GetGuildRosterInfo, i)
		name = NS(name)
		if name then
			roster[R.NameKey(name)] = { online = NS(online) and true or false, level = NS(level), class = NS(class), note = NS(note) }
		end
	end
	return n > 0
end

-- Quita a quien ya no está en la hermandad o hace mucho que no se ve
local function prune()
	local g = guildData()
	if not g then return end
	local hasRoster = next(roster) ~= nil
	local limit = time() - db.forgetDays * 86400
	for k, m in pairs(g.members) do
		if (hasRoster and not roster[k]) or (m.t or 0) < limit then g.members[k] = nil end
	end
end

----------------------------------------------------------------------
-- Ventana: profesiones a la izquierda; a la derecha tres pestañas
----------------------------------------------------------------------

local W, H = 700, 524
local SIDE_W = 170
local ROW_H, ROWS = 22, 14
local LIST_TOP = 156
local FILTER_TOP = 98   -- dos filas de filtros entre el buscador y la lista
local filter, search = 0, ""
local view = "people"   -- people | recipes | mine
local offset = 0
local visible = {}

local function skillOf(m, id)
	for _, s in ipairs(m.skills or {}) do
		if s.k == id then return s end
	end
end

local function classColor(class)
	local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
	if c then return c.r, c.g, c.b end
	return 0.8, 0.8, 0.8
end

local function isOnline(key)
	local r = roster[key]
	return (r and r.online) or key == myKey()
end

local function recipeName(r)
	return spellName(r.id) or (r.i and r.i > 0 and C_Item and C_Item.GetItemNameByID and call(C_Item.GetItemNameByID, r.i)) or ("#" .. r.id)
end

local function recipeIcon(r)
	if r.i and r.i > 0 and C_Item and C_Item.GetItemIconByID then
		local icon = call(C_Item.GetItemIconByID, r.i)
		if icon then return icon end
	end
	return spellIcon(r.id) or 134400
end

local function recipeColor(r)
	local q = r.i and r.i > 0 and C_Item and C_Item.GetItemQualityByID and call(C_Item.GetItemQualityByID, r.i)
	local c = q and ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
	if c then return c.r, c.g, c.b end
	return 1, 1, 1
end

local function skillColor(s)
	if s.r >= s.m and s.m >= 300 then return 0.2, 1, 0.2 end
	if s.r >= 225 then return 1, 0.82, 0 end
	return 0.3, 0.7, 1
end

-- Personas
local function buildPeople(g, q)
	for key, m in pairs(g.members) do
		m.skills = unique(m.skills)   -- datos guardados antes de quitar las repetidas
		if (not db.onlyOnline or isOnline(key)) and (q == "" or key:lower():find(q, 1, true))
			and (filter == 0 or skillOf(m, filter)) then
			visible[#visible + 1] = { key = key, m = m, online = isOnline(key), r = roster[key] }
		end
	end
	table.sort(visible, function(a, b)
		if filter ~= 0 then
			local sa, sb = skillOf(a.m, filter), skillOf(b.m, filter)
			if sa.r ~= sb.r then return sa.r > sb.r end
		end
		if a.online ~= b.online then return a.online end
		return a.key < b.key
	end)
end

----------------------------------------------------------------------
-- Filtros de las recetas (los valores salen de lo que hay en la lista)
----------------------------------------------------------------------

-- Datos del objeto que se fabrica: tipo, subtipo, hueco y calidad
local itemCache = {}
local itemWaiting = false
local function itemInfo(id)
	if not id or id <= 0 then return end
	local c = itemCache[id]
	if c and c.q then return c end
	local get = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
	local _, typ, sub, slot = call(get, id)
	local q = C_Item and C_Item.GetItemQualityByID and call(C_Item.GetItemQualityByID, id)
	if q == nil and C_Item and C_Item.RequestLoadItemDataByID then
		-- El juego aún no lo tiene: llega con GET_ITEM_INFO_RECEIVED
		call(C_Item.RequestLoadItemDataByID, id)
		itemWaiting = true
	end
	c = { typ = typ, sub = sub, slot = (slot and slot ~= "" and slot ~= "INVTYPE_NON_EQUIP_IGNORE") and slot or nil, q = q }
	itemCache[id] = c
	return c
end

local NO_ITEM = "Sin objeto (encantamientos...)"

local function enrich(e)
	local it = itemInfo(e.r.i)
	e.typ = it and it.typ or L[NO_ITEM]
	e.sub = it and it.sub
	e.slot = it and it.slot
	e.q = it and it.q
end

local function qualityText(q)
	local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[q]
	local name = _G["ITEM_QUALITY" .. q .. "_DESC"] or tostring(q)
	return c and (c.hex or ("|cff%02x%02x%02x"):format(c.r * 255, c.g * 255, c.b * 255)) .. name .. "|r" or name
end

-- Dificultad de una receta tuya (Enum.TradeskillRelativeDifficulty)
local DIFF = {
	[0] = { "Naranja: sube seguro", "ff8040" },
	[1] = { "Amarilla: suele subir", "ffff00" },
	[2] = { "Verde: sube a veces", "40c040" },
	[3] = { "Gris: ya no sube", "808080" },
}

-- Cuenta cuántas entradas tienen cada valor y lo devuelve ordenado
local function tally(pool, getter)
	local n, list = {}, {}
	for _, e in ipairs(pool) do
		local v = getter(e)
		if v ~= nil then
			if not n[v] then list[#list + 1] = v end
			n[v] = (n[v] or 0) + 1
		end
	end
	return list, n
end

local function withCount(text, n)
	return text .. " |cff888888(" .. n .. ")|r"
end

local FILTERS = {
	player = {
		label = "Jugador", all = "Todos",
		options = function(pool)
			local n, list = {}, {}
			for _, e in ipairs(pool) do
				for _, c in ipairs(e.crafters) do
					if not n[c.key] then list[#list + 1] = c end
					n[c.key] = (n[c.key] or 0) + 1
				end
			end
			table.sort(list, function(a, b)
				if a.online ~= b.online then return a.online end
				return a.key < b.key
			end)
			local out = {}
			for _, c in ipairs(list) do
				local r, g, b = classColor(c.m.class)
				local name = ("|cff%02x%02x%02x%s|r"):format(r * 255, g * 255, b * 255, c.key)
				out[#out + 1] = { value = c.key, text = withCount((c.online and "|cff33ff33•|r " or "") .. name, n[c.key]), short = c.key }
			end
			return out
		end,
		test = function(e, v)
			for _, c in ipairs(e.crafters) do if c.key == v then return true end end
			return false
		end,
	},
	state = {
		label = "Estado", all = "Todas",
		options = function(pool)
			local _, n = tally(pool, function(e) return e.featured and "featured" or "normal" end)
			local out = {}
			if n.featured then out[#out + 1] = { value = "featured", text = withCount(L["Destacadas"], n.featured), short = L["Destacadas"] } end
			if n.normal then out[#out + 1] = { value = "normal", text = withCount(L["Sin destacar"], n.normal), short = L["Sin destacar"] } end
			return out
		end,
		test = function(e, v) return (e.featured and "featured" or "normal") == v end,
	},
	diff = {
		label = "Dificultad", all = "Todas",
		options = function(pool)
			local _, n = tally(pool, function(e) return e.d end)
			local out = {}
			for d = 0, 3 do
				if n[d] then
					local t = "|cff" .. DIFF[d][2] .. L[DIFF[d][1]] .. "|r"
					out[#out + 1] = { value = d, text = withCount(t, n[d]), short = t }
				end
			end
			return out
		end,
		test = function(e, v) return e.d == v end,
	},
	cat = {
		label = "Categoría", all = "Todas",
		options = function(pool)
			local list, n = tally(pool, function(e) return e.cat end)
			table.sort(list)
			local out = {}
			for _, c in ipairs(list) do out[#out + 1] = { value = c, text = withCount(c, n[c]), short = c } end
			return out
		end,
		test = function(e, v) return e.cat == v end,
	},
	typ = {
		label = "Tipo", all = "Todos",
		-- Cada tipo con sus subtipos (valor "tipo" o "tipo|subtipo")
		options = function(pool)
			local list, n = tally(pool, function(e) return e.typ end)
			table.sort(list)
			local out = {}
			for _, t in ipairs(list) do
				local subs, sn = tally(pool, function(e) return e.typ == t and e.sub or nil end)
				table.sort(subs)
				local o = { value = t, text = withCount(t, n[t]), short = t }
				if #subs > 1 then
					o.children = {}
					for _, s in ipairs(subs) do
						o.children[#o.children + 1] = { value = t .. "|" .. s, text = withCount(s, sn[s]), short = s }
					end
				end
				out[#out + 1] = o
			end
			return out
		end,
		test = function(e, v)
			local t, s = v:match("^(.-)|(.*)$")
			if t then return e.typ == t and e.sub == s end
			return e.typ == v
		end,
	},
	slot = {
		label = "Hueco", all = "Todos",
		options = function(pool)
			local list, n = tally(pool, function(e) return e.slot end)
			local function name(s) return _G[s] or s end
			table.sort(list, function(a, b) return name(a) < name(b) end)
			local out = {}
			for _, s in ipairs(list) do out[#out + 1] = { value = s, text = withCount(name(s), n[s]), short = name(s) } end
			return out
		end,
		test = function(e, v) return e.slot == v end,
	},
	quality = {
		label = "Calidad", all = "Todas",
		options = function(pool)
			local list, n = tally(pool, function(e) return e.q end)
			table.sort(list, function(a, b) return a > b end)
			local out = {}
			for _, q in ipairs(list) do out[#out + 1] = { value = q, text = withCount(qualityText(q), n[q]), short = qualityText(q) } end
			return out
		end,
		test = function(e, v) return e.q == v end,
	},
	sort = {
		label = "Orden", noAll = true, default = "name",
		options = function()
			local out = {
				{ value = "name", text = L["Nombre"] },
				{ value = "quality", text = L["Calidad"] },
				{ value = "type", text = L["Tipo"] },
			}
			if view == "recipes" then out[#out + 1] = { value = "crafters", text = L["Más jugadores"] } end
			return out
		end,
	},
}

-- Qué filtros tiene cada pestaña (en este orden, cuatro por fila)
local FILTER_ORDER = {
	recipes = { "player", "typ", "slot", "quality", "sort" },
	mine = { "state", "diff", "cat", "typ", "slot", "quality", "sort" },
}
local filterValues = { recipes = {}, mine = {} }
local pool = {}   -- entradas antes de los filtros (para las opciones)

local function filterValue(key)
	local v = filterValues[view] and filterValues[view][key]
	if v == nil and FILTERS[key].default then return FILTERS[key].default end
	return v
end

local function passesFilters(e, skip)
	for _, key in ipairs(FILTER_ORDER[view] or {}) do
		local def = FILTERS[key]
		if key ~= skip and def.test then
			local v = filterValues[view][key]
			if v ~= nil and not def.test(e, v) then return false end
		end
	end
	return true
end

-- Opciones de un filtro: con lo que queda al aplicar los demás
local function filterOptions(key)
	local sub = {}
	for _, e in ipairs(pool) do
		if passesFilters(e, key) then sub[#sub + 1] = e end
	end
	return FILTERS[key].options(sub)
end

local function sortRecipes()
	local how = filterValue("sort")
	table.sort(visible, function(a, b)
		if view == "mine" and how == "name" and a.featured ~= b.featured then return a.featured end
		if how == "quality" and (a.q or -1) ~= (b.q or -1) then return (a.q or -1) > (b.q or -1) end
		if how == "type" then
			local ta, tb = (a.typ or "") .. (a.sub or ""), (b.typ or "") .. (b.sub or "")
			if ta ~= tb then return ta < tb end
		end
		if how == "crafters" and #a.crafters ~= #b.crafters then return #a.crafters > #b.crafters end
		return a.name < b.name
	end)
end

-- Recetas destacadas de todos, juntas por receta
local function buildRecipes(g, q)
	local byID = {}
	for key, m in pairs(g.members) do
		for _, r in ipairs(m.recipes or {}) do
			if filter == 0 or r.p == filter then
				local e = byID[r.id]
				if not e then
					e = { r = r, crafters = {} }
					byID[r.id] = e
				end
				e.crafters[#e.crafters + 1] = { key = key, online = isOnline(key), m = m }
			end
		end
	end
	for _, e in pairs(byID) do
		e.name = recipeName(e.r)
		local any = false
		for _, c in ipairs(e.crafters) do if c.online then any = true end end
		e.online = any
		if (q == "" or e.name:lower():find(q, 1, true)) and (not db.onlyOnline or any) then
			table.sort(e.crafters, function(a, b)
				if a.online ~= b.online then return a.online end
				return a.key < b.key
			end)
			enrich(e)
			pool[#pool + 1] = e
		end
	end
end

-- Mis recetas conocidas, para marcar las buenas
local function buildMine(q)
	local d = myData()
	for prof, list in pairs(d.known) do
		if filter == 0 or prof == filter then
			for _, r in ipairs(list) do
				local e = { r = { id = r.id, i = r.i, p = prof }, name = recipeName(r), mine = true, cat = r.c, d = r.d }
				e.featured = d.featured[r.id] ~= nil
				if q == "" or e.name:lower():find(q, 1, true) then
					enrich(e)
					pool[#pool + 1] = e
				end
			end
		end
	end
end

local function build()
	wipe(visible)
	wipe(pool)
	local q = search:lower()
	if view == "people" then
		local g = guildData()
		if g then buildPeople(g, q) end
		return
	end
	if view == "mine" then
		buildMine(q)
	else
		local g = guildData()
		if not g then return end
		buildRecipes(g, q)
	end
	for _, e in ipairs(pool) do
		if passesFilters(e) then visible[#visible + 1] = e end
	end
	sortRecipes()
end

-- Números de la barra lateral según la pestaña
local function counts()
	local c, total = {}, 0
	if view == "mine" then
		for prof, list in pairs(myData().known) do
			c[prof] = #list
			total = total + #list
		end
		return c, total
	end
	local g = guildData()
	if not g then return c, 0 end
	if view == "recipes" then
		local seen = {}
		for _, m in pairs(g.members) do
			for _, r in ipairs(m.recipes or {}) do
				if not seen[r.id] then
					seen[r.id] = true
					c[r.p or 0] = (c[r.p or 0] or 0) + 1
					total = total + 1
				end
			end
		end
		return c, total
	end
	for key, m in pairs(g.members) do
		if not db.onlyOnline or isOnline(key) then
			total = total + 1
			for _, s in ipairs(m.skills or {}) do c[s.k] = (c[s.k] or 0) + 1 end
		end
	end
	return c, total
end

----------------------------------------------------------------------
-- Filas: una para personas y otra para recetas
----------------------------------------------------------------------

local function rowBase(parent, i)
	local row = CreateFrame("Button", nil, parent)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", SIDE_W + 12, -(LIST_TOP + (i - 1) * ROW_H))
	row:SetPoint("RIGHT", -12, 0)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	if i % 2 == 0 then
		local bg = row:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints()
		bg:SetColorTexture(1, 1, 1, 0.025)
	end
	row:RegisterForClicks("LeftButtonUp")
	row:SetScript("OnLeave", GameTooltip_Hide)
	return row
end

local function whisper(key)
	if key and key ~= myKey() and ChatFrame_OpenChat then
		ChatFrame_OpenChat("/w " .. (key:gsub(" ", "-")) .. " ")
	end
end

local function newPersonRow(parent, i)
	local row = rowBase(parent, i)
	row.dot = row:CreateTexture(nil, "ARTWORK")
	row.dot:SetSize(6, 6)
	row.dot:SetPoint("LEFT", 4, 0)
	row.dot:SetTexture(WHITE)
	row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.name:SetPoint("LEFT", 16, 0)
	row.name:SetWidth(140)
	row.name:SetJustifyH("LEFT")
	row.name:SetWordWrap(false)
	row.level = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	row.level:SetPoint("LEFT", 156, 0)
	row.level:SetWidth(22)
	row.level:SetJustifyH("RIGHT")
	row.stars = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	row.stars:SetPoint("RIGHT", -4, 0)

	-- Con una profesión elegida: barra de su nivel
	row.bar = CreateFrame("StatusBar", nil, row)
	row.bar:SetPoint("LEFT", 188, 0)
	row.bar:SetPoint("RIGHT", -40, 0)
	row.bar:SetHeight(14)
	row.bar:SetStatusBarTexture(R.TEXTURES[2][1])
	row.bar.bg = row.bar:CreateTexture(nil, "BACKGROUND")
	row.bar.bg:SetAllPoints()
	row.bar.bg:SetColorTexture(0, 0, 0, 0.5)
	row.bar.text = row.bar:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.bar.text:SetPoint("CENTER")

	-- Con «Todas»: iconos pequeños con su nivel
	row.icons = {}
	for j = 1, 6 do
		local ic = CreateFrame("Frame", nil, row)
		ic:SetSize(40, ROW_H)
		ic:SetPoint("LEFT", 188 + (j - 1) * 42, 0)
		ic.tex = ic:CreateTexture(nil, "ARTWORK")
		ic.tex:SetSize(16, 16)
		ic.tex:SetPoint("LEFT")
		ic.tex:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		ic.num = ic:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		ic.num:SetPoint("LEFT", ic.tex, "RIGHT", 3, 0)
		row.icons[j] = ic
	end

	row:SetScript("OnClick", function(self) if self.entry then whisper(self.entry.key) end end)
	row:SetScript("OnEnter", function(self)
		local e = self.entry
		if not e then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(e.key, classColor(e.m.class))
		for _, s in ipairs(e.m.skills or {}) do
			local p = BY_ID[s.k]
			if p then
				GameTooltip:AddDoubleLine(iconTag(profIcon(p)) .. " " .. L[p.name], ("%d / %d"):format(s.r, s.m), 1, 1, 1, skillColor(s))
			end
		end
		local recipes = e.m.recipes or {}
		if #recipes > 0 then
			GameTooltip:AddLine(" ")
			GameTooltip:AddLine(L["Recetas destacadas:"], 1, 0.82, 0)
			for j, r in ipairs(recipes) do
				if j > 12 then
					GameTooltip:AddLine(L["...y %d más"]:format(#recipes - 12), 0.6, 0.6, 0.6)
					break
				end
				GameTooltip:AddLine(iconTag(recipeIcon(r)) .. " " .. recipeName(r), recipeColor(r))
			end
		end
		if e.r and e.r.note and e.r.note ~= "" then GameTooltip:AddLine(L["Nota: %s"]:format(e.r.note), 0.7, 0.7, 0.7, true) end
		if e.m.t then GameTooltip:AddLine(L["Datos de %s"]:format(date("%d/%m/%Y %H:%M", e.m.t)), 0.5, 0.5, 0.5) end
		if e.key ~= myKey() then GameTooltip:AddLine(L["Clic: susurrarle"], 0.3, 0.8, 1) end
		GameTooltip:Show()
	end)
	return row
end

local function drawPerson(row, e)
	local m = e.m
	row.entry = e
	row.dot:SetVertexColor(e.online and 0.2 or 0.35, e.online and 1 or 0.35, e.online and 0.2 or 0.35)
	row.name:SetText(e.key)
	row.name:SetTextColor(classColor(m.class or (e.r and e.r.class)))
	row.name:SetAlpha(e.online and 1 or 0.6)
	row.level:SetText(m.level or (e.r and e.r.level) or "")
	local n = m.recipes and #m.recipes or 0
	row.stars:SetText(n > 0 and ("|TInterface\\Common\\ReputationStar:12:12:0:0:32:32:0:16:0:16|t" .. n) or "")
	if filter ~= 0 then
		local s = skillOf(m, filter)
		row.bar:SetMinMaxValues(0, math.max(s.m, 1))
		row.bar:SetValue(s.r)
		row.bar:SetStatusBarColor(skillColor(s))
		row.bar.text:SetText(("%d / %d"):format(s.r, s.m))
		row.bar:Show()
		for _, ic in ipairs(row.icons) do ic:Hide() end
	else
		row.bar:Hide()
		local j = 0
		for _, s in ipairs(m.skills or {}) do
			local p = BY_ID[s.k]
			if p and j < #row.icons then
				j = j + 1
				local ic = row.icons[j]
				ic.tex:SetTexture(profIcon(p))
				ic.num:SetText(s.r)
				ic.num:SetTextColor(skillColor(s))
				ic:Show()
			end
		end
		for k = j + 1, #row.icons do row.icons[k]:Hide() end
	end
	row:Show()
end

-- Enlace de Wowhead de una receta para copiarlo (un addon no abre el navegador)
local function openWowhead(e)
	local r = e.r
	local url
	if db.whTarget == "item" and r.i and r.i > 0 then
		url = R.WowheadURL("item", r.i, db.whSite, db.whSpanish)
	else
		url = R.WowheadURL("spell", r.id, db.whSite, db.whSpanish)
	end
	R:ShowCopyBox(L["Wowhead: %s"]:format(e.name or "?"), url)
end

local function newRecipeRow(parent, i)
	local row = rowBase(parent, i)
	row.wh = CreateFrame("Button", nil, row)
	row.wh:SetSize(16, 16)
	row.wh:SetPoint("RIGHT", -4, 0)
	row.wh:SetNormalTexture("Interface\\Icons\\INV_Misc_Spyglass_03")
	row.wh:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
	row.wh:SetScript("OnClick", function() if row.entry then openWowhead(row.entry) end end)
	row.wh:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		GameTooltip:AddLine(L["Ver en Wowhead"])
		GameTooltip:AddLine(L["Muestra el enlace para copiarlo y abrirlo en el navegador."], 1, 1, 1, true)
		GameTooltip:Show()
	end)
	row.wh:SetScript("OnLeave", GameTooltip_Hide)
	row.check = CreateFrame("CheckButton", nil, row, "UICheckButtonTemplate")
	row.check:SetSize(20, 20)
	row.check:SetPoint("LEFT", 0, 0)
	row.check:SetScript("OnClick", function(self)
		local e = row.entry
		if not e then return end
		if not M:SetFeatured(e.r.id, e.r.p, e.r.i, self:GetChecked()) then self:SetChecked(false) end
	end)
	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetSize(18, 18)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	row.name:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
	row.name:SetJustifyH("LEFT")
	row.name:SetWordWrap(false)
	row.who = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.who:SetPoint("RIGHT", -4, 0)
	row.who:SetWidth(170)
	row.who:SetJustifyH("RIGHT")
	row.who:SetWordWrap(false)
	row.name:SetPoint("RIGHT", row.who, "LEFT", -6, 0)

	row:SetScript("OnClick", function(self)
		local e = self.entry
		if not e then return end
		if db.whCtrl and IsControlKeyDown() then
			openWowhead(e)
			return
		end
		if e.mine then
			row.check:Click()
			return
		end
		-- Susurrar al primero conectado que la hace
		local c = e.crafters[1]
		if c then whisper(c.key) end
	end)
	row:SetScript("OnEnter", function(self)
		local e = self.entry
		if not e then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		local r = e.r
		if not (r.i and r.i > 0 and pcall(GameTooltip.SetItemByID, GameTooltip, r.i)) then
			if not pcall(GameTooltip.SetSpellByID, GameTooltip, r.id) then GameTooltip:AddLine(e.name) end
		end
		if e.crafters then
			GameTooltip:AddLine(" ")
			GameTooltip:AddLine(L["La hacen:"], 1, 0.82, 0)
			for _, c in ipairs(e.crafters) do
				local s = r.p and skillOf(c.m, r.p)
				local cr, cg, cb = classColor(c.m.class)
				GameTooltip:AddDoubleLine((c.online and "|cff33ff33•|r " or "|cff666666•|r ") .. c.key,
					s and ("%d / %d"):format(s.r, s.m) or "", cr, cg, cb, 0.7, 0.7, 0.7)
			end
			if e.crafters[1] and e.crafters[1].key ~= myKey() then
				GameTooltip:AddLine(L["Clic: susurrar a %s"]:format(e.crafters[1].key), 0.3, 0.8, 1)
			end
		elseif e.mine then
			GameTooltip:AddLine(" ")
			GameTooltip:AddLine(e.featured and L["Destacada: la ve tu hermandad."] or L["Clic: destacarla en la hermandad."], 0.3, 0.8, 1)
		end
		if db.whCtrl then GameTooltip:AddLine(L["Ctrl+clic: enlace de Wowhead"], 0.3, 0.8, 1) end
		GameTooltip:Show()
	end)
	return row
end

local function drawRecipe(row, e)
	row.entry = e
	-- Con el botón de Wowhead, los nombres de quién la hace se apartan
	row.wh:SetShown(db.whButton)
	row.who:ClearAllPoints()
	row.who:SetPoint("RIGHT", db.whButton and -24 or -4, 0)
	row.icon:ClearAllPoints()
	if e.mine then
		row.check:Show()
		row.check:SetChecked(e.featured)
		row.icon:SetPoint("LEFT", 24, 0)
		row.who:SetText("")
	else
		row.check:Hide()
		row.icon:SetPoint("LEFT", 4, 0)
		local names = {}
		for j, c in ipairs(e.crafters) do
			if j > 3 then
				names[#names + 1] = "+" .. (#e.crafters - 3)
				break
			end
			local cr, cg, cb = classColor(c.m.class)
			local hex = ("%02x%02x%02x"):format(cr * 255, cg * 255, cb * 255)
			names[#names + 1] = (c.online and "|cff" .. hex or "|cff777777") .. (c.key:match("^(%S+)") or c.key) .. "|r"
		end
		row.who:SetText(table.concat(names, ", "))
	end
	row.icon:SetTexture(recipeIcon(e.r))
	row.name:SetText(e.name)
	row.name:SetTextColor(recipeColor(e.r))
	row:Show()
end

----------------------------------------------------------------------
-- Pintar la ventana
----------------------------------------------------------------------

local HEADINGS = { people = "Personas", recipes = "Recetas destacadas", mine = "Mis recetas" }

-- Personas no tiene filtros: su lista empieza más arriba
local function listTop()
	return view == "people" and FILTER_TOP or LIST_TOP
end

local function setFilter(key, value)
	filterValues[view][key] = value
	offset = 0
	M:Refresh()
end

-- Texto corto del valor elegido de un filtro
local function filterShort(key)
	local v = filterValue(key)
	local def = FILTERS[key]
	if v == nil then return L[def.all] end
	for _, o in ipairs(def.options(pool)) do
		if o.value == v then return o.short or o.text end
		for _, ch in ipairs(o.children or {}) do
			if ch.value == v then return ch.short or ch.text end
		end
	end
	-- Ya no está en la lista (se fue el jugador...): el valor tal cual
	return type(v) == "string" and (v:match("|(.*)$") or v) or tostring(v)
end

local function openFilterMenu(btn)
	local key = btn.key
	local def = key and FILTERS[key]
	if not def then return end
	local options = filterOptions(key)
	if MenuUtil and MenuUtil.CreateContextMenu then
		MenuUtil.CreateContextMenu(btn, function(_, root)
			root:CreateTitle(L[def.label])
			local function radio(parent, text, value)
				return parent:CreateRadio(text, function() return filterValue(key) == value end, function() setFilter(key, value) end, value)
			end
			if not def.noAll then radio(root, L[def.all], nil) end
			for _, o in ipairs(options) do
				if o.children then
					-- Submenú: el tipo entero y cada subtipo
					local sub = root:CreateButton(o.text)
					radio(sub, L["Todo: %s"]:format(o.short or o.text), o.value)
					for _, ch in ipairs(o.children) do radio(sub, ch.text, ch.value) end
				else
					radio(root, o.text, o.value)
				end
			end
		end)
		return
	end
	-- Sin menús modernos: cada clic pasa a la siguiente opción
	local flat = {}
	if not def.noAll then flat[1] = { value = nil } end
	for _, o in ipairs(options) do
		flat[#flat + 1] = o
		for _, ch in ipairs(o.children or {}) do flat[#flat + 1] = ch end
	end
	local cur = filterValue(key)
	local idx = 0
	for i, o in ipairs(flat) do if o.value == cur then idx = i end end
	local nextOpt = flat[idx % math.max(#flat, 1) + 1]
	setFilter(key, nextOpt and nextOpt.value)
end

local function drawFilters()
	local order = FILTER_ORDER[view]
	local n = 0
	for i, btn in ipairs(win.filters) do
		local key = order and order[i]
		btn.key = key
		if key then
			n = i
			local def = FILTERS[key]
			local active = filterValues[view][key] ~= nil and not def.noAll
			btn.text:SetText("|cff888888" .. L[def.label] .. ":|r " .. filterShort(key))
			btn:SetBackdropBorderColor(active and 0.2 or 0.3, active and 0.8 or 0.3, active and 1 or 0.3, 1)
			btn:Show()
		else
			btn:Hide()
		end
	end
	-- «Quitar filtros» detrás del último
	local clear = win.clearFilters
	if order then
		local col, row = n % 4, math.floor(n / 4)
		clear:ClearAllPoints()
		clear:SetPoint("TOPLEFT", win, "TOPLEFT", SIDE_W + 12 + col * (win.filterW + 6), -(FILTER_TOP + row * 28))
		clear:SetWidth(win.filterW)
		local any = false
		for _, v in pairs(filterValues[view]) do if v ~= nil then any = true end end
		clear:SetEnabled(any)
		clear.text:SetTextColor(any and 1 or 0.5, any and 1 or 0.5, any and 1 or 0.5)
		clear:Show()
	else
		clear:Hide()
	end
end

function M:Refresh()
	if not win then return end
	build()
	drawFilters()
	for i = 1, ROWS do
		for _, row in ipairs({ win.peopleRows[i], win.recipeRows[i] }) do
			row:ClearAllPoints()
			row:SetPoint("TOPLEFT", SIDE_W + 12, -(listTop() + (i - 1) * ROW_H))
			row:SetPoint("RIGHT", -12, 0)
		end
	end
	-- Barra lateral
	local c, total = counts()
	for _, b in ipairs(win.side) do
		local n = b.id == 0 and total or (c[b.id] or 0)
		b.count:SetText(n > 0 and n or "")
		b.sel:SetShown(b.id == filter)
		b.label:SetFontObject(b.id == filter and "GameFontHighlight" or (n > 0 and "GameFontNormal" or "GameFontDisable"))
	end
	for key, t in pairs(win.tabs) do
		t.sel:SetShown(key == view)
		t.text:SetFontObject(key == view and "GameFontHighlight" or "GameFontNormal")
	end
	local p = BY_ID[filter]
	win.heading:SetText((p and (iconTag(profIcon(p), 16) .. " " .. L[p.name]) or L["Todas las profesiones"])
		.. "  |cff888888· " .. #visible .. "|r")
	win.hint:SetText(view == "mine" and L["Marca las recetas buenas que haces tú. Salen las de cada profesión cuando abres su ventana."] or "")
	win.online:SetShown(view ~= "mine")
	win.onlineLabel:SetShown(view ~= "mine")
	win.searchHint:SetText(view == "people" and L["Buscar nombre..."] or L["Buscar receta..."])

	offset = math.max(0, math.min(offset, #visible - ROWS))
	for i = 1, ROWS do
		local e = visible[i + offset]
		local pr, rr = win.peopleRows[i], win.recipeRows[i]
		pr:Hide(); pr.entry = nil
		rr:Hide(); rr.entry = nil
		if e then
			if view == "people" then drawPerson(pr, e) else drawRecipe(rr, e) end
		end
	end
	win.scroll:SetShown(#visible > ROWS)
	if #visible > ROWS then
		local track = ROWS * ROW_H
		local size = math.max(20, track * ROWS / #visible)
		win.scroll:SetHeight(size)
		win.scroll:ClearAllPoints()
		win.scroll:SetPoint("TOPRIGHT", win, "TOPRIGHT", -4, -(listTop() + (track - size) * offset / (#visible - ROWS)))
	end

	local members = NS(call(GetNumGuildMembers)) or 0
	local g = guildData()
	local withData = 0
	if g then for _ in pairs(g.members) do withData = withData + 1 end end
	win.status:SetText(L["%d con datos de %d miembros · solo salen quienes usan Rheizor"]:format(withData, members))
	local empty = ""
	win.empty:ClearAllPoints()
	win.empty:SetPoint("TOPLEFT", SIDE_W + 24, -(listTop() + 30))
	win.empty:SetPoint("RIGHT", -24, 0)
	if #visible == 0 then
		if #pool > 0 then
			empty = L["Ninguna receta con estos filtros."]
		elseif view == "mine" then
			empty = L["Abre la ventana de tus profesiones (una vez cada una) para que salgan aquí sus recetas."]
		elseif view == "recipes" then
			empty = L["Nadie ha destacado recetas todavía. Marca las tuyas en «Mis recetas» o en la ventana de profesiones."]
		else
			empty = L["Nadie todavía. Las profesiones llegan de los miembros que usan Rheizor cuando se conectan (o con «Pedir datos»)."]
		end
	end
	win.empty:SetText(empty)
end

local function sideButton(parent, i, id, text, icon)
	local b = CreateFrame("Button", nil, parent)
	b:SetSize(SIDE_W - 12, 22)
	b:SetPoint("TOPLEFT", 8, -(44 + (i - 1) * 24))
	b.id = id
	b.sel = b:CreateTexture(nil, "BACKGROUND")
	b.sel:SetAllPoints()
	b.sel:SetColorTexture(0.2, 0.8, 1, 0.18)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	local x = 6
	if icon then
		b.icon = b:CreateTexture(nil, "ARTWORK")
		b.icon:SetSize(16, 16)
		b.icon:SetPoint("LEFT", 4, 0)
		b.icon:SetTexture(icon)
		b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		x = 26
	end
	b.label = b:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	b.label:SetPoint("LEFT", x, 0)
	b.label:SetPoint("RIGHT", -26, 0)
	b.label:SetJustifyH("LEFT")
	b.label:SetWordWrap(false)
	b.label:SetText(text)
	b.count = b:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	b.count:SetPoint("RIGHT", -4, 0)
	b:SetScript("OnClick", function()
		filter, offset = id, 0
		M:Refresh()
	end)
	return b
end

local function tabButton(parent, key, text, x)
	local t = CreateFrame("Button", nil, parent)
	t:SetSize(120, 24)
	t:SetPoint("TOPLEFT", SIDE_W + 12 + x, -40)
	t.sel = t:CreateTexture(nil, "BACKGROUND")
	t.sel:SetPoint("BOTTOMLEFT")
	t.sel:SetPoint("BOTTOMRIGHT")
	t.sel:SetHeight(2)
	t.sel:SetColorTexture(0.2, 0.8, 1, 1)
	local hl = t:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	t.text = t:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	t.text:SetPoint("CENTER")
	t.text:SetText(text)
	t:SetScript("OnClick", function()
		view, offset = key, 0
		M:Refresh()
	end)
	return t
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorGuildFrame", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetPoint("CENTER")
	win:SetFrameStrata("HIGH")
	win:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	win:SetBackdropColor(0.05, 0.05, 0.07, 0.95)
	win:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	win:EnableMouse(true)
	win:SetMovable(true)
	win:SetClampedToScreen(true)
	win:RegisterForDrag("LeftButton")
	win:SetScript("OnDragStart", win.StartMoving)
	win:SetScript("OnDragStop", win.StopMovingOrSizing)
	tinsert(UISpecialFrames, "RheizorGuildFrame")

	local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 12, -12)
	title:SetText(L["|cff33ccffRheizor|r · Profesiones de la hermandad"])
	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)

	-- Barra lateral con las profesiones
	local sideBg = win:CreateTexture(nil, "BACKGROUND", nil, 1)
	sideBg:SetPoint("TOPLEFT", 1, -38)
	sideBg:SetPoint("BOTTOMLEFT", 1, 30)
	sideBg:SetWidth(SIDE_W)
	sideBg:SetColorTexture(0, 0, 0, 0.3)
	local sep = win:CreateTexture(nil, "ARTWORK")
	sep:SetColorTexture(0.2, 0.8, 1, 0.3)
	sep:SetPoint("TOPLEFT", SIDE_W + 1, -38)
	sep:SetPoint("BOTTOMLEFT", SIDE_W + 1, 30)
	sep:SetWidth(1)
	win.side = { sideButton(win, 1, 0, L["Todas"]) }
	for i, p in ipairs(PROFS) do
		win.side[#win.side + 1] = sideButton(win, i + 1, p.id, L[p.name], profIcon(p))
	end

	-- Pestañas
	win.tabs = {
		people = tabButton(win, "people", L[HEADINGS.people], 0),
		recipes = tabButton(win, "recipes", L[HEADINGS.recipes], 124),
		mine = tabButton(win, "mine", L[HEADINGS.mine], 248),
	}

	-- Encima de la lista: título, buscador y «conectados»
	win.heading = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	win.heading:SetPoint("TOPLEFT", SIDE_W + 14, -74)

	local box = CreateFrame("EditBox", nil, win, "InputBoxTemplate")
	box:SetSize(130, 20)
	box:SetPoint("TOPRIGHT", -120, -70)
	box:SetAutoFocus(false)
	box:SetScript("OnTextChanged", function(self)
		search, offset = self:GetText() or "", 0
		win.searchHint:SetShown(search == "")
		M:Refresh()
	end)
	box:SetScript("OnEscapePressed", box.ClearFocus)
	win.searchHint = box:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	win.searchHint:SetPoint("LEFT", 2, 0)

	local online = CreateFrame("CheckButton", nil, win, "UICheckButtonTemplate")
	online:SetSize(22, 22)
	online:SetPoint("LEFT", box, "RIGHT", 8, 0)
	win.onlineLabel = online:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	win.onlineLabel:SetPoint("LEFT", online, "RIGHT", 1, 0)
	win.onlineLabel:SetText(L["Conectados"])
	online:SetScript("OnClick", function(self)
		db.onlyOnline = self:GetChecked() and true or false
		offset = 0
		M:Refresh()
	end)
	win.online = online

	-- Filtros: dos filas de cuatro botones. Clic: elegir · Clic derecho: quitar
	win.filterW = math.floor((W - SIDE_W - 24 - 18) / 4)
	local function flat(text)
		local b = CreateFrame("Button", nil, win, "BackdropTemplate")
		b:SetSize(win.filterW, 22)
		b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		b:SetBackdropColor(0.1, 0.1, 0.12, 0.9)
		b:SetBackdropBorderColor(0.3, 0.3, 0.3, 1)
		local hl = b:CreateTexture(nil, "HIGHLIGHT")
		hl:SetAllPoints()
		hl:SetColorTexture(1, 1, 1, 0.08)
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		b.text:SetPoint("LEFT", 6, 0)
		b.text:SetPoint("RIGHT", -6, 0)
		b.text:SetJustifyH("LEFT")
		b.text:SetWordWrap(false)
		b.text:SetText(text or "")
		return b
	end
	win.filters = {}
	for i = 1, 8 do
		local b = flat()
		local col, row = (i - 1) % 4, math.floor((i - 1) / 4)
		b:SetPoint("TOPLEFT", win, "TOPLEFT", SIDE_W + 12 + col * (win.filterW + 6), -(FILTER_TOP + row * 28))
		b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		b:SetScript("OnClick", function(self, mouse)
			if not self.key then return end
			if mouse == "RightButton" then setFilter(self.key, nil) else openFilterMenu(self) end
		end)
		b:SetScript("OnEnter", function(self)
			if not self.key then return end
			GameTooltip:SetOwner(self, "ANCHOR_TOP")
			GameTooltip:AddLine(L[FILTERS[self.key].label] .. ": " .. filterShort(self.key))
			GameTooltip:AddLine(L["Clic: elegir · Clic derecho: quitar este filtro"], 1, 1, 1, true)
			GameTooltip:Show()
		end)
		b:SetScript("OnLeave", GameTooltip_Hide)
		win.filters[i] = b
	end
	win.clearFilters = flat(L["Quitar filtros"])
	win.clearFilters.text:SetJustifyH("CENTER")
	win.clearFilters:SetScript("OnClick", function()
		wipe(filterValues[view])
		offset = 0
		M:Refresh()
	end)

	win.peopleRows, win.recipeRows = {}, {}
	for i = 1, ROWS do
		win.peopleRows[i] = newPersonRow(win, i)
		win.recipeRows[i] = newRecipeRow(win, i)
	end
	win:EnableMouseWheel(true)
	win:SetScript("OnMouseWheel", function(_, delta)
		offset = math.max(0, math.min(offset - delta * 3, #visible - ROWS))
		M:Refresh()
	end)
	win.scroll = win:CreateTexture(nil, "OVERLAY")
	win.scroll:SetWidth(3)
	win.scroll:SetColorTexture(0.2, 0.8, 1, 0.6)

	win.empty = win:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	win.empty:SetPoint("TOPLEFT", SIDE_W + 24, -(LIST_TOP + 30))
	win.empty:SetPoint("RIGHT", -24, 0)

	-- Pie: ayuda de la pestaña, estado y pedir datos
	win.hint = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	win.hint:SetPoint("BOTTOMLEFT", SIDE_W + 14, 34)
	win.hint:SetPoint("RIGHT", -12, 0)
	win.hint:SetJustifyH("LEFT")
	win.status = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	win.status:SetPoint("BOTTOMLEFT", 12, 10)
	local ask = CreateFrame("Button", nil, win, "UIPanelButtonTemplate")
	ask:SetSize(110, 20)
	ask:SetPoint("BOTTOMRIGHT", -10, 6)
	ask:SetText(L["Pedir datos"])
	ask:SetScript("OnClick", function() M:Request(true) end)

	win:SetScript("OnShow", function()
		if C_GuildInfo and C_GuildInfo.GuildRoster then call(C_GuildInfo.GuildRoster) elseif GuildRoster then call(GuildRoster) end
		saveMine()
		M:Refresh()
	end)
end

function M:Toggle()
	if not IsInGuild() then
		R:Print(L["No estás en ninguna hermandad."])
		return
	end
	if not win then createWindow() end
	win.online:SetChecked(db.onlyOnline)
	win:SetShown(not win:IsShown())
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, ...)
	if event == "CHAT_MSG_ADDON" then
		onMessage(...)
	elseif event == "GUILD_ROSTER_UPDATE" then
		if readRoster() then prune() end
		if win and win:IsShown() then M:Refresh() end
	elseif event == "SKILL_LINES_CHANGED" or event == "CHAT_MSG_SKILL" then
		-- Al subir una profesión: se guarda ya y se comparte como mucho cada 20 s
		saveMine()
		C_Timer.After(2, function() M:Share() end)
	elseif event == "PLAYER_GUILD_UPDATE" then
		saveMine()
	elseif event == "TRADE_SKILL_SHOW" or event == "TRADE_SKILL_LIST_UPDATE" or event == "TRADE_SKILL_DATA_SOURCE_CHANGED" then
		queueScan()
		M:UpdateStar()
	elseif event == "GET_ITEM_INFO_RECEIVED" then
		-- Llegan los datos de objetos pedidos (calidad): se repinta una vez
		if itemWaiting and win and win:IsShown() then
			itemWaiting = false
			for _, c in pairs(itemCache) do if c.q == nil then itemCache = {} break end end
			C_Timer.After(0.5, function() if win:IsShown() then M:Refresh() end end)
		end
	end
end)

function M:OnEnable()
	db = self.db
	RheizorGuildDB = type(RheizorGuildDB) == "table" and RheizorGuildDB or {}
	store = RheizorGuildDB
	if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then call(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX) end
	for _, e in ipairs({ "CHAT_MSG_ADDON", "GUILD_ROSTER_UPDATE", "SKILL_LINES_CHANGED", "CHAT_MSG_SKILL", "PLAYER_GUILD_UPDATE",
		"TRADE_SKILL_SHOW", "TRADE_SKILL_LIST_UPDATE", "TRADE_SKILL_DATA_SOURCE_CHANGED", "GET_ITEM_INFO_RECEIVED" }) do
		pcall(events.RegisterEvent, events, e)
	end
	if EventUtil and EventUtil.ContinueOnAddOnLoaded then
		EventUtil.ContinueOnAddOnLoaded("Blizzard_Professions", setupStar)
	end
	-- Al entrar: las mías a la hermandad y pedir las de los conectados
	C_Timer.After(10, function()
		saveMine()
		M:Share(true)
		C_Timer.After(3, function() M:Request() end)
	end)
end

function M:OnOptionChanged(key)
	if key == "share" and db.share then self:Share(true) end
	if key == "forgetDays" then prune() end
	if key == "professionCheck" then self:UpdateStar() end
	if win and win:IsShown() then self:Refresh() end
end

SLASH_RHEIZORGUILD1 = "/rzg"
SlashCmdList.RHEIZORGUILD = function()
	R:RunModuleAction(M, function(m) m:Toggle() end)
end
