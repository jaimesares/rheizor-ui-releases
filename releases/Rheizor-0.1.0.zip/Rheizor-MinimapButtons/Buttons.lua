-- Agrupa los iconos que los addons ponen en el borde del minimapa (LibDBIcon y
-- los demás) en un solo botón, como MBB: clic o ratón encima abre un panel con
-- todos. También pueden ir en una barra fija que se mueve donde quieras.
--
-- Solo se recogen botones creados por addons: los de Blizzard (correo,
-- rastreo, reloj, calendario…) tienen su variable global "segura" y no se
-- tocan. Los ganchos no se pueden quitar: devolver un botón al minimapa
-- necesita /reload.

local R = Rheizor:Namespace(...)
local L = R.L

local WHITE = "Interface\\Buttons\\WHITE8X8"
local ICON = "Interface\\Icons\\INV_Misc_Bag_10"
local DEFAULT_ANGLE = 200
local PAD = 5

-- Nombres que no son botones de addon aunque estén en el minimapa: puntos de
-- mapas (Questie, HandyNotes, GatherMate, TomTom…). LibDBIcon siempre vale.
local NOT_BUTTONS = { "Questie", "Pin", "HandyNotes", "GatherMate", "TomTom", "Node", "Ping", "Arrow", "Blip" }

local M = R:RegisterModule("minimapbuttons", {
	title = "Botones del minimapa",
	defaults = {
		enabled = true,
		includeRheizor = true,
		exclude = "",
		mode = "panel",
		open = "click",
		autoClose = true,
		closeDelay = 0.5,
		buttonHover = false,
		style = "classic",
		size = 31,
		locked = false,
		angle = DEFAULT_ANGLE,
		direction = "auto",
		columns = 6,
		iconSize = 28,
		spacing = 2,
		background = true,
		barFade = false,
		barFadeAlpha = 0,
		barFadeCombat = false,
		barLocked = true,
	},
	options = {
		{ type = "header", text = "Iconos" },
		{ type = "toggle", key = "enabled", name = "Agrupar los iconos de addons del minimapa",
		  desc = "Quita del borde del minimapa los iconos de los addons y los junta en un panel o una barra. Los de Blizzard (correo, rastreo, reloj…) se quedan donde están.\nPara devolverlos al minimapa hace falta /reload." },
		{ type = "toggle", key = "includeRheizor", name = "Incluir el icono de Rheizor" },
		{ type = "text", key = "exclude", name = "Dejar en el minimapa",
		  desc = "Iconos que no se agrupan: parte de su nombre, separados por comas (por ejemplo: BugSack, Questie). Los nombres salen con el botón de abajo. Quitar uno ya agrupado necesita /reload." },
		{ type = "button", name = "Iconos agrupados", text = "Ver en el chat",
		  desc = "Escribe en el chat el nombre de cada icono agrupado, para usarlo en «Dejar en el minimapa».",
		  func = function(mod) mod:PrintList() end },

		{ type = "header", text = "Dónde van" },
		{ type = "dropdown", key = "mode", name = "Mostrar los iconos",
		  values = {
			{ "panel", "En un panel que abre un botón del minimapa" },
			{ "bar", "En una barra fija" },
		  },
		  desc = "Panel: como MBB, un solo botón en el minimapa que abre la lista.\nBarra fija: siempre a la vista donde la pongas (desbloquéala abajo o usa /rz mover)." },
		{ type = "slider", key = "columns", name = "Iconos por fila", min = 1, max = 12, step = 1, format = R.fmt.int },
		{ type = "slider", key = "iconSize", name = "Tamaño de los iconos", min = 18, max = 44, step = 1, format = R.fmt.int },
		{ type = "slider", key = "spacing", name = "Separación", min = 0, max = 10, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "background", name = "Fondo" },
		{ type = "dropdown", key = "style", name = "Estilo",
		  values = { { "classic", "Clásico (aro dorado)" }, { "flat", "Plano (colores del tema)" } },
		  desc = "Del botón del minimapa y del fondo. Plano usa los colores de Rheizor-Core > Tema." },

		{ type = "header", text = "Panel" },
		{ type = "dropdown", key = "open", name = "Abrir el panel",
		  values = { { "click", "Con clic en el botón" }, { "hover", "Al pasar el ratón por el botón" } } },
		{ type = "toggle", key = "autoClose", name = "Cerrar al sacar el ratón",
		  desc = "Con «Al pasar el ratón» se cierra siempre así. Desmarcada (con clic), se cierra con otro clic en el botón." },
		{ type = "slider", key = "closeDelay", name = "Espera antes de cerrar", min = 0, max = 3, step = 0.25, format = R.fmt.dec2,
		  desc = "Segundos con el ratón fuera del panel y del botón." },
		{ type = "dropdown", key = "direction", name = "Hacia dónde se abre",
		  values = {
			{ "auto", "Hacia el centro de la pantalla" },
			{ "left", "A la izquierda" },
			{ "right", "A la derecha" },
			{ "up", "Hacia arriba" },
			{ "down", "Hacia abajo" },
		  } },
		{ type = "toggle", key = "buttonHover", name = "Botón solo al pasar el ratón por el minimapa",
		  desc = "El botón queda invisible hasta que pones el ratón encima del minimapa." },
		{ type = "slider", key = "size", name = "Tamaño del botón", min = 20, max = 44, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "locked", name = "Bloquear el botón",
		  desc = "Desbloqueado, el botón se arrastra alrededor del borde del minimapa." },
		{ type = "button", name = "Posición del botón", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

		{ type = "header", text = "Barra fija" },
		{ type = "toggle", key = "barFade", name = "Ocultar hasta pasar el ratón",
		  desc = "Aun invisibles, los iconos se pueden pulsar." },
		{ type = "slider", key = "barFadeAlpha", name = "Opacidad sin ratón", min = 0, max = 0.8, step = 0.05, format = R.fmt.percent },
		{ type = "toggle", key = "barFadeCombat", name = "Mostrarla siempre en combate" },
		{ type = "toggle", key = "barLocked", name = "Bloquear posición",
		  desc = "Desbloqueada, aparece un marco encima de la barra para arrastrarla." },
		{ type = "button", name = "Posición de la barra", text = "Restablecer", func = function(mod) mod:ResetBarPosition() end },
	},
	unsupported = {
		"Devolver al minimapa un icono ya agrupado sin recargar: el addon que lo creó lo sigue moviendo y solo se suelta con /reload.",
	},
})

local db
local started = false
local function running()
	return started and db.enabled and R:IsAddonActive(M.addon)
end

local toggle, holder, anchor, anchorMover
local collected = {}   -- botón -> true
local list = {}        -- botones agrupados, en el orden en que se encontraron
local orig = {}        -- tamaño original de cada botón (para escalarlo)
local pos = {}         -- centro de cada botón dentro del panel
local placing = false

----------------------------------------------------------------------
-- Qué botones se agrupan
----------------------------------------------------------------------

local function niceName(btn)
	local name = btn:GetName() or "?"
	return (name:gsub("^LibDBIcon10_", ""))
end

local function excluded(name)
	name = name:lower()
	for word in (db.exclude or ""):gmatch("[^,]+") do
		word = strtrim(word):lower()
		if word ~= "" and name:find(word, 1, true) then return true end
	end
	return false
end

local function isCandidate(f)
	if collected[f] or f == toggle or f == holder then return false end
	if f.IsForbidden and f:IsForbidden() then return false end
	local name = f:GetName()
	if type(name) ~= "string" then return false end
	if excluded(name) then return false end
	if name == "RheizorMinimapButton" then return db.includeRheizor end
	if name:find("^Rheizor") then return false end
	if name:find("^LibDBIcon10_") then return true end
	-- De Blizzard: su variable global es "segura"
	if issecurevariable and issecurevariable(name) then return false end
	for _, word in ipairs(NOT_BUTTONS) do
		if name:find(word, 1, true) then return false end
	end
	local clickable = f:IsObjectType("Button")
	if not clickable then
		local ok, script = pcall(f.GetScript, f, "OnMouseUp")
		clickable = ok and script ~= nil
	end
	if not clickable then return false end
	local w, h = f:GetSize()
	return w >= 16 and h >= 16 and w <= 64 and h <= 64
end

----------------------------------------------------------------------
-- Colocación dentro del panel
----------------------------------------------------------------------

local function placeButton(b)
	local p = pos[b]
	if not p or not holder then return end
	if InCombatLockdown() and b:IsProtected() then return end
	local s = db.iconSize / (orig[b] or 31)
	placing = true
	if b:GetParent() ~= holder then b:SetParent(holder) end
	b:SetScale(s)
	b:ClearAllPoints()
	b:SetPoint("CENTER", holder, "TOPLEFT", p[1] / s, -p[2] / s)
	b:SetAlpha(1)
	placing = false
end

function M:Layout()
	if not holder or not running() then return end
	local shown = {}
	for _, b in ipairs(list) do
		if b:IsShown() then shown[#shown + 1] = b end
	end
	table.sort(shown, function(a, b) return niceName(a):lower() < niceName(b):lower() end)

	local n = #shown
	local cols = math.max(1, math.min(db.columns, n))
	local rows = math.max(1, math.ceil(n / cols))
	local cell = db.iconSize + db.spacing
	local w = PAD * 2 + cols * cell - db.spacing
	local h = PAD * 2 + rows * cell - db.spacing
	if n == 0 then w, h = 150, 30 end
	holder:SetSize(w, h)
	holder.empty:SetShown(n == 0)
	for i, b in ipairs(shown) do
		local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
		pos[b] = { PAD + col * cell + db.iconSize / 2, PAD + row * cell + db.iconSize / 2 }
		placeButton(b)
	end
	if anchor then anchor:SetSize(w, h) end
end

local pending = false
local function queueLayout()
	if pending or not running() then return end
	pending = true
	C_Timer.After(0, function()
		pending = false
		M:Layout()
	end)
end

local function adopt(b)
	placing = true
	b:SetParent(holder)
	pcall(b.SetFixedFrameStrata, b, false)
	b:SetFrameStrata(holder:GetFrameStrata())
	pcall(b.SetFixedFrameLevel, b, false)
	b:SetFrameLevel(holder:GetFrameLevel() + 3)
	placing = false
end

local function capture(b)
	if InCombatLockdown() and b:IsProtected() then return end
	collected[b] = true
	list[#list + 1] = b
	local w, h = b:GetSize()
	orig[b] = math.max(w or 31, h or 31, 1)
	-- El icono de Rheizor deja de colocarse solo en el borde del mapa
	if b:GetName() == "RheizorMinimapButton" then b.rzCollected = true end
	-- Sin arrastrarlo alrededor del minimapa
	pcall(b.RegisterForDrag, b)

	-- El addon que lo creó lo vuelve a colocar (al actualizarse, al cambiar
	-- la forma del mapa…): se devuelve a su sitio en el panel
	hooksecurefunc(b, "SetPoint", function(self)
		if not placing and running() then placeButton(self) end
	end)
	hooksecurefunc(b, "SetParent", function(self, parent)
		if not placing and running() and parent ~= holder then adopt(self) end
	end)
	-- Si el addon lo oculta o lo vuelve a mostrar, el panel se reordena
	hooksecurefunc(b, "Show", queueLayout)
	hooksecurefunc(b, "Hide", queueLayout)
	if b.SetShown then hooksecurefunc(b, "SetShown", queueLayout) end
	adopt(b)
end

function M:Scan()
	if not running() or not holder then return end
	local found = false
	for _, parent in ipairs({ Minimap, MinimapBackdrop, MinimapCluster }) do
		for _, f in ipairs({ parent:GetChildren() }) do
			local ok, yes = pcall(isCandidate, f)
			if ok and yes then
				capture(f)
				found = true
			end
		end
	end
	-- LibDBIcon: también los que el addon aún no ha puesto en el minimapa
	local lib = LibStub and LibStub("LibDBIcon-1.0", true)
	if lib and type(lib.objects) == "table" then
		for _, b in pairs(lib.objects) do
			local ok, yes = pcall(isCandidate, b)
			if ok and yes then
				capture(b)
				found = true
			end
		end
	end
	if found then self:Layout() end
end

function M:PrintList()
	local names = {}
	for _, b in ipairs(list) do names[#names + 1] = niceName(b) end
	table.sort(names)
	if #names == 0 then
		R:Print(L["No hay iconos agrupados."])
	else
		R:Print(L["Iconos agrupados: %s"]:format(table.concat(names, ", ")))
	end
end

----------------------------------------------------------------------
-- Aspecto
----------------------------------------------------------------------

local function accentRGB()
	local hex = R.db and R.db.manager and R.db.manager.accent or "33ccff"
	local ok, r, g, b = pcall(R.HexToRGB, hex)
	if ok and r then return r, g, b end
	return 0.2, 0.8, 1
end

local function themeColors()
	if R.ThemeColors then return R:ThemeColors() end
	return 0.06, 0.06, 0.08, 0.92, 0.17, 0.17, 0.2
end

local function applyBackdrop()
	if not db.background then
		holder:SetBackdrop(nil)
		return
	end
	if db.style == "flat" then
		holder:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
		local r, g, b, a, er, eg, eb = themeColors()
		holder:SetBackdropColor(r, g, b, a)
		holder:SetBackdropBorderColor(er, eg, eb, 1)
	else
		holder:SetBackdrop({
			bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", edgeSize = 12,
			insets = { left = 3, right = 3, top = 3, bottom = 3 },
		})
		holder:SetBackdropColor(0, 0, 0, 0.85)
		holder:SetBackdropBorderColor(0.8, 0.8, 0.8, 1)
	end
end

local function applyToggleStyle()
	local size = db.size
	toggle:SetSize(size, size)
	local icon = toggle.icon
	icon:SetTexture(ICON)
	icon:ClearAllPoints()
	if db.style == "flat" then
		icon:SetPoint("TOPLEFT", 2, -2)
		icon:SetPoint("BOTTOMRIGHT", -2, 2)
		icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
		toggle.bg:Hide()
		toggle.ring:Hide()
		toggle.flat:Show()
		local r, g, b, a = themeColors()
		toggle.flat:SetBackdropColor(r, g, b, a)
		toggle.flat:SetBackdropBorderColor(accentRGB())
		toggle:GetHighlightTexture():SetAlpha(0)
	else
		-- Las medidas clásicas de un botón de minimapa (31 px), a escala
		local k = size / 31
		icon:SetSize(20 * k, 20 * k)
		icon:SetPoint("CENTER")
		icon:SetTexCoord(0.05, 0.95, 0.05, 0.95)
		toggle.bg:SetSize(24 * k, 24 * k)
		toggle.bg:Show()
		toggle.ring:SetSize(53 * k, 53 * k)
		toggle.ring:Show()
		toggle.flat:Hide()
		toggle:GetHighlightTexture():SetAlpha(1)
	end
end

----------------------------------------------------------------------
-- Botón del minimapa (en el borde, como LibDBIcon)
----------------------------------------------------------------------

local function placeToggle()
	if not toggle then return end
	local rad = math.rad(db.angle or DEFAULT_ANGLE)
	local x, y = math.cos(rad), math.sin(rad)
	local w = Minimap:GetWidth() / 2 + 5
	local h = Minimap:GetHeight() / 2 + 5
	if (GetMinimapShape and GetMinimapShape() or "ROUND") == "SQUARE" then
		local m = math.max(math.abs(x), math.abs(y))
		x, y = x / m * w, y / m * h
	else
		x, y = x * w, y * h
	end
	toggle:ClearAllPoints()
	toggle:SetPoint("CENTER", Minimap, "CENTER", x, y)
end

local function angleFromCursor()
	local mx, my = Minimap:GetCenter()
	local px, py = GetCursorPosition()
	local scale = Minimap:GetEffectiveScale()
	return math.deg(math.atan2(py / scale - my, px / scale - mx)) % 360
end

local function anchorPanel()
	holder:ClearAllPoints()
	local dir = db.direction
	if dir == "left" then
		holder:SetPoint("RIGHT", toggle, "LEFT", -2, 0)
	elseif dir == "right" then
		holder:SetPoint("LEFT", toggle, "RIGHT", 2, 0)
	elseif dir == "up" then
		holder:SetPoint("BOTTOM", toggle, "TOP", 0, 2)
	elseif dir == "down" then
		holder:SetPoint("TOP", toggle, "BOTTOM", 0, -2)
	else
		-- Hacia el centro de la pantalla desde donde esté el botón
		local x, y = toggle:GetCenter()
		local s = toggle:GetEffectiveScale() / UIParent:GetEffectiveScale()
		local left = x and x * s > UIParent:GetWidth() / 2
		local down = y and y * s > UIParent:GetHeight() / 2
		local side = left and "RIGHT" or "LEFT"
		if down then
			holder:SetPoint("TOP" .. side, toggle, "BOTTOM" .. side, 0, -2)
		else
			holder:SetPoint("BOTTOM" .. side, toggle, "TOP" .. side, 0, 2)
		end
	end
end

function M:OpenPanel()
	if db.mode ~= "panel" or not running() then return end
	anchorPanel()
	holder.closeT = 0
	holder:Show()
	self:Layout()
end

function M:ClosePanel()
	if db.mode == "panel" then holder:Hide() end
end

local function toggleTooltip(self)
	GameTooltip:SetOwner(self, "ANCHOR_LEFT")
	GameTooltip:AddLine(L["Botones del minimapa"], accentRGB())
	if db.open == "click" then
		GameTooltip:AddLine(L["|cffffffffClic:|r mostrar u ocultar los iconos"], 0.8, 0.8, 0.8)
	end
	GameTooltip:AddLine(L["|cffffffffClic derecho:|r opciones"], 0.8, 0.8, 0.8)
	if not db.locked then
		GameTooltip:AddLine(L["|cffffffffArrastrar:|r mover el botón"], 0.8, 0.8, 0.8)
	end
	GameTooltip:Show()
end

local function menuOpen()
	local ok, open = pcall(function() return Menu and Menu.GetManager and Menu.GetManager():IsAnyMenuOpen() end)
	return ok and open
end

local function createFrames()
	-- Panel / barra con los iconos
	holder = CreateFrame("Frame", "RheizorMinimapButtonsPanel", UIParent, "BackdropTemplate")
	holder:SetFrameStrata("HIGH")
	holder:SetClampedToScreen(true)
	holder:EnableMouse(true)
	holder:Hide()
	holder.empty = holder:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	holder.empty:SetPoint("CENTER")
	holder.empty:SetText(L["No hay iconos de addons"])

	local t = 0
	holder:SetScript("OnUpdate", function(self, elapsed)
		t = t + elapsed
		if t < 0.05 then return end
		local dt = t
		t = 0
		local over = self:IsMouseOver(6, -6, -6, 6) or (toggle and toggle:IsMouseOver())
		if db.mode == "panel" then
			-- Cerrar al sacar el ratón
			if db.open == "hover" or db.autoClose then
				if over or menuOpen() then
					self.closeT = 0
				else
					self.closeT = (self.closeT or 0) + dt
					if self.closeT >= db.closeDelay then self:Hide() end
				end
			end
			if self:GetAlpha() ~= 1 then self:SetAlpha(1) end
		else
			-- Barra fija: ocultar hasta pasar el ratón
			local target = 1
			if db.barFade and db.barLocked and not over and not (db.barFadeCombat and InCombatLockdown()) then
				target = db.barFadeAlpha
			end
			local cur = self:GetAlpha()
			if math.abs(cur - target) > 0.01 then
				cur = cur < target and math.min(target, cur + dt * 6) or math.max(target, cur - dt * 3)
				self:SetAlpha(cur)
			elseif cur ~= target then
				self:SetAlpha(target)
			end
		end
	end)

	-- Botón en el borde del minimapa
	toggle = CreateFrame("Button", "RheizorMinimapButtonsToggle", Minimap)
	toggle:SetFrameStrata("MEDIUM")
	toggle:SetFrameLevel(Minimap:GetFrameLevel() + 8)
	toggle:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	toggle:RegisterForDrag("LeftButton")
	toggle:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight")
	toggle.bg = toggle:CreateTexture(nil, "BACKGROUND")
	toggle.bg:SetTexture("Interface\\Minimap\\UI-Minimap-Background")
	toggle.bg:SetPoint("CENTER")
	toggle.icon = toggle:CreateTexture(nil, "ARTWORK")
	toggle.ring = toggle:CreateTexture(nil, "OVERLAY")
	toggle.ring:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	toggle.ring:SetPoint("TOPLEFT")
	toggle.flat = CreateFrame("Frame", nil, toggle, "BackdropTemplate")
	toggle.flat:SetAllPoints()
	toggle.flat:SetFrameLevel(toggle:GetFrameLevel())
	toggle.flat:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })

	toggle:SetScript("OnClick", function(_, which)
		GameTooltip:Hide()
		if which == "RightButton" then
			if R.OpenModuleOptions then R:OpenModuleOptions(M) end
		elseif holder:IsShown() then
			M:ClosePanel()
		else
			M:OpenPanel()
		end
	end)
	toggle:SetScript("OnEnter", function(self)
		toggleTooltip(self)
		if db.open == "hover" then M:OpenPanel() end
	end)
	toggle:SetScript("OnLeave", GameTooltip_Hide)
	toggle:SetScript("OnDragStart", function(self)
		if db.locked then return end
		self.dragging = true
		GameTooltip:Hide()
		M:ClosePanel()
		self:SetScript("OnUpdate", function()
			db.angle = angleFromCursor()
			placeToggle()
		end)
	end)
	toggle:SetScript("OnDragStop", function(self)
		self.dragging = nil
		self:SetScript("OnUpdate", nil)
	end)

	-- Botón solo al pasar el ratón por el minimapa
	local watch = CreateFrame("Frame", nil, toggle)
	local w = 0
	watch:SetScript("OnUpdate", function(_, elapsed)
		w = w + elapsed
		if w < 0.15 then return end
		w = 0
		local visible = not db.buttonHover or toggle.dragging or holder:IsShown()
			or Minimap:IsMouseOver() or toggle:IsMouseOver()
		toggle:SetAlpha(visible and 1 or 0)
	end)

	Minimap:HookScript("OnSizeChanged", placeToggle)
end

function M:Apply()
	if not holder then return end
	if not running() then
		toggle:Hide()
		holder:Hide()
		if anchor then anchor:Hide() end
		return
	end
	applyBackdrop()
	applyToggleStyle()
	placeToggle()
	if db.mode == "bar" then
		toggle:Hide()
		if not anchor then
			anchor = CreateFrame("Frame", "RheizorMinimapButtonsBar", UIParent)
			anchor:SetSize(100, 30)
			anchorMover = R:CreateMover(anchor, "Botones del minimapa", db, "barPoint", { "TOPRIGHT", "TOPRIGHT", -230, -20 })
		end
		anchor:Show()
		anchorMover:Place()
		anchorMover:SetShown(not db.barLocked)
		holder:ClearAllPoints()
		holder:SetPoint("TOPLEFT", anchor, "TOPLEFT")
		holder:Show()
	else
		if anchor then anchor:Hide() end
		toggle:Show()
		if holder:IsShown() then anchorPanel() end
	end
	self:Layout()
end

function M:ResetPosition()
	db.angle = DEFAULT_ANGLE
	placeToggle()
end

function M:ResetBarPosition()
	db.barPoint = nil
	if anchorMover then anchorMover:Place() end
end

----------------------------------------------------------------------
-- Arranque
----------------------------------------------------------------------

function M:Start()
	if holder then return end
	createFrames()
	self:Apply()
	-- Los addons crean sus iconos al cargar o un poco después
	self:Scan()
	for _, delay in ipairs({ 1, 3, 8 }) do
		C_Timer.After(delay, function() M:Scan() end)
	end
	C_Timer.NewTicker(5, function()
		if not InCombatLockdown() then M:Scan() end
	end)
	local lib = LibStub and LibStub("LibDBIcon-1.0", true)
	if lib and lib.RegisterCallback then
		pcall(lib.RegisterCallback, M, "LibDBIcon_IconCreated", function()
			C_Timer.After(0, function() M:Scan() end)
		end)
	end
	local events = CreateFrame("Frame")
	events:RegisterEvent("ADDON_LOADED")
	events:SetScript("OnEvent", function()
		C_Timer.After(0.5, function() M:Scan() end)
	end)
	R:OnThemeChanged(function()
		if holder then
			applyBackdrop()
			applyToggleStyle()
		end
	end)
end

function M:OnEnable()
	db = self.db
	started = true
	if db.enabled then self:Start() end
end

function M:OnOptionChanged(key, value)
	if key == "enabled" then
		if value then
			self:Start()
			self:Apply()
			self:Scan()
		else
			self:Apply()
			R:NeedReload()
		end
		return
	end
	if not holder then return end
	if key == "exclude" or key == "includeRheizor" then
		self:Scan()
		R:Print(L["Los iconos ya agrupados vuelven al minimapa con /reload."])
		return
	end
	self:Apply()
end
