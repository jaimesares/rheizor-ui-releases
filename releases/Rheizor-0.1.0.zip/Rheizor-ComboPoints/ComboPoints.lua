-- Rheizor-ComboPoints: los puntos de combo del pícaro (y del druida en
-- forma felina) donde quieras y como quieras.
--
--   · Forma: cuadrados, círculos o rombos, del ancho y alto que elijas
--     (con alto pequeño y separación 0 son segmentos de una barra).
--   · Colocación: en línea (horizontal o vertical, en cualquier sentido) o en
--     arco; en pantalla (con el mover), sobre la placa de tu objetivo o en
--     los dos sitios a la vez (son dos marcos independientes).
--   · Color: uno solo, degradado del primero al último o de tu clase, y otro
--     distinto al llegar al máximo. Los apagados con su propio color.
--   · Efectos: al ganar un punto (salto, destello, aparecer), al gastarlos
--     (desvanecer) y al llegar al máximo (halo, latido, sonido).
--
-- Cada marco se dibuja con su OnUpdate mientras se ve. Los puntos se leen de
-- GetComboPoints / UnitPower; si el juego los diera secretos, se mantiene el
-- último valor conocido.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local SHAPES = { { "circle", "Círculos" }, { "square", "Cuadrados" }, { "diamond", "Rombos" } }
local LAYOUTS = { { "line", "En línea" }, { "arc", "En arco" } }
local DIRECTIONS = {
	{ "right", "De izquierda a derecha" }, { "left", "De derecha a izquierda" },
	{ "up", "De abajo arriba" }, { "down", "De arriba abajo" },
}
local PLATE_SIDES = {
	{ "above", "Encima de la barra" }, { "below", "Debajo de la barra" },
	{ "left", "A la izquierda de la barra" }, { "right", "A la derecha de la barra" },
	{ "inside", "Dentro de la barra" },
}
local SHOW = {
	{ "always", "Siempre" },
	{ "combat", "Solo en combate" },
	{ "target", "Con un objetivo atacable" },
	{ "points", "Solo si tienes puntos" },
}
local COLOR_MODES = {
	{ "single", "Un solo color" },
	{ "gradient", "Degradado del primero al último" },
	{ "class", "Color de tu clase" },
}
local GAIN_FX = {
	{ "none", "Ninguno" },
	{ "pop", "Salto: crece y vuelve" },
	{ "flash", "Destello blanco" },
	{ "fade", "Aparecer poco a poco" },
	{ "popflash", "Salto y destello" },
}
local SPEND_FX = { { "none", "Ninguno: se apagan de golpe" }, { "fade", "Desvanecer" } }
local MAX_FX = {
	{ "none", "Ninguno" },
	{ "glow", "Halo que late" },
	{ "pulse", "Los puntos laten" },
	{ "both", "Halo y latido" },
}
local SOUNDS = {
	{ "none", "Ninguno" },
	{ "alert", "Alerta de banda" },
	{ "ready", "Comprobación de listos" },
	{ "whisper", "Susurro" },
	{ "click", "Clic" },
}
local TEXT_POS = {
	{ "none", "No mostrar" }, { "center", "En el centro" }, { "left", "A la izquierda" },
	{ "right", "A la derecha" }, { "above", "Encima" }, { "below", "Debajo" },
}

-- Las opciones de la placa solo tienen sentido con la placa activada
local function plateOff(mod)
	return function()
		local d = mod and mod.db
		if d and not d.showPlate then return L["Activa antes «En la placa del objetivo»."] end
	end
end

local M = R:RegisterModule("combopoints", {
	title = "Puntos de combo",
	defaults = {
		locked = true,
		shape = "circle",
		width = 18,
		height = 18,
		spacing = 4,
		layout = "line",
		direction = "right",
		radius = 60,
		arcStart = 150,
		arcSpan = 120,
		showScreen = true,
		showPlate = false,
		plateSide = "above",
		plateX = 0,
		plateY = 6,
		plateScale = 1,
		plateHideEmpty = false,
		plateMissing = "hide",
		scale = 1,
		show = "always",
		oocAlpha = 1,
		druidCatOnly = true,
		colorMode = "single",
		color1 = "ffd100",
		color2 = "ff3333",
		maxColorOn = true,
		maxColor = "ff5a1f",
		emptyColor = "000000",
		emptyAlpha = 0.45,
		border = 1,
		borderColor = "000000",
		gainFx = "pop",
		spendFx = "fade",
		fadeTime = 0.25,
		popSize = 1.4,
		maxFx = "glow",
		maxSound = "none",
		textPos = "none",
		textSize = 14,
		textColor = "ffffff",
		hideBlizzard = false,
	},
	options = {
		{ type = "header", text = "Puntos de combo" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueados se ven todos encendidos y se pueden arrastrar (en la pantalla con el mover; en la placa, arrastrándolos sobre ella). También con /rz mover." },
		{ type = "button", name = "Posición en la pantalla", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "button", name = "Probar los efectos", text = "Probar",
		  desc = "Gana los puntos uno a uno hasta el máximo y luego los gasta, para ver cómo queda.",
		  func = function(mod) mod:Test() end },

		{ type = "header", text = "Dónde se ven" },
		{ type = "toggle", key = "showScreen", name = "En la pantalla", refresh = true,
		  desc = "En el sitio que elijas con el mover. Desactívalo para verlos solo en la placa." },
		{ type = "toggle", key = "showPlate", name = "En la placa del objetivo", refresh = true,
		  desc = "Sobre la placa de nombre del enemigo que tienes seleccionado (necesita las placas activadas). Puede estar a la vez que la de la pantalla." },
		{ type = "dropdown", key = "plateSide", name = "Posición en la placa", values = PLATE_SIDES,
		  desc = "Respecto a la barra de vida si usas las placas de Rheizor; si no, respecto a la placa de Blizzard." },
		{ type = "slider", key = "plateX", name = "Desplazamiento X sobre la placa", min = -200, max = 200, step = 1, format = R.fmt.int },
		{ type = "slider", key = "plateY", name = "Desplazamiento Y sobre la placa", min = -200, max = 200, step = 1, format = R.fmt.int },
		{ type = "slider", key = "plateScale", name = "Escala en la placa", min = 0.3, max = 2, step = 0.05,
		  desc = "Se multiplica por la escala general." },
		{ type = "toggle", key = "plateHideEmpty", name = "En la placa, ocultarlos si no tienes puntos",
		  desc = "Con 0 puntos no sale nada sobre la placa. Los de la pantalla siguen la opción «Mostrar» de más abajo." },
		{ type = "dropdown", key = "plateMissing", name = "Si el objetivo no tiene placa",
		  values = { { "hide", "No mostrar nada" }, { "screen", "Mostrarlos en su sitio de la pantalla" } },
		  desc = "Solo cuenta si no los tienes ya en la pantalla." },

		{ type = "header", text = "Forma y tamaño" },
		{ type = "dropdown", key = "shape", name = "Forma", values = SHAPES },
		{ type = "slider", key = "width", name = "Ancho", min = 4, max = 80, step = 1, format = R.fmt.int },
		{ type = "slider", key = "height", name = "Alto", min = 2, max = 80, step = 1, format = R.fmt.int },
		{ type = "slider", key = "spacing", name = "Separación", min = -10, max = 40, step = 1, format = R.fmt.int,
		  desc = "Con 0 y un alto pequeño parecen los segmentos de una barra." },
		{ type = "slider", key = "scale", name = "Escala", min = 0.5, max = 3, step = 0.05 },
		{ type = "slider", key = "border", name = "Grosor del borde", min = 0, max = 5, step = 1, format = R.fmt.int },
		{ type = "color", key = "borderColor", name = "Color del borde" },

		{ type = "header", text = "Colocación" },
		{ type = "dropdown", key = "layout", name = "Distribución", values = LAYOUTS },
		{ type = "dropdown", key = "direction", name = "Dirección (en línea)", values = DIRECTIONS },
		{ type = "slider", key = "radius", name = "Radio del arco", min = 10, max = 300, step = 1, format = R.fmt.int },
		{ type = "slider", key = "arcStart", name = "Ángulo del primer punto", min = 0, max = 360, step = 5, format = R.fmt.int,
		  desc = "En grados: 0 = a la derecha, 90 = arriba, 180 = a la izquierda, 270 = abajo." },
		{ type = "slider", key = "arcSpan", name = "Apertura del arco", min = -360, max = 360, step = 5, format = R.fmt.int,
		  desc = "Grados de un extremo a otro. Negativo: en el sentido de las agujas del reloj." },

		{ type = "header", text = "Cuándo se ven" },
		{ type = "dropdown", key = "show", name = "Mostrar", values = SHOW },
		{ type = "slider", key = "oocAlpha", name = "Opacidad fuera de combate", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "druidCatOnly", name = "Druida: solo en forma felina" },
		{ type = "toggle", key = "hideBlizzard", name = "Ocultar los puntos de Blizzard", reload = true,
		  desc = "Los que Blizzard pone junto al marco del objetivo." },

		{ type = "header", text = "Colores" },
		{ type = "dropdown", key = "colorMode", name = "Color de los puntos", values = COLOR_MODES },
		{ type = "color", key = "color1", name = "Color (o primer punto del degradado)" },
		{ type = "color", key = "color2", name = "Último punto del degradado" },
		{ type = "toggle", key = "maxColorOn", name = "Otro color al llegar al máximo" },
		{ type = "color", key = "maxColor", name = "Color al máximo" },
		{ type = "color", key = "emptyColor", name = "Color de los apagados" },
		{ type = "slider", key = "emptyAlpha", name = "Opacidad de los apagados", min = 0, max = 1, step = 0.05,
		  desc = "0 = los apagados no se ven." },

		{ type = "header", text = "Efectos" },
		{ type = "dropdown", key = "gainFx", name = "Al ganar un punto", values = GAIN_FX },
		{ type = "dropdown", key = "spendFx", name = "Al gastarlos", values = SPEND_FX },
		{ type = "slider", key = "fadeTime", name = "Duración de aparecer y desvanecer", min = 0.05, max = 1, step = 0.05,
		  format = function(v) return string.format("%.2f s", v) end },
		{ type = "slider", key = "popSize", name = "Tamaño del salto", min = 1.1, max = 2.5, step = 0.05,
		  format = function(v) return string.format("×%.2f", v) end },
		{ type = "dropdown", key = "maxFx", name = "Al llegar al máximo", values = MAX_FX },
		{ type = "dropdown", key = "maxSound", name = "Sonido al llegar al máximo", values = SOUNDS },

		{ type = "header", text = "Número" },
		{ type = "dropdown", key = "textPos", name = "Número de puntos", values = TEXT_POS },
		{ type = "slider", key = "textSize", name = "Tamaño del número", min = 8, max = 40, step = 1, format = R.fmt.int },
		{ type = "color", key = "textColor", name = "Color del número" },
	},
	unsupported = {
		"Si en combate el juego ocultara a los addons cuántos puntos tienes, se mostraría el último valor conocido hasta que vuelva a poder leerse.",
	},
})

-- Las de la placa, grises si la placa está desactivada
for _, opt in ipairs(M.options) do
	if opt.key and (opt.key:find("^plate")) then opt.disabled = plateOff(M) end
end

local WHITE = "Interface\\Buttons\\WHITE8X8"
local CIRCLE = "Interface\\CHARACTERFRAME\\TempPortraitAlphaMask"
local POP_TIME, FLASH_TIME = 0.18, 0.35
local MAX_POINTS = 10
local SOUND_IDS = {
	alert = function() return SOUNDKIT.RAID_WARNING end,
	ready = function() return SOUNDKIT.READY_CHECK end,
	whisper = function() return SOUNDKIT.TELL_MESSAGE end,
	click = function() return SOUNDKIT.IG_MAINMENU_OPTION_CHECKBOX_ON end,
}

local db
local screen, plate     -- los dos marcos: { holder, points, shownCount, ... }
local count, maxCount = 0, 5
local shownTarget = 0   -- lo que se está dibujando (real, prueba o ejemplo)
local sim               -- número de la prueba en curso (nil = sin prueba)
local simToken = 0
local inCombat = false
local atMax = false

local function call(fn, ...)
	if not fn then return end
	local ok, a, b = pcall(fn, ...)
	if ok then return a, b end
end

local function rgb(hex) return R.HexToRGB(hex) end

local function displays()
	return screen, plate
end

----------------------------------------------------------------------
-- Lectura de los puntos
----------------------------------------------------------------------

local COMBO = Enum and Enum.PowerType and Enum.PowerType.ComboPoints or 14

local function readPoints()
	local v = GetComboPoints and NS(call(GetComboPoints, "player", "target"))
	if v == nil then v = NS(call(UnitPower, "player", COMBO)) end
	local m = NS(call(UnitPowerMax, "player", COMBO))
	if not m or m <= 0 then m = 5 end
	return v, math.min(m, MAX_POINTS)
end

local function classOK()
	local _, class = UnitClass("player")
	if class == "ROGUE" then return true end
	if class == "DRUID" then
		if not db.druidCatOnly then return true end
		local form = GetShapeshiftFormID and NS(GetShapeshiftFormID())
		return form == (CAT_FORM or 1)
	end
	return false
end

----------------------------------------------------------------------
-- Puntos
----------------------------------------------------------------------

local function newMask(p, region)
	local m = p:CreateMaskTexture()
	m:SetTexture(CIRCLE, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
	m:SetAllPoints(region)
	return m
end

local function createPoint(D, i)
	local p = CreateFrame("Frame", nil, D.holder)
	p:SetSize(1, 1)
	p.glow = p:CreateTexture(nil, "BACKGROUND", nil, -2)
	p.bg = p:CreateTexture(nil, "BACKGROUND", nil, 0)
	p.empty = p:CreateTexture(nil, "ARTWORK", nil, 0)
	p.lit = p:CreateTexture(nil, "ARTWORK", nil, 1)
	p.flash = p:CreateTexture(nil, "OVERLAY")
	for _, t in ipairs({ p.glow, p.bg, p.empty, p.lit, p.flash }) do
		t:SetTexture(WHITE)
		t:SetPoint("CENTER")
	end
	p.glow:SetBlendMode("ADD")
	p.flash:SetBlendMode("ADD")
	p.flash:SetVertexColor(1, 1, 1)
	p.flash:SetAlpha(0)
	p.glow:SetAlpha(0)
	p.lit:SetAlpha(0)
	-- Máscaras para los círculos (una por tamaño distinto)
	p.masks = {
		glow = newMask(p, p.glow), bg = newMask(p, p.bg),
		empty = newMask(p, p.empty), lit = newMask(p, p.empty), flash = newMask(p, p.empty),
	}
	p.index = i
	p.litA, p.litTarget, p.popT, p.flashT, p.drawnScale = 0, 0, 0, 0, nil
	D.points[i] = p
	return p
end

local function applyShape(p)
	local circle = db.shape == "circle"
	local rot = db.shape == "diamond" and math.pi / 4 or 0
	for key, m in pairs(p.masks) do
		local t = p[key]
		if circle and not p.masked then t:AddMaskTexture(m) end
		if not circle and p.masked then t:RemoveMaskTexture(m) end
		if t.SetRotation then t:SetRotation(rot) end
	end
	p.masked = circle
	p.bg:SetVertexColor(rgb(db.borderColor))
	p.bg:SetShown(db.border > 0)
	local r, g, b = rgb(db.emptyColor)
	p.empty:SetVertexColor(r, g, b, db.emptyAlpha)
end

-- Tamaño de las texturas de un punto (s = escala del efecto)
local function sizePoint(p, s)
	if p.drawnScale and math.abs(p.drawnScale - s) < 0.002 then return end
	p.drawnScale = s
	-- El rombo es un cuadrado girado: algo más pequeño para ocupar lo mismo
	local k = db.shape == "diamond" and 0.72 or 1
	local w, h = db.width * s * k, db.height * s * k
	local b = db.border
	p.empty:SetSize(w, h)
	p.lit:SetSize(w, h)
	p.flash:SetSize(w, h)
	p.bg:SetSize(w + 2 * b, h + 2 * b)
	p.glow:SetSize(w + 2 * b + 10, h + 2 * b + 10)
end

local function colorFor(i, n)
	if db.maxColorOn and n >= maxCount then return rgb(db.maxColor) end
	if db.colorMode == "gradient" and maxCount > 1 then
		local r1, g1, b1 = rgb(db.color1)
		local r2, g2, b2 = rgb(db.color2)
		local f = (i - 1) / (maxCount - 1)
		return r1 + (r2 - r1) * f, g1 + (g2 - g1) * f, b1 + (b2 - b1) * f
	elseif db.colorMode == "class" then
		local _, class = UnitClass("player")
		local c = class and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
		if c then return c.r, c.g, c.b end
	end
	return rgb(db.color1)
end

local function paintColors(D, n)
	for i = 1, maxCount do
		local p = D.points[i]
		if p then
			local r, g, b = colorFor(i, n)
			p.lit:SetVertexColor(r, g, b)
			p.glow:SetVertexColor(r, g, b)
		end
	end
end

----------------------------------------------------------------------
-- Colocación
----------------------------------------------------------------------

local function layout(D)
	local holder = D.holder
	for i = 1, MAX_POINTS do
		local p = D.points[i]
		if i <= maxCount then
			p = p or createPoint(D, i)
			applyShape(p)
			p.drawnScale = nil
			sizePoint(p, 1)
			p:Show()
		elseif p then
			p:Hide()
		end
	end

	local w, h, gap = db.width, db.height, db.spacing
	local minX, maxX, minY, maxY = 0, 0, 0, 0
	for i = 1, maxCount do
		local x, y
		if db.layout == "arc" then
			local span = db.arcSpan
			-- Un círculo entero: el último no se monta sobre el primero
			local steps = math.abs(span) >= 360 and maxCount or math.max(maxCount - 1, 1)
			local a = math.rad(db.arcStart + span * (i - 1) / steps)
			x, y = db.radius * math.cos(a), db.radius * math.sin(a)
		else
			local off = (i - (maxCount + 1) / 2)
			if db.direction == "left" then x, y = -off * (w + gap), 0
			elseif db.direction == "up" then x, y = 0, off * (h + gap)
			elseif db.direction == "down" then x, y = 0, -off * (h + gap)
			else x, y = off * (w + gap), 0 end
		end
		D.points[i]:ClearAllPoints()
		D.points[i]:SetPoint("CENTER", holder, "CENTER", x, y)
		minX, maxX = math.min(minX, x), math.max(maxX, x)
		minY, maxY = math.min(minY, y), math.max(maxY, y)
	end
	-- El marco abarca todos los puntos (para el mover)
	local pad = db.border + 2
	local W = 2 * math.max(math.abs(minX), math.abs(maxX)) + w + 2 * pad
	local H = 2 * math.max(math.abs(minY), math.abs(maxY)) + h + 2 * pad
	holder:SetSize(math.max(W, 10), math.max(H, 10))

	local fs = holder.num
	fs:SetFont(STANDARD_TEXT_FONT, db.textSize, "OUTLINE")
	fs:SetTextColor(rgb(db.textColor))
	fs:ClearAllPoints()
	local pos = db.textPos
	if pos == "left" then fs:SetPoint("RIGHT", holder, "LEFT", -2, 0)
	elseif pos == "right" then fs:SetPoint("LEFT", holder, "RIGHT", 2, 0)
	elseif pos == "above" then fs:SetPoint("BOTTOM", holder, "TOP", 0, 2)
	elseif pos == "below" then fs:SetPoint("TOP", holder, "BOTTOM", 0, -2)
	else fs:SetPoint("CENTER", holder, "CENTER", 0, 0) end
	fs:SetShown(pos ~= "none")
	paintColors(D, D.shownCount)
end

local function layoutAll()
	for _, D in ipairs({ displays() }) do layout(D) end
end

local function setScale(D, s)
	s = math.max(s, 0.1)
	if D.curScale ~= s then
		D.curScale = s
		D.holder:SetScale(s)
	end
end

-- Punto del marco de los puntos -> punto de la barra de la placa
local SIDE_POINTS = {
	above = { "BOTTOM", "TOP" }, below = { "TOP", "BOTTOM" },
	left = { "RIGHT", "LEFT" }, right = { "LEFT", "RIGHT" }, inside = { "CENTER", "CENTER" },
}

-- La barra de vida de la placa de Rheizor (Rheizor-Nameplates), o la placa
-- de Blizzard si no la hay
local function targetPlate()
	local np = C_NamePlate and C_NamePlate.GetNamePlateForUnit and call(C_NamePlate.GetNamePlateForUnit, "target")
	if not np then return end
	local rz = np.rz
	if type(rz) == "table" and rz.health and rz:IsShown() then return rz.health end
	return np
end

local function placePlate(bar)
	local holder = plate.holder
	local s = math.max(db.scale * db.plateScale, 0.1)
	setScale(plate, s)
	local p = SIDE_POINTS[db.plateSide] or SIDE_POINTS.above
	holder:ClearAllPoints()
	holder:SetPoint(p[1], bar, p[2], db.plateX / s, db.plateY / s)
	-- Desbloqueados: se arrastran sobre la placa
	holder:EnableMouse(not db.locked)
	holder.dragHint:SetShown(not db.locked)
end

----------------------------------------------------------------------
-- Cambios de número y efectos
----------------------------------------------------------------------

local function playMaxSound()
	local get = SOUND_IDS[db.maxSound]
	local id = get and get()
	if id then PlaySound(id, "Master") end
end

local function setShown(D, n, quiet)
	n = math.max(0, math.min(n or 0, maxCount))
	D.shownCount = n
	local gain, spend = db.gainFx, db.spendFx
	for i = 1, maxCount do
		local p = D.points[i]
		if p then
			local on = i <= n
			local was = p.litTarget == 1
			p.litTarget = on and 1 or 0
			if on and not was then
				if quiet or not (gain == "fade") then p.litA = 1 else p.litA = 0 end
				if not quiet and (gain == "pop" or gain == "popflash") then p.popT = POP_TIME end
				if not quiet and (gain == "flash" or gain == "popflash") then p.flashT = FLASH_TIME end
			elseif not on and was then
				if quiet or spend ~= "fade" then p.litA = 0 end
			end
		end
	end
	paintColors(D, n)
	D.holder.num:SetText(n > 0 and n or "")
end

-- Mostrar u ocultar un marco; soft = esperar a que se apaguen los puntos
local function setVisible(D, show, soft)
	if show then
		D.fadeOut = nil
		D.holder:Show()
	elseif soft and D.holder:IsShown() and db.spendFx == "fade" then
		D.fadeOut = true
	else
		D.fadeOut = nil
		D.holder:Hide()
	end
end

local function onUpdate(D, elapsed)
	-- Arrastrándolos sobre la placa: se cambia el desplazamiento
	local d = D.drag
	if d then
		local x, y = GetCursorPosition()
		local k = UIParent:GetEffectiveScale()
		local function clamp(v) return math.max(-200, math.min(200, math.floor(v + 0.5))) end
		db.plateX = clamp(d[3] + (x - d[1]) / k)
		db.plateY = clamp(d[4] + (y - d[2]) / k)
		local bar = targetPlate()
		if bar then placePlate(bar) end
	end

	local fade = math.max(db.fadeTime, 0.01)
	local maxFx = atMax and db.maxFx or "none"
	local glowOn = maxFx == "glow" or maxFx == "both"
	local pulseOn = maxFx == "pulse" or maxFx == "both"
	local wave = (math.sin(GetTime() * math.pi * 2 * 1.2) + 1) / 2   -- 0..1
	local anyLit = false
	for i = 1, maxCount do
		local p = D.points[i]
		if p then
			if p.litA ~= p.litTarget then
				local step = elapsed / fade
				p.litA = p.litA < p.litTarget and math.min(p.litTarget, p.litA + step) or math.max(p.litTarget, p.litA - step)
			end
			if p.litA > 0 then anyLit = true end
			p.lit:SetAlpha(p.litA)
			local s = 1
			if p.popT > 0 then
				p.popT = math.max(0, p.popT - elapsed)
				s = 1 + (db.popSize - 1) * (p.popT / POP_TIME)
			end
			if pulseOn and p.litTarget == 1 then s = s * (1 + 0.1 * wave) end
			sizePoint(p, s)
			if p.flashT > 0 then
				p.flashT = math.max(0, p.flashT - elapsed)
				p.flash:SetAlpha(0.9 * p.flashT / FLASH_TIME)
			else
				p.flash:SetAlpha(0)
			end
			p.glow:SetAlpha((glowOn and p.litTarget == 1) and (0.15 + 0.45 * wave) or 0)
		end
	end
	-- Ocultarse cuando ya se han desvanecido
	if D.fadeOut and not anyLit then
		D.fadeOut = nil
		D.holder:Hide()
	end
end

----------------------------------------------------------------------
-- Estado general
----------------------------------------------------------------------

local function wanted()
	if not db.locked or sim then return true end
	if not classOK() then return false end
	local s = db.show
	if s == "combat" then return inCombat end
	if s == "target" then
		return UnitExists("target") and UnitCanAttack("player", "target") and not UnitIsDeadOrGhost("target") and true or false
	end
	if s == "points" then return count > 0 end
	return true
end

function M:Update()
	if not screen then return end
	local v, m = readPoints()
	if v ~= nil then count = v end
	if m ~= maxCount then
		maxCount = m
		layoutAll()
	end
	local target = sim or (not db.locked and maxCount) or count
	if target ~= shownTarget then
		local nowMax = target >= maxCount and target > 0
		if nowMax and not atMax and target > shownTarget then playMaxSound() end
		atMax = nowMax
		shownTarget = target
		setShown(screen, target)
		setShown(plate, target)
	end

	local base = wanted()
	local bar = db.showPlate and targetPlate()
	local alpha = (inCombat or not db.locked or sim) and 1 or db.oocAlpha

	-- En la placa
	if bar then placePlate(bar) end
	if not bar then plate.drag = nil end
	local empty = db.plateHideEmpty and target == 0
	setVisible(plate, base and bar and not empty and true or false, base and bar and empty)
	plate.holder:SetAlpha(alpha)

	-- En la pantalla (o en su lugar, si el objetivo no tiene placa)
	local onScreen = db.showScreen or (db.showPlate and not bar and db.plateMissing == "screen")
	setScale(screen, db.scale)
	screen.holder.mover:Place()
	screen.holder.mover:SetShown(not db.locked and onScreen and true or false)
	setVisible(screen, base and onScreen and true or false)
	screen.holder:SetAlpha(alpha)
end

function M:Refresh()
	if not screen then return end
	layoutAll()
	-- Sin efectos: solo repintar
	for _, D in ipairs({ displays() }) do setShown(D, D.shownCount, true) end
	self:Update()
end

function M:ResetPosition()
	db.point = nil
	self:Refresh()
end

-- Prueba: ganar uno a uno hasta el máximo y gastarlos
function M:Test()
	if not screen then return end
	simToken = simToken + 1
	local token = simToken
	sim = 0
	for _, D in ipairs({ displays() }) do setShown(D, 0, true) end
	shownTarget = 0
	atMax = false
	self:Update()
	local function step(n)
		if token ~= simToken then return end
		if n <= maxCount then
			sim = n
			M:Update()
			C_Timer.After(0.45, function() step(n + 1) end)
		else
			C_Timer.After(1.5, function()
				if token ~= simToken then return end
				sim = 0
				M:Update()
				C_Timer.After(1.2, function()
					if token ~= simToken then return end
					sim = nil
					M:Update()
				end)
			end)
		end
	end
	C_Timer.After(0.3, function() step(1) end)
end

local function hideBlizzard()
	for _, name in ipairs({ "ComboFrame", "ComboPointPlayerFrame", "RogueComboPointBarFrame", "ComboPointDruidPlayerFrame" }) do
		local f = _G[name]
		if type(f) == "table" and f.Hide and not (f.IsProtected and f:IsProtected()) then
			f:Hide()
			f:HookScript("OnShow", f.Hide)
		end
	end
end

local function newDisplay(name)
	local D = { points = {}, shownCount = 0 }
	local holder = CreateFrame("Frame", name, UIParent)
	holder:SetFrameStrata("MEDIUM")
	holder:SetSize(100, 20)
	holder:Hide()
	holder.num = holder:CreateFontString(nil, "OVERLAY")
	holder.num:SetFont(STANDARD_TEXT_FONT, 14, "OUTLINE")
	holder:SetScript("OnUpdate", function(_, elapsed) onUpdate(D, elapsed) end)
	D.holder = holder
	return D
end

local function update() M:Update() end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event)
	if event == "PLAYER_REGEN_DISABLED" then
		inCombat = true
	elseif event == "PLAYER_REGEN_ENABLED" then
		inCombat = false
	end
	M:Update()
	-- Rheizor-Nameplates crea su placa con los mismos eventos: otra vez al
	-- siguiente fotograma, para ponerse sobre su barra y no sobre la de Blizzard
	if event == "PLAYER_TARGET_CHANGED" or event == "NAME_PLATE_UNIT_ADDED" or event == "NAME_PLATE_UNIT_REMOVED" then
		C_Timer.After(0, update)
	end
end)

function M:OnEnable()
	db = self.db
	-- Antes era un solo sitio: "anchor" = pantalla o placa
	if db.anchor ~= nil then
		db.showPlate = db.anchor == "plate"
		db.showScreen = db.anchor ~= "plate"
		db.anchor = nil
	end
	if not screen then
		screen = newDisplay("RheizorComboPoints")
		screen.holder.mover = R:CreateMover(screen.holder, "Puntos de combo", db, "point", { "CENTER", "CENTER", 0, -160 })

		plate = newDisplay("RheizorComboPointsPlate")
		local ph = plate.holder
		-- Sobre la placa y desbloqueados: se arrastran con el ratón
		ph.dragHint = ph:CreateTexture(nil, "BACKGROUND", nil, -8)
		ph.dragHint:SetAllPoints()
		ph.dragHint:SetColorTexture(0.2, 0.8, 1, 0.25)
		ph.dragHint:Hide()
		ph:EnableMouse(false)
		ph:SetScript("OnMouseDown", function(_, button)
			if button ~= "LeftButton" then return end
			local x, y = GetCursorPosition()
			plate.drag = { x, y, db.plateX, db.plateY }
		end)
		ph:SetScript("OnMouseUp", function() plate.drag = nil end)
		ph:SetScript("OnHide", function() plate.drag = nil end)

		for _, e in ipairs({ "PLAYER_TARGET_CHANGED", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED",
			"UPDATE_SHAPESHIFT_FORM", "PLAYER_ENTERING_WORLD", "NAME_PLATE_UNIT_ADDED", "NAME_PLATE_UNIT_REMOVED" }) do
			pcall(events.RegisterEvent, events, e)
		end
		for _, e in ipairs({ "UNIT_POWER_UPDATE", "UNIT_POWER_FREQUENT", "UNIT_MAXPOWER" }) do
			pcall(events.RegisterUnitEvent, events, e, "player")
		end
		if db.hideBlizzard then hideBlizzard() end
	end
	inCombat = InCombatLockdown()
	local v, m = readPoints()
	count, maxCount = v or 0, m
	self:Refresh()
end

function M:OnOptionChanged(key)
	if key == "hideBlizzard" and db.hideBlizzard then hideBlizzard() end
	self:Refresh()
end
