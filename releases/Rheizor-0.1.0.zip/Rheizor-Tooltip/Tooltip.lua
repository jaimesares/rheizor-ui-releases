-- Tooltips al estilo TipTac: aspecto (fondo, borde, letra, escala), posición
-- (ratón, fija, oculta, en combate), información de jugadores y PNJ (colores,
-- hermandad, nivel, objetivo), barras de vida y recurso, y extras de objetos
-- y hechizos (icono, nivel, cuántos tienes, precio, IDs, quién lanzó un aura).
--
-- La información se añade con TooltipDataProcessor (motor 12.x); si no existe
-- se usan los scripts antiguos OnTooltipSetUnit/Item/Spell. Cada añadido va
-- protegido: si algo falla, se avisa una vez y el tooltip queda como el de
-- Blizzard.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local GROUP = "Tooltips"

----------------------------------------------------------------------
-- Opciones
----------------------------------------------------------------------

local ANCHORS = {
	{ "default", "Donde lo pone Blizzard" },
	{ "cursor", "Encima del ratón" },
	{ "cursorLeft", "A la izquierda del ratón" },
	{ "cursorRight", "A la derecha del ratón" },
	{ "fixed", "Posición fija (se puede mover)" },
	{ "hide", "No mostrar" },
}

local MODIFIERS = {
	{ "none", "Nunca" },
	{ "shift", "Manteniendo Mayús" },
	{ "ctrl", "Manteniendo Ctrl" },
	{ "alt", "Manteniendo Alt" },
}

-- Opciones de tooltips que da Blizzard (solo las que existen en este cliente)
local BLIZZARD = {
	{ "UberTooltips", "Tooltips detallados",
	  "Muestra la descripción completa de hechizos, habilidades y botones (en Blizzard: «Tooltips mejorados»)." },
	{ "showNewbieTips", "Consejos para principiantes",
	  "Añade explicaciones de ayuda a los tooltips de la interfaz." },
	{ "alwaysCompareItems", "Comparar objetos siempre",
	  "Muestra al lado el objeto que llevas puesto sin tener que mantener Mayús." },
	{ "showQuestTrackingTooltips", "Progreso de misiones",
	  "Muestra en los tooltips de PNJ y objetos cuánto te falta de tus misiones." },
	{ "SoftTargetTooltipEnemy", "Objetivo suave: enemigos",
	  "Muestra el tooltip del enemigo que marca el objetivo suave (la selección automática al mirar)." },
	{ "SoftTargetTooltipFriend", "Objetivo suave: aliados",
	  "Muestra el tooltip del aliado que marca el objetivo suave." },
	{ "SoftTargetTooltipInteract", "Objetivo suave: objetos",
	  "Muestra el tooltip del objeto o PNJ con el que puedes interactuar." },
}

-- Orden de la página: Aspecto, Posición y comportamiento, Personajes y PNJ,
-- Barras de vida y recurso, Objetos y hechizos. Las secciones salen en el
-- orden en que se registran, así que Aspecto va primero.

local Style = R:RegisterModule("tooltipStyle", {
	title = "Aspecto",
	group = GROUP,
	defaults = {
		enabled = true,
		border = "flat",
		bgColor = "0c0c12",
		bgAlpha = 0.9,
		borderColor = "3a3a3a",
		borderAlpha = 1,
		gradient = true,
		classBorder = true,
		reactionBorder = false,
		qualityBorder = true,
		font = false,
		fontFace = "default",
		fontSize = 12,
		headerSize = 14,
		fontOutline = "",
	},
	options = {
		{ type = "toggle", key = "enabled", name = "Cambiar el fondo y el borde",
		  desc = "Desactivado, el recuadro de los tooltips se ve como el de Blizzard. La letra y las barras tienen sus propias opciones." },

		{ type = "header", text = "Fondo y borde" },
		{ type = "dropdown", key = "border", name = "Borde",
		  values = {
			{ "flat", "Plano fino" },
			{ "thick", "Plano grueso" },
			{ "classic", "Clásico de Blizzard" },
			{ "none", "Sin borde" },
		  } },
		{ type = "color", key = "bgColor", name = "Color del fondo" },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "color", key = "borderColor", name = "Color del borde",
		  desc = "El de siempre. Las opciones de abajo lo cambian según lo que muestra el tooltip." },
		{ type = "slider", key = "borderAlpha", name = "Opacidad del borde", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "gradient", name = "Brillo arriba",
		  desc = "Un degradado suave en la parte de arriba, como en TipTac." },

		{ type = "header", text = "Color del borde según lo que muestra" },
		{ type = "toggle", key = "classBorder", name = "Jugadores: color de su clase" },
		{ type = "toggle", key = "reactionBorder", name = "PNJ: verde, amarillo o rojo según su reacción" },
		{ type = "toggle", key = "qualityBorder", name = "Objetos: color de su calidad" },

		{ type = "header", text = "Letra" },
		{ type = "toggle", key = "font", name = "Cambiar la letra",
		  desc = "Cambia la letra de todos los tooltips del juego." },
		{ type = "dropdown", key = "fontFace", name = "Tipo de letra",
		  values = (function()
			local list = {
				{ "default", "La del juego" },
				{ "Fonts\\FRIZQT__.TTF", "Friz Quadrata" },
				{ "Fonts\\ARIALN.TTF", "Arial Narrow" },
				{ "Fonts\\skurri.ttf", "Skurri" },
				{ "Fonts\\MORPHEUS.ttf", "Morpheus" },
			}
			for _, f in ipairs(R.EXTRA_FONTS or {}) do list[#list + 1] = { f[2], f[3] } end
			return list
		  end)() },
		{ type = "slider", key = "fontSize", name = "Tamaño del texto", min = 8, max = 20, step = 1, format = R.fmt.int },
		{ type = "slider", key = "headerSize", name = "Tamaño del título", min = 8, max = 24, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "fontOutline", name = "Contorno",
		  values = {
			{ "", "Sin contorno" },
			{ "OUTLINE", "Contorno fino" },
			{ "THICKOUTLINE", "Contorno grueso" },
		  } },
	},
})

local general = {
	{ type = "header", text = "Tamaño" },
	{ type = "slider", key = "scale", name = "Escala de los tooltips", min = 0.5, max = 2, step = 0.05 },

	{ type = "header", text = "Dónde sale cada tooltip" },
	{ type = "dropdown", key = "anchorWorldUnit", name = "Personajes y PNJ del mundo", values = ANCHORS },
	{ type = "dropdown", key = "anchorFrameUnit", name = "Marcos de unidad", values = ANCHORS,
	  desc = "Tu marco, el de tu objetivo, el grupo, la banda..." },
	{ type = "dropdown", key = "anchorWorldTip", name = "Cosas del mundo", values = ANCHORS,
	  desc = "Buzones, menas, hierbas, cofres, carteles..." },
	{ type = "dropdown", key = "anchorFrameTip", name = "Resto de la interfaz", values = ANCHORS,
	  desc = "Botones de acción, bolsas, libro de hechizos... (solo los que usan la posición por defecto de Blizzard)." },

	{ type = "header", text = "Pegado al ratón" },
	{ type = "slider", key = "offsetX", name = "Separación del ratón en horizontal", min = -100, max = 100, step = 1, format = R.fmt.int,
	  desc = "Solo para los tooltips que salen junto al ratón." },
	{ type = "slider", key = "offsetY", name = "Separación del ratón en vertical", min = -100, max = 100, step = 1, format = R.fmt.int,
	  desc = "Solo para los tooltips que salen junto al ratón." },

	{ type = "header", text = "Posición fija" },
	{ type = "toggle", key = "locked", name = "Bloquear la posición fija",
	  desc = "Desbloqueado aparece un recuadro que puedes arrastrar: ahí salen los tooltips con «Posición fija»." },
	{ type = "dropdown", key = "fixedGrow", name = "Desde la posición fija, crecer hacia",
	  values = {
		{ "BOTTOMRIGHT", "Arriba y a la izquierda" },
		{ "BOTTOMLEFT", "Arriba y a la derecha" },
		{ "TOPRIGHT", "Abajo y a la izquierda" },
		{ "TOPLEFT", "Abajo y a la derecha" },
	  } },
	{ type = "button", name = "Posición fija", text = "Restablecer", func = function(mod) mod:ResetPosition() end },

	{ type = "header", text = "En combate" },
	{ type = "toggle", key = "combatWorldUnit", name = "Ocultar los de personajes y PNJ del mundo" },
	{ type = "toggle", key = "combatFrameUnit", name = "Ocultar los de los marcos de unidad" },
	{ type = "toggle", key = "combatOther", name = "Ocultar todos los demás" },
	{ type = "dropdown", key = "combatModifier", name = "Mostrarlos igualmente", values = MODIFIERS,
	  desc = "Si mantienes esta tecla al pasar el ratón, el tooltip sale aunque estés en combate." },

	{ type = "header", text = "Al quitar el ratón" },
	{ type = "toggle", key = "hideInstant", name = "Ocultar al instante",
	  desc = "Al quitar el ratón de un personaje o PNJ del mundo, el tooltip desaparece en vez de desvanecerse poco a poco." },
}

-- Opciones del propio juego, al final (solo las que existen en este cliente)
local blizzardHeader = false
for _, b in ipairs(BLIZZARD) do
	if C_CVar and C_CVar.GetCVar(b[1]) ~= nil then
		if not blizzardHeader then
			table.insert(general, { type = "header", text = "Opciones de Blizzard" })
			blizzardHeader = true
		end
		table.insert(general, { type = "toggle", cvar = b[1], name = b[2], desc = b[3] })
	end
end

local M = R:RegisterModule("tooltip", {
	title = "Posición y comportamiento",
	group = GROUP,
	defaults = {
		scale = 1,
		anchorWorldUnit = "default",
		anchorFrameUnit = "default",
		anchorWorldTip = "default",
		anchorFrameTip = "default",
		offsetX = 0,
		offsetY = 0,
		locked = true,
		fixedGrow = "BOTTOMRIGHT",
		point = nil,
		combatWorldUnit = false,
		combatFrameUnit = false,
		combatOther = false,
		combatModifier = "shift",
		hideInstant = false,
	},
	options = general,
})

local Units = R:RegisterModule("tooltipUnits", {
	title = "Personajes y PNJ",
	group = GROUP,
	defaults = {
		classColor = true,
		reactionColor = true,
		title = true,
		realm = "star",
		raidIcon = true,
		status = true,
		guild = true,
		guildRank = true,
		guildColor = "e066ff",
		ownGuildColor = "40ff40",
		levelLine = true,
		reaction = false,
		hideFaction = true,
		hidePvP = true,
		target = true,
		targetedBy = true,
	},
	options = {
		{ type = "header", text = "Nombre" },
		{ type = "toggle", key = "classColor", name = "Jugadores: nombre del color de su clase" },
		{ type = "toggle", key = "reactionColor", name = "PNJ: nombre del color de su reacción" },
		{ type = "toggle", key = "title", name = "Mostrar títulos", desc = "Por ejemplo «Soldado Fulano»." },
		{ type = "dropdown", key = "realm", name = "Reino de jugadores de otros reinos",
		  values = {
			{ "full", "Nombre del reino" },
			{ "star", "Solo un asterisco (*)" },
			{ "none", "No mostrar" },
		  } },
		{ type = "toggle", key = "raidIcon", name = "Marca de banda junto al nombre" },
		{ type = "toggle", key = "status", name = "Etiquetas <Ausente>, <No molestar>, <Muerto>" },

		{ type = "header", text = "Hermandad" },
		{ type = "toggle", key = "guild", name = "Mostrar la hermandad" },
		{ type = "toggle", key = "guildRank", name = "Rango en la hermandad" },
		{ type = "color", key = "guildColor", name = "Color de las hermandades" },
		{ type = "color", key = "ownGuildColor", name = "Color de tu hermandad" },

		{ type = "header", text = "Nivel, raza y clase" },
		{ type = "toggle", key = "levelLine", name = "Reescribir la línea de nivel",
		  desc = "Nivel del color de la dificultad, clase con su color y rango del PNJ (Élite, Raro, Jefe)." },
		{ type = "toggle", key = "reaction", name = "Texto de reacción de los PNJ",
		  desc = "Añade Hostil, Neutral, Amistoso..." },

		{ type = "header", text = "Quitar líneas" },
		{ type = "toggle", key = "hideFaction", name = "Quitar la línea de facción (Alianza / Horda)" },
		{ type = "toggle", key = "hidePvP", name = "Quitar la línea JcJ" },

		{ type = "header", text = "Objetivo" },
		{ type = "toggle", key = "target", name = "A quién tiene seleccionado" },
		{ type = "toggle", key = "targetedBy", name = "Quién de tu grupo o banda lo tiene seleccionado" },
	},
	unsupported = {
		"De algunos PNJ enemigos el juego no deja a los addons leer sus datos, así que su tooltip puede quedarse como el de Blizzard (sin nivel reescrito, reacción ni ID).",
	},
})

local Bars = R:RegisterModule("tooltipBars", {
	title = "Barras de vida y recurso",
	group = GROUP,
	defaults = {
		health = "style",
		inside = false,
		texture = R.TEXTURES[2][1],
		height = 8,
		classColor = true,
		healthText = "pct",
		power = true,
		powerHeight = 4,
		powerText = false,
		fontSize = 9,
	},
	options = {
		{ type = "header", text = "Barra de vida" },
		{ type = "dropdown", key = "health", name = "Barra de vida",
		  values = {
			{ "blizzard", "Como la de Blizzard" },
			{ "style", "Con el estilo de Rheizor" },
			{ "hide", "Ocultar" },
		  } },
		{ type = "slider", key = "height", name = "Alto de la barra de vida", min = 3, max = 20, step = 1, format = R.fmt.int,
		  desc = "Con el estilo de Rheizor." },
		{ type = "toggle", key = "classColor", name = "Color de la barra: clase o reacción",
		  desc = "Con el estilo de Rheizor: jugadores con el color de su clase y PNJ verde, amarillo o rojo. Desactivado: verde, como la de Blizzard." },
		{ type = "dropdown", key = "healthText", name = "Texto de la vida",
		  desc = "Con el estilo de Rheizor.",
		  values = {
			{ "none", "Sin texto" },
			{ "pct", "Porcentaje" },
			{ "value", "Valor" },
			{ "both", "Valor y porcentaje" },
		  } },

		{ type = "header", text = "Barra de recurso" },
		{ type = "toggle", key = "power", name = "Barra de maná, ira o energía" },
		{ type = "slider", key = "powerHeight", name = "Alto de la barra de recurso", min = 2, max = 16, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "powerText", name = "Texto en la barra de recurso",
		  desc = "Con el mismo formato que el de la vida." },

		{ type = "header", text = "Aspecto de las barras" },
		{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
		{ type = "toggle", key = "inside", name = "Barras dentro del tooltip",
		  desc = "Con la barra de vida con el estilo de Rheizor, pone las barras dentro del recuadro en vez de debajo." },
		{ type = "slider", key = "fontSize", name = "Tamaño del texto de las barras", min = 6, max = 16, step = 1, format = R.fmt.int },
	},
})

local Items = R:RegisterModule("tooltipItems", {
	title = "Objetos y hechizos",
	group = GROUP,
	defaults = {
		icon = true,
		itemLevel = true,
		itemCount = true,
		sellPrice = true,
		stack = false,
		auraCaster = true,
		ids = "shift",
	},
	options = {
		{ type = "header", text = "Objetos" },
		{ type = "toggle", key = "icon", name = "Icono de objetos y hechizos",
		  desc = "Al lado del tooltip, arriba a la izquierda." },
		{ type = "toggle", key = "itemLevel", name = "Nivel de objeto",
		  desc = "En armas y armaduras, si el tooltip no lo muestra ya." },
		{ type = "toggle", key = "itemCount", name = "Cuántos tienes (bolsas y banco)" },
		{ type = "toggle", key = "sellPrice", name = "Precio de venta",
		  desc = "Si el tooltip no lo muestra ya. En un montón, el precio de todo el montón." },
		{ type = "toggle", key = "stack", name = "Tamaño máximo del montón" },

		{ type = "header", text = "Beneficios y perjuicios" },
		{ type = "toggle", key = "auraCaster", name = "Quién lo lanzó" },

		{ type = "header", text = "Identificadores" },
		{ type = "dropdown", key = "ids", name = "Mostrar el ID",
		  values = {
			{ "none", "Nunca" },
			{ "shift", "Manteniendo Mayús" },
			{ "always", "Siempre" },
		  },
		  desc = "De objetos, hechizos, auras y PNJ. Útil para macros y bases de datos." },
	},
})

local A, S, U, B, I   -- bases de datos de cada sección

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

-- ¿Está el addon en marcha? Los ganchos de Blizzard no se pueden quitar: si
-- se apaga en Rheizor, siguen llamándose pero no hacen nada. (No se usa
-- R:IsModuleRunning: durante el propio OnEnable aún da false)
local function running()
	return M.ready and R:IsAddonActive(M.addon)
end

-- Llama a fn protegida; cada error distinto se avisa una sola vez
local reported = {}
local function safe(fn, ...)
	if not running() then return end
	local ok, err = pcall(fn, ...)
	if not ok and not reported[err] then
		reported[err] = true
		geterrorhandler()(err)
	end
end

local function wrap(text, r, g, b)
	return string.format("|cff%02x%02x%02x%s|r", math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5), text)
end

local function hexWrap(text, hex)
	return "|cff" .. hex .. text .. "|r"
end

local function short(v)
	if v >= 1e6 then return string.format("%.1fM", v / 1e6) end
	if v >= 1e4 then return string.format("%.1fk", v / 1e3) end
	return string.format("%d", math.floor(v + 0.5))
end

local function classColor(unit)
	local _, class = UnitClass(unit)
	class = NS(class)
	local colors = CUSTOM_CLASS_COLORS or RAID_CLASS_COLORS
	local c = class and colors and colors[class]
	if c then return c.r, c.g, c.b end
end

local function reactionColor(unit)
	if UnitIsTapDenied and NS(UnitIsTapDenied(unit)) then return 0.6, 0.6, 0.6 end
	local reaction = NS(UnitReaction(unit, "player"))
	local c = reaction and FACTION_BAR_COLORS and FACTION_BAR_COLORS[reaction]
	if c then return c.r, c.g, c.b end
end

local function unitColor(unit)
	if NS(UnitIsPlayer(unit)) then return classColor(unit) end
	return reactionColor(unit)
end

local function coloredName(unit)
	local name = R.UnitFullName(unit)
	if not name then return end
	local r, g, b = unitColor(unit)
	return r and wrap(name, r, g, b) or name
end

local function modifierDown(m)
	return (m == "shift" and IsShiftKeyDown()) or (m == "ctrl" and IsControlKeyDown()) or (m == "alt" and IsAltKeyDown())
end

local function idsWanted()
	return I.ids == "always" or (I.ids == "shift" and IsShiftKeyDown())
end

----------------------------------------------------------------------
-- Líneas del tooltip: editar, quitar y reutilizar
----------------------------------------------------------------------

local function getLine(tt, i)
	local name = tt:GetName()
	if not name then return end
	return _G[name .. "TextLeft" .. i], _G[name .. "TextRight" .. i]
end

local function copyLine(tt, from, to)
	local fl, fr = getLine(tt, from)
	local tl, tr = getLine(tt, to)
	if not (fl and tl) then return end
	tl:SetText(fl:GetText())
	tl:SetTextColor(fl:GetTextColor())
	if fr and tr then
		if fr:IsShown() then
			tr:SetText(fr:GetText())
			tr:SetTextColor(fr:GetTextColor())
			tr:Show()
		else
			tr:SetText(nil)
			tr:Hide()
		end
	end
end

-- Quita las líneas marcadas subiendo las de debajo. Las que quedan libres al
-- final se reutilizan para lo que se añada después (addLine).
local function removeLines(tt, remove)
	if not next(remove) then return end
	local n = tt:NumLines()
	local w = 1
	for i = 1, n do
		if not remove[i] then
			if w ~= i then copyLine(tt, i, w) end
			w = w + 1
		end
	end
	for i = w, n do
		local l, r = getLine(tt, i)
		if l then l:SetText(nil) l:Hide() end
		if r then r:SetText(nil) r:Hide() end
	end
	tt.rzFree, tt.rzLast = w, n
end

local function addLine(tt, text, r, g, b, wrapText)
	local i = tt.rzFree
	if i and i <= tt.rzLast then
		local l = getLine(tt, i)
		l:SetText(text)
		l:SetTextColor(r or 1, g or 1, b or 1)
		l:Show()
		tt.rzFree = i + 1
	else
		tt:AddLine(text, r or 1, g or 1, b or 1, wrapText)
	end
end

local function findLine(tt, prefix)
	for i = 2, tt:NumLines() do
		local l = getLine(tt, i)
		local t = l and NS(l:GetText())
		if t and t:find(prefix, 1, true) then return i end
	end
end

-- Vuelve a calcular el tamaño si ya se está viendo. Solo hace falta al
-- añadir líneas DESPUÉS de que Blizzard lo muestre (auras). En los añadidos
-- de TooltipDataProcessor no: Blizzard llama a :Show() justo después
-- (TooltipDataHandlerMixin:InternalProcessInfo). Nunca se muestra uno oculto
-- desde aquí: su OnShow calcularía el relleno con su ancho, que puede ser
-- secreto, desde código de addon
local function relayout(tt)
	if tt:IsShown() then tt:Show() end
end

----------------------------------------------------------------------
-- Aspecto: fondo, borde, degradado, letra y escala
----------------------------------------------------------------------

local tips, tracked = {}, {}

-- Grosor del borde de cada estilo ("classic" usa el borde de Blizzard)
local EDGE = { flat = 1, thick = 2, none = 0 }

-- Los tooltips modernos se dibujan con NineSlice: se oculta y se ponen
-- texturas propias (fondo y cuatro bordes) ancladas al tooltip. No se usa
-- BackdropTemplate en el tooltip: al cambiar de tamaño calcula con su ancho,
-- que en WoW Forever puede ser secreto (textos secretos dentro) y, llamado
-- desde un addon, da error y contamina el tooltip.
local function skin(tt)
	local k = tt.rzSkin
	if k then return k end
	k = { edges = {} }
	k.bg = tt:CreateTexture(nil, "BACKGROUND", nil, -8)
	k.bg:SetAllPoints(tt)
	for i = 1, 4 do k.edges[i] = tt:CreateTexture(nil, "BACKGROUND", nil, 6) end
	local top, bottom, left, right = k.edges[1], k.edges[2], k.edges[3], k.edges[4]
	top:SetPoint("TOPLEFT")
	top:SetPoint("TOPRIGHT")
	bottom:SetPoint("BOTTOMLEFT")
	bottom:SetPoint("BOTTOMRIGHT")
	left:SetPoint("TOPLEFT")
	left:SetPoint("BOTTOMLEFT")
	right:SetPoint("TOPRIGHT")
	right:SetPoint("BOTTOMRIGHT")
	tt.rzSkin = k
	return k
end

local function hideSkin(tt)
	local k = tt.rzSkin
	if not k then return end
	k.bg:Hide()
	for _, e in ipairs(k.edges) do e:Hide() end
end

local function gradient(tt)
	local g = tt.rzGradient
	if not g then
		g = tt:CreateTexture(nil, "BACKGROUND", nil, 7)
		g:SetColorTexture(1, 1, 1, 1)
		g:SetPoint("TOPLEFT", 2, -2)
		g:SetPoint("TOPRIGHT", -2, -2)
		g:SetHeight(24)
		local ok = CreateColor and pcall(g.SetGradient, g, "VERTICAL", CreateColor(1, 1, 1, 0), CreateColor(1, 1, 1, 0.1))
		if not ok and g.SetGradientAlpha then
			pcall(g.SetGradientAlpha, g, "VERTICAL", 1, 1, 1, 0, 1, 1, 1, 0.1)
		end
		tt.rzGradient = g
	end
	return g
end

local function unpaint(tt)
	if not tt.rzStyle then return end
	tt.rzStyle = nil
	hideSkin(tt)
	if tt.NineSlice then tt.NineSlice:SetAlpha(1) end
	if tt.rzGradient then tt.rzGradient:Hide() end
end

local function paint(tt)
	if not (tracked[tt] and S) then return end
	if not (S.enabled and running()) then
		unpaint(tt)
		return
	end
	local r, g, b = R.HexToRGB(S.bgColor)
	local br, bg, bb
	if tt.rzBorder then
		br, bg, bb = tt.rzBorder[1], tt.rzBorder[2], tt.rzBorder[3]
	else
		br, bg, bb = R.HexToRGB(S.borderColor)
	end
	local nine = tt.NineSlice
	if S.border == "classic" and nine then
		-- Borde clásico: el propio de Blizzard, solo se colorea
		hideSkin(tt)
		nine:SetAlpha(1)
		if nine.SetCenterColor then nine:SetCenterColor(r, g, b, S.bgAlpha) end
		if nine.SetBorderColor then nine:SetBorderColor(br, bg, bb, S.borderAlpha) end
	else
		if nine then nine:SetAlpha(0) end
		local k = skin(tt)
		k.bg:SetColorTexture(r, g, b, S.bgAlpha)
		k.bg:Show()
		local size = EDGE[S.border] or 1
		for i, e in ipairs(k.edges) do
			if size > 0 then
				if i <= 2 then e:SetHeight(size) else e:SetWidth(size) end
				e:SetColorTexture(br, bg, bb, S.borderAlpha)
				e:Show()
			else
				e:Hide()
			end
		end
	end
	tt.rzStyle = S.border
	if tt.rzIcon then tt.rzIcon.border:SetColorTexture(br, bg, bb, 1) end
	gradient(tt):SetShown(S.gradient)
end

local FONT_OBJECTS = { GameTooltipHeaderText = "header", GameTooltipText = "text", GameTooltipTextSmall = "small" }
local originalFonts, fontsChanged = {}, false

local function applyFonts()
	for name, kind in pairs(FONT_OBJECTS) do
		local fo = _G[name]
		if fo and fo.GetFont then
			if not originalFonts[name] then originalFonts[name] = { fo:GetFont() } end
			local o = originalFonts[name]
			if S.font then
				local face = S.fontFace == "default" and o[1] or S.fontFace
				local size = kind == "header" and S.headerSize or (kind == "small" and S.fontSize - 2 or S.fontSize)
				if not fo:SetFont(face, size, S.fontOutline) and o[1] then fo:SetFont(o[1], size, S.fontOutline) end
			elseif fontsChanged and o[1] then
				fo:SetFont(o[1], o[2], o[3])
			end
		end
	end
	fontsChanged = S.font
end

local function applyScale()
	for _, tt in ipairs(tips) do
		-- Los que van dentro de otro tooltip ya heredan su escala
		local parent = tt:GetParent()
		if not parent or parent == UIParent then
			if A.scale ~= 1 or tt.rzScaled then
				tt:SetScale(A.scale)
				tt.rzScaled = A.scale ~= 1
			end
		end
	end
end

----------------------------------------------------------------------
-- Icono
----------------------------------------------------------------------

local function setIcon(tt, texture)
	local f = tt.rzIcon
	if not texture then
		if f then f:Hide() end
		return
	end
	if not f then
		-- Texturas simples (sin BackdropTemplate): el marco va pegado al
		-- tooltip, cuyo tamaño puede ser secreto
		f = CreateFrame("Frame", nil, tt)
		f:SetSize(34, 34)
		f:SetPoint("TOPRIGHT", tt, "TOPLEFT", -2, 0)
		f.border = f:CreateTexture(nil, "BACKGROUND")
		f.border:SetAllPoints()
		f.border:SetColorTexture(0, 0, 0, 1)
		f.tex = f:CreateTexture(nil, "ARTWORK")
		f.tex:SetPoint("TOPLEFT", 1, -1)
		f.tex:SetPoint("BOTTOMRIGHT", -1, 1)
		f.tex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
		tt.rzIcon = f
	end
	f.tex:SetTexture(texture)
	f:Show()
end

----------------------------------------------------------------------
-- Barras de vida y recurso (solo GameTooltip)
----------------------------------------------------------------------

local hb = GameTooltipStatusBar
local pb
local originalBar

local SCALE100 = CurveConstants and CurveConstants.ScaleTo100

-- Escribe el texto de una barra. Si los valores son secretos (vida de
-- enemigos en combate) no se puede operar con ellos: el porcentaje lo
-- calcula el juego (pctFunc, con la curva 0-100) y el valor se abrevia con
-- AbbreviateNumbers; todo se pinta con SetFormattedText, sin compararlo
local function barText(fs, mode, cur, max, pctFunc)
	if not fs then return end
	if mode == "none" then
		fs:SetText("")
		return
	end
	local c, m = NS(cur), NS(max)
	if c and m then
		if m <= 0 then
			fs:SetText("")
			return
		end
		local pct = c / m * 100
		-- A los PNJ el juego a veces solo les da el porcentaje (máximo 100)
		if mode == "pct" or m == 100 then
			fs:SetFormattedText("%d%%", pct + 0.5)
		elseif mode == "value" then
			fs:SetText(short(c))
		else
			fs:SetFormattedText("%s / %s  (%d%%)", short(c), short(m), pct + 0.5)
		end
		return
	end
	local ok = false
	if mode == "pct" and pctFunc then
		ok = pcall(function() fs:SetFormattedText("%.0f%%", pctFunc()) end)
	elseif mode == "value" and AbbreviateNumbers then
		ok = pcall(function() fs:SetFormattedText("%s", AbbreviateNumbers(cur)) end)
	elseif mode == "both" and AbbreviateNumbers and pctFunc then
		ok = pcall(function()
			fs:SetFormattedText("%s / %s  (%.0f%%)", AbbreviateNumbers(cur), AbbreviateNumbers(max), pctFunc())
		end)
	end
	if not ok then fs:SetText("") end
end

-- Texto de la vida. La barra de Blizzard va de 0 a 1 (porcentaje secreto
-- que pone el propio juego), así que el texto se saca de la unidad
local function updateHealthText()
	local unit = hb and hb.rzUnit
	if not unit or not NS(UnitExists(unit)) then return end
	local pctFunc = UnitHealthPercent and SCALE100 and function() return UnitHealthPercent(unit, true, SCALE100) end
	barText(hb.rzText, B.healthText, UnitHealth(unit), UnitHealthMax(unit), pctFunc)
end

local function barFont(fs)
	fs:SetFont(STANDARD_TEXT_FONT, B.fontSize, "OUTLINE")
end

local function newBarDecor(bar)
	bar.rzBg = bar:CreateTexture(nil, "BACKGROUND", nil, -8)
	bar.rzBg:SetPoint("TOPLEFT", -1, 1)
	bar.rzBg:SetPoint("BOTTOMRIGHT", 1, -1)
	bar.rzBg:SetColorTexture(0, 0, 0, 0.7)
	bar.rzText = bar:CreateFontString(nil, "OVERLAY")
	bar.rzText:SetPoint("CENTER", 0, 0)
end

local function saveOriginalBar()
	if originalBar or not hb then return end
	local tex = hb:GetStatusBarTexture()
	originalBar = { height = hb:GetHeight(), texture = tex and tex:GetTexture(), points = {} }
	for i = 1, hb:GetNumPoints() do
		originalBar.points[i] = { hb:GetPoint(i) }
	end
end

local function updatePower()
	local unit = pb.unit
	if not unit or not NS(UnitExists(unit)) then return end
	local max, cur = UnitPowerMax(unit), UnitPower(unit)
	pcall(pb.SetMinMaxValues, pb, 0, max)
	pcall(pb.SetValue, pb, cur)
	local mode = "none"
	if B.powerText then mode = B.healthText ~= "none" and B.healthText or "value" end
	local pctFunc = UnitPowerPercent and SCALE100 and function() return UnitPowerPercent(unit, nil, true, SCALE100) end
	barText(pb.rzText, mode, cur, max, pctFunc)
end

local function createPowerBar()
	pb = CreateFrame("StatusBar", nil, GameTooltip)
	pb:Hide()
	newBarDecor(pb)
	local elapsed = 0
	pb:SetScript("OnUpdate", function(_, e)
		elapsed = elapsed + e
		if elapsed < 0.2 then return end
		elapsed = 0
		updatePower()
	end)
end

-- Aspecto general de las barras (al activar y al cambiar opciones)
local function styleBars()
	pb:SetStatusBarTexture(B.texture)
	pb:SetHeight(B.powerHeight)
	barFont(pb.rzText)
	if not B.power then pb:Hide() end

	if not hb then return end
	saveOriginalBar()
	if not hb.rzBg then newBarDecor(hb) end
	if B.health == "style" then
		hb:SetStatusBarTexture(B.texture)
		hb:SetHeight(B.height)
		hb.rzBg:Show()
		hb.rzText:Show()
		barFont(hb.rzText)
	else
		hb.rzBg:Hide()
		hb.rzText:Hide()
		hb.rzColor = nil
		if originalBar and hb.rzStyled then
			if originalBar.texture then hb:SetStatusBarTexture(originalBar.texture) end
			hb:SetHeight(originalBar.height)
			hb:ClearAllPoints()
			for _, p in ipairs(originalBar.points) do hb:SetPoint(p[1], p[2], p[3], p[4], p[5]) end
		end
	end
	hb.rzStyled = B.health == "style"
	if B.health == "hide" then hb:Hide() end
end

local function placeBars(tt, powerShown)
	local style = B.health == "style"
	-- Blizzard puede mostrar su barra justo después: se da por hecho que sale
	local healthShown = B.health ~= "hide"
	local pad = 0
	if style and B.inside then
		local y = 6
		if powerShown then
			pb:ClearAllPoints()
			pb:SetPoint("BOTTOMLEFT", tt, "BOTTOMLEFT", 6, y)
			pb:SetPoint("BOTTOMRIGHT", tt, "BOTTOMRIGHT", -6, y)
			y = y + B.powerHeight + 2
		end
		if healthShown then
			hb:ClearAllPoints()
			hb:SetPoint("BOTTOMLEFT", tt, "BOTTOMLEFT", 6, y)
			hb:SetPoint("BOTTOMRIGHT", tt, "BOTTOMRIGHT", -6, y)
			y = y + B.height
		end
		pad = y > 6 and (y - 2) or 0
	else
		if style then
			hb:ClearAllPoints()
			hb:SetPoint("TOPLEFT", tt, "BOTTOMLEFT", 1, -2)
			hb:SetPoint("TOPRIGHT", tt, "BOTTOMRIGHT", -1, -2)
		end
		pb:ClearAllPoints()
		if healthShown then
			pb:SetPoint("TOPLEFT", hb, "BOTTOMLEFT", 0, -2)
			pb:SetPoint("TOPRIGHT", hb, "BOTTOMRIGHT", 0, -2)
		else
			pb:SetPoint("TOPLEFT", tt, "BOTTOMLEFT", 1, -2)
			pb:SetPoint("TOPRIGHT", tt, "BOTTOMRIGHT", -1, -2)
		end
	end
	if tt.SetPadding and (pad > 0 or tt.rzPadded) then
		tt:SetPadding(0, pad)
		tt.rzPadded = pad > 0
	end
end

local function barsForUnit(tt, unit)
	if not hb then return end
	if B.health == "style" then
		if B.classColor then
			local r, g, b = unitColor(unit)
			hb.rzColor = r and { r, g, b } or nil
		else
			hb.rzColor = nil
		end
		if hb.rzColor then hb:SetStatusBarColor(unpack(hb.rzColor)) end
		hb.rzUnit = unit
		updateHealthText()
	end

	local powerShown = false
	if B.power then
		local max = NS(UnitPowerMax(unit))
		if max ~= 0 then
			pb.unit = unit
			local _, token = UnitPowerType(unit)
			local colors = PowerBarColor
			local c = colors and (colors[NS(token) or ""] or colors[NS(UnitPowerType(unit)) or 0])
			if c then pb:SetStatusBarColor(c.r, c.g, c.b) else pb:SetStatusBarColor(0, 0.4, 1) end
			updatePower()
			pb:Show()
			powerShown = true
		end
	end
	if not powerShown then pb:Hide() end
	placeBars(tt, powerShown)
end

----------------------------------------------------------------------
-- Personajes y PNJ
----------------------------------------------------------------------

local CLASSIFICATION = {
	worldboss = "Jefe",
	rareelite = "Élite raro",
	elite = "Élite",
	rare = "Raro",
}

local function levelText(unit, isPlayer)
	local level = NS(UnitLevel(unit))
	if not level then return end
	local eff = UnitEffectiveLevel and NS(UnitEffectiveLevel(unit)) or level
	local lv
	if level < 0 or eff < 0 then
		lv = "|cffff0000??|r"
	else
		local getColor = GetCreatureDifficultyColor or GetQuestDifficultyColor
		local c = getColor and getColor(eff)
		lv = c and wrap(tostring(eff), c.r, c.g, c.b) or tostring(eff)
	end
	local parts = { (LEVEL or L["Nivel"]) .. " " .. lv }

	if isPlayer then
		local race = NS(UnitRace(unit))
		if race then parts[#parts + 1] = race end
		local className = NS(UnitClass(unit))
		if className then
			local r, g, b = classColor(unit)
			parts[#parts + 1] = r and wrap(className, r, g, b) or className
		end
	else
		local rank = CLASSIFICATION[NS(UnitClassification(unit)) or ""]
		if rank then
			parts[#parts + 1] = (rank == "Jefe" and "|cffff3333" or "|cffffcc00") .. L[rank] .. "|r"
		end
		local kind = NS(UnitCreatureFamily(unit)) or NS(UnitCreatureType(unit))
		if kind then parts[#parts + 1] = kind end
	end
	return table.concat(parts, " ")
end

local function nameText(unit, isPlayer, name, realm)
	local text = name
	if isPlayer and U.title then
		local pvp = NS(UnitPVPName(unit))
		if pvp and pvp ~= "" then text = pvp end
	end
	if realm and realm ~= "" then
		if U.realm == "full" then
			text = text .. "-" .. realm
		elseif U.realm == "star" then
			text = text .. " (*)"
		end
	end
	if U.status then
		if NS(UnitIsGhost(unit)) then
			text = text .. " |cff999999" .. L["<Fantasma>"] .. "|r"
		elseif NS(UnitIsDead(unit)) then
			text = text .. " |cff999999" .. L["<Muerto>"] .. "|r"
		end
		if isPlayer and NS(UnitIsAFK(unit)) then
			text = text .. " |cffff9900" .. L["<Ausente>"] .. "|r"
		elseif isPlayer and NS(UnitIsDND(unit)) then
			text = text .. " |cffff3333" .. L["<No molestar>"] .. "|r"
		end
	end
	return text
end

local function targetedBy(unit)
	local names = {}
	local function check(u)
		if NS(UnitExists(u)) and NS(UnitIsUnit(u .. "target", unit)) then
			local n = coloredName(u)
			if n then names[#names + 1] = n end
		end
	end
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do check("raid" .. i) end
	else
		check("player")
		for i = 1, GetNumSubgroupMembers() do check("party" .. i) end
	end
	return names
end

local function unitFromTooltip(tt, data)
	local unit
	if TooltipUtil and TooltipUtil.GetDisplayedUnit then
		local ok, _, u = pcall(TooltipUtil.GetDisplayedUnit, tt)
		if ok then unit = u end
	elseif tt.GetUnit then
		local ok, _, u = pcall(tt.GetUnit, tt)
		if ok then unit = u end
	end
	unit = NS(unit)
	if unit then return unit end
	local guid = data and NS(data.guid)
	if guid and UnitTokenFromGUID then return NS(UnitTokenFromGUID(guid)) end
	if NS(UnitExists("mouseover")) then return "mouseover" end
end

local function onUnit(tt, data)
	if tt ~= GameTooltip then return end
	local unit = unitFromTooltip(tt, data)
	if not unit then return end
	-- Con apellidos (Forever) sale el nombre completo y no hay reino
	local name, realm = R.UnitFullName(unit)
	if not name then return end
	local isPlayer = NS(UnitIsPlayer(unit))

	-- Nombre
	local line1 = getLine(tt, 1)
	if line1 then
		local text = nameText(unit, isPlayer, name, realm)
		line1:SetText(text)
		-- Marca de banda: el número puede llegar secreto; no se compara, se
		-- pinta directamente dentro del texto con SetFormattedText
		if U.raidIcon then
			local idx = GetRaidTargetIndex(unit)
			if (issecretvalue and issecretvalue(idx)) or NS(idx) then
				pcall(line1.SetFormattedText, line1, "|TInterface\\TargetingFrame\\UI-RaidTargetingIcon_%d:0|t %s", idx, text)
			end
		end
		local r, g, b
		if isPlayer and U.classColor then
			r, g, b = classColor(unit)
		elseif not isPlayer and U.reactionColor then
			r, g, b = reactionColor(unit)
		end
		if r then line1:SetTextColor(r, g, b) end
	end

	-- Hermandad, nivel, facción y JcJ
	local guild, rank
	if isPlayer then
		guild, rank = GetGuildInfo(unit)
		guild, rank = NS(guild), NS(rank)
	end
	local remove = {}
	local guildLine, levelLine
	for i = 2, tt:NumLines() do
		local l = getLine(tt, i)
		local t = l and NS(l:GetText())
		if t then
			if guild and not guildLine and t:find(guild, 1, true) then
				guildLine = i
			elseif not levelLine and LEVEL and t:find(LEVEL, 1, true) then
				levelLine = i
			elseif U.hideFaction and (t == FACTION_ALLIANCE or t == FACTION_HORDE) then
				remove[i] = true
			elseif U.hidePvP and PVP and t == PVP then
				remove[i] = true
			end
		end
	end

	if guildLine then
		if not U.guild then
			remove[guildLine] = true
		else
			local mine = IsInGuild() and NS(GetGuildInfo("player"))
			local text = hexWrap("<" .. guild .. ">", mine == guild and U.ownGuildColor or U.guildColor)
			if U.guildRank and rank and rank ~= "" then text = text .. " |cff999999" .. rank .. "|r" end
			getLine(tt, guildLine):SetText(text)
		end
	end

	if levelLine and U.levelLine then
		local text = levelText(unit, isPlayer)
		if text then
			local l = getLine(tt, levelLine)
			l:SetText(text)
			l:SetTextColor(1, 1, 1)
		end
	end

	removeLines(tt, remove)

	-- Añadidos
	if U.reaction and not isPlayer then
		local reaction = NS(UnitReaction(unit, "player"))
		local label = reaction and _G["FACTION_STANDING_LABEL" .. reaction]
		if label then
			local r, g, b = reactionColor(unit)
			addLine(tt, label, r, g, b)
		end
	end

	if U.target then
		local tu = unit .. "target"
		if NS(UnitExists(tu)) then
			local text
			if NS(UnitIsUnit(tu, "player")) then
				text = "|cffff3333" .. L["<< TÚ >>"] .. "|r"
			else
				text = coloredName(tu)
			end
			if text then addLine(tt, "|cffffd100" .. L["Objetivo:"] .. "|r " .. text) end
		end
	end

	if U.targetedBy and IsInGroup() then
		local names = targetedBy(unit)
		if #names > 0 then
			addLine(tt, "|cffffd100" .. L["Seleccionado por (%d):"]:format(#names) .. "|r " .. table.concat(names, ", "), 1, 1, 1, true)
		end
	end

	if idsWanted() and not isPlayer then
		local guid = NS(UnitGUID(unit))
		if guid then
			local kind, _, _, _, _, id = strsplit("-", guid)
			if id and (kind == "Creature" or kind == "Vehicle" or kind == "Pet") then
				addLine(tt, L["ID de PNJ: %s"]:format(id), 0.6, 0.6, 0.6)
			end
		end
	end

	-- Borde
	if isPlayer and S.classBorder then
		local r, g, b = classColor(unit)
		if r then tt.rzBorder = { r, g, b } end
	elseif not isPlayer and S.reactionBorder then
		local r, g, b = reactionColor(unit)
		if r then tt.rzBorder = { r, g, b } end
	end

	barsForUnit(tt, unit)
	paint(tt)
end

----------------------------------------------------------------------
-- Objetos
----------------------------------------------------------------------

local getItemInfo = (C_Item and C_Item.GetItemInfo) or GetItemInfo
local getItemCount = (C_Item and C_Item.GetItemCount) or GetItemCount
local getItemLevel = (C_Item and C_Item.GetDetailedItemLevelInfo) or GetDetailedItemLevelInfo
local getQualityColor = (C_Item and C_Item.GetItemQualityColor) or GetItemQualityColor

local ITEM_LEVEL_PREFIX = ITEM_LEVEL and ITEM_LEVEL:match("^(.-)%%")

local function hasSellPrice(tt, data)
	if tt.shownMoneyFrames and tt.shownMoneyFrames > 0 then return true end
	local sell = Enum and Enum.TooltipDataLineType and Enum.TooltipDataLineType.SellPrice
	if sell and data and data.lines then
		for _, line in ipairs(data.lines) do
			if NS(line.type) == sell then return true end
		end
	end
	return false
end

-- Unidades del montón sobre el que está el ratón (en las bolsas)
local function ownerStack(tt)
	local owner = tt:GetOwner()
	if owner and owner.GetBagID and C_Container and C_Container.GetContainerItemInfo then
		local ok, info = pcall(C_Container.GetContainerItemInfo, owner:GetBagID(), owner:GetID())
		if ok and info and info.stackCount then return info.stackCount end
	end
	return 1
end

-- Enlace del objeto del tooltip. En el motor nuevo los tooltips ya no siempre
-- tienen :GetItem(); primero se mira lo que trae el propio tooltip (data)
local function itemLink(tt, data)
	local link = data and NS(data.hyperlink)
	if link then return link end
	if TooltipUtil and TooltipUtil.GetDisplayedItem then
		local ok, _, l = pcall(TooltipUtil.GetDisplayedItem, tt)
		if ok then return NS(l) end
	elseif tt.GetItem then
		local ok, _, l = pcall(tt.GetItem, tt)
		if ok then return NS(l) end
	end
end

local function onItem(tt, data)
	if not tracked[tt] then return end
	local link = itemLink(tt, data)
	local id = data and NS(data.id)
	if not id and link then id = tonumber(link:match("item:(%d+)")) end
	local item = link or id
	if not item then return end

	local _, _, quality, _, _, _, _, stackMax, equipLoc, icon, sellPrice = getItemInfo(item)

	if S.qualityBorder and quality and getQualityColor then
		local r, g, b = getQualityColor(quality)
		if r then tt.rzBorder = { r, g, b } end
	end

	if I.icon then
		setIcon(tt, icon or (id and C_Item and C_Item.GetItemIconByID and C_Item.GetItemIconByID(id)))
	end

	if I.itemLevel and equipLoc and equipLoc ~= "" and equipLoc ~= "INVTYPE_BAG" and getItemLevel
		and ITEM_LEVEL and not (ITEM_LEVEL_PREFIX and findLine(tt, ITEM_LEVEL_PREFIX)) then
		local level = NS(getItemLevel(item))
		if level and level > 1 then tt:AddLine(ITEM_LEVEL:format(level), 1, 0.82, 0) end
	end

	if I.stack and stackMax and stackMax > 1 then
		tt:AddLine(L["Montón de %d"]:format(stackMax), 0.7, 0.7, 0.7)
	end

	if I.itemCount and id and getItemCount then
		local bags = getItemCount(id) or 0
		local total = getItemCount(id, true) or bags
		if total > 0 then
			local text = L["Tienes: %d"]:format(bags)
			if total > bags then text = text .. "  " .. L["(%d en el banco)"]:format(total - bags) end
			tt:AddLine(text, 0.5, 0.8, 1)
		end
	end

	if I.sellPrice and sellPrice and sellPrice > 0 and not hasSellPrice(tt, data) then
		-- Texto con iconos de monedas, no el marco de dinero de Blizzard: usarlo
		-- desde un addon lo contamina y, en tooltips con valores secretos (como
		-- las recompensas de misión del mapa), el propio marco da error
		local amount = sellPrice * ownerStack(tt)
		tt:AddDoubleLine(L["Precio de venta:"], R.Money(amount), 1, 1, 1, 1, 1, 1)
	end

	if idsWanted() and id then
		tt:AddLine(L["ID de objeto: %d"]:format(id), 0.6, 0.6, 0.6)
	end

	paint(tt)
end

----------------------------------------------------------------------
-- Hechizos y auras
----------------------------------------------------------------------

local function spellIcon(id)
	if C_Spell and C_Spell.GetSpellTexture then return C_Spell.GetSpellTexture(id) end
	if GetSpellTexture then return GetSpellTexture(id) end
end

local function onSpell(tt, data)
	if not tracked[tt] then return end
	local id = data and NS(data.id)
	if not id and tt.GetSpell then
		local _, sid = tt:GetSpell()
		id = NS(sid)
	end
	if not id then return end
	if I.icon then setIcon(tt, spellIcon(id)) end
	if idsWanted() then
		tt:AddLine(L["ID de hechizo: %d"]:format(id), 0.6, 0.6, 0.6)
	end
	paint(tt)
end

local function auraByIndex(unit, index, filter)
	if C_UnitAuras and C_UnitAuras.GetAuraDataByIndex then
		return C_UnitAuras.GetAuraDataByIndex(unit, index, filter)
	end
	if UnitAura then
		local _, _, _, _, _, _, source, _, _, spellId = UnitAura(unit, index, filter)
		return { sourceUnit = source, spellId = spellId }
	end
end

local function auraByInstance(unit, id)
	if C_UnitAuras and C_UnitAuras.GetAuraDataByAuraInstanceID then
		return C_UnitAuras.GetAuraDataByAuraInstanceID(unit, id)
	end
end

local function onAura(tt, aura)
	if not aura then return end
	local added = false
	if I.auraCaster then
		local source = NS(aura.sourceUnit)
		local name = source and coloredName(source)
		if name then
			tt:AddLine("|cffffd100" .. L["Lanzado por:"] .. "|r " .. name, 1, 1, 1)
			added = true
		end
	end
	local id = NS(aura.spellId)
	if id and idsWanted() then
		tt:AddLine(L["ID de aura: %d"]:format(id), 0.6, 0.6, 0.6)
		added = true
	end
	if added then relayout(tt) end
end

local function hookAuras(tt)
	local function by(filter)
		return function(self, unit, index, f)
			safe(onAura, self, auraByIndex(unit, index, f or filter))
		end
	end
	if tt.SetUnitAura then hooksecurefunc(tt, "SetUnitAura", by("HELPFUL")) end
	if tt.SetUnitBuff then hooksecurefunc(tt, "SetUnitBuff", by("HELPFUL")) end
	if tt.SetUnitDebuff then hooksecurefunc(tt, "SetUnitDebuff", by("HARMFUL")) end
	local function byInstance(self, unit, id)
		safe(onAura, self, auraByInstance(unit, id))
	end
	if tt.SetUnitBuffByAuraInstanceID then hooksecurefunc(tt, "SetUnitBuffByAuraInstanceID", byInstance) end
	if tt.SetUnitDebuffByAuraInstanceID then hooksecurefunc(tt, "SetUnitDebuffByAuraInstanceID", byInstance) end
end

----------------------------------------------------------------------
-- Posición y ocultar
----------------------------------------------------------------------

local anchorFrame, mover

local function unitOf(frame)
	return frame.unit or (frame.GetAttribute and frame:GetAttribute("unit"))
end

-- Qué tipo de tooltip es según quién lo pide
local function kindOf(parent)
	if not parent or parent == UIParent or parent == WorldFrame then
		return NS(UnitExists("mouseover")) and "WorldUnit" or "WorldTip"
	end
	local ok, unit = pcall(unitOf, parent)
	if ok and unit then return "FrameUnit" end
	return "FrameTip"
end

local function follow(tt)
	local x, y = GetCursorPosition()
	local s = tt:GetEffectiveScale()
	x, y = x / s + A.offsetX, y / s + A.offsetY
	tt:ClearAllPoints()
	local mode = tt.rzFollow
	if mode == "cursorLeft" then
		tt:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMLEFT", x - 12, y + 4)
	elseif mode == "cursorRight" then
		tt:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", x + 20, y + 4)
	else
		tt:SetPoint("BOTTOM", UIParent, "BOTTOMLEFT", x, y + 20)
	end
end

local function onDefaultAnchor(tt, parent)
	if tt ~= GameTooltip then return end
	local kind = kindOf(parent)
	tt.rzKind = kind
	local mode = A["anchor" .. kind]
	if mode == "fixed" then
		tt:ClearAllPoints()
		tt:SetPoint(A.fixedGrow, anchorFrame, A.fixedGrow, 0, 0)
	elseif mode == "cursor" or mode == "cursorLeft" or mode == "cursorRight" then
		tt.rzFollow = mode
		follow(tt)
	end
end

local COMBAT_KEY = {
	WorldUnit = "combatWorldUnit",
	FrameUnit = "combatFrameUnit",
	WorldTip = "combatOther",
	FrameTip = "combatOther",
}

local function shouldHide(tt)
	local kind = tt.rzKind
	if kind and A["anchor" .. kind] == "hide" then return true end
	if InCombatLockdown() and A[COMBAT_KEY[kind or "FrameTip"]] and not modifierDown(A.combatModifier) then
		return true
	end
	return false
end

local function createAnchor()
	anchorFrame = CreateFrame("Frame", "RheizorTooltipAnchor", UIParent)
	anchorFrame:SetSize(200, 90)
	anchorFrame:SetFrameStrata("TOOLTIP")
	mover = R:CreateMover(anchorFrame, L["Tooltips"], A, "point", { "BOTTOMRIGHT", "BOTTOMRIGHT", -90, 130 })
end

function M:ResetPosition()
	A.point = nil
	if mover then mover:Place() end
end

----------------------------------------------------------------------
-- Tooltips a los que se aplica todo
----------------------------------------------------------------------

local TIP_NAMES = {
	"GameTooltip", "ItemRefTooltip", "ShoppingTooltip1", "ShoppingTooltip2",
	"ItemRefShoppingTooltip1", "ItemRefShoppingTooltip2",
	"WorldMapTooltip", "FriendsTooltip",
}

local function onCleared(tt)
	tt.rzBorder = nil
	tt.rzFree, tt.rzLast = nil, nil
	if tt.rzIcon then tt.rzIcon:Hide() end
	if tt == GameTooltip then
		if pb then pb:Hide() pb.unit = nil end
		if hb then hb.rzColor, hb.rzUnit = nil, nil end
		if tt.rzPadded then
			tt:SetPadding(0, 0)
			tt.rzPadded = nil
		end
	end
	paint(tt)
end

local function track(tt)
	if type(tt) ~= "table" or not tt.HookScript or tracked[tt] then return end
	tracked[tt] = true
	tips[#tips + 1] = tt
	if tt:HasScript("OnTooltipCleared") then tt:HookScript("OnTooltipCleared", onCleared) end
	tt:HookScript("OnHide", onCleared)
	if tt ~= GameTooltip then tt:HookScript("OnShow", paint) end
end

local function hookGameTooltip()
	local tt = GameTooltip
	tt:HookScript("OnShow", function(self)
		if running() and shouldHide(self) then
			self:Hide()
			return
		end
		paint(self)
	end)
	tt:HookScript("OnUpdate", function(self)
		if not running() then return end
		if self.rzFollow then follow(self) end
		if self.rzKind == "WorldUnit" and A.hideInstant and not NS(UnitExists("mouseover")) then
			self:Hide()
		end
	end)
	hooksecurefunc(tt, "SetOwner", function(self)
		self.rzKind, self.rzFollow = nil, nil
	end)
	if tt.FadeOut then
		hooksecurefunc(tt, "FadeOut", function(self)
			if self.rzKind == "WorldUnit" and A.hideInstant and running() then self:Hide() end
		end)
	end
	hooksecurefunc("GameTooltip_SetDefaultAnchor", function(t, parent) safe(onDefaultAnchor, t, parent) end)
	if SharedTooltip_SetBackdropStyle then
		hooksecurefunc("SharedTooltip_SetBackdropStyle", function(t) paint(t) end)
	end

	if hb then
		hb:HookScript("OnShow", function(self)
			if B.health == "hide" and running() then self:Hide() end
		end)
		-- El valor que llega es secreto: no se usa, el texto se lee de la unidad
		hb:HookScript("OnValueChanged", function(self)
			if B.health ~= "style" or not running() then return end
			if self.rzColor then self:SetStatusBarColor(self.rzColor[1], self.rzColor[2], self.rzColor[3]) end
			updateHealthText()
		end)
	end
	hookAuras(tt)
end

local function hookData()
	local P = TooltipDataProcessor
	local T = Enum and Enum.TooltipDataType
	if P and P.AddTooltipPostCall and T then
		if T.Unit then P.AddTooltipPostCall(T.Unit, function(tt, data) safe(onUnit, tt, data) end) end
		if T.Item then P.AddTooltipPostCall(T.Item, function(tt, data) safe(onItem, tt, data) end) end
		if T.Spell then P.AddTooltipPostCall(T.Spell, function(tt, data) safe(onSpell, tt, data) end) end
		return
	end
	-- Clientes antiguos (aquí el tooltip puede estar ya a la vista)
	for _, tt in ipairs(tips) do
		if tt:HasScript("OnTooltipSetUnit") then tt:HookScript("OnTooltipSetUnit", function(t) safe(onUnit, t) safe(relayout, t) end) end
		if tt:HasScript("OnTooltipSetItem") then tt:HookScript("OnTooltipSetItem", function(t) safe(onItem, t) safe(relayout, t) end) end
		if tt:HasScript("OnTooltipSetSpell") then tt:HookScript("OnTooltipSetSpell", function(t) safe(onSpell, t) safe(relayout, t) end) end
	end
end

----------------------------------------------------------------------

function M:ApplyAll()
	for _, tt in ipairs(tips) do
		if S.enabled then paint(tt) else unpaint(tt) end
	end
	applyFonts()
	applyScale()
	styleBars()
	if mover then mover:SetShown(not A.locked) end
end

function M:OnEnable()
	A, S, U, B, I = M.db, Style.db, Units.db, Bars.db, Items.db
	for _, name in ipairs(TIP_NAMES) do track(R:Resolve(name)) end
	createPowerBar()
	createAnchor()
	hookGameTooltip()
	hookData()
	self.ready = true
	self:ApplyAll()
end

local function changed()
	if M.ready then M:ApplyAll() end
end
M.OnOptionChanged = changed
Style.OnOptionChanged = changed
Units.OnOptionChanged = changed
Bars.OnOptionChanged = changed
Items.OnOptionChanged = changed
