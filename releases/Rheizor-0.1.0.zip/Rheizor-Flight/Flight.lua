-- Rheizor-Flight: temporizador de vuelos (como InFlight).
--
-- Al coger un vuelo (TakeTaxiNode) se apunta la ruta, origen > destino.
-- Mientras vuelas, una barra muestra lo que falta. Al aterrizar se guarda
-- cuánto ha tardado: la próxima vez el tiempo es exacto. Hasta entonces se
-- estima con la distancia de cada tramo del vuelo (y los tramos que ya
-- conoces), a una velocidad que se ajusta con cada vuelo terminado.
--
-- Los tiempos van en RheizorFlightDB, compartido por toda la cuenta (las
-- rutas son las mismas para todos tus personajes). Las opciones de aspecto
-- van en el perfil. El vuelo en curso también se guarda, por si recargas
-- la interfaz a mitad de camino.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("flight", {
	title = "Vuelos",
	defaults = {
		locked = true,
		width = 240,
		height = 18,
		texture = R.TEXTURES[2][1],
		barColor = "33ccff",
		estColor = "d9a633",
		bgAlpha = 0.6,
		border = true,
		spark = true,
		textSize = 11,
		showDest = true,
		showArrival = false,
		mapTooltip = true,
		arrivalSound = false,
	},
	options = {
		{ type = "header", text = "Vuelos" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueada, la barra se ve de ejemplo y se puede arrastrar. También con /rz mover." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "toggle", key = "mapTooltip", name = "Tiempo de vuelo en el mapa de vuelo",
		  desc = "Al pasar el ratón por un destino, cuánto se tarda desde donde estás." },
		{ type = "toggle", key = "arrivalSound", name = "Sonido al aterrizar" },

		{ type = "header", text = "Barra" },
		{ type = "slider", key = "width", name = "Ancho", min = 100, max = 500, step = 5, format = R.fmt.int },
		{ type = "slider", key = "height", name = "Alto", min = 8, max = 40, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "texture", name = "Textura", values = R.TEXTURES },
		{ type = "color", key = "barColor", name = "Color con tiempo conocido" },
		{ type = "color", key = "estColor", name = "Color con tiempo estimado",
		  desc = "La primera vez que vuelas una ruta el tiempo se calcula por la distancia; al aterrizar se aprende el exacto." },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
		{ type = "toggle", key = "border", name = "Borde" },
		{ type = "toggle", key = "spark", name = "Chispa en el borde de avance" },
		{ type = "slider", key = "textSize", name = "Tamaño del texto", min = 7, max = 20, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "showDest", name = "Mostrar el destino" },
		{ type = "toggle", key = "showArrival", name = "Mostrar la hora de llegada",
		  desc = "La hora de tu ordenador a la que aterrizas, además del tiempo que falta." },

		{ type = "header", text = "Tiempos aprendidos" },
		{ type = "button", name = "Olvidar todos los tiempos", text = "Olvidar",
		  desc = "Borra los tiempos de todas las rutas: se vuelven a estimar hasta que las vueles otra vez.",
		  func = function(mod) mod:ForgetTimes() end },
	},
})

local WHITE = "Interface\\Buttons\\WHITE8X8"
local DEFAULT_SPEED = 1 / 30   -- segundos por metro hasta tener vuelos propios

local db        -- opciones (perfil)
local store     -- RheizorFlightDB
local frame     -- la barra
local flight    -- vuelo en curso: { from, to, key, total, known, start, epoch, dist, aborted }
local pending   -- vuelo pedido, esperando a despegar

local function call(fn, ...)
	if not fn then return end
	local ok, a, b, c, d = pcall(fn, ...)
	if ok then return a, b, c, d end
end

local function fmtTime(s)
	s = math.max(0, math.floor(s + 0.5))
	local floor = math.floor
	if s >= 3600 then
		return string.format("%d:%02d:%02d", floor(s / 3600), floor((s % 3600) / 60), s % 60)
	end
	return string.format("%d:%02d", floor(s / 60), s % 60)
end

----------------------------------------------------------------------
-- Nodos del mapa de vuelo (solo con el mapa abierto)
----------------------------------------------------------------------

local function nodeName(i)
	return NS(call(TaxiNodeName, i))
end

local function currentNode()
	local n = NS(call(NumTaxiNodes)) or 0
	for i = 1, n do
		if NS(call(TaxiNodeGetType, i)) == "CURRENT" then return i end
	end
end

-- Posición en metros (del mundo) de un nodo, o nil
local function nodeWorldPos(i)
	local x, y = call(TaxiNodePosition, i)
	x, y = NS(x), NS(y)
	if not (x and y) then return end
	local mapID = NS(call(GetTaxiMapID))
	if not mapID and C_Map and C_Map.GetBestMapForUnit then
		-- Sin GetTaxiMapID: el continente en el que estás
		local m = NS(call(C_Map.GetBestMapForUnit, "player"))
		for _ = 1, 6 do
			local info = m and call(C_Map.GetMapInfo, m)
			if not info then break end
			if info.mapType == (Enum.UIMapType and Enum.UIMapType.Continent or 2) then mapID = m break end
			m = info.parentMapID
		end
	end
	if not (mapID and C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
	local _, pos = call(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(x, y))
	if not pos then return end
	local wx, wy = pos:GetXY()
	return NS(wx), NS(wy)
end

local function nodeDist(a, b)
	local ax, ay = nodeWorldPos(a)
	local bx, by = nodeWorldPos(b)
	if not (ax and ay and bx and by) then return end
	return math.sqrt((ax - bx) ^ 2 + (ay - by) ^ 2)
end

local function routeKey(from, to)
	return from .. " > " .. to
end

-- Los tramos del vuelo hasta el nodo dest: { {a, b}, … } (índices de nodo)
local function hops(dest)
	local n = NS(call(GetNumRoutes, dest))
	local list = {}
	if n and n > 0 and TaxiGetNodeSlot then
		for r = 1, n do
			local a = NS(call(TaxiGetNodeSlot, dest, r, true))
			local b = NS(call(TaxiGetNodeSlot, dest, r, false))
			if not (a and b) then list = {} break end
			list[#list + 1] = { a, b }
		end
	end
	if #list == 0 then
		local cur = currentNode()
		if cur then list[1] = { cur, dest } end
	end
	return list
end

local function secondsPerYard()
	local c = store.calib
	if c and c.d and c.d > 500 and c.t and c.t > 0 then return c.t / c.d end
	return DEFAULT_SPEED
end

-- Tiempo hasta el nodo dest: segundos, ¿exacto?, distancia (para aprender)
local function routeTime(dest)
	local cur = currentNode()
	local from, to = cur and nodeName(cur), nodeName(dest)
	if not (from and to) then return end
	local list = hops(dest)
	local dist, estimate, exact = 0, 0, true
	for _, h in ipairs(list) do
		local d = nodeDist(h[1], h[2])
		if d then dist = dist + d end
		local a, b = nodeName(h[1]), nodeName(h[2])
		local leg = a and b and store.routes[routeKey(a, b)]
		if leg and leg.t then
			estimate = estimate + leg.t
		elseif d then
			estimate = estimate + d * secondsPerYard()
			exact = false
		else
			estimate, exact = nil, false
			break
		end
	end
	if #list == 0 then estimate, exact = nil, false end
	local known = store.routes[routeKey(from, to)]
	if known and known.t then return known.t, true, dist > 0 and dist or nil, from, to end
	-- Con un solo tramo conocido, el propio tramo es la ruta (ya devuelta)
	return estimate, exact and estimate ~= nil, dist > 0 and dist or nil, from, to
end

----------------------------------------------------------------------
-- Barra
----------------------------------------------------------------------

local function createFrame()
	frame = CreateFrame("StatusBar", "RheizorFlightBar", UIParent)
	frame:SetMinMaxValues(0, 1)
	frame:SetFrameStrata("MEDIUM")
	frame.bg = frame:CreateTexture(nil, "BACKGROUND")
	frame.bg:SetAllPoints()
	frame.border = CreateFrame("Frame", nil, frame, "BackdropTemplate")
	frame.border:SetPoint("TOPLEFT", -1, 1)
	frame.border:SetPoint("BOTTOMRIGHT", 1, -1)
	frame.border:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	frame.border:SetBackdropBorderColor(0, 0, 0, 1)
	frame.spark = frame:CreateTexture(nil, "OVERLAY")
	frame.spark:SetTexture("Interface\\CastingBar\\UI-CastingBar-Spark")
	frame.spark:SetBlendMode("ADD")
	frame.dest = frame:CreateFontString(nil, "OVERLAY")
	frame.dest:SetPoint("LEFT", 4, 0)
	frame.dest:SetJustifyH("LEFT")
	frame.dest:SetWordWrap(false)
	frame.time = frame:CreateFontString(nil, "OVERLAY")
	frame.time:SetPoint("RIGHT", -4, 0)
	frame.dest:SetPoint("RIGHT", frame.time, "LEFT", -6, 0)
	frame:Hide()

	frame.mover = R:CreateMover(frame, "Vuelos", db, "point", { "TOP", "TOP", 0, -120 })
end

function M:ApplyStyle()
	if not frame then return end
	frame:SetSize(db.width, db.height)
	pcall(frame.SetStatusBarTexture, frame, db.texture)
	frame.bg:SetColorTexture(0, 0, 0, db.bgAlpha)
	frame.border:SetShown(db.border)
	frame.spark:SetSize(16, db.height * 2.2)
	for _, fs in ipairs({ frame.dest, frame.time }) do
		fs:SetFont(STANDARD_TEXT_FONT, db.textSize, "OUTLINE")
	end
	frame.mover:Place()
	frame.mover:SetShown(not db.locked)
	self:Draw()
end

-- Dibuja la barra: vuelo real, o de ejemplo si está desbloqueada
function M:Draw()
	if not frame then return end
	local f = flight
	local demo = not f and not db.locked
	if not f and not demo then
		frame:Hide()
		return
	end
	local dest, total, known, elapsed
	if demo then
		dest, total, known, elapsed = L["Destino de ejemplo"], 150, true, 60
	else
		dest, total, known = f.to, f.total, f.known
		elapsed = GetTime() - f.start
	end
	local color = known and db.barColor or db.estColor
	frame:SetStatusBarColor(R.HexToRGB(color))
	frame.dest:SetText(db.showDest and (dest or "") or "")

	local text
	if total and total > 0 then
		local left = total - elapsed
		local p = math.min(math.max(left / total, 0), 1)
		frame:SetValue(p)
		if db.spark and p > 0 and p < 1 then
			frame.spark:ClearAllPoints()
			frame.spark:SetPoint("CENTER", frame, "LEFT", p * db.width, 0)
			frame.spark:Show()
		else
			frame.spark:Hide()
		end
		if left >= 0 then
			text = (known and "" or "~") .. fmtTime(left)
		else
			-- Más de lo previsto (estimación corta): cuánto se lleva de más
			text = "+" .. fmtTime(-left)
		end
		if db.showArrival and left > 0 then
			text = text .. "  |cffbbbbbb" .. date("%H:%M", time() + math.floor(left + 0.5)) .. "|r"
		end
	else
		-- Sin forma de estimar: tiempo que llevas volando
		frame:SetValue(1)
		frame.spark:Hide()
		text = fmtTime(elapsed)
	end
	frame.time:SetText(text)
	frame:Show()
end

----------------------------------------------------------------------
-- Vuelo: despegar, aterrizar, aprender
----------------------------------------------------------------------

local ticker

local function onTaxi()
	return NS(UnitOnTaxi("player")) and true or false
end

local function stopTicker()
	if ticker then ticker:Cancel() ticker = nil end
end

local function land()
	local f = flight
	flight = nil
	store.current = nil
	stopTicker()
	if f and not f.aborted and f.key then
		-- Recargar a mitad de vuelo pierde la precisión de GetTime: se usa la hora
		local took = f.resumed and (time() - f.epoch) or (GetTime() - f.start)
		if took > 5 and took < 3 * 3600 then
			local r = store.routes[f.key] or {}
			local first = r.t == nil
			r.t = math.floor(took * 10 + 0.5) / 10
			if f.dist then
				r.d = math.floor(f.dist + 0.5)
				-- Solo los vuelos directos (un tramo) afinan la velocidad
				if f.direct then
					local c = store.calib
					c.t, c.d = (c.t or 0) + took, (c.d or 0) + f.dist
				end
			end
			store.routes[f.key] = r
			if first then
				R:Print(L["Vuelos: aprendido %s (%s)."]:format(f.key, fmtTime(took)))
			end
		end
	end
	if f and db.arrivalSound then PlaySound(SOUNDKIT.READY_CHECK or 8960, "Master") end
	M:Draw()
end

local function tick()
	if flight then
		if not onTaxi() then
			land()
			return
		end
		M:Draw()
	elseif pending then
		if onTaxi() then
			flight = pending
			pending = nil
			flight.start, flight.epoch = GetTime(), time()
			store.current = {
				from = flight.from, to = flight.to, key = flight.key, total = flight.total,
				known = flight.known, epoch = flight.epoch, dist = flight.dist, direct = flight.direct,
			}
			M:Draw()
		elseif GetTime() - pending.at > 10 then
			-- No llegó a despegar
			pending = nil
			stopTicker()
		end
	else
		stopTicker()
	end
end

local function startTicker()
	if not ticker then ticker = C_Timer.NewTicker(0.1, tick) end
end

-- TakeTaxiNode(i): lo llama el mapa de vuelo al elegir destino
local function onTakeTaxi(i)
	i = NS(i)
	if not i then return end
	local total, exact, dist, from, to = routeTime(i)
	if not (from and to) then return end
	pending = {
		from = from, to = to, key = routeKey(from, to), total = total, known = exact,
		dist = dist, direct = #hops(i) == 1, at = GetTime(),
	}
	startTicker()
end

-- Tras recargar la interfaz a mitad de vuelo
local function resume()
	local c = store.current
	if not c then return end
	if not onTaxi() or type(c.epoch) ~= "number" or time() - c.epoch > 3 * 3600 then
		store.current = nil
		return
	end
	flight = {
		from = c.from, to = c.to, key = c.key, total = c.total, known = c.known,
		dist = c.dist, direct = c.direct, epoch = c.epoch, resumed = true,
		start = GetTime() - (time() - c.epoch),
	}
	startTicker()
	M:Draw()
end

----------------------------------------------------------------------
-- Tooltip del mapa de vuelo
----------------------------------------------------------------------

local function addTooltip(i)
	if not (db and db.mapTooltip and i) then return end
	if NS(call(TaxiNodeGetType, i)) ~= "REACHABLE" then return end
	local total, exact = routeTime(i)
	if not total then return end
	local text = exact and fmtTime(total) or ("~" .. fmtTime(total) .. " " .. L["(estimado)"])
	GameTooltip:AddLine(L["Tiempo de vuelo: %s"]:format(text), 0.2, 0.8, 1)
	GameTooltip:Show()
end

local hookedMap = false
local function hookMaps()
	-- Mapa clásico (TaxiFrame): botones TaxiButtonN
	if not hookedMap and type(TaxiNodeOnButtonEnter) == "function" then
		hookedMap = true
		hooksecurefunc("TaxiNodeOnButtonEnter", function(button)
			addTooltip(button and button:GetID())
		end)
	end
	-- Mapa moderno (FlightMapFrame): chinchetas de cada punto de vuelo
	if FlightMap_FlightPointPinMixin and not FlightMap_FlightPointPinMixin.rzHooked then
		FlightMap_FlightPointPinMixin.rzHooked = true
		hooksecurefunc(FlightMap_FlightPointPinMixin, "OnMouseEnter", function(pin)
			local data = pin.taxiNodeData
			addTooltip(data and NS(data.slotIndex))
		end)
	end
end

----------------------------------------------------------------------

function M:ResetPosition()
	db.point = nil
	self:ApplyStyle()
end

function M:ForgetTimes()
	wipe(store.routes)
	store.calib = {}
	R:Print(L["Vuelos: tiempos olvidados."])
end

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, arg1)
	if event == "ADDON_LOADED" then
		if arg1 == "Blizzard_FlightMap" or arg1 == "Blizzard_TaxiUI" then hookMaps() end
	elseif event == "TAXIMAP_OPENED" then
		hookMaps()
	elseif event == "PLAYER_ENTERING_WORLD" then
		if not flight then resume() end
	elseif event == "PLAYER_CONTROL_LOST" then
		if pending or flight then tick() end
	elseif event == "PLAYER_CONTROL_GAINED" then
		if flight then tick() end
	end
end)

function M:OnEnable()
	db = self.db
	RheizorFlightDB = type(RheizorFlightDB) == "table" and RheizorFlightDB or {}
	store = RheizorFlightDB
	if type(store.routes) ~= "table" then store.routes = {} end
	if type(store.calib) ~= "table" then store.calib = {} end

	if not frame then
		createFrame()
		hooksecurefunc("TakeTaxiNode", onTakeTaxi)
		-- Bajarse antes de tiempo: ese vuelo no vale para aprender
		if type(TaxiRequestEarlyLanding) == "function" then
			hooksecurefunc("TaxiRequestEarlyLanding", function() if flight then flight.aborted = true end end)
		end
		for _, e in ipairs({ "ADDON_LOADED", "TAXIMAP_OPENED", "PLAYER_ENTERING_WORLD",
			"PLAYER_CONTROL_LOST", "PLAYER_CONTROL_GAINED" }) do
			pcall(events.RegisterEvent, events, e)
		end
		hookMaps()
	end
	self:ApplyStyle()
	resume()
end

function M:OnOptionChanged()
	self:ApplyStyle()
end
