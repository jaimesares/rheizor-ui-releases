-- Chat (estilo Prat): nombres con color de clase, nivel e icono, canales
-- abreviados, resaltado de tu nombre y ajustes de las ventanas.
--
-- Cada línea se reescribe justo antes de pintarse (AddMessage). El nivel y la
-- clase de cada jugador salen de una caché que se llena con: grupo/banda,
-- hermandad, amigos, /quién, objetivo, ratón, placas y el GUID de los mensajes.
-- El juego no dice el nivel de un desconocido que solo habla por un canal,
-- así que a esos se les muestra solo la clase hasta que se sepa su nivel.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("chatmod", {
	title = "Chat",
	defaults = {
		enabled = true,
		classColor = true,
		showLevel = true,
		levelColor = true,
		classIcon = false,
		raceIcon = false,
		hideRealm = true,
		brackets = "square",
		channels = "short",
		highlight = true,
		mentionSound = false,
		noFade = false,
		editBoxPos = "bottom",
		editBoxY = 0,
		arrowMod = "alt",
		keepHistory = true,
		historySize = 50,
		chatFade = "never",
		chatFadeDelay = 15,
		chatFadeAlpha = 0,
		chatShowOn = "important",
		chatShowHover = true,
		chatShowTyping = true,
	},
	options = {
		{ type = "header", text = "General" },
		{ type = "toggle", key = "enabled", name = "Mejorar el chat",
		  desc = "Interruptor de las mejoras de nombres, canales y menciones de esta página. Las opciones de \"Ventanas de chat\" funcionan aparte.\nLa marca de hora, los bocadillos y la rueda del ratón son opciones del juego: están en Configuraciones > Chat." },

		{ type = "header", text = "Nombres de jugador" },
		{ type = "toggle", key = "classColor", name = "Color de clase" },
		{ type = "toggle", key = "showLevel", name = "Mostrar nivel", desc = "[60:Nombre]" },
		{ type = "toggle", key = "levelColor", name = "Colorear el nivel por dificultad",
		  desc = "Gris, verde, amarillo, naranja o rojo según la diferencia con tu nivel." },
		{ type = "toggle", key = "classIcon", name = "Icono de clase" },
		{ type = "toggle", key = "raceIcon", name = "Icono de raza",
		  desc = "La raza se sabe de los jugadores de tu grupo, los que ves (objetivo, ratón, placas) y los que escriben en el chat." },
		{ type = "toggle", key = "hideRealm", name = "Ocultar el reino" },
		{ type = "dropdown", key = "brackets", name = "Corchetes",
		  values = { { "square", "[Nombre]" }, { "angle", "<Nombre>" }, { "none", "Nombre" } } },

		{ type = "header", text = "Canales" },
		{ type = "dropdown", key = "channels", name = "Nombre de los canales",
		  values = {
			{ "full", "Completo — [2. Comercio - Ciudad]" },
			{ "short", "Abreviado — [2.CC]" },
			{ "number", "Solo número — [2]" },
		  } },

		{ type = "header", text = "Menciones" },
		{ type = "toggle", key = "highlight", name = "Resaltar mi nombre",
		  desc = "Pinta tu nombre en naranja cuando alguien lo escribe." },
		{ type = "toggle", key = "mentionSound", name = "Sonido al mencionarme" },

		{ type = "header", text = "Ventanas de chat" },
		{ type = "toggle", key = "noFade", name = "No desvanecer el texto",
		  desc = "Los mensajes no desaparecen con el tiempo." },
		{ type = "dropdown", cvar = "chatStyle", name = "Mostrar la caja de texto",
		  values = {
			{ "im", "Siempre" },
			{ "classic", "Solo al escribir (Enter)" },
		  },
		  desc = "Solo al escribir: la caja aparece al pulsar Enter o / y se oculta al enviar o pulsar Esc.\nEs la opción del juego \"Estilo del chat\" (moderno o clásico). Si ahora está abierta, el cambio se nota al enviar el siguiente mensaje." },
		{ type = "dropdown", key = "editBoxPos", name = "Caja de texto",
		  values = {
			{ "bottom", "Debajo del chat" },
			{ "top", "Encima del chat, sobre las pestañas" },
		  } },
		{ type = "slider", key = "editBoxY", name = "Altura de la caja de texto", min = -100, max = 300, step = 1, format = R.fmt.int,
		  desc = "Cuánto sube (positivo) o baja (negativo) desde su sitio, debajo o encima del chat." },
		{ type = "dropdown", key = "arrowMod", name = "Recorrer mis mensajes enviados con",
		  values = {
			{ "alt", "Alt + flecha arriba/abajo (como el juego)" },
			{ "none", "Solo flecha arriba/abajo" },
			{ "shift", "Mayús + flecha arriba/abajo" },
			{ "ctrl", "Ctrl + flecha arriba/abajo" },
		  },
		  desc = "En la caja de texto. Con Alt, las flechas solas mueven al personaje y el cursor se mueve con Alt + izquierda/derecha.\nCon las demás, izquierda y derecha mueven el cursor sin pulsar nada (como en Prat)." },
		{ type = "toggle", key = "keepHistory", name = "Recordar mis mensajes al salir",
		  desc = "Tus últimos mensajes y comandos siguen en el historial de flechas después de /reload o de volver a entrar. Se guardan por personaje y no se incluyen al exportar ni en las copias de seguridad." },
		{ type = "slider", key = "historySize", name = "Mensajes que se recuerdan", min = 10, max = 100, step = 5, format = R.fmt.int },

		{ type = "header", text = "Ocultar el chat entero" },
		{ type = "dropdown", key = "chatFade", name = "Ocultar el chat",
		  values = {
			{ "never", "Nunca (como el juego)" },
			{ "idle", "Cuando no lo uso" },
		  },
		  desc = "Ventanas, fondo, pestañas y botones del chat se desvanecen tras unos segundos sin actividad, y vuelven a verse con lo que marques abajo." },
		{ type = "slider", key = "chatFadeDelay", name = "Segundos hasta ocultarse", min = 2, max = 120, step = 1, format = R.fmt.int },
		{ type = "slider", key = "chatFadeAlpha", name = "Opacidad del chat oculto", min = 0, max = 0.8, step = 0.05,
		  desc = "0% = invisible del todo." },
		{ type = "dropdown", key = "chatShowOn", name = "Mostrarlo al llegar un mensaje",
		  values = {
			{ "all", "Cualquier mensaje" },
			{ "important", "Susurros, grupo, banda, hermandad y menciones" },
			{ "whisper", "Solo susurros" },
			{ "none", "Ninguno" },
		  } },
		{ type = "toggle", key = "chatShowHover", name = "Mostrarlo al pasar el ratón" },
		{ type = "toggle", key = "chatShowTyping", name = "Mostrarlo al escribir (Enter)",
		  desc = "Mientras la caja de texto está abierta." },
	},
	unsupported = {
		"Algunos mensajes llegan protegidos por el juego y se muestran tal cual, sin color de clase, nivel ni resaltado de tu nombre.",
	},
})

local db
local lastActivity = 0   -- (ocultar el chat entero) último mensaje, ratón o escritura

----------------------------------------------------------------------
-- Caché de jugadores: nombre -> { class = "WARRIOR", level = 60 }
----------------------------------------------------------------------

local cache = {}
local myRealm = GetNormalizedRealmName and GetNormalizedRealmName() or ""

local classByLocalized = {}
for token, name in pairs(LOCALIZED_CLASS_NAMES_MALE or {}) do classByLocalized[name] = token end
for token, name in pairs(LOCALIZED_CLASS_NAMES_FEMALE or {}) do classByLocalized[name] = token end

-- race = nombre interno ("NightElf", "Scourge"), sex = 2 hombre / 3 mujer
local function store(name, class, level, race, sex)
	name, class, level, race, sex = NS(name), NS(class), NS(level), NS(race), NS(sex)
	if not name or name == "" then return end
	if class and not RAID_CLASS_COLORS[class] then class = classByLocalized[class] end
	if level and level <= 0 then level = nil end
	if type(race) ~= "string" or race == "" then race = nil end

	local short, realm = name:match("^([^-]+)-?(.*)$")
	local full = (realm and realm ~= "") and name or (short .. "-" .. myRealm)
	local entry = cache[full] or {}
	entry.class = class or entry.class
	entry.level = level or entry.level
	if race then entry.race, entry.sex = race, sex end
	cache[full] = entry
	if not realm or realm == "" or realm == myRealm then cache[short] = entry end
end

local function storeUnit(unit)
	if not NS(UnitExists(unit)) or not NS(UnitIsPlayer(unit)) then return end
	local name = NS(GetUnitName(unit, true))
	if not name then return end
	store(name, select(2, UnitClass(unit)), UnitLevel(unit), select(2, UnitRace(unit)), UnitSex(unit))
end

local function scanGroup()
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do storeUnit("raid" .. i) end
	else
		for i = 1, GetNumSubgroupMembers() do storeUnit("party" .. i) end
	end
	storeUnit("player")
end

local function scanGuild()
	if not IsInGuild() then return end
	for i = 1, GetNumGuildMembers() do
		local name, _, _, level, _, _, _, _, _, _, class = GetGuildRosterInfo(i)
		store(name, class, level)
	end
end

local function scanFriends()
	if not (C_FriendList and C_FriendList.GetNumFriends) then return end
	for i = 1, C_FriendList.GetNumFriends() do
		local info = C_FriendList.GetFriendInfoByIndex(i)
		if info then store(info.name, info.className, info.level) end
	end
end

local function scanWho()
	if not (C_FriendList and C_FriendList.GetNumWhoResults) then return end
	for i = 1, C_FriendList.GetNumWhoResults() do
		local info = C_FriendList.GetWhoInfo(i)
		if info then store(info.fullName, info.filename, info.level) end
	end
end

-- Antes de pintar un mensaje: la clase y la raza del autor a partir de su GUID
local function chatFilter(_, _, _, author, ...)
	local name = NS(author)
	local entry = name and cache[name]
	if name and not (entry and entry.class and entry.race) then
		local guid = NS((select(10, ...)))
		if guid and GetPlayerInfoByGUID then
			local _, class, _, race, sex, _, _, level = GetPlayerInfoByGUID(guid)
			store(name, class, level, race, sex)
		end
	end
	return false
end

local CHAT_EVENTS = {
	"CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_WHISPER", "CHAT_MSG_WHISPER_INFORM", "CHAT_MSG_EMOTE",
	"CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER", "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
	"CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_CHANNEL", "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
}

----------------------------------------------------------------------
-- Reescritura de líneas
----------------------------------------------------------------------

local function hex(r, g, b)
	return string.format("ff%02x%02x%02x", r * 255, g * 255, b * 255)
end

local function stripColors(s)
	return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|cn[^:]*:", ""):gsub("|r", ""))
end

local BRACKETS = { square = { "[", "]" }, angle = { "<", ">" }, none = { "", "" } }

-- Atlas del icono de raza ("raceicon-nightelf-female"); false si el juego
-- no lo tiene
local function atlasExists(atlas)
	return not (C_Texture and C_Texture.GetAtlasInfo) or C_Texture.GetAtlasInfo(atlas) ~= nil
end

-- Tamaño y altura de los iconos según la letra de la ventana que pinta la
-- línea (se fija en AddMessage antes de reescribir). Los atlas quedan
-- por encima de la línea: se bajan un 28% de la altura de la letra
local iconSize, iconY = 13, -4

local function setIconLayout(frame)
	local height = 14
	if frame and frame.GetFont then
		local _, h = frame:GetFont()
		h = NS(h)
		if type(h) == "number" and h > 0 then height = h end
	end
	iconSize = math.max(8, math.floor(height * 0.9 + 0.5))
	iconY = -math.floor(height * 0.28 + 0.5)
end

local function iconMarkup(atlas)
	return ("|A:%s:%d:%d:0:%d|a"):format(atlas, iconSize, iconSize, iconY)
end

-- Icono de clase: el atlas "classicon-*"; si el juego no lo tiene, la
-- textura clásica de clases (la de la ventana de banda)
local classIcons = {}
local CLASS_COORDS = {   -- por si el juego no trae CLASS_ICON_TCOORDS
	WARRIOR = { 0, 0.25, 0, 0.25 }, MAGE = { 0.25, 0.49609375, 0, 0.25 },
	ROGUE = { 0.49609375, 0.7421875, 0, 0.25 }, DRUID = { 0.7421875, 0.98828125, 0, 0.25 },
	HUNTER = { 0, 0.25, 0.25, 0.5 }, SHAMAN = { 0.25, 0.49609375, 0.25, 0.5 },
	PRIEST = { 0.49609375, 0.7421875, 0.25, 0.5 }, WARLOCK = { 0.7421875, 0.98828125, 0.25, 0.5 },
	PALADIN = { 0, 0.25, 0.5, 0.75 },
}
local function classIcon(class)
	local icon = classIcons[class]
	if icon == nil then
		local atlas = (GetClassAtlas and GetClassAtlas(class:lower())) or ("classicon-" .. class:lower())
		local coords = (CLASS_ICON_TCOORDS and CLASS_ICON_TCOORDS[class]) or CLASS_COORDS[class]
		if atlasExists(atlas) then
			icon = { atlas = atlas }
		elseif coords then
			icon = { coords = coords }
		else
			icon = false
		end
		classIcons[class] = icon
	end
	if not icon then return "" end
	if icon.atlas then return iconMarkup(icon.atlas) end
	local c = icon.coords
	return ("|TInterface\\Glues\\CharacterCreate\\UI-CharacterCreate-Classes:%d:%d:0:%d:256:256:%d:%d:%d:%d|t")
		:format(iconSize, iconSize, iconY, c[1] * 256, c[2] * 256, c[3] * 256, c[4] * 256)
end

local RACE_ATLAS_NAME = { scourge = "undead", highmountaintauren = "highmountain",
	lightforgeddraenei = "lightforged", zandalaritroll = "zandalari" }
local raceAtlases = {}

local function raceAtlas(race, sex)
	local key = race .. (sex or 2)
	if raceAtlases[key] == nil then
		local r = race:lower()
		local atlas = ("raceicon-%s-%s"):format(RACE_ATLAS_NAME[r] or r, sex == 3 and "female" or "male")
		raceAtlases[key] = atlasExists(atlas) and atlas or false
	end
	return raceAtlases[key]
end

local function decoratePlayer(linkStart, fullName, display, linkEnd)
	local name = stripColors(display)
	if db.hideRealm then name = name:match("^[^-]+") or name end

	local info = cache[fullName] or cache[fullName:match("^[^-]+")]
	local class = info and info.class
	local level = info and info.level

	if db.classColor and class and RAID_CLASS_COLORS[class] then
		local c = RAID_CLASS_COLORS[class]
		name = "|c" .. (c.colorStr or hex(c.r, c.g, c.b)) .. name .. "|r"
	end
	if db.showLevel and level then
		local lvl = tostring(level)
		if db.levelColor and GetQuestDifficultyColor then
			local c = GetQuestDifficultyColor(level)
			lvl = "|c" .. hex(c.r, c.g, c.b) .. lvl .. "|r"
		end
		name = lvl .. ":" .. name
	end
	-- Iconos fuera del enlace y separados por espacios: dentro de un enlace
	-- el juego solo dibuja el primero (como hace Better Forever Chat)
	local icons = {}
	local atlas = db.raceIcon and info and info.race and raceAtlas(info.race, info.sex)
	if atlas then icons[#icons + 1] = iconMarkup(atlas) end
	if db.classIcon and class then
		local c = classIcon(class)
		if c ~= "" then icons[#icons + 1] = c end
	end
	local prefix = #icons > 0 and (table.concat(icons, " ") .. " ") or ""

	local b = BRACKETS[db.brackets] or BRACKETS.square
	return prefix .. linkStart .. b[1] .. name .. b[2] .. linkEnd
end

local function firstChar(word)
	return word:match("^[%z\1-\127\194-\244][\128-\191]*") or ""
end

local function decorateChannel(linkStart, display, linkEnd)
	if db.channels == "full" then return nil end
	local num, name = display:match("^(%d+)%.%s*(.+)$")
	if num and db.channels == "number" then
		return linkStart .. "[" .. num .. "]" .. linkEnd
	end
	local initials = {}
	for word in (name or display):gmatch("[^%s%-]+") do
		table.insert(initials, firstChar(word):upper())
	end
	local short = table.concat(initials)
	return linkStart .. "[" .. (num and (num .. "." .. short) or short) .. "]" .. linkEnd
end

local me = UnitName("player")
local lastMention = 0

local function highlightMentions(text)
	if not db.highlight or not me then return text end
	-- Solo el cuerpo del mensaje, después del enlace del autor
	local head, body = text:match("^(.-|Hplayer:.-|h.-|h[^:]*:%s?)(.*)$")
	if not body then return text end
	-- Mensaje propio. Se compara el autor entero: con apellidos, otro jugador
	-- (u otro personaje tuyo) puede compartir tu nombre de pila
	local author = head:match("|Hplayer:([^:|]+)")
	if author and R.IsMyName(author) then return text end

	-- Sin distinguir mayúsculas (la gente escribe «rheizor»); se deja el texto
	-- tal como lo escribieron
	local pattern = "%f[%w\128-\255]" .. me:gsub("(%W)", "%%%1"):gsub("%a", function(c)
		return "[" .. c:upper() .. c:lower() .. "]"
	end) .. "%f[^%w\128-\255]"
	local newBody, count = body:gsub(pattern, "|cffff8000%0|r")
	if count == 0 then return text end
	if db.chatShowOn == "important" then lastActivity = GetTime() end
	if db.mentionSound and GetTime() - lastMention > 2 then
		lastMention = GetTime()
		PlaySound(SOUNDKIT.TELL_MESSAGE, "Master")
	end
	return head .. newBody
end

local function rewrite(text)
	text = text:gsub("(|Hplayer:([^:|]+)[^|]*|h)%[(.-)%](|h)", decoratePlayer)
	text = text:gsub("(|Hchannel:[^|]+|h)%[(.-)%](|h)", decorateChannel)
	return highlightMentions(text)
end

----------------------------------------------------------------------
-- Ventanas de chat
----------------------------------------------------------------------

local function chatFrames()
	local list = {}
	for _, name in ipairs(CHAT_FRAMES or {}) do
		local frame = _G[name]
		if frame then table.insert(list, frame) end
	end
	if #list == 0 then
		for i = 1, NUM_CHAT_WINDOWS or 10 do
			local frame = _G["ChatFrame" .. i]
			if frame then table.insert(list, frame) end
		end
	end
	return list
end

local function hookFrame(frame)
	if frame.rzHooked or frame == ChatFrame2 then return end -- ChatFrame2 = registro de combate
	frame.rzHooked = true
	local original = frame.AddMessage
	frame.AddMessage = function(self, text, ...)
		if db.chatShowOn == "all" then lastActivity = GetTime() end
		-- Apagado en Rheizor sin recargar: el mensaje pasa tal cual
		if db.enabled and R:IsModuleRunning(M) and type(text) == "string" and not (issecretvalue and issecretvalue(text)) then
			pcall(setIconLayout, self)
			local ok, newText = pcall(rewrite, text)
			if ok and newText then text = newText end
		end
		return original(self, text, ...)
	end
end

----------------------------------------------------------------------
-- Historial de mensajes enviados (flecha arriba) que dura entre sesiones.
-- Va en RheizorDB.chatHistory[personaje], fuera del perfil: así no viaja
-- en las exportaciones ni en las copias de seguridad.
----------------------------------------------------------------------

local restoring = false

local function historyList()
	if not (R.store and R.charKey) then return end
	if type(R.store.chatHistory) ~= "table" then R.store.chatHistory = {} end
	local list = R.store.chatHistory[R.charKey]
	if type(list) ~= "table" then
		list = {}
		R.store.chatHistory[R.charKey] = list
	end
	return list
end

local function trimHistory(list)
	local max = tonumber(db.historySize) or 50
	while #list > max do table.remove(list, 1) end
end

-- Sin Alt el historial lo lleva Rheizor: el del juego se vacía (si no, con
-- Mayús o Ctrl la flecha sola también lo recorrería) y "sent" guarda lo enviado
-- en esta sesión, lo más nuevo al final
local sent = {}
local MAX_SENT = 100

-- Todo lo que no es Alt lo lleva Rheizor (el historial del juego no
-- responde a la flecha sola en este cliente)
local function customArrows()
	return db.arrowMod == "none" or db.arrowMod == "shift" or db.arrowMod == "ctrl"
end

local function pushUnique(list, line)
	-- Repetir lo mismo no llena el historial
	for i = #list, 1, -1 do
		if list[i] == line then table.remove(list, i) end
	end
	list[#list + 1] = line
end

local function remember(editBox, line)
	-- (al restaurar, durante OnEnable, el módulo aún no cuenta como en marcha)
	if not restoring and not R:IsModuleRunning(M) then return end
	if type(line) ~= "string" or (issecretvalue and issecretvalue(line)) then return end
	line = strtrim(line)
	if line == "" then return end
	pushUnique(sent, line)
	if #sent > MAX_SENT then table.remove(sent, 1) end
	editBox.rzPos = nil
	if customArrows() and editBox.ClearHistory then editBox:ClearHistory() end

	if restoring or not db.keepHistory then return end
	local list = historyList()
	if not list then return end
	pushUnique(list, line)
	trimHistory(list)
end

-- Mayús/Ctrl + arriba/abajo: recorre "sent" como lo haría el juego
local function onArrow(editBox, key)
	if not (customArrows() and R:IsModuleRunning(M)) or (key ~= "UP" and key ~= "DOWN") then return end
	local held = db.arrowMod == "none" or (db.arrowMod == "shift" and IsShiftKeyDown()) or (db.arrowMod == "ctrl" and IsControlKeyDown())
	if not held or #sent == 0 then return end
	if AutoCompleteBox and AutoCompleteBox:IsShown() then return end   -- las flechas son de las sugerencias
	local pos = editBox.rzPos
	if key == "UP" then
		pos = math.max(1, (pos or #sent + 1) - 1)
		editBox:SetText(sent[pos])
	else
		if not pos then return end
		pos = pos + 1
		if pos > #sent then pos = nil end
		editBox:SetText(pos and sent[pos] or "")
	end
	editBox.rzPos = pos
	editBox:SetCursorPosition(#editBox:GetText())
end

local function editBoxes()
	local out = {}
	for _, frame in ipairs(chatFrames()) do
		local editBox = frame.editBox or _G[frame:GetName() .. "EditBox"]
		if editBox then out[#out + 1] = editBox end
	end
	return out
end

local function hookHistory(editBox)
	if editBox.rzHistory or not editBox.AddHistoryLine then return end
	editBox.rzHistory = true
	hooksecurefunc(editBox, "AddHistoryLine", remember)
	editBox:HookScript("OnArrowPressed", onArrow)
	-- Al abrirse, el modo de flechas otra vez (por si algo lo ha cambiado)
	local function reset(self)
		self.rzPos = nil
		if self.SetAltArrowKeyMode and R:IsModuleRunning(M) and not (AutoCompleteBox and AutoCompleteBox:IsShown()) then
			self:SetAltArrowKeyMode(db.arrowMod == "alt")
		end
	end
	editBox:HookScript("OnShow", reset)
	editBox:HookScript("OnEditFocusGained", reset)
	-- Lo guardado, en orden (lo más nuevo queda el primero al pulsar arriba)
	local list = db.keepHistory and historyList()
	if list then
		restoring = true
		for _, line in ipairs(list) do pcall(editBox.AddHistoryLine, editBox, line) end
		restoring = false
	end
end

-- Al pasar de Mayús/Ctrl a Alt o a solo flechas, el historial del juego
-- (vaciado) se vuelve a llenar con lo de esta sesión
local function refillHistory(editBox)
	if not (editBox.ClearHistory and editBox.AddHistoryLine) then return end
	editBox:ClearHistory()
	if customArrows() then return end
	-- (una copia: cada línea añadida pasa otra vez por remember y toca "sent")
	local lines = { unpack(sent) }
	restoring = true
	for _, line in ipairs(lines) do pcall(editBox.AddHistoryLine, editBox, line) end
	restoring = false
end

-- Caja de texto encima del chat (por encima de las pestañas) o debajo, más
-- la altura elegida. Debajo y sin mover se devuelven los anclajes
-- originales (si nunca se movió, no se toca)
local function placeEditBox(frame, editBox)
	local offset = tonumber(db.editBoxY) or 0
	if db.editBoxPos == "top" or offset ~= 0 then
		if not editBox.rzPoints then
			editBox.rzPoints = {}
			for i = 1, editBox:GetNumPoints() do editBox.rzPoints[i] = { editBox:GetPoint(i) } end
		end
		local right = (frame.ScrollBar and frame.ScrollBar:GetWidth() or 0) + 8
		editBox:ClearAllPoints()
		if db.editBoxPos == "top" then
			local tab = _G[frame:GetName() .. "Tab"]
			local bg = frame.Background
			local bgOffset = 3
			if bg and bg:GetTop() and frame:GetTop() then bgOffset = bg:GetTop() - frame:GetTop() end
			local y = bgOffset + (tab and tab:GetHeight() or 32) + offset
			editBox:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", -5, y)
			editBox:SetPoint("BOTTOMRIGHT", frame, "TOPRIGHT", right, y)
		else
			editBox:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", -5, -2 + offset)
			editBox:SetPoint("TOPRIGHT", frame, "BOTTOMRIGHT", right, -2 + offset)
		end
	elseif editBox.rzPoints then
		editBox:ClearAllPoints()
		for _, p in ipairs(editBox.rzPoints) do editBox:SetPoint(unpack(p)) end
	end
end

----------------------------------------------------------------------
-- Ocultar el chat entero cuando no se usa.
-- Blizzard ya cambia la opacidad de pestañas, fondos y botones por su
-- cuenta (al pasar el ratón): se guarda la que quiere Blizzard y se
-- multiplica por la nuestra, así no se pisan.
----------------------------------------------------------------------

-- Además de cada ventana y su pestaña (lo que es hijo de uno de estos ya se
-- desvanece con él)
local FADE_NAMES = {
	"GeneralDockManager", "ChatFrameMenuButton", "ChatFrameChannelButton", "QuickJoinToastButton",
	"ChatFrameToggleVoiceDeafenButton", "ChatFrameToggleVoiceMuteButton", "TextToSpeechButtonFrame",
}

local IMPORTANT = {
	CHAT_MSG_WHISPER = "whisper", CHAT_MSG_BN_WHISPER = "whisper",
	CHAT_MSG_PARTY = true, CHAT_MSG_PARTY_LEADER = true, CHAT_MSG_RAID = true, CHAT_MSG_RAID_LEADER = true,
	CHAT_MSG_RAID_WARNING = true, CHAT_MSG_INSTANCE_CHAT = true, CHAT_MSG_INSTANCE_CHAT_LEADER = true,
	CHAT_MSG_GUILD = true, CHAT_MSG_OFFICER = true,
}

local fadeFrames = {}    -- marco -> true
local fadeAmount = 1     -- 1 = se ve del todo
local fadeTarget = 1
local settingAlpha = false

local function fadeOn()
	return db and db.chatFade == "idle" and R:IsModuleRunning(M)
end

local function managedAncestor(frame)
	local p = frame:GetParent()
	while p do
		if fadeFrames[p] then return true end
		p = p:GetParent()
	end
	return false
end

local function applyFade(frame)
	local factor
	if frame.rzFadeEditBox then
		-- La caja de texto (que Blizzard cuelga de la pantalla, no del chat)
		-- desaparece del todo aunque el chat oculto quede algo visible, y sin
		-- ratón; escribiendo se ve siempre
		local h = tonumber(db.chatFadeAlpha) or 0
		if frame:HasFocus() then
			factor = 1
		elseif h >= 1 then
			factor = fadeAmount
		else
			factor = math.max(0, (fadeAmount - h) / (1 - h))
		end
		frame:EnableMouse(factor > 0.05)
	else
		factor = managedAncestor(frame) and 1 or fadeAmount
	end
	settingAlpha = true
	frame:SetAlpha((frame.rzWantAlpha or 1) * factor)
	settingAlpha = false
end

local function manage(frame)
	if type(frame) ~= "table" or fadeFrames[frame] or not frame.SetAlpha then return end
	fadeFrames[frame] = true
	frame.rzWantAlpha = frame:GetAlpha()
	hooksecurefunc(frame, "SetAlpha", function(self, a)
		if settingAlpha then return end
		self.rzWantAlpha = a
		if fadeAmount < 1 then applyFade(self) end
	end)
end

local function typing()
	for _, editBox in ipairs(editBoxes()) do
		if editBox:HasFocus() then return true end
	end
	return false
end

local function hovering()
	for frame in pairs(fadeFrames) do
		if frame:IsVisible() and frame:IsMouseOver() then return true end
	end
	return false
end

local function wantShown()
	local now = GetTime()
	local editing = EditModeManagerFrame and EditModeManagerFrame.IsEditModeActive and EditModeManagerFrame:IsEditModeActive()
	if editing or (db.chatShowTyping and typing()) or (db.chatShowHover and hovering()) then
		-- Al soltar el ratón o dejar de escribir, cuenta el tiempo desde ahí
		lastActivity = now
		return true
	end
	return now - lastActivity < (tonumber(db.chatFadeDelay) or 15)
end

local fadeDriver = CreateFrame("Frame")
fadeDriver:Hide()
local sinceCheck = 1
fadeDriver:SetScript("OnUpdate", function(_, elapsed)
	-- Apagado en Rheizor: el chat vuelve a verse
	if not fadeOn() then M:ApplyFade() return end
	sinceCheck = sinceCheck + elapsed
	if sinceCheck >= 0.1 then
		sinceCheck = 0
		fadeTarget = wantShown() and 1 or (tonumber(db.chatFadeAlpha) or 0)
	end
	if fadeAmount == fadeTarget then return end
	-- Aparece en 0,2 s y se va en 0,6 s
	if fadeAmount < fadeTarget then
		fadeAmount = math.min(fadeTarget, fadeAmount + elapsed / 0.2)
	else
		fadeAmount = math.max(fadeTarget, fadeAmount - elapsed / 0.6)
	end
	for frame in pairs(fadeFrames) do applyFade(frame) end
end)

local fadeEvents = CreateFrame("Frame")
fadeEvents:SetScript("OnEvent", function(_, event)
	local kind = IMPORTANT[event]
	if db.chatShowOn == "important" or (db.chatShowOn == "whisper" and kind == "whisper") then
		lastActivity = GetTime()
	end
end)

function M:ApplyFade()
	fadeEvents:UnregisterAllEvents()
	if not fadeOn() then
		fadeDriver:Hide()
		if fadeAmount ~= 1 then
			fadeAmount, fadeTarget = 1, 1
			for frame in pairs(fadeFrames) do applyFade(frame) end
		end
		return
	end
	for _, frame in ipairs(chatFrames()) do
		manage(frame)
		manage(_G[frame:GetName() .. "Tab"])
	end
	for _, name in ipairs(FADE_NAMES) do manage(_G[name]) end
	for _, editBox in ipairs(editBoxes()) do
		if not editBox.rzFadeEditBox then
			editBox.rzFadeEditBox = true
			manage(editBox)
			-- Al pulsar Enter se ve al momento (sin esperar al siguiente repaso)
			editBox:HookScript("OnEditFocusGained", function(self) if fadeAmount < 1 then applyFade(self) end end)
			editBox:HookScript("OnEditFocusLost", function(self) if fadeAmount < 1 then applyFade(self) end end)
		end
	end
	for event in pairs(IMPORTANT) do pcall(fadeEvents.RegisterEvent, fadeEvents, event) end
	lastActivity = GetTime()
	sinceCheck = 1
	fadeDriver:Show()
end

local lastArrowMod

function M:ApplyFrames()
	for _, frame in ipairs(chatFrames()) do
		hookFrame(frame)
		if frame.SetFading then frame:SetFading(not db.noFade) end
		local editBox = frame.editBox or _G[frame:GetName() .. "EditBox"]
		if editBox then placeEditBox(frame, editBox) end
	end
	-- Con la caja arriba, el chat ya se puede pegar al borde de abajo
	if R.UpdateChatClamp then R:UpdateChatClamp() end
	local modeChanged = lastArrowMod ~= nil and lastArrowMod ~= db.arrowMod
	lastArrowMod = db.arrowMod
	for _, editBox in ipairs(editBoxes()) do
		hookHistory(editBox)
		if editBox.SetAltArrowKeyMode then editBox:SetAltArrowKeyMode(db.arrowMod == "alt") end
		if modeChanged then
			refillHistory(editBox)
		elseif customArrows() and editBox.ClearHistory then
			editBox:ClearHistory()
		end
		editBox.rzPos = nil
	end
	self:ApplyFade()
end

----------------------------------------------------------------------

function M:OnEnable()
	db = self.db
	me = UnitName("player")
	myRealm = GetNormalizedRealmName and GetNormalizedRealmName() or myRealm
	-- Antes era una casilla "Flechas sin pulsar Alt"
	if db.arrowKeys ~= nil then
		if db.arrowKeys then db.arrowMod = "none" end
		db.arrowKeys = nil
	end

	self:ApplyFrames()
	-- Con la interfaz ya colocada, las pestañas miden lo que miden
	C_Timer.After(1, function() if R:IsModuleRunning(M) then M:ApplyFrames() end end)
	if FCF_OpenTemporaryWindow then
		hooksecurefunc("FCF_OpenTemporaryWindow", function() M:ApplyFrames() end)
	end

	local addFilter = ChatFrame_AddMessageEventFilter or (ChatFrameUtil and ChatFrameUtil.AddMessageEventFilter)
	if addFilter then
		for _, event in ipairs(CHAT_EVENTS) do addFilter(event, chatFilter) end
	else
		R.missing[L["Chat: clase por GUID"]] = "ChatFrame_AddMessageEventFilter"
	end

	local events = CreateFrame("Frame")
	local handlers = {
		GROUP_ROSTER_UPDATE = scanGroup,
		PLAYER_LEVEL_UP = function() storeUnit("player") end,
		GUILD_ROSTER_UPDATE = scanGuild,
		FRIENDLIST_UPDATE = scanFriends,
		WHO_LIST_UPDATE = scanWho,
		PLAYER_TARGET_CHANGED = function() storeUnit("target") end,
		UPDATE_MOUSEOVER_UNIT = function() storeUnit("mouseover") end,
		NAME_PLATE_UNIT_ADDED = storeUnit,
	}
	for event in pairs(handlers) do pcall(events.RegisterEvent, events, event) end
	events:SetScript("OnEvent", function(_, event, ...) handlers[event](...) end)

	scanGroup()
	scanFriends()
	if IsInGuild() and C_GuildInfo and C_GuildInfo.GuildRoster then C_GuildInfo.GuildRoster() end
end

function M:OnOptionChanged(key)
	if key == "noFade" or key == "arrowMod" or key == "editBoxPos" or key == "editBoxY" then self:ApplyFrames() end
	if key:find("^chat") then self:ApplyFade() end
	if key == "historySize" then
		local list = historyList()
		if list then trimHistory(list) end
	elseif key == "keepHistory" and not db.keepHistory and R.store and R.store.chatHistory and R.charKey then
		-- Sin recordar, no se deja nada guardado
		R.store.chatHistory[R.charKey] = nil
	end
end
