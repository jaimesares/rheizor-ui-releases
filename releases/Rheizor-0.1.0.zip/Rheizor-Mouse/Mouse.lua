-- Ratón: opciones del juego (CVars) y efectos en el cursor.
--
-- El cursor del sistema no se puede cambiar ni ocultar desde un addon, así
-- que todo lo visual son marcos que siguen al ratón:
--   · un anillo (puntos, guiones o remolino) que puede girar y latir, con
--     resplandor y colores arcoíris;
--   · el tiempo global y el lanzamiento como un reloj dentro del anillo
--     (Cooldown: acepta los tiempos secretos del combate tal cual);
--   · una estela: puntos, cinta, chispas o resplandor;
--   · rayos que saltan del anillo, hechos con líneas en zigzag;
--   · efectos al hacer clic: onda, chispas, rayos;
--   · agitar el ratón agranda el anillo un momento para encontrarlo.
-- Mientras giras la cámara con el ratón el cursor no se ve: todo se oculta.
-- Las texturas son de la interfaz clásica (ping del minimapa, estrella de los
-- tiempos de reutilización); se desaturan para poder teñirlas de cualquier color.

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local CIRCLE = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local STAR = "Interface\\Cooldown\\star4"
local GLOW = "Interface\\minimap\\UI-Minimap-Ping-Center"
local WAVE = "Interface\\minimap\\UI-Minimap-Ping-Expand"
local SWIRL = "Interface\\minimap\\UI-Minimap-Ping-Rotate"
local GCD_SPELL = 61304
local DOTS = 48
local MAX_TRAIL = 40
local MAX_PARTICLES = 180
local MAX_BOLTS = 10
local ARC_DOTS = 60
local TAU = 2 * math.pi

local COLORS = { { "class", "Color de clase" }, { "rainbow", "Arcoíris" } }
for _, c in ipairs(R.COLORS) do table.insert(COLORS, c) end
local FX_COLORS = { { "ring", "Como el anillo" } }
for _, c in ipairs(COLORS) do table.insert(FX_COLORS, c) end

-- Opciones del indicador que solo valen para algunas formas (disabled no
-- recibe el módulo: se lee su tabla del perfil)
local function notStyle(_, ...)
	local d = R.db and R.db.mouse
	local style = d and d.gcdStyle or "ring"
	for i = 1, select("#", ...) do
		if style == select(i, ...) then return nil end
	end
	return L["No se usa con esta forma."]
end

local M = R:RegisterModule("mouse", {
	title = "Ratón",
	defaults = {
		ring = true,
		onlyCombat = false,
		ringStyle = "dots",
		ringAnim = "none",
		animSpeed = 1,
		ringGlow = false,
		ringSize = 44,
		ringThick = 3,
		ringColor = "class",
		ringAlpha = 0.8,
		centerDot = false,
		shake = true,
		additive = true,
		gcd = true,
		cast = true,
		castColor = "ffd100",
		gcdStyle = "ring",
		gcdColor = "ring",
		gcdAlpha = 0.9,
		gcdThick = 4,
		gcdGap = 8,
		gcdInner = 0.8,
		barPos = "below",
		barWidth = 60,
		barHeight = 5,
		barX = 0,
		barY = 0,
		trail = false,
		trailStyle = "dots",
		trailLength = 20,
		trailSize = 10,
		fxColor = "ring",
		sparkRate = 40,
		sparkGravity = true,
		lightning = false,
		lightningColor = "80ccff",
		lightningRate = 2,
		lightningLength = 50,
		lightningMove = false,
		click = "wave",
		clickLeftOnly = false,
	},
	options = {
		{ type = "header", text = "Ratón" },
		{ type = "dropdown", cvar = "cursorSizePreferred", name = "Tamaño del cursor", optional = true,
		  values = {
			{ "-1", "Automático" },
			{ "0", "32x32" },
			{ "1", "48x48" },
			{ "2", "64x64" },
			{ "3", "96x96" },
			{ "4", "128x128" },
		  } },
		{ type = "toggle", cvar = "ClipCursor", name = "Encerrar el cursor en la ventana", optional = true,
		  desc = "El cursor no puede salir de la ventana del juego (útil con varios monitores)." },
		{ type = "toggle", cvar = "enableMouseSpeed", name = "Sensibilidad propia del juego", refresh = true,
		  desc = "Apagado, el juego usa la velocidad del ratón de Windows." },
		{ type = "slider", cvar = "mouseSpeed", name = "Sensibilidad", min = 0.5, max = 1.4, step = 0.05, format = R.fmt.dec2,
		  disabled = function()
			if C_CVar.GetCVar("enableMouseSpeed") ~= "1" then return L["Activa antes «Sensibilidad propia del juego»."] end
		  end },
		-- Como la opción de Blizzard: el giro vertical es la mitad del horizontal
		{ type = "slider", id = "mouselook", name = "Velocidad al girar la cámara", min = 90, max = 270, step = 10,
		  default = 180, format = R.fmt.int,
		  desc = "Con un botón del ratón pulsado. Cambia a la vez el giro horizontal y el vertical.",
		  get = function() return tonumber(C_CVar.GetCVar("cameraYawMoveSpeed")) or 180 end,
		  set = function(v)
			R:SetCVar("cameraYawMoveSpeed", tostring(v))
			R:SetCVar("cameraPitchMoveSpeed", tostring(v / 2))
		  end },
		{ type = "toggle", cvar = "mouseInvertPitch", name = "Invertir el eje vertical" },
		{ type = "toggle", cvar = "autointeract", name = "Clic para moverse" },

		{ type = "header", text = "Anillo en el cursor" },
		{ type = "toggle", key = "ring", name = "Anillo alrededor del cursor" },
		{ type = "toggle", key = "onlyCombat", name = "Solo en combate",
		  desc = "Los efectos (anillo, estela, rayos y clics) solo se ven en combate. El tiempo global y el lanzamiento se ven siempre." },
		{ type = "dropdown", key = "ringStyle", name = "Estilo",
		  values = { { "dots", "Puntos" }, { "dashes", "Guiones" }, { "swirl", "Remolino" } } },
		{ type = "dropdown", key = "ringAnim", name = "Animación",
		  values = { { "none", "Ninguna" }, { "spin", "Girar" }, { "pulse", "Latir" }, { "both", "Girar y latir" } } },
		{ type = "slider", key = "animSpeed", name = "Velocidad de la animación", min = 0.2, max = 3, step = 0.1, format = R.fmt.dec2 },
		{ type = "slider", key = "ringSize", name = "Tamaño", min = 20, max = 120, step = 2, format = R.fmt.int },
		{ type = "slider", key = "ringThick", name = "Grosor", min = 1, max = 10, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "ringColor", name = "Color", values = COLORS },
		{ type = "slider", key = "ringAlpha", name = "Opacidad", min = 0.1, max = 1, step = 0.05 },
		{ type = "toggle", key = "ringGlow", name = "Resplandor detrás del anillo" },
		{ type = "toggle", key = "centerDot", name = "Punto en el centro" },
		{ type = "toggle", key = "shake", name = "Agitar para encontrar el cursor",
		  desc = "Si mueves el ratón deprisa de lado a lado, el anillo se agranda un momento." },
		{ type = "toggle", key = "additive", name = "Efectos brillantes",
		  desc = "Los colores se suman a lo que hay detrás, como la luz. Apagado, se ven más sólidos." },

		{ type = "header", text = "Estela" },
		{ type = "toggle", key = "trail", name = "Estela detrás del cursor" },
		{ type = "dropdown", key = "trailStyle", name = "Estilo de la estela",
		  values = { { "dots", "Puntos" }, { "ribbon", "Cinta" }, { "sparks", "Chispas" }, { "glow", "Resplandor" } } },
		{ type = "slider", key = "trailLength", name = "Longitud", min = 5, max = MAX_TRAIL, step = 1, format = R.fmt.int },
		{ type = "slider", key = "trailSize", name = "Tamaño de la estela", min = 4, max = 30, step = 1, format = R.fmt.int },
		{ type = "dropdown", key = "fxColor", name = "Color de la estela y los clics", values = FX_COLORS },
		{ type = "slider", key = "sparkRate", name = "Cantidad de chispas", min = 10, max = 120, step = 5, format = R.fmt.int,
		  desc = "Chispas por segundo al mover el ratón (estilo Chispas)." },
		{ type = "toggle", key = "sparkGravity", name = "Las chispas caen",
		  desc = "Las chispas (de la estela y de los clics) caen como si pesaran." },

		{ type = "header", text = "Rayos" },
		{ type = "toggle", key = "lightning", name = "Rayos alrededor del cursor" },
		{ type = "dropdown", key = "lightningColor", name = "Color de los rayos", values = FX_COLORS },
		{ type = "slider", key = "lightningRate", name = "Rayos por segundo", min = 0.5, max = 12, step = 0.5, format = R.fmt.dec2 },
		{ type = "slider", key = "lightningLength", name = "Largo de los rayos", min = 15, max = 150, step = 5, format = R.fmt.int },
		{ type = "toggle", key = "lightningMove", name = "Solo al mover el ratón" },

		{ type = "header", text = "Al hacer clic" },
		{ type = "dropdown", key = "click", name = "Efecto",
		  values = {
			{ "none", "Ninguno" },
			{ "wave", "Onda" },
			{ "sparks", "Chispas" },
			{ "bolts", "Rayos" },
			{ "all", "Todo junto" },
		  } },
		{ type = "toggle", key = "clickLeftOnly", name = "Solo con el botón izquierdo" },

		{ type = "header", text = "Tiempo global y lanzamiento" },
		{ type = "toggle", key = "gcd", name = "Tiempo global de reutilización",
		  desc = "Se ve aunque el anillo esté apagado o «Solo en combate» lo oculte." },
		{ type = "toggle", key = "cast", name = "Lanzamiento y canalización",
		  desc = "Mientras lanzas o canalizas, se ve el lanzamiento en vez del tiempo global." },
		{ type = "button", name = "Ejemplo", text = "Probar", desc = "Muestra un tiempo global de ejemplo durante unos segundos.",
		  func = function(mod) mod:TestIndicator() end },
		{ type = "dropdown", key = "gcdStyle", name = "Forma", refresh = true,
		  values = {
			{ "ring", "Arco sobre el anillo" },
			{ "outer", "Arco por fuera del anillo" },
			{ "inner", "Reloj dentro del anillo" },
			{ "bar", "Barra" },
		  } },
		{ type = "dropdown", key = "gcdColor", name = "Color del tiempo global", values = FX_COLORS },
		{ type = "dropdown", key = "castColor", name = "Color del lanzamiento", values = COLORS },
		{ type = "slider", key = "gcdAlpha", name = "Opacidad del indicador", min = 0.2, max = 1, step = 0.05 },
		{ type = "slider", key = "gcdThick", name = "Grosor del arco", min = 2, max = 14, step = 1, format = R.fmt.int,
		  disabled = function(mod) return notStyle(mod, "ring", "outer") end },
		{ type = "slider", key = "gcdGap", name = "Separación del arco", min = 0, max = 40, step = 1, format = R.fmt.int,
		  desc = "Distancia entre el anillo y el arco por fuera.",
		  disabled = function(mod) return notStyle(mod, "outer") end },
		{ type = "slider", key = "gcdInner", name = "Tamaño del reloj", min = 0.3, max = 1.5, step = 0.05,
		  desc = "Respecto al tamaño del anillo.",
		  disabled = function(mod) return notStyle(mod, "inner") end },
		{ type = "dropdown", key = "barPos", name = "Posición de la barra",
		  values = { { "below", "Debajo del cursor" }, { "above", "Encima del cursor" }, { "right", "A la derecha" }, { "left", "A la izquierda" } },
		  disabled = function(mod) return notStyle(mod, "bar") end },
		{ type = "slider", key = "barWidth", name = "Ancho de la barra", min = 20, max = 200, step = 2, format = R.fmt.int,
		  disabled = function(mod) return notStyle(mod, "bar") end },
		{ type = "slider", key = "barHeight", name = "Alto de la barra", min = 2, max = 16, step = 1, format = R.fmt.int,
		  disabled = function(mod) return notStyle(mod, "bar") end },
		{ type = "slider", key = "barX", name = "Desplazamiento horizontal", min = -150, max = 150, step = 1, format = R.fmt.int,
		  disabled = function(mod) return notStyle(mod, "bar") end },
		{ type = "slider", key = "barY", name = "Desplazamiento vertical", min = -150, max = 150, step = 1, format = R.fmt.int,
		  disabled = function(mod) return notStyle(mod, "bar") end },
	},
	unsupported = {
		"Cambiar la imagen del cursor o esconderlo: un addon solo puede hacerlo encima de sus propias ventanas.",
	},
})

local db
local holder, ring, trailFrame, fx
local dots, trailDots, ribbon, points = {}, {}, {}, {}
local boostUntil = 0

local function running() return db and R:IsModuleRunning(M) end

----------------------------------------------------------------------
-- Colores
----------------------------------------------------------------------

local function hsv(h, s, v)
	local i = math.floor(h * 6)
	local f = h * 6 - i
	local p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
	i = i % 6
	if i == 0 then return v, t, p end
	if i == 1 then return q, v, p end
	if i == 2 then return p, v, t end
	if i == 3 then return p, q, v end
	if i == 4 then return t, p, v end
	return v, p, q
end

-- offset desplaza el tono del arcoíris (0-1), para que no todo sea del mismo color
local function colorOf(key, offset)
	if key == "ring" then key = db.ringColor end
	if key == "rainbow" then
		return hsv((GetTime() * 0.25 + (offset or 0)) % 1, 0.85, 1)
	end
	if key == "class" then
		local c = RAID_CLASS_COLORS[R:PlayerClass()]
		if c then return c.r, c.g, c.b end
		key = "33ccff"
	end
	return R.HexToRGB(key)
end

local function blend()
	return db.additive and "ADD" or "BLEND"
end

local function cursor()
	local scale = UIParent:GetEffectiveScale()
	local x, y = GetCursorPosition()
	return x / scale, y / scale
end

local function mouselooking()
	return IsMouselooking and IsMouselooking()
end

-- Los efectos (no los relojes) respetan «Solo en combate»
local function effectsVisible()
	return not db.onlyCombat or InCombatLockdown()
end

----------------------------------------------------------------------
-- Marcos
----------------------------------------------------------------------

local function newCooldown(parent)
	local cd = CreateFrame("Cooldown", nil, parent, "CooldownFrameTemplate")
	cd:SetPoint("CENTER")
	cd:SetDrawEdge(false)
	cd:SetDrawBling(false)
	cd:SetHideCountdownNumbers(true)
	cd:SetSwipeTexture(CIRCLE)
	if cd.SetUseCircularEdge then cd:SetUseCircularEdge(true) end
	return cd
end

-- Textura teñible: se desatura para que el color de vértice mande
local function tintable(parent, layer, file)
	local t = parent:CreateTexture(nil, layer)
	t:SetTexture(file)
	t:SetDesaturated(true)
	return t
end

local function createFrames()
	holder = CreateFrame("Frame", "RheizorMouse", UIParent)
	holder:SetFrameStrata("TOOLTIP")
	holder:SetAllPoints(UIParent)
	holder:EnableMouse(false)

	-- Estela y partículas sueltas (coordenadas absolutas), por debajo del anillo
	trailFrame = CreateFrame("Frame", nil, holder)
	trailFrame:SetAllPoints(holder)
	for i = 1, MAX_TRAIL do
		local t = trailFrame:CreateTexture(nil, "BACKGROUND")
		t:SetTexture(CIRCLE)
		t:Hide()
		trailDots[i] = t
		local l = trailFrame:CreateLine(nil, "BACKGROUND")
		l:SetTexture(WHITE)
		l:Hide()
		ribbon[i] = l
	end
	fx = CreateFrame("Frame", nil, holder)
	fx:SetAllPoints(holder)
	fx:SetFrameLevel(trailFrame:GetFrameLevel() + 1)

	-- El anillo sigue al ratón; los rayos se anclan a él para moverse con el cursor
	ring = CreateFrame("Frame", nil, holder)
	ring:SetSize(10, 10)
	ring:EnableMouse(false)
	ring:SetFrameLevel(fx:GetFrameLevel() + 1)
	ring.glow = tintable(ring, "BACKGROUND", GLOW)
	ring.glow:SetPoint("CENTER")
	ring.swirl = tintable(ring, "BORDER", SWIRL)
	ring.swirl:SetPoint("CENTER")
	for i = 1, DOTS do
		local t = ring:CreateTexture(nil, "ARTWORK")
		t:SetTexture(CIRCLE)
		dots[i] = t
	end
	ring.dot = ring:CreateTexture(nil, "OVERLAY")
	ring.dot:SetTexture(CIRCLE)
	ring.dot:SetPoint("CENTER")
	-- Indicador del tiempo global / lanzamiento: arco de puntos, reloj o barra
	local ind = CreateFrame("Frame", nil, ring)
	ind:SetPoint("CENTER")
	ind:SetSize(1, 1)
	ind:SetFrameLevel(ring:GetFrameLevel() + 2)
	ind.arc = {}
	for i = 1, ARC_DOTS do
		local t = ind:CreateTexture(nil, "OVERLAY")
		t:SetTexture(CIRCLE)
		t:Hide()
		ind.arc[i] = t
	end
	ind.pie = newCooldown(ind)
	ind.bar = CreateFrame("StatusBar", nil, ind)
	ind.bar:SetMinMaxValues(0, 1)
	ind.bar:SetStatusBarTexture(R.TEXTURES[2][1])
	ind.bar.bg = ind.bar:CreateTexture(nil, "BACKGROUND")
	ind.bar.bg:SetPoint("TOPLEFT", -1, 1)
	ind.bar.bg:SetPoint("BOTTOMRIGHT", 1, -1)
	ind.bar.bg:SetColorTexture(0, 0, 0, 0.6)
	ind.bar:Hide()
	ring.ind = ind

	ring.bolts = CreateFrame("Frame", nil, ring)
	ring.bolts:SetAllPoints(ring)
	ring.bolts:SetFrameLevel(ind:GetFrameLevel() + 2)
end

function M:ApplyStyle()
	if not ring then return end
	local r, g, b = colorOf(db.ringColor)
	for _, t in ipairs(dots) do
		t:SetVertexColor(r, g, b, db.ringAlpha)
		t:SetBlendMode(blend())
	end
	ring.dot:SetVertexColor(r, g, b, db.ringAlpha)
	ring.swirl:SetVertexColor(r, g, b, db.ringAlpha)
	ring.glow:SetVertexColor(r, g, b)
	for _, t in ipairs({ ring.swirl, ring.glow }) do t:SetBlendMode(blend()) end
	for i = 1, MAX_TRAIL do
		trailDots[i]:SetBlendMode(blend())
		ribbon[i]:SetBlendMode(blend())
	end
	for _, t in ipairs(ring.ind.arc) do t:SetBlendMode(blend()) end
	-- Obliga a recolocar el indicador con las opciones nuevas
	ring.ind.shown = nil
	self:UpdateCast()
	self:UpdateGCD()
end

----------------------------------------------------------------------
-- Anillo: forma y animación, cada fotograma
----------------------------------------------------------------------

local function updateRing(now, size, show)
	local anim, speed = db.ringAnim, db.animSpeed
	local pulse = (anim == "pulse" or anim == "both") and math.sin(now * 4 * speed) or 0
	local spin = (anim == "spin" or anim == "both") and now * 1.5 * speed or 0
	size = size * (1 + 0.1 * pulse)
	ring:SetSize(size, size)
	local radius = size / 2
	local style = db.ringStyle
	local rainbow = db.ringColor == "rainbow"
	local thick = db.ringThick
	local alpha = db.ringAlpha

	local showDots = show and style ~= "swirl"
	for i, t in ipairs(dots) do
		-- Guiones: 4 puntos sí, 2 no
		local on = showDots and (style ~= "dashes" or (i - 1) % 6 < 4)
		t:SetShown(on)
		if on then
			local a = (i - 1) / DOTS * TAU + spin
			t:SetSize(thick + 1, thick + 1)
			t:ClearAllPoints()
			t:SetPoint("CENTER", ring, "CENTER", math.sin(a) * radius, math.cos(a) * radius)
			if rainbow then
				local r, g, b = hsv((now * 0.25 + (i - 1) / DOTS) % 1, 0.85, 1)
				t:SetVertexColor(r, g, b, alpha)
			end
		end
	end

	ring.swirl:SetShown(show and style == "swirl")
	if style == "swirl" then
		ring.swirl:SetSize(size * 1.3, size * 1.3)
		-- El remolino gira siempre un poco; con «Girar», más deprisa
		ring.swirl:SetRotation(-(spin * 2 + now * 0.8))
		if rainbow then
			local r, g, b = colorOf("rainbow")
			ring.swirl:SetVertexColor(r, g, b, alpha)
		end
	end

	ring.glow:SetShown(show and db.ringGlow)
	if db.ringGlow then
		ring.glow:SetSize(size * 1.9, size * 1.9)
		ring.glow:SetAlpha(alpha * (0.55 + 0.25 * pulse))
		if rainbow then ring.glow:SetVertexColor(colorOf("rainbow")) end
	end

	ring.dot:SetShown(show and db.centerDot)
	ring.dot:SetSize(math.max(thick + 2, 4), math.max(thick + 2, 4))
	if rainbow then ring.dot:SetVertexColor(hsv((now * 0.25) % 1, 0.85, 1)) end
	-- Tamaño real (con el latido), para que el arco del indicador lo siga
	return size
end

----------------------------------------------------------------------
-- Tiempo global y lanzamiento
----------------------------------------------------------------------

-- ¿Hay valor? Sin mirar dentro si es secreto (no se puede ni comparar)
local function present(v)
	return (issecretvalue and issecretvalue(v)) or v ~= nil
end

-- Temporizadores propios, con números normales: así el indicador se dibuja
-- como se quiera también en combate. (Antes se pasaba al reloj el objeto de
-- duración del juego, pero en combate lleva valores secretos y el reloj de un
-- addon no los acepta: no se veía nada.)
local timers = {
	gcd = { start = 0, dur = 0 },
	cast = { start = 0, dur = 0, channel = false },
	test = { start = 0, dur = 0 },
}
-- Duración del tiempo global cuando llega secreta: la última vista (Classic
-- no la acelera: 1,5 s, o 1 s los pícaros)
local lastGcd = 1.5
local lastSpell, lastSpellAt = nil, 0

local function readCooldown(spellID)
	local ok, info = pcall(C_Spell.GetSpellCooldown, spellID)
	if ok then return info end
end

function M:UpdateGCD()
	local t = timers.gcd
	local now = GetTime()
	-- 1) El hechizo «tiempo global», si este cliente lo tiene (Forever no parece)
	local info = readCooldown(GCD_SPELL)
	local s, d = info and NS(info.startTime), info and NS(info.duration)
	if s and d and d > 0 and d <= 2 then
		t.start, t.dur = s, d
		lastGcd = d
		return
	end
	-- 2) El hechizo que acabas de lanzar: si ha empezado a contar, el tiempo
	-- global también (isOnGCD e isActive nunca son secretos)
	if not lastSpell or now - lastSpellAt > 1 then return end
	info = readCooldown(lastSpell)
	if not (info and (info.isOnGCD or info.isActive)) then return end
	s, d = NS(info.startTime), NS(info.duration)
	if info.isOnGCD and s and d and d > 0 and d <= 2 then
		t.start, t.dur = s, d
		lastGcd = d
	elseif now >= t.start + t.dur then
		-- Secreto o con reutilización propia: se cuenta desde ahora
		t.start, t.dur = now, lastGcd
	end
end

-- Lo que lanzas (su id llega claro en UNIT_SPELLCAST_SENT); los disparos
-- automáticos y la varita no cuentan: bloquean hechizos pero no son el global
function M:OnSpellSent(_, _, _, _, spellID)
	spellID = NS(spellID)
	if not spellID then return end
	local name = C_Spell.GetSpellName and C_Spell.GetSpellName(spellID)
	if name and IsAutoRepeatSpell and IsAutoRepeatSpell(name) then return end
	lastSpell, lastSpellAt = spellID, GetTime()
end

function M:UpdateCast(event, _, _, spellID)
	local t = timers.cast
	local channel = false
	local name, _, _, startMS, endMS = UnitCastingInfo("player")
	if not present(name) then
		name, _, _, startMS, endMS = UnitChannelInfo("player")
		channel = true
	end
	if not present(name) then t.dur = 0 return end
	t.channel = channel
	local s, e = NS(startMS), NS(endMS)
	if s and e and e > s then
		t.start, t.dur = s / 1000, (e - s) / 1000
	elseif event == "UNIT_SPELLCAST_START" and NS(spellID) then
		-- Tiempos secretos: el tiempo de lanzamiento del hechizo
		local info = C_Spell.GetSpellInfo(spellID)
		local ms = info and NS(info.castTime)
		if ms and ms > 0 then t.start, t.dur = GetTime(), ms / 1000 end
	end
end

function M:TestIndicator()
	if not ring then return end
	timers.test.start, timers.test.dur = GetTime(), 3
end

-- Dibuja el lanzamiento (si hay) o el tiempo global en la forma elegida
local function updateIndicator(now, ringSize)
	local ind = ring.ind
	local test, cast, gcd = timers.test, timers.cast, timers.gcd
	local t, colorKey
	if now < test.start + test.dur then
		t, colorKey = test, db.gcdColor
	elseif db.cast and now < cast.start + cast.dur then
		t, colorKey = cast, db.castColor
	elseif db.gcd and now < gcd.start + gcd.dur then
		t, colorKey = gcd, db.gcdColor
	end
	local style = t and db.gcdStyle or false
	if ind.shown ~= style then
		ind.shown, ind.radius, ind.pieKey = style, nil, nil
		for _, d in ipairs(ind.arc) do d:SetShown(style == "ring" or style == "outer") end
		if style ~= "inner" then ind.pie:Clear() end
		ind.pie:SetShown(style == "inner")
		ind.bar:SetShown(style == "bar")
	end
	if not t then return end

	local p = math.min(math.max((now - t.start) / t.dur, 0), 1)
	-- Canalizado: se va vaciando
	if t.channel then p = 1 - p end
	local r, g, b = colorOf(colorKey, 0)
	local alpha = db.gcdAlpha

	if style == "ring" or style == "outer" then
		local radius = ringSize / 2
		if style == "outer" then radius = radius + db.ringThick / 2 + db.gcdGap + db.gcdThick / 2 end
		if ind.radius ~= radius then
			ind.radius = radius
			for i, d in ipairs(ind.arc) do
				local a = (i - 1) / ARC_DOTS * TAU
				d:SetSize(db.gcdThick, db.gcdThick)
				d:ClearAllPoints()
				d:SetPoint("CENTER", ring, "CENTER", math.sin(a) * radius, math.cos(a) * radius)
			end
		end
		-- Desde arriba en el sentido de las agujas; lo que falta, tenue
		local lit = p * ARC_DOTS
		for i, d in ipairs(ind.arc) do
			d:SetVertexColor(r, g, b, i <= lit and alpha or alpha * 0.18)
		end
	elseif style == "inner" then
		local size = ringSize * db.gcdInner
		ind.pie:SetSize(size, size)
		ind.pie:SetSwipeColor(r, g, b, alpha * 0.85)
		if ind.pieKey ~= t.start then
			ind.pieKey = t.start
			ind.pie:SetReverse(t.channel and true or false)
			ind.pie:SetCooldown(t.start, t.dur)
		end
	else
		local bar = ind.bar
		bar:SetSize(db.barWidth, db.barHeight)
		bar:SetStatusBarColor(r, g, b, alpha)
		bar.bg:SetColorTexture(0, 0, 0, 0.6 * alpha)
		bar:SetValue(p)
		local off = ringSize / 2 + 6
		bar:ClearAllPoints()
		if db.barPos == "above" then
			bar:SetPoint("BOTTOM", ring, "CENTER", db.barX, off + db.barY)
		elseif db.barPos == "right" then
			bar:SetPoint("LEFT", ring, "CENTER", off + db.barX, db.barY)
		elseif db.barPos == "left" then
			bar:SetPoint("RIGHT", ring, "CENTER", -off + db.barX, db.barY)
		else
			bar:SetPoint("TOP", ring, "CENTER", db.barX, -off + db.barY)
		end
	end
end

----------------------------------------------------------------------
-- Partículas: chispas, resplandores y ondas (texturas sueltas que se
-- mueven, crecen o encogen y se desvanecen)
----------------------------------------------------------------------

local freeParticles, particles = {}, {}

local function spawn(file, x, y, size, size1, life, alpha, r, g, b, vx, vy, grav, spin)
	if #particles >= MAX_PARTICLES then return end
	local p = table.remove(freeParticles)
	if not p then p = { t = fx:CreateTexture(nil, "ARTWORK") } end
	local t = p.t
	t:SetTexture(file)
	t:SetDesaturated(true)
	t:SetBlendMode(blend())
	t:SetVertexColor(r, g, b)
	p.rot = math.random() * TAU
	t:SetRotation(p.rot)
	p.x, p.y, p.vx, p.vy, p.grav, p.spin = x, y, vx or 0, vy or 0, grav or 0, spin or 0
	p.s0, p.s1, p.life, p.age, p.a0 = size, size1 or size, life, 0, alpha
	t:Show()
	particles[#particles + 1] = p
end

local function updateParticles(e)
	local i = 1
	while i <= #particles do
		local p = particles[i]
		p.age = p.age + e
		if p.age >= p.life then
			p.t:Hide()
			freeParticles[#freeParticles + 1] = p
			particles[i] = particles[#particles]
			particles[#particles] = nil
		else
			local k = p.age / p.life
			p.vy = p.vy - p.grav * e
			p.x, p.y = p.x + p.vx * e, p.y + p.vy * e
			local size = p.s0 + (p.s1 - p.s0) * k
			local t = p.t
			t:SetSize(size, size)
			t:ClearAllPoints()
			t:SetPoint("CENTER", fx, "BOTTOMLEFT", p.x, p.y)
			t:SetAlpha(p.a0 * (1 - k))
			if p.spin ~= 0 then
				p.rot = p.rot + p.spin * e
				t:SetRotation(p.rot)
			end
			i = i + 1
		end
	end
end

local function spark(x, y, speedMin, speedMax, size, life)
	local a = math.random() * TAU
	local v = speedMin + math.random() * (speedMax - speedMin)
	local r, g, b = colorOf(db.fxColor, math.random())
	local s = size * (0.6 + math.random() * 0.8)
	spawn(STAR, x, y, s, s * 0.2, life * (0.7 + math.random() * 0.6), 1, r, g, b,
		math.sin(a) * v, math.cos(a) * v + (db.sparkGravity and 30 or 0),
		db.sparkGravity and 260 or 0, (math.random() - 0.5) * 12)
end

----------------------------------------------------------------------
-- Rayos: zigzag de líneas (un trazo ancho y tenue + uno fino y brillante)
-- anclados al anillo, que parpadean y se apagan en unas décimas
----------------------------------------------------------------------

local bolts, freeLines = {}, {}

local function getLine()
	local l = table.remove(freeLines)
	if not l then
		l = ring.bolts:CreateLine(nil, "OVERLAY")
		l:SetTexture(WHITE)
	end
	return l
end

local function addSegment(bolt, x1, y1, x2, y2, r, g, b)
	for pass = 1, 2 do
		local l = getLine()
		l:SetStartPoint("CENTER", ring.bolts, x1, y1)
		l:SetEndPoint("CENTER", ring.bolts, x2, y2)
		l:SetBlendMode(blend())
		if pass == 1 then
			l:SetThickness(5)
			l:SetVertexColor(r, g, b, 0.35)
		else
			l:SetThickness(1.5)
			l:SetVertexColor(math.min(r + 0.5, 1), math.min(g + 0.5, 1), math.min(b + 0.5, 1), 1)
		end
		l:SetAlpha(1)
		l:Show()
		bolt.lines[#bolt.lines + 1] = l
	end
end

local function jagged(bolt, x1, y1, x2, y2, segs, r, g, b, fork)
	local dx, dy = x2 - x1, y2 - y1
	local len = math.sqrt(dx * dx + dy * dy)
	if len < 1 then return end
	local nx, ny = -dy / len, dx / len
	local jitter = len * 0.18
	local px, py = x1, y1
	for s = 1, segs do
		local k = s / segs
		local x, y = x1 + dx * k, y1 + dy * k
		if s < segs then
			local off = (math.random() * 2 - 1) * jitter
			x, y = x + nx * off, y + ny * off
		end
		addSegment(bolt, px, py, x, y, r, g, b)
		-- Una rama corta que sale hacia un lado
		if fork and s == 2 and math.random() < 0.6 then
			local a = math.atan2 and math.atan2(dx, dy) or math.atan(dx, dy)
			a = a + (math.random() < 0.5 and -0.6 or 0.6)
			local bl = len * 0.4
			jagged(bolt, x, y, x + math.sin(a) * bl, y + math.cos(a) * bl, 3, r, g, b, false)
		end
		px, py = x, y
	end
end

local function spawnBolt(from, length)
	if #bolts >= MAX_BOLTS then return end
	local a = math.random() * TAU
	local r, g, b = colorOf(db.lightningColor, math.random())
	local bolt = { lines = {}, age = 0, life = 0.12 + math.random() * 0.14 }
	local sx, sy = math.sin(a), math.cos(a)
	jagged(bolt, sx * from, sy * from, sx * (from + length), sy * (from + length), 5, r, g, b, true)
	bolts[#bolts + 1] = bolt
end

local function updateBolts(e)
	local i = 1
	while i <= #bolts do
		local bolt = bolts[i]
		bolt.age = bolt.age + e
		if bolt.age >= bolt.life then
			for _, l in ipairs(bolt.lines) do
				l:Hide()
				freeLines[#freeLines + 1] = l
			end
			bolts[i] = bolts[#bolts]
			bolts[#bolts] = nil
		else
			-- Parpadeo: cada fotograma una intensidad al azar que va bajando
			local a = (1 - bolt.age / bolt.life) * (0.5 + math.random() * 0.5)
			for _, l in ipairs(bolt.lines) do l:SetAlpha(a) end
			i = i + 1
		end
	end
end

----------------------------------------------------------------------
-- Estela
----------------------------------------------------------------------

local function hideTrail()
	wipe(points)
	for i = 1, MAX_TRAIL do
		trailDots[i]:Hide()
		ribbon[i]:Hide()
	end
end

-- Puntos y cinta: siguen los últimos puntos por los que pasó el cursor
local function updatePath(x, y, now)
	local last = points[1]
	if not last or math.abs(last[1] - x) + math.abs(last[2] - y) > 1 then
		-- Llena: se reutiliza el punto más viejo
		local p = #points >= db.trailLength and table.remove(points) or {}
		p[1], p[2] = x, y
		table.insert(points, 1, p)
	elseif #points > 1 then
		-- Quieto: la estela se va recogiendo
		table.remove(points)
	end
	while #points > db.trailLength do table.remove(points) end

	local ribbonStyle = db.trailStyle == "ribbon"
	for i = 1, MAX_TRAIL do
		local p, q = points[i], points[i + 1]
		local k = 1 - (i - 1) / db.trailLength
		local r, g, b = colorOf(db.fxColor, i * 0.03)
		local dot, line = trailDots[i], ribbon[i]
		if not ribbonStyle and p and i > 1 then
			local size = math.max(db.trailSize * k, 2)
			dot:SetSize(size, size)
			dot:ClearAllPoints()
			dot:SetPoint("CENTER", trailFrame, "BOTTOMLEFT", p[1], p[2])
			dot:SetVertexColor(r, g, b, db.ringAlpha * k * 0.8)
			dot:Show()
		else
			dot:Hide()
		end
		if ribbonStyle and p and q then
			line:SetStartPoint("BOTTOMLEFT", trailFrame, p[1], p[2])
			line:SetEndPoint("BOTTOMLEFT", trailFrame, q[1], q[2])
			line:SetThickness(math.max(db.trailSize * 0.6 * k, 1))
			line:SetVertexColor(r, g, b, db.ringAlpha * k)
			line:Show()
		else
			line:Hide()
		end
	end
end

-- Chispas y resplandor: se sueltan partículas mientras el ratón se mueve
local sparkAcc, glowAcc = 0, 0

local function emitTrail(x, y, e, speed, moved)
	if db.trailStyle == "sparks" then
		if speed > 40 then
			sparkAcc = sparkAcc + db.sparkRate * e * math.min(speed / 400, 1.5)
			while sparkAcc >= 1 do
				sparkAcc = sparkAcc - 1
				spark(x + (math.random() - 0.5) * 6, y + (math.random() - 0.5) * 6, 5, 50,
					db.trailSize, db.trailLength / 25)
			end
		end
	elseif db.trailStyle == "glow" then
		-- Un resplandor cada pocos píxeles recorridos
		glowAcc = glowAcc + moved
		while glowAcc >= 4 do
			glowAcc = glowAcc - 4
			local r, g, b = colorOf(db.fxColor, GetTime() * 0.5)
			local s = db.trailSize * 2.2
			spawn(GLOW, x, y, s, s * 0.3, db.trailLength / 40, 0.8, r, g, b)
		end
	end
end

----------------------------------------------------------------------
-- Clic
----------------------------------------------------------------------

function M:OnMouseDown(_, button)
	if db.click == "none" or not effectsVisible() or mouselooking() then return end
	if db.clickLeftOnly and button ~= "LeftButton" then return end
	local x, y = cursor()
	local c = db.click
	if c == "wave" or c == "all" then
		local r, g, b = colorOf(db.fxColor, math.random())
		spawn(WAVE, x, y, 8, db.ringSize * 2.6, 0.45, 1, r, g, b)
		spawn(GLOW, x, y, db.ringSize * 1.2, db.ringSize * 0.3, 0.3, 0.9, r, g, b)
	end
	if c == "sparks" or c == "all" then
		for _ = 1, 16 do spark(x, y, 120, 260, 14, 0.55) end
	end
	if c == "bolts" or c == "all" then
		for _ = 1, 4 do spawnBolt(4, db.lightningLength * 0.9) end
	end
end

----------------------------------------------------------------------
-- Cada fotograma
----------------------------------------------------------------------

-- Últimos movimientos horizontales, para ver si se está agitando
local shakes, lastDX = {}, 0
local lastX, lastY, moveSpeed, nextBolt = nil, nil, 0, 0

local function detectShake(dx, now)
	-- Un cambio de sentido tras un tramo rápido cuenta como sacudida
	if math.abs(dx) > 6 then
		if lastDX ~= 0 and (dx > 0) ~= (lastDX > 0) then
			table.insert(shakes, now)
		end
		lastDX = dx
	end
	while shakes[1] and now - shakes[1] > 0.6 do table.remove(shakes, 1) end
	if #shakes >= 4 then
		boostUntil = now + 1.2
		wipe(shakes)
	end
end

local function onUpdate(_, e)
	if not running() then holder:Hide() return end
	updateParticles(e)
	updateBolts(e)
	if mouselooking() then
		ring:Hide()
		hideTrail()
		lastX = nil
		return
	end

	local now = GetTime()
	local x, y = cursor()
	local dx, dy = lastX and x - lastX or 0, lastY and y - lastY or 0
	lastX, lastY = x, y
	local moved = math.sqrt(dx * dx + dy * dy)
	-- Velocidad suavizada en píxeles por segundo
	moveSpeed = moveSpeed * 0.8 + (moved / math.max(e, 0.001)) * 0.2
	local visible = effectsVisible()

	if db.shake then detectShake(dx, now) end
	local size = db.ringSize
	local boosted = now < boostUntil
	if boosted then
		-- Crece de golpe y vuelve poco a poco
		size = size * (1 + 2 * math.min((boostUntil - now) / 0.6, 1))
	end

	ring:ClearAllPoints()
	ring:SetPoint("CENTER", holder, "BOTTOMLEFT", x, y)
	local shown = updateRing(now, size, db.ring and (visible or boosted))
	updateIndicator(now, shown)
	ring:Show()

	if db.trail and visible then
		if db.trailStyle == "dots" or db.trailStyle == "ribbon" then
			updatePath(x, y, now)
		else
			if points[1] then hideTrail() end
			emitTrail(x, y, e, moveSpeed, moved)
		end
	elseif points[1] then
		hideTrail()
	end

	if db.lightning and visible and (not db.lightningMove or moveSpeed > 150) and now >= nextBolt then
		spawnBolt(size / 2, db.lightningLength)
		-- Intervalos irregulares, de media «rayos por segundo»
		nextBolt = now + (0.4 + math.random() * 1.2) / db.lightningRate
	end
end

----------------------------------------------------------------------
-- Arranque
----------------------------------------------------------------------

local events = {
	SPELL_UPDATE_COOLDOWN = "UpdateGCD",
	GLOBAL_MOUSE_DOWN = "OnMouseDown",
	UNIT_SPELLCAST_START = "UpdateCast",
	UNIT_SPELLCAST_SUCCEEDED = "UpdateGCD",
	UNIT_SPELLCAST_SENT = "OnSpellSent",
	UNIT_SPELLCAST_STOP = "UpdateCast",
	UNIT_SPELLCAST_FAILED = "UpdateCast",
	UNIT_SPELLCAST_INTERRUPTED = "UpdateCast",
	UNIT_SPELLCAST_DELAYED = "UpdateCast",
	UNIT_SPELLCAST_CHANNEL_START = "UpdateCast",
	UNIT_SPELLCAST_CHANNEL_UPDATE = "UpdateCast",
	UNIT_SPELLCAST_CHANNEL_STOP = "UpdateCast",
}

function M:OnEnable()
	db = self.db
	if R:PlayerClass() == "ROGUE" then lastGcd = 1 end
	createFrames()
	local ev = CreateFrame("Frame")
	for event in pairs(events) do
		if event:find("^UNIT_") then
			ev:RegisterUnitEvent(event, "player")
		else
			pcall(ev.RegisterEvent, ev, event)
		end
	end
	ev:SetScript("OnEvent", function(_, event, ...)
		if not running() then return end
		M[events[event]](M, event, ...)
		-- Por si el aviso de tiempos de reutilización llega antes que el lanzamiento
		if event == "UNIT_SPELLCAST_START" then M:UpdateGCD() end
	end)
	holder:SetScript("OnUpdate", onUpdate)
	self:ApplyStyle()
	holder:Show()
end

function M:OnOptionChanged()
	if not ring then return end
	if not db.trail then hideTrail() end
	self:ApplyStyle()
end
