-- Herramientas de banda: una barra compacta con
--   · iconos de banda sobre tu objetivo (y limpiar todos los visibles),
--   · marcadores de mundo en el suelo (opcional),
--   · cuenta atrás de pull (la de Blizzard, o DBM, o avisos en el chat),
--   · comprobación de listos y de roles,
--   · un panel desplegable con el estado del grupo y la durabilidad de cada
--     uno (la comparten entre sí quienes llevan Rheizor).

local R = Rheizor:Namespace(...)
local L = R.L
local NS = R.NotSecret

local PREFIX = "RheizorRT"
local WHITE = "Interface\\Buttons\\WHITE8X8"
local RAID_ICON = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_"
-- Marcador de mundo -> icono de banda con el mismo símbolo
local WORLD_ICON = { 6, 4, 3, 7, 1, 2, 5, 8 }
local WORLD_NAMES = { L["Cuadrado azul"], L["Triángulo verde"], L["Rombo morado"], L["Cruz roja"], L["Estrella amarilla"], L["Círculo naranja"], L["Luna plateada"], L["Calavera blanca"] }
local RAID_NAMES = { L["Estrella"], L["Círculo"], L["Rombo"], L["Triángulo"], L["Luna"], L["Cuadrado"], L["Cruz"], L["Calavera"] }

-- Iconos dentro del texto (las fuentes del juego no tienen símbolos como ✖)
local X_ICON = "|TInterface\\RaidFrame\\ReadyCheck-NotReady:14|t"
local STOP_ICON = "|TInterface\\Buttons\\UI-StopButton:14|t"

-- Pings: palabra de /ping, nombre, iconos del juego (se prueban en orden) y
-- un icono de banda de reserva
local PINGS = {
	{ key = "Attack", token = "attack", name = L["Atacar"], short = L["Atacar"], fallback = RAID_ICON .. 8,
	  atlases = { "Ping_Marker_Icon_Attack", "Ping_Wheel_Icon_Attack", "Ping_Chat_Attack" } },
	{ key = "Warning", token = "warning", name = L["Aviso / peligro"], short = L["Aviso"], fallback = RAID_ICON .. 7,
	  atlases = { "Ping_Marker_Icon_Warning", "Ping_Wheel_Icon_Warning", "Ping_Chat_Warning" } },
	{ key = "OnMyWay", token = "onmyway", name = L["Voy de camino"], short = L["Voy"], fallback = RAID_ICON .. 4,
	  atlases = { "Ping_Marker_Icon_OnMyWay", "Ping_Wheel_Icon_OnMyWay", "Ping_Chat_OnMyWay" } },
	{ key = "Assist", token = "assist", name = L["Ayuda / asistir"], short = L["Ayuda"], fallback = RAID_ICON .. 6,
	  atlases = { "Ping_Marker_Icon_Assist", "Ping_Wheel_Icon_Assist", "Ping_Chat_Assist" } },
}

-- Nombres en Teclado > AddOns (ver Bindings.xml)
BINDING_HEADER_RHEIZORRAID = L["Rheizor · Banda"]
for _, ping in ipairs(PINGS) do
	_G["BINDING_NAME_CLICK RheizorPing" .. ping.key .. ":LeftButton"] = L["Ping: %s"]:format(ping.name:lower())
end

local function setPingIcon(tex, ping)
	if C_Texture and C_Texture.GetAtlasInfo then
		for _, atlas in ipairs(ping.atlases) do
			if C_Texture.GetAtlasInfo(atlas) then
				tex:SetAtlas(atlas)
				return
			end
		end
	end
	tex:SetTexture(ping.fallback)
end

local ROWS = {
	{ "ping", "Pings (sistema nuevo)" },
	{ "world", "Marcadores de mundo" },
	{ "none", "Ninguna" },
}

local ACCENTS ={ { "class", "Color de clase" } }
for _, c in ipairs(R.COLORS) do table.insert(ACCENTS, c) end

local M = R:RegisterModule("raidtools", {
	title = "Herramientas de banda",
	defaults = {
		enabled = true,
		locked = true,
		show = "group",
		hideCombat = false,
		scale = 1,
		bgAlpha = 0.75,
		accent = "class",
		row = "ping",
		pull1 = 5, pull2 = 10, pull3 = 15,
		pullChat = false,
		share = true,
		low = 30,
	},
	options = {
		{ type = "header", text = "Herramientas de banda" },
		{ type = "toggle", key = "enabled", name = "Activar herramientas de banda",
		  desc = "Una barra con iconos de banda, cuenta atrás de pull, comprobación de listos y un panel con la durabilidad del grupo." },

		{ type = "header", text = "Aspecto" },
		{ type = "dropdown", key = "row", name = "Segunda fila", values = ROWS,
		  desc = "Pings: atacar, aviso, voy de camino y ayuda sobre tu objetivo (o lo que tengas bajo el ratón si les pones tecla).\nMarcadores de mundo: las marcas de suelo clásicas, si tu versión las tiene." },
		{ type = "dropdown", key = "accent", name = "Color de acento", values = ACCENTS },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },

		{ type = "header", text = "Posición y tamaño" },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueada, aparece una pestaña encima de la barra para arrastrarla." },
		{ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end },
		{ type = "slider", key = "scale", name = "Tamaño", min = 0.6, max = 1.8, step = 0.05 },

		{ type = "header", text = "Comportamiento" },
		{ type = "dropdown", key = "show", name = "Mostrar",
		  values = { { "always", "Siempre" }, { "group", "En grupo o banda" }, { "raid", "Solo en banda" } } },
		{ type = "toggle", key = "hideCombat", name = "Ocultar en combate" },

		{ type = "header", text = "Cuenta atrás de pull" },
		{ type = "slider", key = "pull1", name = "Botón 1 (segundos)", min = 3, max = 30, step = 1, format = R.fmt.int },
		{ type = "slider", key = "pull2", name = "Botón 2 (segundos)", min = 3, max = 30, step = 1, format = R.fmt.int },
		{ type = "slider", key = "pull3", name = "Botón 3 (segundos)", min = 3, max = 60, step = 1, format = R.fmt.int },
		{ type = "toggle", key = "pullChat", name = "Anunciar también en el chat",
		  desc = "Escribe la cuenta atrás en aviso de banda o en el chat de grupo, además de la cuenta atrás en pantalla." },

		{ type = "header", text = "Durabilidad" },
		{ type = "toggle", key = "share", name = "Compartir mi durabilidad con el grupo",
		  desc = "Necesario para que otros con Rheizor vean tu estado. Solo se envía a tu grupo." },
		{ type = "slider", key = "low", name = "Aviso por debajo de", min = 5, max = 80, step = 5, format = R.fmt.int,
		  desc = "Porcentaje a partir del cual alguien aparece en rojo y entra en el aviso de reparar." },
	},
	-- Lo que no se puede hacer en WoW Forever
	unsupported = {
		"Anunciar interrupciones y disipaciones: el juego oculta a los addons qué hechizo se ha cortado o quitado y quién lo hizo (el registro de combate está cerrado).",
		"Temporizadores de habilidades de jefes al estilo DBM: dependen del registro de combate, que los addons ya no pueden leer.",
		"Resaltar qué icono de banda tiene tu objetivo: el juego no deja a los addons leerlo.",
		"Compartir la durabilidad dentro de mazmorras y bandas: allí el juego puede bloquear los mensajes entre addons. Se envía al salir o fuera de ellas.",
	},
})

local db
local bar, info
local S, PAD = 26, 4

----------------------------------------------------------------------
-- Utilidades
----------------------------------------------------------------------

local function accent()
	if db.accent == "class" then
		local c = RAID_CLASS_COLORS[R:PlayerClass()]
		if c then return c.r, c.g, c.b end
	end
	return R.HexToRGB(db.accent ~= "class" and db.accent or "33ccff")
end

local function canLead()
	if not IsInGroup() then return true end
	if not IsInRaid() then return true end
	return UnitIsGroupLeader("player") or UnitIsGroupAssistant("player")
end

local function groupChannel()
	if LE_PARTY_CATEGORY_INSTANCE and IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then return "INSTANCE_CHAT" end
	if IsInRaid() then return "RAID" end
	if IsInGroup() then return "PARTY" end
end

local function tooltip(frame, title, ...)
	local lines = { ... }
	frame:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:AddLine(title)
		for _, line in ipairs(lines) do GameTooltip:AddLine(line, 1, 1, 1, true) end
		GameTooltip:Show()
	end)
	frame:SetScript("OnLeave", GameTooltip_Hide)
end

-- Botón plano: fondo oscuro, borde fino y resalte de acento al pasar el ratón
local function styleButton(b, w, h)
	b:SetSize(w, h)
	b.bg = b:CreateTexture(nil, "BACKGROUND")
	b.bg:SetAllPoints()
	b.bg:SetColorTexture(0.1, 0.1, 0.12, 0.9)
	b.edge = CreateFrame("Frame", nil, b, "BackdropTemplate")
	b.edge:SetAllPoints()
	b.edge:SetBackdrop({ edgeFile = WHITE, edgeSize = 1 })
	b.edge:SetBackdropBorderColor(0, 0, 0, 1)
	b.hover = b:CreateTexture(nil, "HIGHLIGHT")
	b.hover:SetAllPoints()
	b.hover:SetColorTexture(1, 1, 1, 0.12) -- la capa HIGHLIGHT se muestra sola al pasar el ratón
end

local function flatButton(parent, w, h, text, onClick, template)
	local b = CreateFrame("Button", nil, parent, template)
	styleButton(b, w, h)
	if text then
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		b.text:SetPoint("CENTER")
		b.text:SetText(text)
	end
	if onClick then
		b:RegisterForClicks("LeftButtonUp", "RightButtonUp")
		b:SetScript("OnClick", onClick)
	end
	return b
end

local function iconOn(b, texture, inset)
	b.icon = b:CreateTexture(nil, "ARTWORK")
	b.icon:SetPoint("TOPLEFT", inset or 3, -(inset or 3))
	b.icon:SetPoint("BOTTOMRIGHT", -(inset or 3), inset or 3)
	b.icon:SetTexture(texture)
	return b.icon
end

----------------------------------------------------------------------
-- Iconos de banda
----------------------------------------------------------------------

local markButtons = {}

-- En gris si no puedes marcar. No se resalta el icono que ya tiene tu
-- objetivo: GetRaidTargetIndex siempre da un valor secreto en Forever.
function M:UpdateMarks()
	if not bar then return end
	local allowed = canLead()
	for _, btn in ipairs(markButtons) do
		btn.icon:SetDesaturated(not allowed)
		btn:SetAlpha(allowed and 1 or 0.5)
	end
end

----------------------------------------------------------------------
-- Pull
----------------------------------------------------------------------

local pull = { endTime = nil, ticker = nil }

-- SendChatMessage global es un alias antiguo; la función actual está en C_ChatInfo
local function sendChat(text, chan)
	local fn = (C_ChatInfo and C_ChatInfo.SendChatMessage) or SendChatMessage
	if fn then pcall(fn, text, chan) end
end

-- Mensajes entre addons bloqueados (mazmorras, bandas, encuentros…)
local function chatLockdown()
	return C_ChatInfo and C_ChatInfo.InChatMessagingLockdown and C_ChatInfo.InChatMessagingLockdown() == true
end

local function announce(text)
	local chan = groupChannel()
	if not chan then return end
	if chan == "RAID" and canLead() then chan = "RAID_WARNING" end
	sendChat(text, chan)
end

local function stopChatCountdown()
	if pull.ticker then pull.ticker:Cancel() pull.ticker = nil end
end

local function chatCountdown(seconds)
	stopChatCountdown()
	announce(L["Pull en %d s"]:format(seconds))
	local left = seconds
	pull.ticker = C_Timer.NewTicker(1, function(t)
		left = left - 1
		if left <= 0 then
			announce(">> PULL <<")
			t:Cancel()
			pull.ticker = nil
		elseif left <= 5 or left % 5 == 0 then
			announce(tostring(left))
		end
	end, seconds)
end

function M:Pull(seconds)
	if not canLead() then
		R:Print(L["Necesitas ser líder o ayudante para iniciar el pull."])
		return
	end
	-- La cuenta atrás de Blizzard (/countdown); si no está o falla, DBM; si
	-- tampoco, solo la del chat
	local started = false
	if C_PartyInfo and C_PartyInfo.DoCountdown then
		local ok, success = pcall(C_PartyInfo.DoCountdown, seconds)
		started = ok and success ~= false
	end
	if not started and SlashCmdList.DEADLYBOSSMODS then
		SlashCmdList.DEADLYBOSSMODS("pull " .. seconds)
		started = true
	end
	if db.pullChat or not started then
		chatCountdown(seconds)
	end
	pull.endTime = GetTime() + seconds
end

function M:CancelPull()
	if C_PartyInfo and C_PartyInfo.DoCountdown then
		pcall(C_PartyInfo.DoCountdown, 0)
	end
	if pull.ticker then
		stopChatCountdown()
		announce(L["Pull cancelado"])
	elseif pull.endTime and not (C_PartyInfo and C_PartyInfo.DoCountdown) and SlashCmdList.DEADLYBOSSMODS then
		SlashCmdList.DEADLYBOSSMODS("pull 0")
	end
	pull.endTime = nil
end

----------------------------------------------------------------------
-- Durabilidad compartida
----------------------------------------------------------------------

local durability = {} -- [nombre] = { pct, low, broken, time }
local lastSent, lastRequest = 0, 0

local function myDurability()
	local cur, max, broken, low = 0, 0, 0, 100
	for slot = 1, 18 do
		local c, m = GetInventoryItemDurability(slot)
		if c and m and m > 0 then
			cur, max = cur + c, max + m
			if c == 0 then broken = broken + 1 end
			low = math.min(low, c / m * 100)
		end
	end
	local pct = max > 0 and math.floor(cur / max * 100 + 0.5) or 100
	return pct, math.floor(low + 0.5), broken
end

local function send(msg)
	local chan = groupChannel()
	if chan and C_ChatInfo and C_ChatInfo.SendAddonMessage then
		pcall(C_ChatInfo.SendAddonMessage, PREFIX, msg, chan)
	end
end

local function shareDurability(force)
	if not db.enabled or not db.share or not IsInGroup() then return end
	-- Bloqueado ahora: se intentará en la próxima ocasión (al salir, etc.)
	if chatLockdown() then return end
	local now = GetTime()
	if not force and now - lastSent < 15 then return end
	lastSent = now
	send(string.format("D:%d:%d:%d", myDurability()))
end

local function requestDurability()
	local now = GetTime()
	if now - lastRequest < 5 then return end
	lastRequest = now
	send("R")
end

local function onAddonMessage(prefix, msg, _, sender)
	if prefix ~= PREFIX or type(msg) ~= "string" then return end
	-- Con apellidos el nombre de pila no identifica a nadie: clave completa
	local name = R.NameKey(sender)
	if msg == "R" then
		if not R.IsMyName(sender) then shareDurability(true) end
		return
	end
	local pct, low, broken = msg:match("^D:(%d+):(%d+):(%d+)$")
	if pct then
		durability[name] = { pct = tonumber(pct), low = tonumber(low), broken = tonumber(broken), time = GetTime() }
		if info and info:IsShown() then M:RefreshInfo() end
	end
end

----------------------------------------------------------------------
-- Panel de información
----------------------------------------------------------------------

local rows = {}
local ROW_H = 16

local function roster()
	local list = {}
	if IsInRaid() then
		for i = 1, GetNumGroupMembers() do
			local name, _, subgroup = GetRaidRosterInfo(i)
			if name then list[#list + 1] = { unit = "raid" .. i, group = subgroup or 1 } end
		end
	else
		list[1] = { unit = "player", group = 1 }
		for i = 1, GetNumSubgroupMembers() do list[#list + 1] = { unit = "party" .. i, group = 1 } end
	end
	for _, m in ipairs(list) do m.name = R.UnitFullName(m.unit) or "?" end
	table.sort(list, function(a, b)
		if a.group ~= b.group then return a.group < b.group end
		return a.name < b.name
	end)
	return list
end

local function getRow(i)
	if rows[i] then return rows[i] end
	local r = CreateFrame("Frame", nil, info.list)
	r:SetSize(200, ROW_H)
	r.group = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	r.group:SetPoint("LEFT", 2, 0)
	r.group:SetWidth(12)
	r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.name:SetPoint("LEFT", 16, 0)
	r.name:SetWidth(96)
	r.name:SetJustifyH("LEFT")
	r.name:SetWordWrap(false)
	r.bar = CreateFrame("StatusBar", nil, r)
	r.bar:SetStatusBarTexture(WHITE)
	r.bar:SetMinMaxValues(0, 100)
	r.bar:SetPoint("LEFT", 116, 0)
	r.bar:SetSize(52, 8)
	r.bar.bg = r.bar:CreateTexture(nil, "BACKGROUND")
	r.bar.bg:SetAllPoints()
	r.bar.bg:SetColorTexture(0, 0, 0, 0.6)
	r.value = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	r.value:SetPoint("LEFT", r.bar, "RIGHT", 4, 0)
	r.value:SetWidth(40)
	r.value:SetJustifyH("LEFT")
	rows[i] = r
	return r
end

local function durColor(pct)
	local low = db.low
	if pct <= low then return 1, 0.25, 0.25 end
	if pct < 60 then return 1, 0.8, 0.2 end
	return 0.3, 1, 0.3
end

function M:RefreshInfo()
	if not info then return end
	local members = roster()
	local columns = #members > 20 and 2 or 1
	local perColumn = math.ceil(#members / columns)
	local colWidth = 200

	local sum, count, lowList, noData = 0, 0, {}, 0
	for i, m in ipairs(members) do
		local r = getRow(i)
		r:ClearAllPoints()
		local col = math.floor((i - 1) / perColumn)
		r:SetPoint("TOPLEFT", info.list, "TOPLEFT", col * (colWidth + 8), -((i - 1) % perColumn) * ROW_H)
		r.group:SetText(IsInRaid() and m.group or "")

		local _, class = UnitClass(m.unit)
		local c = class and RAID_CLASS_COLORS[class]
		local level = NS(UnitLevel(m.unit))
		local status = ""
		if not UnitIsConnected(m.unit) then
			status = " " .. L["|cff888888(desc.)|r"]
		elseif UnitIsDeadOrGhost(m.unit) then
			status = " " .. L["|cffff4040(muerto)|r"]
		end
		r.name:SetText(string.format("|cff%02x%02x%02x%s|r |cffaaaaaa%s|r%s",
			(c and c.r or 1) * 255, (c and c.g or 1) * 255, (c and c.b or 1) * 255, m.name,
			(level and level > 0) and level or "??", status))

		local data
		if UnitIsUnit(m.unit, "player") then
			local pct, low, broken = myDurability()
			data = { pct = pct, low = low, broken = broken }
		else
			data = durability[m.name]
		end
		if data then
			r.bar:SetValue(data.pct)
			r.bar:SetStatusBarColor(durColor(data.pct))
			r.value:SetText(data.pct .. "%" .. (data.broken > 0 and (" " .. L["|cffff4040%d rotas|r"]:format(data.broken)) or ""))
			r.bar:Show()
			sum, count = sum + data.pct, count + 1
			if data.pct <= db.low or data.broken > 0 then lowList[#lowList + 1] = m.name .. " (" .. data.pct .. "%)" end
		else
			r.bar:Hide()
			r.value:SetText("|cff666666—|r")
			noData = noData + 1
		end
		r:Show()
	end
	for i = #members + 1, #rows do rows[i]:Hide() end

	local summary = count > 0 and string.format(L["Media |cffffffff%d%%|r"], sum / count) or L["Sin datos"]
	if #lowList > 0 then summary = summary .. "  ·  " .. string.format(L["|cffff4040%d por reparar|r"], #lowList) end
	if noData > 0 then summary = summary .. "  ·  " .. string.format(L["|cff888888%d sin Rheizor|r"], noData) end
	info.summary:SetText(summary)
	info.lowList = lowList

	local height = math.max(perColumn, 1) * ROW_H
	info.list:SetSize(columns * colWidth + (columns - 1) * 8, height)
	info:SetSize(math.max(info.list:GetWidth() + 20, 300), height + 74)
end

local function createInfo()
	info = CreateFrame("Frame", "RheizorRaidInfo", bar, "BackdropTemplate")
	info:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	info:SetFrameStrata("MEDIUM")
	info:Hide()

	info.title = info:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	info.title:SetPoint("TOPLEFT", 10, -8)
	info.title:SetText(L["Estado del grupo"])
	info.summary = info:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	info.summary:SetPoint("TOPLEFT", 10, -26)

	info.list = CreateFrame("Frame", nil, info)
	info.list:SetPoint("TOPLEFT", 10, -44)

	local ask = flatButton(info, 70, 20, L["Actualizar"], function()
		lastRequest = 0
		requestDurability()
		shareDurability(true)
		M:RefreshInfo()
	end)
	ask:SetPoint("BOTTOMLEFT", 10, 8)
	tooltip(ask, L["Pedir datos"], L["Pide la durabilidad a todos los del grupo que llevan Rheizor."])

	local warn = flatButton(info, 110, 20, L["Avisar de reparar"], function()
		if not info.lowList or #info.lowList == 0 then
			R:Print(L["Nadie por debajo del %d%%."]:format(db.low))
			return
		end
		local chan = groupChannel()
		if chan then sendChat(L["Reparad: %s"]:format(table.concat(info.lowList, ", ")), chan) end
	end)
	warn:SetPoint("LEFT", ask, "RIGHT", 6, 0)
	tooltip(warn, L["Avisar de reparar"], L["Escribe en el chat del grupo quién está por debajo del umbral o con piezas rotas."])

	info:SetScript("OnShow", function()
		requestDurability()
		M:RefreshInfo()
	end)
	local elapsedSince = 0
	info:SetScript("OnUpdate", function(_, elapsed)
		elapsedSince = elapsedSince + elapsed
		if elapsedSince > 2 then
			elapsedSince = 0
			M:RefreshInfo()
		end
	end)
end

function M:PlaceInfo()
	if not info then return end
	info:ClearAllPoints()
	local bottom = bar:GetBottom()
	if bottom and bottom * bar:GetEffectiveScale() < 300 then
		info:SetPoint("BOTTOMLEFT", bar, "TOPLEFT", 0, 4)
	else
		info:SetPoint("TOPLEFT", bar, "BOTTOMLEFT", 0, -4)
	end
end

----------------------------------------------------------------------
-- Barra
----------------------------------------------------------------------

local worldButtons = {}
local separators = {}

local function separator(x, height)
	local t = bar:CreateTexture(nil, "ARTWORK")
	t:SetWidth(1)
	t:SetPoint("TOPLEFT", x, -PAD - 2)
	t:SetHeight(height)
	separators[#separators + 1] = t
	return t
end

local function createBar()
	bar = CreateFrame("Frame", "RheizorRaidTools", UIParent, "SecureHandlerStateTemplate,BackdropTemplate")
	bar:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	bar:SetFrameStrata("MEDIUM")

	local x = PAD

	-- Iconos de banda (botones seguros: el motor actual no deja marcar desde
	-- código normal de un addon)
	for i = 1, 8 do
		local b = flatButton(bar, S, S, nil, nil, "SecureActionButtonTemplate")
		b:RegisterForClicks("AnyUp", "AnyDown")
		b:SetAttribute("type", "raidtarget")
		b:SetAttribute("unit", "target")
		b:SetAttribute("marker", i)
		b:SetAttribute("action1", "toggle")
		b:SetAttribute("action2", "clear")
		iconOn(b, RAID_ICON .. i, 3)
		b:SetPoint("TOPLEFT", x, -PAD)
		tooltip(b, RAID_NAMES[i], L["Clic: poner en tu objetivo (otra vez para quitarlo)."], L["Clic derecho: quitarlo."])
		markButtons[i] = b
		x = x + S + 2
	end
	local clear = flatButton(bar, S, S, X_ICON, nil, "SecureActionButtonTemplate")
	clear:RegisterForClicks("AnyUp", "AnyDown")
	clear:SetAttribute("type", "raidtarget")
	clear:SetAttribute("unit", "target")
	clear:SetAttribute("action", "clear")
	clear:SetPoint("TOPLEFT", x, -PAD)
	tooltip(clear, L["Quitar icono"], L["Quita el icono de tu objetivo."])
	x = x + S + 8
	separator(x - 5, S - 4)

	-- Pull
	bar.pullLabel = bar:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	bar.pullLabel:SetPoint("TOPLEFT", x, -PAD)
	bar.pullLabel:SetSize(40, S)
	bar.pullLabel:SetText(L["Pull"])
	x = x + 42
	bar.pullButtons = {}
	for i = 1, 3 do
		local b = flatButton(bar, 30, S, "", function() M:Pull(db["pull" .. i]) end)
		b:SetPoint("TOPLEFT", x, -PAD)
		tooltip(b, L["Cuenta atrás de pull"], L["Inicia una cuenta atrás visible para todo el grupo."])
		bar.pullButtons[i] = b
		x = x + 32
	end
	local cancel = flatButton(bar, S, S, STOP_ICON, function() M:CancelPull() end)
	cancel:SetPoint("TOPLEFT", x, -PAD)
	tooltip(cancel, L["Cancelar pull"])
	x = x + S + 8
	separator(x - 5, S - 4)

	-- Listos y roles
	local ready = flatButton(bar, S, S, nil, function()
		if C_PartyInfo and C_PartyInfo.DoReadyCheck then C_PartyInfo.DoReadyCheck() elseif DoReadyCheck then DoReadyCheck() end
	end)
	iconOn(ready, "Interface\\RaidFrame\\ReadyCheck-Ready", 4)
	ready:SetPoint("TOPLEFT", x, -PAD)
	tooltip(ready, L["¿Listos?"], L["Comprobación de listos (líder o ayudante)."])
	x = x + S + 2
	if InitiateRolePoll then
		local role = flatButton(bar, S, S, L["Rol"], function() InitiateRolePoll() end)
		role:SetPoint("TOPLEFT", x, -PAD)
		tooltip(role, L["Comprobar roles"], L["Pide a cada uno que elija su rol."])
		x = x + S + 2
	end
	x = x + 6
	separator(x - 5, S - 4)

	-- Panel de información
	local infoButton = flatButton(bar, S, S, nil, function()
		if not info then createInfo() end
		M:PlaceInfo()
		info:SetShown(not info:IsShown())
	end)
	iconOn(infoButton, "Interface\\Icons\\Trade_BlackSmithing", 3):SetTexCoord(0.08, 0.92, 0.08, 0.92)
	infoButton:SetPoint("TOPLEFT", x, -PAD)
	tooltip(infoButton, L["Estado del grupo"], L["Durabilidad, nivel y estado de cada miembro."])
	x = x + S + PAD

	bar.rowWidth = x

	-- Marcadores de mundo (botones seguros: funcionan en combate)
	bar.worldRow = CreateFrame("Frame", nil, bar)
	bar.worldRow:SetPoint("TOPLEFT", 0, -(PAD + S + 4))
	bar.worldRow:SetSize(x, S)
	local wx = PAD
	for i = 1, 8 do
		local b = CreateFrame("Button", nil, bar.worldRow, "SecureActionButtonTemplate")
		styleButton(b, S, S)
		iconOn(b, RAID_ICON .. WORLD_ICON[i], 5)
		b:RegisterForClicks("AnyUp", "AnyDown")
		b:SetAttribute("type", "worldmarker")
		b:SetAttribute("marker", i)
		b:SetAttribute("action1", "toggle")
		b:SetAttribute("action2", "clear")
		b:SetPoint("TOPLEFT", wx, 0)
		tooltip(b, L["Marcador: %s"]:format(WORLD_NAMES[i]), L["Clic: ponerlo en el suelo donde apuntes (o quitarlo)."], L["Clic derecho: quitarlo."])
		b.floor = b:CreateTexture(nil, "OVERLAY")
		b.floor:SetPoint("BOTTOMLEFT", 2, 2)
		b.floor:SetPoint("BOTTOMRIGHT", -2, 2)
		b.floor:SetHeight(2)
		worldButtons[i] = b
		wx = wx + S + 2
	end
	local wclear = CreateFrame("Button", nil, bar.worldRow, "SecureActionButtonTemplate")
	styleButton(wclear, S, S)
	wclear.text = wclear:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	wclear.text:SetPoint("CENTER")
	wclear.text:SetText(X_ICON)
	wclear:RegisterForClicks("AnyUp", "AnyDown")
	wclear:SetAttribute("type", "worldmarker")
	wclear:SetAttribute("action", "clear")
	wclear:SetPoint("TOPLEFT", wx, 0)
	tooltip(wclear, L["Quitar todos los marcadores de mundo"])

	-- Pings (sistema nuevo): se lanzan con /ping desde botones seguros.
	-- Al hacer clic se usa tu objetivo; con tecla asignada, lo que tengas bajo el ratón.
	bar.pingRow = CreateFrame("Frame", nil, bar)
	bar.pingRow:SetPoint("TOPLEFT", 0, -(PAD + S + 4))
	bar.pingRow:SetSize(x, S)
	local px = PAD
	for _, ping in ipairs(PINGS) do
		local b = CreateFrame("Button", "RheizorPing" .. ping.key, bar.pingRow, "SecureActionButtonTemplate")
		styleButton(b, 64, S)
		b.icon = b:CreateTexture(nil, "ARTWORK")
		b.icon:SetSize(S - 6, S - 6)
		b.icon:SetPoint("LEFT", 3, 0)
		setPingIcon(b.icon, ping)
		b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
		b.text:SetPoint("LEFT", b.icon, "RIGHT", 3, 0)
		b.text:SetPoint("RIGHT", -2, 0)
		b.text:SetJustifyH("LEFT")
		b.text:SetWordWrap(false)
		b.text:SetText(ping.short)
		b:RegisterForClicks("AnyUp", "AnyDown")
		b:SetAttribute("type", "macro")
		b:SetAttribute("macrotext", "/ping [@mouseover,exists][@target,exists][] " .. ping.token)
		b:SetPoint("TOPLEFT", px, 0)
		tooltip(b, L["Ping: %s"]:format(ping.name),
			L["Clic: sobre tu objetivo."],
			L["Con tecla asignada (Teclado > AddOns > Rheizor): sobre lo que tengas bajo el ratón, o tu objetivo."],
			L["|cff888888Para pings en el suelo, usa la rueda de ping del juego (su tecla en Teclado).|r"])
		px = px + 66
	end

	-- Pestaña para arrastrar (encima de la barra, sin tapar los botones)
	bar:SetMovable(true)
	bar:SetClampedToScreen(true)
	R:RegisterMovable(bar)
	local handle = CreateFrame("Frame", nil, bar, "BackdropTemplate")
	handle:SetSize(170, 16)
	handle:SetPoint("BOTTOMLEFT", bar, "TOPLEFT", 0, 2)
	handle:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	handle:SetBackdropColor(0.1, 0.5, 0.8, 0.6)
	handle:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
	handle.text = handle:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	handle.text:SetPoint("CENTER")
	handle.text:SetText(L["Arrastra aquí para mover"])
	handle:EnableMouse(true)
	handle:RegisterForDrag("LeftButton")
	handle:SetScript("OnDragStart", function()
		if not InCombatLockdown() then bar:StartMoving() end
	end)
	handle:SetScript("OnDragStop", function()
		bar:StopMovingOrSizing()
		bar:SetUserPlaced(false)
		local point, _, relPoint, px, py = bar:GetPoint()
		db.point = { point, relPoint, px, py }
	end)
	R:AddNudge(handle, bar)
	function handle:Place()
		local p = db.point or { "TOP", "TOP", 0, -20 }
		bar:ClearAllPoints()
		bar:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	end
	bar.mover = handle

	-- Cuenta atrás en la etiqueta de pull
	local throttle = 0
	bar:SetScript("OnUpdate", function(_, elapsed)
		throttle = throttle + elapsed
		if throttle < 0.1 then return end
		throttle = 0
		local left = pull.endTime and pull.endTime - GetTime()
		if left and left > 0 then
			bar.pullLabel:SetText(string.format("|cffff4040%d|r", math.ceil(left)))
		else
			pull.endTime = nil
			bar.pullLabel:SetText(L["Pull"])
		end
	end)
end

function M:ApplyStyle()
	if not bar then return end
	local r, g, b = accent()
	R:RunOutOfCombat(function() bar:SetScale(db.scale) end)
	bar:SetBackdropColor(0.04, 0.04, 0.06, db.bgAlpha)
	bar:SetBackdropBorderColor(r, g, b, 0.8)
	for _, t in ipairs(separators) do t:SetColorTexture(r, g, b, 0.35) end
	for i, btn in ipairs(bar.pullButtons) do btn.text:SetText(db["pull" .. i]) end
	if info then
		info:SetScale(1)
		info:SetBackdropColor(0.04, 0.04, 0.06, math.max(db.bgAlpha, 0.85))
		info:SetBackdropBorderColor(r, g, b, 0.8)
	end
	self:UpdateMarks()
end

-- Tamaño, fila de marcadores y visibilidad: solo fuera de combate (la barra
-- contiene botones seguros)
function M:ApplyLayout()
	R:RunOutOfCombat(function()
		if not bar then return end
		bar.worldRow:SetShown(db.row == "world")
		bar.pingRow:SetShown(db.row == "ping")
		local height = PAD + S + PAD + (db.row ~= "none" and (S + 4) or 0)
		bar:SetSize(bar.rowWidth, height)
		bar.mover:Place()
		bar.mover:SetShown(not db.locked)

		local cond = "show"
		if not db.enabled then
			cond = "hide"
		elseif not db.locked then
			cond = "show"
		elseif db.show == "group" then
			cond = "[group] show; hide"
		elseif db.show == "raid" then
			cond = "[group:raid] show; hide"
		end
		if db.enabled and db.hideCombat and db.locked then cond = "[combat] hide; " .. cond end
		if not db.enabled and info then info:Hide() end
		RegisterStateDriver(bar, "visibility", cond)
		self:PlaceInfo()
	end)
end

function M:ResetPosition()
	db.point = nil
	self:ApplyLayout()
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, ...)
	if event == "CHAT_MSG_ADDON" then
		onAddonMessage(...)
	elseif event == "START_TIMER" then
		local _, remaining = ...
		remaining = NS(remaining)
		if remaining and remaining > 0 then pull.endTime = GetTime() + remaining end
	elseif event == "STOP_TIMER_OF_TYPE" then
		pull.endTime = nil
	elseif event == "UPDATE_INVENTORY_DURABILITY" then
		shareDurability(false)
	elseif event == "PLAYER_ENTERING_WORLD" then
		-- Al salir de una mazmorra o banda los mensajes entre addons vuelven a ir
		C_Timer.After(3, function() shareDurability(true) end)
	elseif event == "GROUP_ROSTER_UPDATE" or event == "PARTY_LEADER_CHANGED" then
		M:UpdateMarks()
		if event == "GROUP_ROSTER_UPDATE" then shareDurability(false) end
		if info and info:IsShown() then M:RefreshInfo() end
	end
end)

-- Crea la barra y empieza a escuchar (la barra tiene botones seguros: fuera de combate)
function M:Setup()
	if bar then return end
	if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
		C_ChatInfo.RegisterAddonMessagePrefix(PREFIX)
	end

	createBar()
	self:ApplyStyle()
	self:ApplyLayout()

	for _, event in ipairs({ "CHAT_MSG_ADDON", "UPDATE_INVENTORY_DURABILITY", "GROUP_ROSTER_UPDATE",
		"PARTY_LEADER_CHANGED", "PLAYER_ENTERING_WORLD", "START_TIMER", "STOP_TIMER_OF_TYPE" }) do
		pcall(events.RegisterEvent, events, event)
	end
	C_Timer.After(5, function() shareDurability(true) end)
end

function M:OnEnable()
	db = self.db
	if db.enabled then self:Setup() end
end

function M:OnOptionChanged(key, value)
	if key == "enabled" then
		-- Activar sin recargar: se crea ahora; desactivar: se oculta
		if value and not bar then
			R:RunOutOfCombat(function() M:Setup() end)
		else
			self:ApplyLayout()
		end
		return
	end
	if not bar then return end
	if key == "locked" or key == "show" or key == "hideCombat" or key == "row" then
		self:ApplyLayout()
	elseif key == "low" then
		if info and info:IsShown() then self:RefreshInfo() end
	else
		self:ApplyStyle()
	end
end
