-- Rheizor-Cooldowns: piezas compartidas por los dos módulos (el estilo del
-- gestor de Blizzard, Viewers.lua, y las barras propias, Bars.lua):
-- listas de valores, fuentes, bordes, colocación en rejilla, anclajes y
-- reglas de visibilidad.
--
-- WoW Forever: en combate los tiempos de reutilización, las auras y muchos
-- valores llegan "secretos" (no se pueden comparar ni operar). Aquí nada
-- opera con ellos: se dibujan con objetos de duración y con los propios
-- marcos de Blizzard, y todo lo que se lee pasa por pcall y R.NotSecret.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret

ns.WHITE = "Interface\\Buttons\\WHITE8X8"

----------------------------------------------------------------------
-- Listas de valores (las traduce RegisterModule al registrar)
----------------------------------------------------------------------

ns.FONTS = {
	{ "arialn", "Arial Narrow" },
	{ "default", "Fuente del juego" },
	{ "friz", "Friz Quadrata" },
	{ "skurri", "Skurri" },
	{ "morpheus", "Morpheus" },
}

local FONT_FILES = {
	arialn = "Fonts\\ARIALN.TTF",
	friz = "Fonts\\FRIZQT__.TTF",
	skurri = "Fonts\\skurri.ttf",
	morpheus = "Fonts\\MORPHEUS.TTF",
}
for _, f in ipairs(R.EXTRA_FONTS or {}) do
	ns.FONTS[#ns.FONTS + 1] = { f[1], f[3] }
	FONT_FILES[f[1]] = f[2]
end

ns.OUTLINES = {
	{ "OUTLINE", "Contorno fino" },
	{ "THICKOUTLINE", "Contorno grueso" },
	{ "MONOCHROME,OUTLINE", "Contorno pixelado" },
	{ "NONE", "Sin contorno" },
}

ns.POINTS = {
	{ "CENTER", "Centro" },
	{ "TOP", "Arriba" },
	{ "BOTTOM", "Abajo" },
	{ "LEFT", "Izquierda" },
	{ "RIGHT", "Derecha" },
	{ "TOPLEFT", "Arriba a la izquierda" },
	{ "TOPRIGHT", "Arriba a la derecha" },
	{ "BOTTOMLEFT", "Abajo a la izquierda" },
	{ "BOTTOMRIGHT", "Abajo a la derecha" },
}

ns.GROW = {
	{ "right", "Hacia la derecha" },
	{ "left", "Hacia la izquierda" },
	{ "down", "Hacia abajo" },
	{ "up", "Hacia arriba" },
}

ns.ROWS = {
	{ "after", "Debajo o a la derecha" },
	{ "before", "Encima o a la izquierda" },
}

ns.ALIGN = {
	{ "start", "Al principio" },
	{ "center", "Centradas" },
	{ "end", "Al final" },
}

ns.SHOW = {
	{ "always", "Siempre" },
	{ "combat", "Solo en combate" },
	{ "target", "Con objetivo" },
	{ "combattarget", "En combate o con objetivo" },
	{ "nocombat", "Solo fuera de combate" },
	{ "mouseover", "Al pasar el ratón" },
}

ns.WHERE = {
	{ "any", "En cualquier sitio" },
	{ "instance", "Solo en mazmorras y bandas" },
	{ "world", "Solo fuera de mazmorras y bandas" },
}

ns.GROUP = {
	{ "any", "Solo o en grupo" },
	{ "solo", "Solo yendo solo" },
	{ "group", "Solo en grupo o banda" },
}

-- Texto de un valor en una de estas listas
function ns.ValueText(values, value)
	for _, v in ipairs(values) do
		if v[1] == value then return L[v[2]] end
	end
	return tostring(value or "")
end

----------------------------------------------------------------------
-- Fuentes
----------------------------------------------------------------------

function ns.FontFile(key)
	return FONT_FILES[key] or STANDARD_TEXT_FONT
end

-- Pone fuente, tamaño y contorno; si el archivo no existe en este cliente
-- (idiomas con otro alfabeto) usa la fuente del juego
function ns.SetFont(fs, key, size, outline)
	if not fs or not fs.SetFont then return end
	local flags = (outline == "NONE" or not outline) and "" or outline
	local ok, set = pcall(fs.SetFont, fs, ns.FontFile(key), size or 12, flags)
	if not ok or not set then pcall(fs.SetFont, fs, STANDARD_TEXT_FONT, size or 12, flags) end
	fs:SetShadowOffset(0, 0)
end

function ns.Color(hex, alpha)
	local r, g, b = R.HexToRGB(hex)
	return r, g, b, alpha or 1
end

----------------------------------------------------------------------
-- Borde fino con cuatro texturas (sin BackdropTemplate, que opera con el
-- ancho del marco). Queda por dentro del icono, así las medidas no cambian.
----------------------------------------------------------------------

function ns.Border(owner, parentFrame)
	local f = CreateFrame("Frame", nil, parentFrame or owner)
	f:SetAllPoints(owner)
	f.edges = {}
	for i = 1, 4 do
		f.edges[i] = f:CreateTexture(nil, "OVERLAY", nil, 7)
		f.edges[i]:SetTexture(ns.WHITE)
	end
	function f:SetLook(size, r, g, b, a)
		local e = self.edges
		for i = 1, 4 do e[i]:ClearAllPoints() end
		if not size or size <= 0 then
			for i = 1, 4 do e[i]:Hide() end
			return
		end
		e[1]:SetPoint("TOPLEFT") e[1]:SetPoint("TOPRIGHT") e[1]:SetHeight(size)
		e[2]:SetPoint("BOTTOMLEFT") e[2]:SetPoint("BOTTOMRIGHT") e[2]:SetHeight(size)
		e[3]:SetPoint("TOPLEFT") e[3]:SetPoint("BOTTOMLEFT") e[3]:SetWidth(size)
		e[4]:SetPoint("TOPRIGHT") e[4]:SetPoint("BOTTOMRIGHT") e[4]:SetWidth(size)
		for i = 1, 4 do
			e[i]:SetVertexColor(r or 0, g or 0, b or 0, a or 1)
			e[i]:Show()
		end
	end
	return f
end

-- Recorte del icono (zoom) corrigiendo la proporción si no es cuadrado
function ns.TexCoord(w, h, zoom)
	zoom = zoom or 0
	local l, r, t, b = zoom, 1 - zoom, zoom, 1 - zoom
	if w and h and w > 0 and h > 0 then
		local ratio = w / h
		local span = 1 - 2 * zoom
		if ratio > 1 then
			local cut = span * (1 - 1 / ratio) / 2
			t, b = t + cut, b - cut
		elseif ratio < 1 then
			local cut = span * (1 - ratio) / 2
			l, r = l + cut, r - cut
		end
	end
	return l, r, t, b
end

----------------------------------------------------------------------
-- Rejilla: coloca marcos del mismo tamaño en filas (o columnas).
-- o = { w, h, gap, perRow, grow, rowGrow, align }
-- Devuelve el ancho y alto que ocupan.
----------------------------------------------------------------------

function ns.LayoutGrid(container, frames, o)
	local n = #frames
	local per = math.max(1, math.min(o.perRow or 1, math.max(n, 1)))
	local rows = math.max(1, math.ceil(n / per))
	local horizontal = (o.grow == "right" or o.grow == "left")
	local w, h, gap = o.w, o.h, o.gap or 0
	local stepX, stepY = w + gap, h + gap
	local W, H
	if horizontal then
		W = per * w + (per - 1) * gap
		H = rows * h + (rows - 1) * gap
	else
		W = rows * w + (rows - 1) * gap
		H = per * h + (per - 1) * gap
	end
	for i, f in ipairs(frames) do
		local line = math.floor((i - 1) / per)
		local pos = (i - 1) % per
		local inLine = (line == rows - 1) and (n - line * per) or per
		local shift = 0
		if o.align == "center" then
			shift = (per - inLine) / 2
		elseif o.align == "end" then
			shift = per - inLine
		end
		local p = pos + shift
		local x, y
		if horizontal then
			x = (o.grow == "right") and p * stepX or (W - w - p * stepX)
			y = (o.rowGrow == "before") and (H - h - line * stepY) or line * stepY
		else
			y = (o.grow == "down") and p * stepY or (H - h - p * stepY)
			x = (o.rowGrow == "before") and (W - w - line * stepX) or line * stepX
		end
		f:ClearAllPoints()
		f:SetPoint("TOPLEFT", container, "TOPLEFT", x, -y)
	end
	return math.max(W, 1), math.max(H, 1)
end

-- El punto de anclaje que hace que el grupo crezca en la dirección elegida
-- (hacia la derecha: se ancla por la izquierda; centradas: por el centro…)
function ns.GrowthPoint(o)
	local horizontal = (o.grow == "right" or o.grow == "left")
	local v, hz
	if horizontal then
		v = (o.rowGrow == "before") and "BOTTOM" or "TOP"
		if o.align == "center" then hz = "" else hz = (o.grow == "right") and "LEFT" or "RIGHT" end
	else
		hz = (o.rowGrow == "before") and "RIGHT" or "LEFT"
		if o.align == "center" then v = "" else v = (o.grow == "down") and "TOP" or "BOTTOM" end
	end
	local p = v .. hz
	return p ~= "" and p or "CENTER"
end

-- Guarda la posición de un marco en db[key] como { punto, "BOTTOMLEFT", x, y }
-- tomando como referencia el punto indicado (así crece hacia donde toca)
function ns.SavePoint(frame, db, key, point)
	local left, bottom, width, height = frame:GetLeft(), frame:GetBottom(), frame:GetWidth(), frame:GetHeight()
	if not left then return end
	local s = frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
	left, bottom, width, height = left * s, bottom * s, width * s, height * s
	local x, y = left + width / 2, bottom + height / 2
	if point:find("LEFT") then x = left elseif point:find("RIGHT") then x = left + width end
	if point:find("TOP") then y = bottom + height elseif point:find("BOTTOM") then y = bottom end
	db[key] = { point, "BOTTOMLEFT", math.floor(x / s + 0.5), math.floor(y / s + 0.5) }
end

----------------------------------------------------------------------
-- Visibilidad: siempre / en combate / con objetivo / al pasar el ratón,
-- ocultar montado, solo en mazmorras, opacidad fuera de combate.
-- Cada marco se registra con una función que devuelve su configuración y
-- otra que aplica la opacidad. Los valores dudosos (secretos) no cambian
-- nada: se mantiene el último estado conocido.
----------------------------------------------------------------------

local targets = {}          -- { frame, get = fn() -> cfg, apply = fn(alpha) }
local state = { combat = false, target = false, mounted = false, instance = false, group = false }
ns.visState = state
ns.forceShow = false        -- editor abierto o marcos desbloqueados
ns.editMode = false         -- Modo edición de Blizzard

local ticker

local function readState()
	local c = NS(UnitAffectingCombat("player"))
	if c ~= nil then state.combat = c and true or false end
	if InCombatLockdown() then state.combat = true end
	local t = NS(UnitExists("target"))
	if t ~= nil then state.target = t and true or false end
	local m = IsMounted and NS(IsMounted())
	if m ~= nil then state.mounted = m and true or false end
	local g = IsInGroup and NS(IsInGroup())
	if g ~= nil then state.group = g and true or false end
	local ok, inInstance, kind = pcall(IsInInstance)
	if ok then
		inInstance, kind = NS(inInstance), NS(kind)
		if inInstance ~= nil then
			state.instance = inInstance and (kind == "party" or kind == "raid" or kind == "scenario") or false
		end
	end
end

local function hovering(frame)
	return frame and frame:IsVisible() and frame:IsMouseOver() or false
end

-- Devuelve si se ve y si es por tener el ratón encima
local function wanted(cfg, frame)
	if ns.forceShow or ns.editMode then return true end
	-- "También al pasar el ratón": el ratón encima gana a todo lo demás
	if cfg.hoverShow and hovering(frame) then return true, true end
	if cfg.hideMounted and state.mounted then return false end
	if cfg.where == "instance" and not state.instance then return false end
	if cfg.where == "world" and state.instance then return false end
	if cfg.group == "solo" and state.group then return false end
	if cfg.group == "group" and not state.group then return false end
	local show = cfg.show or "always"
	if show == "combat" then return state.combat end
	if show == "nocombat" then return not state.combat end
	if show == "target" then return state.target end
	if show == "combattarget" then return state.combat or state.target end
	if show == "mouseover" then
		local over = hovering(frame)
		return over, over
	end
	return true
end

function ns.UpdateVisibility()
	local anyMouse = false
	for _, t in ipairs(targets) do
		local cfg = t.get()
		if cfg then
			if cfg.show == "mouseover" or cfg.hoverShow then anyMouse = true end
			local alpha
			local show, byMouse = wanted(cfg, t.frame)
			if show then
				alpha = (byMouse or state.combat or ns.forceShow or ns.editMode) and 1 or (cfg.oocAlpha or 1)
			else
				alpha = cfg.hiddenAlpha or 0
			end
			if t.alpha ~= alpha then
				t.alpha = alpha
				t.apply(alpha)
			end
		end
	end
	-- El ratón se mira 6 veces por segundo, solo si algún marco lo usa
	if anyMouse and not ticker then
		ticker = C_Timer.NewTicker(0.15, ns.UpdateVisibility)
	elseif not anyMouse and ticker then
		ticker:Cancel()
		ticker = nil
	end
end

-- Vuelve a aplicar la opacidad aunque no haya cambiado (tras reconstruir)
function ns.RefreshVisibility()
	for _, t in ipairs(targets) do t.alpha = nil end
	ns.UpdateVisibility()
end

function ns.RegisterVisibility(frame, get, apply)
	targets[#targets + 1] = { frame = frame, get = get, apply = apply }
	ns.UpdateVisibility()
end

function ns.UnregisterVisibility(frame)
	for i = #targets, 1, -1 do
		if targets[i].frame == frame then table.remove(targets, i) end
	end
end

local visEvents = CreateFrame("Frame")
visEvents:SetScript("OnEvent", function(_, event)
	if event == "PLAYER_REGEN_DISABLED" then
		state.combat = true
	elseif event == "PLAYER_REGEN_ENABLED" then
		state.combat = false
		readState()
	else
		readState()
	end
	ns.UpdateVisibility()
end)

local started = false
function ns.StartVisibility()
	if started then return end
	started = true
	for _, e in ipairs({ "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_TARGET_CHANGED",
		"PLAYER_MOUNT_DISPLAY_CHANGED", "PLAYER_ENTERING_WORLD", "ZONE_CHANGED_NEW_AREA", "GROUP_ROSTER_UPDATE" }) do
		pcall(visEvents.RegisterEvent, visEvents, e)
	end
	-- Por si montar no avisa con su propio evento en esta versión
	pcall(visEvents.RegisterUnitEvent, visEvents, "UNIT_AURA", "player")
	if EventRegistry and EventRegistry.RegisterCallback then
		EventRegistry:RegisterCallback("EditMode.Enter", function()
			ns.editMode = true
			ns.UpdateVisibility()
		end, ns)
		EventRegistry:RegisterCallback("EditMode.Exit", function()
			ns.editMode = false
			ns.UpdateVisibility()
		end, ns)
	end
	readState()
end

----------------------------------------------------------------------
-- Teclas: qué tecla tiene asignada la casilla de la barra de acción donde
-- está un hechizo u objeto
----------------------------------------------------------------------

local BAR_COMMANDS = {
	{ 1, 12, "ACTIONBUTTON" },
	{ 25, 36, "MULTIACTIONBAR3BUTTON" },
	{ 37, 48, "MULTIACTIONBAR4BUTTON" },
	{ 49, 60, "MULTIACTIONBAR2BUTTON" },
	{ 61, 72, "MULTIACTIONBAR1BUTTON" },
	{ 73, 132, "ACTIONBUTTON" },          -- barras de forma/actitud: las teclas de la principal
	{ 145, 156, "MULTIACTIONBAR5BUTTON" },
	{ 157, 168, "MULTIACTIONBAR6BUTTON" },
	{ 169, 180, "MULTIACTIONBAR7BUTTON" },
}

local function shortKey(key)
	key = key:upper()
	key = key:gsub("SHIFT%-", "S"):gsub("CTRL%-", "C"):gsub("ALT%-", "A"):gsub("META%-", "M")
	key = key:gsub("MOUSEWHEELUP", "WU"):gsub("MOUSEWHEELDOWN", "WD"):gsub("BUTTON", "M")
	key = key:gsub("NUMPAD", "N"):gsub("SPACE", "Sp")
	return key
end

local function slotKey(slot)
	for _, r in ipairs(BAR_COMMANDS) do
		if slot >= r[1] and slot <= r[2] then
			local index = (slot - r[1]) % 12 + 1
			local key = GetBindingKey(r[3] .. index)
			if key then return shortKey(key) end
		end
	end
end

-- Mapa { spell = { [id] = "tecla" }, item = { [id] = "tecla" } } de las
-- barras de acción (se rehace cuando cambian barras o teclas)
local keyMap
function ns.InvalidateKeys()
	keyMap = nil
end

local function buildKeys()
	keyMap = { spell = {}, item = {} }
	if not GetActionInfo then return end
	for slot = 1, 180 do
		local ok, kind, id = pcall(GetActionInfo, slot)
		kind, id = ok and NS(kind), ok and NS(id)
		if (kind == "spell" or kind == "item") and type(id) == "number" and not keyMap[kind][id] then
			local key = slotKey(slot)
			if key then keyMap[kind][id] = key end
		end
	end
end

function ns.KeyFor(kind, id)
	if not id then return end
	if not keyMap then buildKeys() end
	local key = keyMap[kind] and keyMap[kind][id]
	if key or kind ~= "spell" then return key end
	-- El hechizo puede estar en la barra con su versión mejorada
	if C_Spell and C_Spell.GetOverrideSpell then
		local ok, other = pcall(C_Spell.GetOverrideSpell, id)
		other = ok and NS(other)
		if other and other ~= id then return keyMap.spell[other] end
	end
end

----------------------------------------------------------------------
-- Hechizos: conocido, icono, nombre
----------------------------------------------------------------------

function ns.KnowsSpell(id)
	if type(id) ~= "number" then return false end
	-- (no se usa ipairs: alguna de estas funciones puede no existir)
	local fns = { C_SpellBook and C_SpellBook.IsSpellKnown or false, IsPlayerSpell or false, IsSpellKnown or false }
	for i = 1, #fns do
		local fn = fns[i]
		if fn then
			local ok, known = pcall(fn, id)
			known = ok and NS(known)
			if known then return true end
		end
	end
	return false
end

function ns.SpellName(id)
	local ok, name = pcall(C_Spell.GetSpellName, id)
	return ok and NS(name) or nil
end

function ns.SpellIcon(id)
	local ok, icon = pcall(C_Spell.GetSpellTexture, id)
	return ok and NS(icon) or nil
end

function ns.ItemName(id)
	local fn = (C_Item and C_Item.GetItemNameByID) or GetItemInfo
	local ok, name = pcall(fn, id)
	return ok and NS(name) or nil
end

function ns.ItemIcon(id)
	local fn = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
	local ok, icon = pcall(fn, id)
	return ok and NS(icon) or nil
end

-- Hechizos raciales con reutilización (el primero que conozca el personaje)
ns.RACIALS = {
	20600,                              -- Percepción (humano)
	20572, 33697, 33702,                -- Furia sangrienta (orco)
	20594,                              -- Forma de piedra (enano)
	20580, 58984,                       -- Fusión de las sombras (elfo de la noche)
	7744,                               -- Voluntad de los Renegados (no-muerto)
	20549,                              -- Pisotón de guerra (tauren)
	20589,                              -- Artista del escape (gnomo)
	26297, 20554, 26296, 26635,         -- Rabiar (trol)
	28880, 59542, 59543, 59544, 59545, 59547, 59548, -- Ofrenda de los naaru (draenei)
	28730, 25046, 50613, 69179, 80483,  -- Torrente arcano (elfo de sangre)
	20577,                              -- Canibalizar (no-muerto)
}

function ns.RacialSpell()
	for _, id in ipairs(ns.RACIALS) do
		if ns.KnowsSpell(id) then return id end
	end
end

----------------------------------------------------------------------
-- Abrir la configuración del gestor de Blizzard (qué hechizos sigue)
----------------------------------------------------------------------

function ns.OpenBlizzardSettings()
	if InCombatLockdown() then
		R:Print(L["En combate no se puede abrir: vuelve a probar al salir de combate."])
		return
	end
	if not CooldownViewerSettings and C_AddOns and C_AddOns.LoadAddOn then
		pcall(C_AddOns.LoadAddOn, "Blizzard_CooldownViewer")
	end
	local s = CooldownViewerSettings
	if s and s.TogglePanel then
		local ok, err = pcall(s.TogglePanel, s)
		if not ok then R:Print(tostring(err)) end
	else
		R:Print(L["Este cliente no tiene el gestor de reutilización de Blizzard."])
	end
end
