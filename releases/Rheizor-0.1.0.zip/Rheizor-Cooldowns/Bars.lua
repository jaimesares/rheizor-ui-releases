-- Barras propias de reutilización: tantas como quieras, cada una con sus
-- hechizos (por número o nombre), objetos (pociones, piedras de salud…),
-- casillas de equipo (abalorios 13 y 14), el racial del personaje o auras
-- propias. Se ven como iconos o como barras que se vacían.
--
-- Secretos de WoW Forever: los tiempos se dibujan con objetos de duración
-- (C_Spell.GetSpellCooldownDuration, GetSpellChargeDuration,
-- C_UnitAuras.GetAuraDuration) en el marco Cooldown y con SetTimerDuration
-- en la barra; los números los pone el propio marco Cooldown. Para decidir
-- (gris, opacidad, ocultar) solo se usan campos que nunca son secretos
-- (isActive, isOnGCD, maxCharges) o valores comprobados con R.NotSecret.
-- Las cargas se escriben con SetFormattedText, que acepta secretos.
--
-- Los iconos no son botones seguros (no lanzan nada al pulsar), así que se
-- pueden recolocar, mostrar y ocultar también en combate.
--
-- La ventana para editarlas está en Editor.lua.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret

local M = R:RegisterModule("cdbars", {
	title = "Barras propias",
	defaults = {
		locked = true,
		zoom = 0.08,
		border = 1,
		borderColor = "000000",
		swipeColor = "000000",
		swipeAlpha = 0.7,
		font = "arialn",
		outline = "OUTLINE",
		cdSize = 14,
		cdColor = "ffffff",
		countSize = 12,
		countColor = "ffffff",
		keySize = 10,
		nameSize = 11,
		barTexture = ns.WHITE,
		barColor = "33ccff",
		readyColor = "2e8f5a",
		bgColor = "000000",
		bgAlpha = 0.6,
		bars = {},
		nextID = 1,
	},
	options = {
		{ type = "header", text = "Barras propias" },
		{ type = "button", name = "Editor de barras", text = "Abrir",
		  desc = "Crear, renombrar y borrar barras, añadir hechizos, objetos, abalorios y raciales, y elegir su distribución, anclaje y visibilidad. También con /rzcd o /rz cd.",
		  func = function(mod) mod:ToggleEditor() end },
		{ type = "toggle", key = "locked", name = "Bloquear posición",
		  desc = "Desbloqueadas, las barras que no están ancladas a otra muestran un recuadro para arrastrarlas." },
		{ type = "header", text = "Iconos" },
		{ type = "slider", key = "zoom", name = "Recorte del borde del icono", min = 0, max = 0.3, step = 0.01 },
		{ type = "slider", key = "border", name = "Grosor del borde", min = 0, max = 4, step = 1, format = R.fmt.int },
		{ type = "color", key = "borderColor", name = "Color del borde" },
		{ type = "color", key = "swipeColor", name = "Color de la sombra de reutilización" },
		{ type = "slider", key = "swipeAlpha", name = "Opacidad de la sombra", min = 0, max = 1, step = 0.05 },
		{ type = "header", text = "Texto" },
		{ type = "dropdown", key = "font", name = "Fuente", values = ns.FONTS },
		{ type = "dropdown", key = "outline", name = "Contorno", values = ns.OUTLINES },
		{ type = "slider", key = "cdSize", name = "Tamaño del tiempo", min = 6, max = 32, step = 1, format = R.fmt.int },
		{ type = "color", key = "cdColor", name = "Color del tiempo" },
		{ type = "slider", key = "countSize", name = "Tamaño de cargas y acumulaciones", min = 6, max = 32, step = 1, format = R.fmt.int },
		{ type = "color", key = "countColor", name = "Color de cargas y acumulaciones" },
		{ type = "slider", key = "keySize", name = "Tamaño de la tecla", min = 6, max = 24, step = 1, format = R.fmt.int },
		{ type = "slider", key = "nameSize", name = "Tamaño del nombre", min = 6, max = 24, step = 1, format = R.fmt.int },
		{ type = "header", text = "Estilo de barra" },
		{ type = "dropdown", key = "barTexture", name = "Textura de la barra", values = R.TEXTURES },
		{ type = "color", key = "barColor", name = "Color en reutilización" },
		{ type = "color", key = "readyColor", name = "Color cuando está lista" },
		{ type = "color", key = "bgColor", name = "Color del fondo" },
		{ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 },
	},
	unsupported = {
		"Seguir reutilizaciones de otros jugadores o del objetivo: necesitaría el registro de combate (COMBAT_LOG_EVENT_UNFILTERED), que en WoW Forever está cerrado para los addons.",
		"Auras propias en combate: el juego puede ocultárselas a los addons; si pasa, el icono de esa aura se ve como ausente hasta salir de combate.",
		"Pulsar un icono para lanzar el hechizo o usar el objeto: los iconos solo muestran información (así se pueden mover y ocultar también en combate).",
	},
})
ns.bars = M

-- Valores por defecto de cada barra (se completan al cargar)
M.BAR_DEFAULTS = {
	name = "",
	style = "icon",       -- icon | bar
	fill = "left",        -- estilo de barras: hacia dónde se vacía (left | right | down | up)
	iconSize = 0,         -- estilo de barras: lado del icono (0 = automático)
	iconPos = "left",     -- estilo de barras: icono a la izquierda o arriba de la barra
	width = 36,
	height = 36,
	spacing = 2,
	perRow = 12,
	grow = "right",
	rowGrow = "after",
	align = "start",
	anchorTo = "screen",  -- screen | bar:<id> | viewer:<id>
	anchorPoint = "TOP",
	anchorRel = "BOTTOM",
	x = 0,
	y = -4,
	matchWidth = false,
	show = "always",
	where = "any",
	group = "any",
	hoverShow = false,
	hideMounted = false,
	oocAlpha = 1,
	hiddenAlpha = 0,
	desaturate = true,
	cdAlpha = 1,
	glow = true,
	hideUnknown = true,
	hideReady = false,    -- ocultar lo que está disponible
	hideOnCD = false,     -- ocultar lo que está en reutilización
	keepGap = false,      -- al ocultar por estado, dejar su hueco (no se mueven los demás)
	showCount = true,
	keybind = false,
	hideGCD = true,
	tint = true,
	tooltip = true,
	showName = true,
}

-- Tipos de entrada
M.TYPES = {
	{ "spell", "Hechizo" },
	{ "item", "Objeto" },
	{ "slot", "Casilla de equipo" },
	{ "racial", "Racial" },
	{ "aura", "Aura propia" },
}

M.STYLES = {
	{ "icon", "Iconos" },
	{ "bar", "Barras" },
}

-- Solo cambia hacia dónde se vacía la barra de tiempo: ni la forma de la
-- barra ni dónde va el icono (eso es iconPos)
M.FILLS = {
	{ "left", "Se vacía hacia la izquierda" },
	{ "right", "Se vacía hacia la derecha" },
	{ "down", "Se vacía hacia abajo" },
	{ "up", "Se vacía hacia arriba" },
}

-- Dónde va el icono respecto a la barra (estilo de barras)
M.ICONPOS = {
	{ "left", "A la izquierda" },
	{ "top", "Arriba" },
}

local db
local bars = {}          -- id -> { conf, frame, buttons, visible }
local overlayed = {}     -- spellID -> true mientras brilla (proc)
local racialID           -- hechizo racial (nil = sin buscar, false = no tiene)
local editorOpen = false

-- El racial del personaje (se busca una vez; se vuelve a buscar al aprender hechizos)
function M:Racial()
	if racialID == nil then racialID = ns.RacialSpell() or false end
	return racialID or nil
end

local function running()
	return R:IsModuleRunning(M)
end

----------------------------------------------------------------------
-- Datos
----------------------------------------------------------------------

local function fill(conf)
	for k, v in pairs(M.BAR_DEFAULTS) do
		if conf[k] == nil then conf[k] = v end
	end
	conf.entries = conf.entries or {}
end

function M:GetBarConfs()
	return db.bars
end

function M:FindConf(id)
	for i, c in ipairs(db.bars) do
		if c.id == id then return c, i end
	end
end

function M:BarFrame(id)
	local b = bars[id]
	return b and b.frame
end

function M:NewBar(name)
	local conf = { id = db.nextID, name = name or L["Barra %d"]:format(db.nextID) }
	db.nextID = db.nextID + 1
	fill(conf)
	table.insert(db.bars, conf)
	self:Rebuild()
	return conf
end

function M:DeleteBar(id)
	local conf, index = self:FindConf(id)
	if not conf then return end
	table.remove(db.bars, index)
	-- Las que estaban ancladas a esta vuelven a la pantalla donde estén
	for _, c in ipairs(db.bars) do
		if c.anchorTo == "bar:" .. id then
			local b = bars[c.id]
			c.anchorTo = "screen"
			if b then ns.SavePoint(b.frame, c, "point", ns.GrowthPoint(c)) end
		end
	end
	local b = bars[id]
	if b then
		ns.UnregisterVisibility(b.frame)
		b.frame:Hide()
		b.dead = true
		bars[id] = nil
	end
	self:Rebuild()
end

-- ¿Anclar conf a target crearía un círculo (A a B y B a A)?
function M:WouldLoop(conf, target)
	local seen = { [conf.id] = true }
	local t = target
	for _ = 1, 20 do
		local id = type(t) == "string" and tonumber(t:match("^bar:(%d+)$"))
		if not id then return false end
		if seen[id] then return true end
		seen[id] = true
		local other = self:FindConf(id)
		if not other then return false end
		t = other.anchorTo
	end
	return true
end

-- Nombre e icono de una entrada (para la barra y el editor)
function M:EntryInfo(e)
	if e.t == "spell" or e.t == "aura" then
		return ns.SpellName(e.id) or e.name or ("#" .. tostring(e.id)), ns.SpellIcon(e.id) or 134400
	elseif e.t == "item" then
		return ns.ItemName(e.id) or e.name or ("#" .. tostring(e.id)), ns.ItemIcon(e.id) or 134400
	elseif e.t == "slot" then
		local icon = NS(GetInventoryItemTexture("player", e.id))
		local name = (e.id == 13 and L["Abalorio 1"]) or (e.id == 14 and L["Abalorio 2"]) or L["Casilla %d"]:format(e.id)
		return name, icon or 134400
	elseif e.t == "racial" then
		local id = M:Racial()
		return id and ns.SpellName(id) or L["Racial"], id and ns.SpellIcon(id) or 134400
	end
	return "?", 134400
end

----------------------------------------------------------------------
-- Botones
----------------------------------------------------------------------

local function tooltip(self)
	local e = self.entry
	if not e then return end
	GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
	if (e.t == "spell" or e.t == "aura") and e.id then
		GameTooltip:SetSpellByID(e.id)
	elseif e.t == "racial" and M:Racial() then
		GameTooltip:SetSpellByID(M:Racial())
	elseif e.t == "item" and e.id then
		GameTooltip:SetItemByID(e.id)
	elseif e.t == "slot" then
		if not GameTooltip:SetInventoryItem("player", e.id) then
			GameTooltip:SetText(M:EntryInfo(e), 1, 1, 1)
		end
	end
	GameTooltip:Show()
end

local function createButton(b)
	local btn = CreateFrame("Frame", nil, b.frame)
	btn:SetSize(36, 36)

	btn.bg = btn:CreateTexture(nil, "BACKGROUND")
	btn.bg:SetAllPoints()

	btn.iconHolder = CreateFrame("Frame", nil, btn)
	btn.icon = btn.iconHolder:CreateTexture(nil, "ARTWORK")
	btn.icon:SetAllPoints()

	btn.cd = CreateFrame("Cooldown", nil, btn.iconHolder, "CooldownFrameTemplate")
	btn.cd:SetAllPoints(btn.iconHolder)
	btn.cd:SetDrawEdge(false)
	btn.cd:SetDrawBling(false)
	btn.cd:SetSwipeTexture(ns.WHITE)
	btn.cd:SetHideCountdownNumbers(false)
	-- Al terminar se vuelve a mirar el estado (no más de 5 veces por segundo,
	-- por si limpiar el marco volviera a avisar)
	btn.cd:SetScript("OnCooldownDone", function()
		local now = GetTime()
		if (btn.doneAt or 0) + 0.2 < now then
			btn.doneAt = now
			M:MarkDirty()
		end
	end)

	-- Barra (solo en el estilo de barras): lista = fondo de color, en
	-- reutilización = barra que se vacía
	btn.ready = btn:CreateTexture(nil, "BORDER")
	btn.bar = CreateFrame("StatusBar", nil, btn)
	btn.bar:SetMinMaxValues(0, 1)
	btn.bar:SetValue(1)

	btn.iconBorder = ns.Border(btn.iconHolder)
	btn.barBorder = ns.Border(btn.bar)

	btn.texts = CreateFrame("Frame", nil, btn)
	btn.texts:SetAllPoints()
	-- Con una fuente desde el principio: drawButton escribe en ellos antes de
	-- que styleButton ponga la elegida, y SetText sin fuente da error (y
	-- cortaba el arranque del módulo entero)
	btn.count = btn.texts:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmall")
	btn.key = btn.texts:CreateFontString(nil, "OVERLAY", "NumberFontNormalSmallGray")
	btn.name = btn.texts:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	btn.name:SetJustifyH("LEFT")
	btn.name:SetWordWrap(false)

	btn:SetScript("OnEnter", tooltip)
	btn:SetScript("OnLeave", GameTooltip_Hide)
	return btn
end

-- Brillo de proc: el de las barras de acción de Blizzard, en un marco propio
-- (sin pasar por su gestor de alertas, que es compartido)
local function setGlow(btn, on)
	if on then
		if btn.glow == nil then
			local ok, g = pcall(CreateFrame, "Frame", nil, btn.iconHolder, "ActionButtonSpellAlertTemplate")
			btn.glow = ok and g or false
			if btn.glow then btn.glow:SetPoint("CENTER", btn.iconHolder, "CENTER", 0, 0) end
		end
		if btn.glow then
			local w, h = btn.iconHolder:GetSize()
			btn.glow:SetSize(w * 1.4, h * 1.4)
			-- El destello inicial mide 150 para botones de 45: se escala igual
			if btn.glow.ProcStartFlipbook then btn.glow.ProcStartFlipbook:SetSize(w * 3.3, h * 3.3) end
			if not btn.glow:IsShown() then
				btn.glow:Show()
				if btn.glow.ProcStartAnim then btn.glow.ProcStartAnim:Play() end
			end
		else
			btn.glowFallback = true
		end
	else
		if btn.glow and btn.glow:IsShown() then
			if btn.glow.ProcStartAnim then btn.glow.ProcStartAnim:Stop() end
			if btn.glow.ProcLoop then btn.glow.ProcLoop:Stop() end
			btn.glow:Hide()
		end
		btn.glowFallback = nil
	end
end

----------------------------------------------------------------------
-- Estado de cada entrada
----------------------------------------------------------------------

local function call(fn, ...)
	if not fn then return end
	local ok, a, b, c, d = pcall(fn, ...)
	if ok then return a, b, c, d end
end

-- Qué hay que dibujar: { known, icon, onCD, dur (objeto de duración) o
-- start/duration (sin secretos), charges (modo recarga), count, usable,
-- noMana, glow, key, aura }
local st = {}

-- Último estado fiable de cada hechizo (en reutilización propia o no), para
-- cuando la varita los bloquea todos a la vez (R:InRangedLockout)
local realCD = {}

local function lockedByWand(id, onCD)
	if not onCD then
		realCD[id] = false
		return false
	end
	if R.InRangedLockout and R:InRangedLockout() and not R:CastRecently(id) then
		-- Mientras dispara la varita no se sabe: se mantiene lo que había
		return not realCD[id]
	end
	realCD[id] = true
	return false
end

local function spellState(id, conf)
	st.known = ns.KnowsSpell(id)
	if not st.known and C_Spell.GetOverrideSpell then
		local other = NS(call(C_Spell.GetOverrideSpell, id))
		if other and other ~= id then st.known = ns.KnowsSpell(other) end
	end
	st.icon = ns.SpellIcon(id)
	local info = call(C_Spell.GetSpellCooldown, id)
	local active = info and NS(info.isActive)
	local gcd = info and NS(info.isOnGCD)
	-- El bloqueo de la varita se trata como la reutilización global
	if active and not gcd and lockedByWand(id, true) then gcd = true end
	if not active then lockedByWand(id, false) end
	local charges = call(C_Spell.GetSpellCharges, id)
	local maxCharges = charges and NS(charges.maxCharges)
	local recharging = charges and NS(charges.isActive)
	st.onCD = (active and not gcd) and true or false
	if st.onCD then
		st.dur = call(C_Spell.GetSpellCooldownDuration, id, true)
	elseif maxCharges and maxCharges > 1 and recharging then
		st.dur = call(C_Spell.GetSpellChargeDuration, id)
		st.charges = true
	elseif active and gcd and not conf.hideGCD then
		st.dur = call(C_Spell.GetSpellCooldownDuration, id, false)
	end
	if maxCharges and maxCharges > 1 and charges then st.countSecret = charges.currentCharges end
	local usable, noMana = call(C_Spell.IsSpellUsable, id)
	st.usable, st.noMana = NS(usable), NS(noMana)
	st.glow = overlayed[id] or NS(call(C_SpellActivationOverlay and C_SpellActivationOverlay.IsSpellOverlayed, id)) or false
	st.key = ns.KeyFor("spell", id)
end

local function itemTimes(start, duration, conf)
	start, duration = NS(start), NS(duration)
	if not (start and duration) or start <= 0 or duration <= 0 then return end
	local gcd = duration <= 1.5
	if gcd and conf.hideGCD then return end
	st.onCD = not gcd
	st.start, st.duration = start, duration
end

local function itemState(id, conf)
	st.icon = ns.ItemIcon(id)
	local count = NS(call(C_Item and C_Item.GetItemCount or GetItemCount, id, false, true))
	st.known = (count or 0) > 0
	if conf.showCount and count and count > 1 then st.count = count end
	local start, duration = call((C_Item and C_Item.GetItemCooldown) or (C_Container and C_Container.GetItemCooldown), id)
	itemTimes(start, duration, conf)
	local usable, noMana = call((C_Item and C_Item.IsUsableItem) or IsUsableItem, id)
	st.usable, st.noMana = NS(usable), NS(noMana)
	st.key = ns.KeyFor("item", id)
end

local function slotState(slot, conf)
	local itemID = NS(GetInventoryItemID("player", slot))
	st.icon = NS(GetInventoryItemTexture("player", slot))
	st.known = itemID ~= nil
	-- Con «ocultar si no se puede usar» los abalorios sin efecto al usar no salen
	if itemID and conf.hideUnknown then
		local spell = call((C_Item and C_Item.GetItemSpell) or GetItemSpell, itemID)
		st.known = NS(spell) ~= nil
	end
	if itemID then
		local start, duration = call(GetInventoryItemCooldown, "player", slot)
		itemTimes(start, duration, conf)
		st.key = ns.KeyFor("item", itemID)
	end
	st.usable = true
end

local function auraState(id, conf)
	st.icon = ns.SpellIcon(id)
	local aura = call(C_UnitAuras.GetPlayerAuraBySpellID, id)
	st.known = aura ~= nil
	st.aura = true
	if aura then
		local instance = NS(aura.auraInstanceID)
		if instance then st.dur = call(C_UnitAuras.GetAuraDuration, "player", instance) end
		local stacks = NS(aura.applications)
		if conf.showCount and stacks and stacks > 1 then st.count = stacks end
	end
	st.usable = true
end

local function readState(e, conf)
	wipe(st)
	if e.t == "spell" then
		spellState(e.id, conf)
	elseif e.t == "racial" then
		local id = M:Racial()
		if id then spellState(id, conf) end
	elseif e.t == "item" then
		itemState(e.id, conf)
	elseif e.t == "slot" then
		slotState(e.id, conf)
	elseif e.t == "aura" then
		auraState(e.id, conf)
	end
	return st
end

----------------------------------------------------------------------
-- Dibujar
----------------------------------------------------------------------

local zeroDuration

local function drawTimer(btn, s, isBar)
	local cd = btn.cd
	cd:SetReverse(s.aura and true or false)
	cd:SetDrawSwipe(not s.charges)
	cd:SetDrawEdge(s.charges and true or false)
	local dur = s.dur
	if dur then
		if not pcall(cd.SetCooldownFromDurationObject, cd, dur, true) then cd:Clear() end
	elseif s.start then
		cd:SetCooldown(s.start, s.duration)
		-- Objetos (sin secretos): un objeto de duración propio para la barra
		if isBar and C_DurationUtil and C_DurationUtil.CreateDuration then
			btn.itemDuration = btn.itemDuration or C_DurationUtil.CreateDuration()
			dur = btn.itemDuration
			if not pcall(dur.SetTimeFromStart, dur, s.start, s.duration) then dur = nil end
		end
	else
		cd:Clear()
	end
	if not isBar then return end
	-- La barra se vacía con el tiempo que queda; lista: fondo de color entero
	local timing = dur ~= nil and (s.onCD or s.aura or s.charges)
	if timing and btn.bar.SetTimerDuration then
		local interp = Enum.StatusBarInterpolation and Enum.StatusBarInterpolation.Immediate or 0
		local dir = Enum.StatusBarTimerDirection and Enum.StatusBarTimerDirection.RemainingTime or 1
		if pcall(btn.bar.SetTimerDuration, btn.bar, dur, interp, dir) then
			btn.bar:Show()
			btn.ready:Hide()
			return
		end
	end
	if btn.bar.SetTimerDuration and btn.bar:IsShown() then
		zeroDuration = zeroDuration or (C_DurationUtil and C_DurationUtil.CreateDuration and C_DurationUtil.CreateDuration())
		if zeroDuration then pcall(btn.bar.SetTimerDuration, btn.bar, zeroDuration) end
	end
	btn.bar:Hide()
	-- Un aura que no está puesta no se ve como "lista"
	btn.ready:SetShown(not s.aura)
end

local function drawButton(b, btn, e)
	local conf = b.conf
	local s = readState(e, conf)
	local isBar = conf.style == "bar"
	btn.icon:SetTexture(s.icon or select(2, M:EntryInfo(e)) or 134400)

	drawTimer(btn, s, isBar)

	-- Gris / opacidad: en reutilización, o un aura que no tienes
	local dim = s.onCD or (s.aura and not s.known) or (not s.known)
	btn.icon:SetDesaturated((dim and conf.desaturate) and true or false)
	btn.iconHolder:SetAlpha(dim and conf.cdAlpha or 1)
	if conf.tint and not dim and s.usable == false then
		if s.noMana then btn.icon:SetVertexColor(0.5, 0.5, 1) else btn.icon:SetVertexColor(0.45, 0.45, 0.45) end
	else
		btn.icon:SetVertexColor(1, 1, 1)
	end

	if s.countSecret ~= nil and conf.showCount then
		-- Las cargas pueden ser secretas: SetFormattedText las escribe sin tocarlas
		if not pcall(btn.count.SetFormattedText, btn.count, "%d", s.countSecret) then btn.count:SetText("") end
	elseif s.count then
		btn.count:SetText(s.count)
	else
		btn.count:SetText("")
	end
	btn.key:SetText(conf.keybind and s.key or "")
	-- Sin la plantilla de Blizzard, el brillo es el borde en dorado
	local hadFallback = btn.glowFallback
	setGlow(btn, conf.glow and s.glow and not s.onCD)
	if btn.glowFallback then
		btn.iconBorder:SetLook(math.max(db.border, 2), 1, 0.82, 0)
	elseif hadFallback then
		btn.iconBorder:SetLook(db.border, ns.Color(db.borderColor))
	end
	if isBar and conf.showName then
		btn.name:SetText((M:EntryInfo(e)))
	else
		btn.name:SetText("")
	end
	-- Ocultar por estado (las auras no: para ellas «disponible» no significa nada)
	local byState = false
	if s.known and not s.aura then
		if s.onCD then byState = conf.hideOnCD else byState = conf.hideReady end
	end
	return s.known, byState and true or false
end

-- ¿Ocupa sitio en la barra? y ¿se ve? (con el editor abierto, todo)
local function showState(conf, known, byState)
	if editorOpen then return true, true end
	if not known and conf.hideUnknown then return false, false end
	if byState then return conf.keepGap and true or false, false end
	return true, true
end

-- Tamaño de cada botón y del icono. En el estilo de barras, ancho y alto son
-- los del botón entero (icono + barra) y el icono tiene su propio tamaño
-- (0 = automático: como el grosor de la barra, sin pasar del 40 % del largo).
-- Devuelve ancho y alto del botón y el lado del icono.
function M.ButtonSize(conf, w, h)
	if conf.style ~= "bar" then return w, h end
	local gap = math.max(db.border, 1) + 1
	local size = tonumber(conf.iconSize) or 0
	if conf.iconPos == "top" then
		local s = size > 0 and math.max(8, size) or math.max(8, math.min(w, math.floor(h * 0.4)))
		return math.max(w, s), math.max(h, s + gap + 8), s
	end
	local s = size > 0 and math.max(8, size) or math.max(8, math.min(h, math.floor(w * 0.4)))
	return math.max(w, s + gap + 8), math.max(h, s), s
end

-- Tamaño y aspecto de un botón (al colocar la barra)
local function styleButton(b, btn, w, h)
	local conf = b.conf
	local isBar = conf.style == "bar"
	-- vertical: cómo se vacía la barra; top: dónde va el icono (independientes)
	local vertical = isBar and (conf.fill == "down" or conf.fill == "up")
	local top = isBar and conf.iconPos == "top"
	local bw, bh, s = M.ButtonSize(conf, w, h)
	btn:SetSize(bw, bh)
	btn.iconHolder:ClearAllPoints()
	local iw, ih = w, h
	if top then
		-- Icono arriba, centrado; la barra debajo con su propio ancho
		iw, ih = s, s
		btn.iconHolder:SetPoint("TOP", btn, "TOP", 0, 0)
	elseif isBar then
		-- Icono a la izquierda, centrado; la barra a su derecha con su alto
		iw, ih = s, s
		btn.iconHolder:SetPoint("LEFT", btn, "LEFT", 0, 0)
	else
		btn.iconHolder:SetPoint("TOPLEFT", btn, "TOPLEFT", 0, 0)
	end
	btn.iconHolder:SetSize(iw, ih)
	btn.icon:SetTexCoord(ns.TexCoord(iw, ih, db.zoom))
	btn.bg:SetColorTexture(0, 0, 0, isBar and 0 or 0.6)
	btn.iconBorder:SetLook(db.border, ns.Color(db.borderColor))

	local r, g, bb = R.HexToRGB(db.swipeColor)
	btn.cd:SetSwipeColor(r, g, bb, db.swipeAlpha)

	-- Barra
	local gap = math.max(db.border, 1) + 1
	btn.bar:ClearAllPoints()
	if top then
		btn.bar:SetPoint("TOP", btn.iconHolder, "BOTTOM", 0, -gap)
		btn.bar:SetPoint("BOTTOM", btn, "BOTTOM", 0, 0)
		btn.bar:SetWidth(w)
	else
		btn.bar:SetPoint("LEFT", btn.iconHolder, "RIGHT", gap, 0)
		btn.bar:SetPoint("RIGHT", btn, "RIGHT", 0, 0)
		btn.bar:SetHeight(h)
	end
	btn.bar:SetOrientation(vertical and "VERTICAL" or "HORIZONTAL")
	if btn.bar.SetRotatesTexture then btn.bar:SetRotatesTexture(vertical and true or false) end
	-- Normal: se llena desde la izquierda (o abajo) y se vacía hacia ahí
	btn.bar:SetReverseFill(conf.fill == "right" or conf.fill == "up")
	pcall(btn.bar.SetStatusBarTexture, btn.bar, db.barTexture)
	btn.bar:SetStatusBarColor(ns.Color(db.barColor))
	btn.ready:ClearAllPoints()
	btn.ready:SetAllPoints(btn.bar)
	btn.ready:SetTexture(db.barTexture)
	btn.ready:SetVertexColor(ns.Color(db.readyColor))
	if not btn.barBg then btn.barBg = btn:CreateTexture(nil, "BACKGROUND", nil, -8) end
	btn.barBg:SetAllPoints(btn.bar)
	btn.barBg:SetColorTexture(ns.Color(db.bgColor, db.bgAlpha))
	btn.barBg:SetShown(isBar)
	btn.barBorder:SetLook(isBar and db.border or 0, ns.Color(db.borderColor))
	if not isBar then
		btn.bar:Hide()
		btn.ready:Hide()
	end

	-- Textos: el tiempo es el del marco Cooldown (a la derecha en las barras)
	local fs = btn.cd.GetCountdownFontString and btn.cd:GetCountdownFontString()
	if fs then
		ns.SetFont(fs, db.font, db.cdSize, db.outline)
		fs:SetTextColor(ns.Color(db.cdColor))
		fs:ClearAllPoints()
		if top then
			fs:SetPoint("BOTTOM", btn.bar, "BOTTOM", 0, 3)
		elseif isBar then
			fs:SetPoint("RIGHT", btn.bar, "RIGHT", -4, 0)
		else
			fs:SetPoint("CENTER", btn.iconHolder, "CENTER", 0, 0)
		end
	end
	btn.texts:SetFrameLevel(btn.cd:GetFrameLevel() + 3)
	btn.iconBorder:SetFrameLevel(btn.cd:GetFrameLevel() + 1)
	btn.barBorder:SetFrameLevel(btn.bar:GetFrameLevel() + 1)
	ns.SetFont(btn.count, db.font, db.countSize, db.outline)
	btn.count:SetTextColor(ns.Color(db.countColor))
	btn.count:ClearAllPoints()
	btn.count:SetPoint("BOTTOMRIGHT", btn.iconHolder, "BOTTOMRIGHT", -2, 2)
	ns.SetFont(btn.key, db.font, db.keySize, db.outline)
	btn.key:ClearAllPoints()
	btn.key:SetPoint("TOPRIGHT", btn.iconHolder, "TOPRIGHT", -2, -2)
	ns.SetFont(btn.name, db.font, db.nameSize, db.outline)
	btn.name:ClearAllPoints()
	btn.name:SetPoint("LEFT", btn.bar, "LEFT", 4, 0)
	btn.name:SetPoint("RIGHT", btn.bar, "RIGHT", -(db.cdSize * 2 + 6), 0)
	-- Con el icono arriba (barra estrecha) el nombre no cabe
	btn.name:SetShown(isBar and not top)
end

----------------------------------------------------------------------
-- Barras: crear, colocar, anclar
----------------------------------------------------------------------

local function targetFrame(anchorTo)
	if type(anchorTo) ~= "string" then return end
	local barID = tonumber(anchorTo:match("^bar:(%d+)$"))
	if barID then
		local other = bars[barID]
		return other and other.frame
	end
	local viewer = anchorTo:match("^viewer:(%w+)$")
	if viewer then return ns.viewerFrames and ns.viewerFrames[viewer] end
end

local layoutBar   -- se define más abajo

-- ¿Está encendido el gestor de reutilización de Blizzard? Apagado, sus
-- visores siguen existiendo pero escondidos donde sea: anclarse a ellos
-- mandaba la barra a cualquier sitio (arriba del todo) al recargar
local function viewersOn()
	local ok, on = pcall(C_CVar.GetCVarBool, "cooldownViewerEnabled")
	return not ok or on ~= false
end

local function anchorTarget(conf)
	if conf.anchorTo == "screen" then return end
	if conf.anchorTo:find("^viewer:") and not viewersOn() then return end
	return targetFrame(conf.anchorTo)
end

local function place(b)
	local conf, f = b.conf, b.frame
	local target = anchorTarget(conf)
	if target then
		f:ClearAllPoints()
		f:SetPoint(conf.anchorPoint, target, conf.anchorRel, conf.x, conf.y)
	else
		if not conf.point then conf.point = { ns.GrowthPoint(conf), "CENTER", 0, -220 } end
		f.mover:Place()
	end
	-- Desbloqueada se puede arrastrar siempre; si estaba anclada, al soltarla
	-- se queda donde la dejas (pasa a anclarse a la pantalla)
	f.mover:SetShown(not db.locked)
end

local function applyAlpha(b, a)
	b.alpha = a
	if not db.locked or editorOpen then a = 1 end
	b.frame:SetAlpha(a)
	local mouse = b.conf.tooltip and a > 0.05
	for _, btn in ipairs(b.buttons) do btn:EnableMouse((mouse and not btn.gap) and true or false) end
end

local function createBar(conf)
	local f = CreateFrame("Frame", "RheizorCDBar" .. conf.id, UIParent)
	f:SetSize(40, 40)
	f:SetFrameStrata("MEDIUM")
	local b = { conf = conf, frame = f, buttons = {}, visible = {} }
	if not conf.point then conf.point = { ns.GrowthPoint(conf), "CENTER", 0, -220 } end
	f.mover = R:CreateMover(f, conf.name, conf, "point", conf.point)
	-- Engranaje del recuadro: el editor con esta barra elegida
	f.mover.configure = function() M:OpenEditorAt(conf.id) end
	-- Al soltar se guarda con el punto de crecimiento (así crece hacia donde toca)
	f.mover:HookScript("OnDragStop", function()
		conf.anchorTo = "screen"
		ns.SavePoint(f, conf, "point", ns.GrowthPoint(conf))
		-- Recoloca también las ancladas a esta y refresca el editor
		M:Rebuild()
	end)
	f.mover:Hide()
	ns.RegisterVisibility(f, function() return running() and b.conf or nil end, function(a) applyAlpha(b, a) end)
	bars[conf.id] = b
	return b
end

-- Barras ancladas a una barra o a un visor de Blizzard (para recolocarlas
-- cuando cambia de tamaño)
local function relayoutDependents(key, depth)
	if (depth or 0) > 6 then return end
	for _, other in pairs(bars) do
		if other.conf.anchorTo == key then layoutBar(other, (depth or 0) + 1) end
	end
end

function layoutBar(b, depth)
	local conf, f = b.conf, b.frame
	if b.dead then return end
	f.mover.text:SetText("|cff33ccffRheizor|r · " .. (conf.name ~= "" and conf.name or "?"))

	-- Qué entradas se ven (con el editor abierto, todas)
	wipe(b.visible)
	for i, e in ipairs(conf.entries) do
		local btn = b.buttons[i] or createButton(b)
		b.buttons[i] = btn
		btn.entry = e
		local known, byState = drawButton(b, btn, e)
		local slot, seen = showState(conf, known, byState)
		btn.slot, btn.gap = slot, not seen
		if slot then b.visible[#b.visible + 1] = btn end
		-- Oculto por estado: sigue mostrado pero transparente y sin ratón, así
		-- su marco de reutilización avisa al terminar y vuelve a aparecer
		if slot or byState then
			btn:Show()
			btn:SetAlpha(seen and 1 or 0)
			if not slot then
				btn:ClearAllPoints()
				btn:SetPoint("CENTER", f, "CENTER")
			end
		else
			btn:Hide()
		end
	end
	for i = #conf.entries + 1, #b.buttons do
		b.buttons[i]:Hide()
		b.buttons[i].entry = nil
		b.buttons[i].slot = nil
	end

	-- Igualar la anchura del marco al que está anclada
	local w, h = conf.width, conf.height
	local target = conf.matchWidth and anchorTarget(conf)
	local n = #b.visible
	if target and n > 0 then
		local tw = NS(target:GetWidth())
		if tw and tw > 4 then
			local horizontal = conf.grow == "right" or conf.grow == "left"
			local per = math.max(1, math.min(conf.perRow, n))
			if not horizontal then per = 1 end
			w = math.max(8, (tw - (per - 1) * conf.spacing) / per)
		end
	end

	for _, btn in ipairs(b.visible) do styleButton(b, btn, w, h) end
	-- Con un icono más grande que la barra, el botón ocupa más
	local bw, bh = M.ButtonSize(conf, w, h)
	local W, H = ns.LayoutGrid(f, b.visible, {
		w = bw, h = bh, gap = conf.spacing, perRow = conf.perRow,
		grow = conf.grow, rowGrow = conf.rowGrow, align = conf.align,
	})
	if n == 0 then W, H = math.max(w, 20), math.max(h, 20) end
	f:SetSize(W, H)
	place(b)
	f:Show()
	-- Los botones nuevos toman la opacidad y el ratón de la barra
	applyAlpha(b, b.alpha or 1)
	relayoutDependents("bar:" .. conf.id, depth)
end

----------------------------------------------------------------------
-- Actualizar (agrupado: como mucho una vez por fotograma)
----------------------------------------------------------------------

local driver = CreateFrame("Frame")
driver:Hide()
local fullPending = false

local function updateAll()
	if not running() then return end
	for _, conf in ipairs(db.bars) do
		local b = bars[conf.id]
		if b then
			-- Si cambia qué entradas se ven, hay que volver a colocar
			local before = #b.visible
			local changed = fullPending
			if not changed then
				local count = 0
				for i, e in ipairs(conf.entries) do
					local btn = b.buttons[i]
					if btn then
						local slot, seen = showState(conf, drawButton(b, btn, e))
						if slot then count = count + 1 end
						if slot ~= btn.slot or btn.gap ~= not seen then changed = true end
					end
				end
				if count ~= before then changed = true end
			end
			if changed then layoutBar(b) end
		end
	end
	fullPending = false
end

driver:SetScript("OnUpdate", function(self)
	self:Hide()
	updateAll()
end)

function M:MarkDirty(full)
	if full then fullPending = true end
	driver:Show()
end

-- Crea las barras que faltan y vuelve a colocarlas todas
function M:Rebuild()
	if not db then return end
	for _, conf in ipairs(db.bars) do
		fill(conf)
		if not bars[conf.id] then createBar(conf) end
	end
	-- Primero las ancladas a la pantalla o a Blizzard, luego las ancladas a otras
	for _, conf in ipairs(db.bars) do
		if not conf.anchorTo:find("^bar:") then layoutBar(bars[conf.id]) end
	end
	for _, conf in ipairs(db.bars) do
		if conf.anchorTo:find("^bar:") then layoutBar(bars[conf.id]) end
	end
	ns.RefreshVisibility()
	if self.RefreshEditor then self:RefreshEditor() end
end

-- Cuando un visor de Blizzard cambia de tamaño (Viewers.lua)
function ns.OnViewerLayout(id)
	if not db or not running() then return end
	relayoutDependents("viewer:" .. id, 0)
end

function ns.OnKeysChanged()
	if db and running() then M:MarkDirty() end
end

function M:SetEditorOpen(open)
	editorOpen = open and true or false
	ns.forceShow = editorOpen
	self:MarkDirty(true)
	ns.RefreshVisibility()
end

----------------------------------------------------------------------
-- Eventos
----------------------------------------------------------------------

local events = CreateFrame("Frame")
events:SetScript("OnEvent", function(_, event, arg1)
	if not running() then return end
	if event == "SPELL_ACTIVATION_OVERLAY_GLOW_SHOW" then
		local id = NS(arg1)
		if id then overlayed[id] = true end
	elseif event == "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE" then
		local id = NS(arg1)
		if id then overlayed[id] = nil end
	elseif event == "SPELLS_CHANGED" or event == "PLAYER_EQUIPMENT_CHANGED" then
		racialID = nil
		M:MarkDirty(true)
		return
	elseif event == "UPDATE_BINDINGS" or event == "ACTIONBAR_SLOT_CHANGED" then
		ns.InvalidateKeys()
	end
	M:MarkDirty()
end)

local EVENTS = {
	"SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_CHARGES", "SPELL_UPDATE_USABLE", "SPELLS_CHANGED",
	"BAG_UPDATE_COOLDOWN", "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED",
	"SPELL_ACTIVATION_OVERLAY_GLOW_SHOW", "SPELL_ACTIVATION_OVERLAY_GLOW_HIDE",
	"UPDATE_BINDINGS", "ACTIONBAR_SLOT_CHANGED", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD",
}

function M:OnEnable()
	db = self.db
	ns.StartVisibility()
	-- La primera vez, una barra de ejemplo con abalorios y racial
	if not db.seeded then
		db.seeded = true
		if #db.bars == 0 then
			local conf = { id = db.nextID, name = L["Abalorios y racial"] }
			db.nextID = db.nextID + 1
			fill(conf)
			conf.entries = { { t = "slot", id = 13 }, { t = "slot", id = 14 }, { t = "racial" } }
			table.insert(db.bars, conf)
		end
	end
	for _, e in ipairs(EVENTS) do pcall(events.RegisterEvent, events, e) end
	pcall(events.RegisterUnitEvent, events, "UNIT_AURA", "player")
	-- Al acabar el bloqueo de la varita, volver a mirar las reutilizaciones
	if R.OnRangedLockEnd and not self.lockHooked then
		self.lockHooked = true
		R:OnRangedLockEnd(function() if running() then M:MarkDirty() end end)
	end
	-- Los visores de Blizzard aparecen algo después: se recoloca al tenerlos
	self:Rebuild()
	C_Timer.After(2, function() if running() then M:Rebuild() end end)
end

function M:OnOptionChanged()
	self:Rebuild()
end

----------------------------------------------------------------------
-- Comandos: /rzcd y /rz cd
----------------------------------------------------------------------

function ns.ToggleEditor()
	R:RunModuleAction(M, function(m) m:ToggleEditor() end)
end

SLASH_RHEIZORCOOLDOWNS1 = "/rzcd"
SlashCmdList.RHEIZORCOOLDOWNS = function()
	ns.ToggleEditor()
end

-- /rz cd … : se añade al comando /rz del núcleo sin cambiarlo
do
	local original = SlashCmdList.RHEIZOR
	if original then
		SlashCmdList.RHEIZOR = function(msg)
			local word = strtrim(msg or ""):match("^(%S+)")
			word = word and word:lower()
			if word == "cd" or word == "cooldowns" or word == "reutilizacion" or word == "reutilización" then
				ns.ToggleEditor()
			else
				original(msg)
			end
		end
	end
end
