-- Estilo y colocación del gestor de reutilización de Blizzard
-- (EssentialCooldownViewer, UtilityCooldownViewer, BuffIconCooldownViewer y
-- BuffBarCooldownViewer, del addon Blizzard_CooldownViewer).
--
-- Blizzard sigue haciendo todo el trabajo de verdad: qué hechizos se ven
-- (se eligen en su propia ventana de configuración), sus tiempos, auras,
-- cargas y brillos, que en combate son valores secretos que un addon no
-- puede tocar. Rheizor solo cambia el aspecto y la colocación DESPUÉS de
-- que Blizzard haya hecho lo suyo:
--   · hooksecurefunc(visor, "Layout")              tras colocar los iconos
--   · hooksecurefunc(visor, "OnAcquireItemFrame")  al sacar un icono del pool
--   · hooksecurefunc(visor, "UpdateSystemSettingOpacity") (opacidad del Modo edición)
--   · hooksecurefunc(visor, "SetPoint")            solo si Rheizor lo coloca
--   · en cada icono: SetSwipeColor, SetCooldown, SetDesaturated, SetTexture
--     y RefreshOverlayGlow, también con hooksecurefunc.
-- Nunca se sustituye un método de Blizzard, nunca se llama a su código Lua
-- (solo a funciones de los marcos: SetSize, SetPoint, SetFont…) y nunca se
-- escribe un campo que Blizzard lea: lo de Rheizor va en una tabla aparte
-- (side). Así su código sigue sin "contaminar" (taint) y puede operar con
-- los valores secretos en combate.
--
-- La posición la lleva el Modo edición de Blizzard (y se guarda con el
-- perfil gracias a BlizzardLayout.lua del núcleo). Solo si se activa
-- «Rheizor lo coloca» se ancla el visor a un marco de Rheizor con su mover.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret

local SWIPE_BLIZZARD = "Interface\\HUD\\UI-HUD-CoolDownManager-Icon-Swipe"
local OVERLAY_ATLAS = "UI-HUD-CoolDownManager-IconOverlay"

----------------------------------------------------------------------
-- Módulo general: activar el gestor y abrir su configuración
----------------------------------------------------------------------

R:RegisterModule("cdm", {
	title = "Gestor de Blizzard",
	defaults = {},
	options = {
		{ type = "header", text = "Gestor de reutilización de Blizzard" },
		{ type = "toggle", cvar = "cooldownViewerEnabled", name = "Activar el gestor de reutilización de Blizzard",
		  desc = "Los cuatro visores de Blizzard (esenciales, utilidades y beneficios en iconos y en barras). Rheizor les cambia el aspecto y la colocación; qué hechizos sale en cada uno se elige en la configuración de Blizzard." },
		{ type = "button", name = "Qué hechizos se ven", text = "Abrir",
		  desc = "Abre la configuración del gestor de Blizzard: arrastra cada hechizo al visor en el que lo quieres (o a «No mostrar»). No se puede abrir en combate.",
		  func = function() ns.OpenBlizzardSettings() end },
		{ type = "button", name = "Barras propias de Rheizor", text = "Abrir editor",
		  desc = "Barras con los hechizos, objetos, abalorios y raciales que tú elijas. También con /rzcd o /rz cd.",
		  func = function() if ns.ToggleEditor then ns.ToggleEditor() end end },
	},
	unsupported = {
		"Elegir qué hechizos sigue el gestor desde Rheizor: se hace en la ventana de Blizzard (botón «Qué hechizos se ven»).",
		"Leer en combate si un hechizo del gestor está en reutilización para decidir otras cosas: en combate esos tiempos son secretos. Rheizor solo cambia cómo se dibujan.",
	},
})

----------------------------------------------------------------------
-- Visores
----------------------------------------------------------------------

local VIEWERS = {
	{ key = "cdmEssential", id = "essential", frame = "EssentialCooldownViewer", title = "Esenciales",
	  kind = "icon", cd = true, w = 42, h = 42, per = 8, cdSize = 17, countSize = 14, collapse = true },
	{ key = "cdmUtility", id = "utility", frame = "UtilityCooldownViewer", title = "Utilidades",
	  kind = "icon", cd = true, w = 32, h = 32, per = 10, cdSize = 13, countSize = 11, collapse = true },
	{ key = "cdmBuffIcon", id = "bufficon", frame = "BuffIconCooldownViewer", title = "Beneficios en iconos",
	  kind = "icon", cd = false, w = 34, h = 34, per = 10, cdSize = 13, countSize = 12, collapse = false },
	{ key = "cdmBuffBar", id = "buffbar", frame = "BuffBarCooldownViewer", title = "Beneficios en barras",
	  kind = "bar", cd = false, w = 200, h = 22, cdSize = 12, countSize = 11, collapse = true },
}
ns.VIEWERS = VIEWERS

local GROW_V = {
	{ "down", "Hacia abajo" },
	{ "up", "Hacia arriba" },
}

local function viewerOptions(v)
	local icon, cd = v.kind == "icon", v.cd
	local o = {}
	local function add(t) o[#o + 1] = t end

	add({ type = "header", text = "Aspecto" })
	add({ type = "toggle", key = "enabled", name = "Aplicar el estilo de Rheizor",
	      desc = "Desactivado, este visor se queda como lo dibuja Blizzard (hace falta /reload para quitar lo ya aplicado)." })
	if icon then
		add({ type = "slider", key = "width", name = "Ancho de los iconos", min = 16, max = 96, step = 1, format = R.fmt.int })
		add({ type = "slider", key = "height", name = "Alto de los iconos", min = 16, max = 96, step = 1, format = R.fmt.int })
	else
		add({ type = "slider", key = "width", name = "Ancho de las barras", min = 60, max = 500, step = 2, format = R.fmt.int })
		add({ type = "slider", key = "height", name = "Alto de las barras", min = 8, max = 48, step = 1, format = R.fmt.int })
	end
	add({ type = "slider", key = "zoom", name = "Recorte del borde del icono", min = 0, max = 0.3, step = 0.01,
	      desc = "Quita el marco que traen dibujado los iconos del juego. 8% deja el icono limpio." })
	add({ type = "toggle", key = "stripArt", name = "Quitar la máscara redonda y el marco de Blizzard",
	      desc = "Iconos cuadrados con borde fino en lugar de las esquinas redondeadas y el marco dorado del gestor." })
	add({ type = "slider", key = "border", name = "Grosor del borde", min = 0, max = 4, step = 1, format = R.fmt.int })
	add({ type = "color", key = "borderColor", name = "Color del borde" })
	if not icon then
		add({ type = "header", text = "Barra" })
		add({ type = "dropdown", key = "barTexture", name = "Textura de la barra", values = R.TEXTURES })
		add({ type = "color", key = "barColor", name = "Color de la barra" })
		add({ type = "color", key = "bgColor", name = "Color del fondo" })
		add({ type = "slider", key = "bgAlpha", name = "Opacidad del fondo", min = 0, max = 1, step = 0.05 })
		add({ type = "toggle", key = "showIcon", name = "Mostrar el icono" })
		add({ type = "toggle", key = "spark", name = "Chispa al final de la barra" })
	end

	add({ type = "header", text = "Distribución" })
	add({ type = "toggle", key = "layout", name = "Rheizor coloca los iconos",
	      desc = "Usa el tamaño, la separación, los iconos por fila y la dirección de aquí en lugar de los del Modo edición de Blizzard. Desactivado, solo se cambia el aspecto." })
	add({ type = "slider", key = "spacing", name = "Separación", min = 0, max = 20, step = 1, format = R.fmt.int })
	if icon then
		add({ type = "slider", key = "perRow", name = "Iconos por fila", min = 1, max = 24, step = 1, format = R.fmt.int })
		add({ type = "dropdown", key = "grow", name = "Dirección", values = ns.GROW })
		add({ type = "dropdown", key = "rowGrow", name = "Filas nuevas", values = ns.ROWS })
		add({ type = "dropdown", key = "align", name = "Filas incompletas", values = ns.ALIGN })
	else
		add({ type = "dropdown", key = "grow", name = "Dirección", values = GROW_V })
	end
	add({ type = "toggle", key = "collapse", name = "Juntar los ocultos",
	      desc = "Los iconos o barras que Blizzard oculta (un beneficio que no tienes, un hueco vacío) no dejan hueco: los demás se juntan." })

	add({ type = "header", text = "Texto" })
	add({ type = "dropdown", key = "font", name = "Fuente", values = ns.FONTS })
	add({ type = "dropdown", key = "outline", name = "Contorno", values = ns.OUTLINES })
	if icon then
		add({ type = "slider", key = "cdSize", name = "Tamaño del tiempo", min = 6, max = 32, step = 1, format = R.fmt.int })
		add({ type = "dropdown", key = "cdPoint", name = "Posición del tiempo", values = ns.POINTS })
		add({ type = "color", key = "cdColor", name = "Color del tiempo" })
	else
		add({ type = "toggle", key = "showName", name = "Mostrar el nombre" })
		add({ type = "slider", key = "nameSize", name = "Tamaño del nombre", min = 6, max = 24, step = 1, format = R.fmt.int })
		add({ type = "toggle", key = "showTime", name = "Mostrar el tiempo",
		      desc = "Si está desactivado «Mostrar temporizador» en el Modo edición de Blizzard, el tiempo no se ve de todos modos." })
		add({ type = "slider", key = "cdSize", name = "Tamaño del tiempo", min = 6, max = 24, step = 1, format = R.fmt.int })
		add({ type = "color", key = "textColor", name = "Color del texto" })
	end
	add({ type = "slider", key = "countSize", name = "Tamaño de cargas y acumulaciones", min = 6, max = 32, step = 1, format = R.fmt.int })
	if icon then
		add({ type = "dropdown", key = "countPoint", name = "Posición de cargas y acumulaciones", values = ns.POINTS })
	end
	add({ type = "color", key = "countColor", name = "Color de cargas y acumulaciones" })
	if cd then
		add({ type = "toggle", key = "keybind", name = "Mostrar la tecla",
		      desc = "La tecla de la casilla de tus barras de acción donde está el hechizo." })
		add({ type = "slider", key = "keySize", name = "Tamaño de la tecla", min = 6, max = 24, step = 1, format = R.fmt.int })
	end

	if icon then
		add({ type = "header", text = "Reutilización" })
		add({ type = "color", key = "swipeColor", name = "Color de la sombra de reutilización" })
		add({ type = "slider", key = "swipeAlpha", name = "Opacidad de la sombra", min = 0, max = 1, step = 0.05 })
		if cd then
			add({ type = "color", key = "auraColor", name = "Color de la sombra mientras dura el efecto",
			      desc = "Cuando el hechizo deja un efecto (un beneficio, un tótem), Blizzard muestra su duración en lugar de la reutilización." })
			add({ type = "toggle", key = "hideGCD", name = "Sin sombra de reutilización global (GCD)",
			      desc = "Los iconos no se oscurecen con el segundo y medio de espera tras cada hechizo; solo con su reutilización propia." })
			add({ type = "toggle", key = "desaturate", name = "En gris mientras está en reutilización" })
			add({ type = "slider", key = "cdAlpha", name = "Opacidad en reutilización", min = 0.1, max = 1, step = 0.05 })
			add({ type = "toggle", key = "glow", name = "Brillo cuando se activa (proc)" })
			add({ type = "toggle", key = "hideFlash", name = "Sin destello al terminar la reutilización" })
		end
	end

	add({ type = "header", text = "Visibilidad" })
	add({ type = "dropdown", key = "show", name = "Mostrar", values = ns.SHOW,
	      desc = "Se suma a «Visibilidad» del Modo edición de Blizzard: si Blizzard lo oculta, no se ve." })
	add({ type = "dropdown", key = "where", name = "Dónde", values = ns.WHERE })
	add({ type = "dropdown", key = "group", name = "Con quién", values = ns.GROUP })
	add({ type = "toggle", key = "hideMounted", name = "Ocultar al ir montado" })
	add({ type = "toggle", key = "hoverShow", name = "Mostrar también al pasar el ratón",
	      desc = "Aunque no toque verse (fuera de combate, montado…), aparece al poner el ratón encima de su sitio." })
	add({ type = "slider", key = "oocAlpha", name = "Opacidad fuera de combate", min = 0, max = 1, step = 0.05 })
	add({ type = "slider", key = "hiddenAlpha", name = "Opacidad cuando está oculto", min = 0, max = 1, step = 0.05,
	      desc = "0% = invisible. Con «Al pasar el ratón», lo que se ve sin el ratón encima." })

	add({ type = "header", text = "Posición" })
	add({ type = "toggle", key = "move", name = "Rheizor lo coloca",
	      desc = "Desactivado (lo normal), se coloca en Esc > Modo edición y la posición se guarda con el perfil de Rheizor. Activado, se mueve con el recuadro de Rheizor (/rz mover) y el Modo edición ya no lo mueve." })
	add({ type = "toggle", key = "locked", name = "Bloquear posición",
	      desc = "Solo con «Rheizor lo coloca». Desbloqueado, aparece un recuadro encima para arrastrarlo." })
	add({ type = "button", name = "Posición", text = "Restablecer", func = function(mod) mod:ResetPosition() end })
	add({ type = "button", name = "Qué hechizos se ven", text = "Abrir", func = function() ns.OpenBlizzardSettings() end })
	return o
end

local function viewerDefaults(v)
	local bar = v.kind == "bar"
	return {
		enabled = true,
		layout = true,
		width = v.w, height = v.h,
		zoom = 0.08,
		stripArt = true,
		border = 1,
		borderColor = "000000",
		spacing = 2,
		perRow = v.per or 8,
		grow = bar and "down" or "right",
		rowGrow = "after",
		align = "center",
		collapse = v.collapse,
		font = "arialn",
		outline = "OUTLINE",
		cdSize = v.cdSize,
		cdPoint = "CENTER",
		cdColor = "ffffff",
		countSize = v.countSize,
		countPoint = "BOTTOMRIGHT",
		countColor = "ffffff",
		keybind = false,
		keySize = 10,
		swipeColor = "000000",
		swipeAlpha = 0.7,
		auraColor = "ffd84d",
		hideGCD = true,
		desaturate = true,
		cdAlpha = 1,
		glow = true,
		hideFlash = false,
		show = "always",
		where = "any",
		group = "any",
		hoverShow = false,
		hideMounted = false,
		oocAlpha = 1,
		hiddenAlpha = 0,
		move = false,
		locked = true,
		-- Barras
		barTexture = ns.WHITE,
		barColor = "33ccff",
		bgColor = "000000",
		bgAlpha = 0.6,
		showIcon = true,
		spark = false,
		showName = true,
		nameSize = 12,
		showTime = true,
		textColor = "ffffff",
	}
end

----------------------------------------------------------------------
-- Estado de Rheizor por marco de Blizzard (nunca en el propio marco)
----------------------------------------------------------------------

local side = setmetatable({}, { __mode = "k" })
local guard = false           -- true mientras Rheizor llama a un método enganchado
local byFrame = {}            -- visor de Blizzard -> V

local function active(V)
	return V.frame ~= nil and R:IsModuleRunning(V.mod) and V.mod.db.enabled
end

local function pointOffset(point, inset)
	local x, y = 0, 0
	if point:find("LEFT") then x = inset elseif point:find("RIGHT") then x = -inset end
	if point:find("TOP") then y = -inset elseif point:find("BOTTOM") then y = inset end
	return x, y
end

-- Máscara y marco dibujado de Blizzard (no tienen nombre: se buscan una vez)
local function findArt(holder, icon, s)
	if s.artFound then return end
	s.artFound = true
	s.masks = {}
	if icon.GetNumMaskTextures then
		local ok, n = pcall(icon.GetNumMaskTextures, icon)
		for i = 1, (ok and n or 0) do
			local m = icon:GetMaskTexture(i)
			if m then s.masks[#s.masks + 1] = m end
		end
	end
	for _, r in ipairs({ holder:GetRegions() }) do
		if r ~= icon and r.IsObjectType and r:IsObjectType("Texture") and not r:IsObjectType("MaskTexture") then
			local atlas = r.GetAtlas and r:GetAtlas()
			if atlas == OVERLAY_ATLAS then
				s.overlay = r
			elseif not s.overlay and not atlas and r:GetDrawLayer() == "OVERLAY" and r ~= holder.OutOfRange then
				s.overlayGuess = r
			end
		end
	end
	s.overlay = s.overlay or s.overlayGuess
end

local function setMasks(icon, s, strip)
	if strip and not s.maskOff then
		for _, m in ipairs(s.masks) do pcall(icon.RemoveMaskTexture, icon, m) end
		s.maskOff = true
	elseif not strip and s.maskOff then
		for _, m in ipairs(s.masks) do pcall(icon.AddMaskTexture, icon, m) end
		s.maskOff = false
	end
end

local function applyCoords(icon, s)
	if s.l then icon:SetTexCoord(s.l, s.r, s.t, s.b) end
end

-- Sombra de reutilización: el color de Rheizor en lugar del de Blizzard.
-- aura = Blizzard está mostrando la duración de un efecto, no la reutilización
local function setSwipe(V, cd, aura)
	local db = V.mod.db
	local hex = (aura and V.def.cd) and db.auraColor or db.swipeColor
	local r, g, b = R.HexToRGB(hex)
	guard = true
	pcall(cd.SetSwipeColor, cd, r, g, b, db.swipeAlpha)
	guard = false
end

-- Brillo de proc: Blizzard crea el marco la primera vez con el tamaño que
-- tuviera el icono; se ajusta al nuestro
local function fixGlow(V, item)
	local alert = item.SpellActivationAlert
	if not alert then return end
	local db = V.mod.db
	local w, h = item:GetWidth(), item:GetHeight()
	w, h = NS(w), NS(h)
	if w and h then alert:SetSize(w * 1.4, h * 1.4) end
	alert:SetAlpha(db.glow and 1 or 0)
end

----------------------------------------------------------------------
-- Ganchos por icono (una vez por marco; el pool los reutiliza)
----------------------------------------------------------------------

local schedule   -- se define más abajo

local function swipeHook(cd, r)
	if guard then return end
	local s = side[cd]
	if not s or not active(s.V) then return end
	-- ITEM_AURA_COLOR de Blizzard es amarillo (r = 1); el de reutilización, negro
	s.aura = (NS(r) or 0) > 0.5
	setSwipe(s.V, cd, s.aura)
end

-- Tras CooldownFrame_Set: si es solo la reutilización global, sin sombra
local function cooldownHook(cd)
	if guard then return end
	local s = side[cd]
	if not s or not active(s.V) or not s.V.mod.db.hideGCD then return end
	local item = s.item
	-- isOnGCD no es nunca secreto (SpellCooldownInfo); los otros son true/false de Blizzard
	if NS(item.isOnGCD) == true and not item.wasSetFromCharges and not item.wasSetFromAura and not item.wasSetFromItem then
		guard = true
		pcall(cd.SetDrawSwipe, cd, false)
		pcall(cd.SetDrawEdge, cd, false)
		guard = false
	end
end

local function desatHook(tex, desaturated)
	if guard then return end
	local s = side[tex]
	if not s or not active(s.V) then return end
	local db = s.V.mod.db
	-- desaturated puede ser un booleano secreto: SetAlphaFromBoolean lo acepta
	if db.cdAlpha < 1 and tex.SetAlphaFromBoolean then
		if not pcall(tex.SetAlphaFromBoolean, tex, desaturated, db.cdAlpha, 1) then tex:SetAlpha(1) end
		s.alphaSet = true
	elseif s.alphaSet then
		tex:SetAlpha(1)
		s.alphaSet = nil
	end
	if not db.desaturate then
		guard = true
		tex:SetDesaturated(false)
		guard = false
	end
end

local function textureHook(tex)
	local s = side[tex]
	if s and s.l and active(s.V) then applyCoords(tex, s) end
end

local function hookItem(V, item, s)
	s.hooked = true
	s.V, s.item = V, item
	item:HookScript("OnShow", function() if V.mod.db.collapse then schedule(V) end end)
	item:HookScript("OnHide", function() if V.mod.db.collapse then schedule(V) end end)

	local icon = (V.def.kind == "bar") and item.Icon and item.Icon.Icon or item.Icon
	if icon and icon.SetTexCoord then
		side[icon] = s
		hooksecurefunc(icon, "SetTexture", textureHook)
		if V.def.cd then hooksecurefunc(icon, "SetDesaturated", desatHook) end
	end
	local cd = item.Cooldown
	if cd then
		side[cd] = s
		hooksecurefunc(cd, "SetSwipeColor", swipeHook)
		if V.def.cd then hooksecurefunc(cd, "SetCooldown", cooldownHook) end
		if cd.GetMinimumCountdownDuration then
			local ok, ms = pcall(cd.GetMinimumCountdownDuration, cd)
			s.minCountdown = ok and NS(ms) or 0
		end
	end
	if item.RefreshOverlayGlow then
		hooksecurefunc(item, "RefreshOverlayGlow", function(self)
			if active(V) then fixGlow(V, self) end
		end)
	end
end

----------------------------------------------------------------------
-- Estilo de un icono (esenciales, utilidades, beneficios en iconos)
----------------------------------------------------------------------

local function keyText(item)
	local info = item.cooldownInfo
	if type(info) ~= "table" then return end
	return ns.KeyFor("spell", NS(info.spellID)) or ns.KeyFor("spell", NS(info.overrideSpellID))
end

local function styleIcon(V, item, s, db)
	local icon = item.Icon
	if not icon or not icon.SetTexCoord then return end
	local w, h
	if db.layout then
		w, h = db.width, db.height
		item:SetScale(1)
		item:SetSize(w, h)
	else
		w, h = NS(item:GetWidth()), NS(item:GetHeight())
	end

	findArt(item, icon, s)
	setMasks(icon, s, db.stripArt)
	if s.overlay then s.overlay:SetAlpha(db.stripArt and 0 or 1) end
	s.l, s.r, s.t, s.b = ns.TexCoord(w, h, db.zoom)
	applyCoords(icon, s)

	local cd = item.Cooldown
	local top = cd and cd:GetFrameLevel() or item:GetFrameLevel()
	if not s.border then s.border = ns.Border(item) end
	s.border:SetFrameLevel(top + 2)
	s.border:SetLook(db.border, ns.Color(db.borderColor))

	if cd then
		pcall(cd.SetSwipeTexture, cd, db.stripArt and ns.WHITE or SWIPE_BLIZZARD)
		setSwipe(V, cd, s.aura)
		local fs = cd.GetCountdownFontString and cd:GetCountdownFontString()
		if fs then
			ns.SetFont(fs, db.font, db.cdSize, db.outline)
			fs:SetTextColor(ns.Color(db.cdColor))
			fs:ClearAllPoints()
			fs:SetPoint(db.cdPoint, item, db.cdPoint, pointOffset(db.cdPoint, 2))
		end
		if V.def.cd and cd.SetMinimumCountdownDuration then
			-- Sin números para la reutilización global (dura 1,5 s o menos)
			pcall(cd.SetMinimumCountdownDuration, cd, db.hideGCD and 1600 or (s.minCountdown or 0))
		end
	end

	-- Cargas (esenciales/utilidades) o acumulaciones (beneficios)
	local countFrame = item.ChargeCount or item.Applications
	local count = countFrame and (countFrame.Current or countFrame.Applications)
	if countFrame then countFrame:SetFrameLevel(top + 3) end
	if count then
		ns.SetFont(count, db.font, db.countSize, db.outline)
		count:SetTextColor(ns.Color(db.countColor))
		count:ClearAllPoints()
		count:SetPoint(db.countPoint, item, db.countPoint, pointOffset(db.countPoint, 2))
	end

	if V.def.cd then
		if db.keybind then
			if not s.key then
				s.key = s.border:CreateFontString(nil, "OVERLAY")
				s.key:SetPoint("TOPRIGHT", -2, -2)
			end
			ns.SetFont(s.key, db.font, db.keySize, db.outline)
			s.key:SetText(keyText(item) or "")
			s.key:Show()
		elseif s.key then
			s.key:Hide()
		end
		if item.CooldownFlash then item.CooldownFlash:SetAlpha(db.hideFlash and 0 or 1) end
		if not db.desaturate then
			guard = true
			icon:SetDesaturated(false)
			guard = false
		end
		if db.cdAlpha >= 1 and s.alphaSet then
			icon:SetAlpha(1)
			s.alphaSet = nil
		end
		fixGlow(V, item)
	end
end

----------------------------------------------------------------------
-- Estilo de una barra (beneficios en barras)
----------------------------------------------------------------------

local function styleBar(V, item, s, db)
	local iconFrame, bar = item.Icon, item.Bar
	if not (iconFrame and bar) then return end
	local icon = iconFrame.Icon
	local w, h
	if db.layout then
		w, h = db.width, db.height
		item:SetScale(1)
		item:SetSize(w, h)
	else
		w, h = NS(item:GetWidth()) or 200, NS(item:GetHeight()) or 30
	end

	if icon and icon.SetTexCoord then
		findArt(iconFrame, icon, s)
		setMasks(icon, s, db.stripArt)
		if s.overlay then s.overlay:SetAlpha(db.stripArt and 0 or 1) end
		s.l, s.r, s.t, s.b = ns.TexCoord(h, h, db.zoom)
		applyCoords(icon, s)
	end
	iconFrame:SetSize(h, h)
	iconFrame:ClearAllPoints()
	iconFrame:SetPoint("LEFT", item, "LEFT", 0, 0)
	iconFrame:SetAlpha(db.showIcon and 1 or 0)
	if item.DebuffBorder then item.DebuffBorder:SetAlpha(db.showIcon and 1 or 0) end

	-- El icono puede estar oculto por el ajuste «Contenido de la barra» de Blizzard
	local withIcon = db.showIcon and iconFrame:IsShown()
	bar:ClearAllPoints()
	if withIcon then
		bar:SetPoint("TOPLEFT", iconFrame, "TOPRIGHT", math.max(db.border, 1) + 1, 0)
	else
		bar:SetPoint("TOPLEFT", item, "TOPLEFT", 0, 0)
	end
	bar:SetPoint("BOTTOMRIGHT", item, "BOTTOMRIGHT", 0, 0)

	pcall(bar.SetStatusBarTexture, bar, db.barTexture)
	bar:SetStatusBarColor(ns.Color(db.barColor))
	if bar.Pip then bar.Pip:SetAlpha(db.spark and 1 or 0) end
	if bar.BarBG then bar.BarBG:SetAlpha(db.stripArt and 0 or 1) end
	if not s.bg then s.bg = bar:CreateTexture(nil, "BACKGROUND", nil, -8) end
	s.bg:SetAllPoints(bar)
	s.bg:SetColorTexture(ns.Color(db.bgColor, db.bgAlpha))
	s.bg:SetShown(db.stripArt)

	if not s.border then s.border = ns.Border(bar) end
	s.border:SetFrameLevel(bar:GetFrameLevel() + 2)
	s.border:SetLook(db.border, ns.Color(db.borderColor))
	if not s.iconBorder then s.iconBorder = ns.Border(iconFrame) end
	s.iconBorder:SetFrameLevel(iconFrame:GetFrameLevel() + 2)
	s.iconBorder:SetLook(withIcon and db.border or 0, ns.Color(db.borderColor))

	if bar.Name then
		ns.SetFont(bar.Name, db.font, db.nameSize, db.outline)
		bar.Name:SetTextColor(ns.Color(db.textColor))
		bar.Name:SetAlpha(db.showName and 1 or 0)
	end
	if bar.Duration then
		ns.SetFont(bar.Duration, db.font, db.cdSize, db.outline)
		bar.Duration:SetTextColor(ns.Color(db.textColor))
		bar.Duration:SetAlpha(db.showTime and 1 or 0)
		bar.Duration:ClearAllPoints()
		bar.Duration:SetPoint("RIGHT", bar, "RIGHT", -4, 0)
	end
	local count = iconFrame.Applications
	if count then
		ns.SetFont(count, db.font, db.countSize, db.outline)
		count:SetTextColor(ns.Color(db.countColor))
		count:ClearAllPoints()
		count:SetPoint("BOTTOMRIGHT", iconFrame, "BOTTOMRIGHT", -1, 2)
	end
end

local function styleItem(V, item)
	local s = side[item]
	if not s then
		s = {}
		side[item] = s
	end
	if not s.hooked then hookItem(V, item, s) end
	local db = V.mod.db
	if V.def.kind == "bar" then
		styleBar(V, item, s, db)
	else
		styleIcon(V, item, s, db)
	end
end

----------------------------------------------------------------------
-- Colocación
----------------------------------------------------------------------

local function gridOptions(V)
	local db = V.mod.db
	if V.def.kind == "bar" then
		return { w = db.width, h = db.height, gap = db.spacing, perRow = 999,
		         grow = (db.grow == "up") and "up" or "down", rowGrow = "after", align = "start" }
	end
	return { w = db.width, h = db.height, gap = db.spacing, perRow = db.perRow,
	         grow = db.grow, rowGrow = db.rowGrow, align = db.align }
end

local function growthPoint(V)
	if not V.mod.db.layout then return "CENTER" end
	return ns.GrowthPoint(gridOptions(V))
end

-- Iconos del visor en el orden de Blizzard (layoutIndex)
local function itemFrames(V, all)
	local list = {}
	local collapse = V.mod.db.collapse
	for _, child in ipairs({ V.frame:GetChildren() }) do
		local index = child.layoutIndex
		if type(index) == "number" and (child.Cooldown or child.Bar) then
			if all or not collapse or child:IsShown() then list[#list + 1] = child end
		end
	end
	table.sort(list, function(a, b) return a.layoutIndex < b.layoutIndex end)
	return list
end

local function anchorViewer(V)
	local v, db = V.frame, V.mod.db
	if not (db.move and V.holder and active(V)) then return end
	if InCombatLockdown() and v:IsProtected() then
		R:RunOutOfCombat(function() anchorViewer(V) end)
		return
	end
	local gp = growthPoint(V)
	guard = true
	v:ClearAllPoints()
	v:SetPoint(gp, V.holder, gp, 0, 0)
	guard = false
end

local function relayout(V)
	if not active(V) then return end
	local v, db = V.frame, V.mod.db
	for _, item in ipairs(itemFrames(V, true)) do styleItem(V, item) end
	if db.layout then
		local frames = itemFrames(V, false)
		-- Los ocultos que no entran en la rejilla se apartan encima del primero
		if db.collapse then
			for _, item in ipairs(itemFrames(V, true)) do
				if not item:IsShown() then
					item:ClearAllPoints()
					item:SetPoint("TOPLEFT", v, "TOPLEFT", 0, 0)
				end
			end
		end
		local W, H = ns.LayoutGrid(v, frames, gridOptions(V))
		v:SetSize(W, H)
	end
	if V.holder then
		V.holder:SetSize(NS(v:GetWidth()) or 40, NS(v:GetHeight()) or 40)
		anchorViewer(V)
	end
	if ns.OnViewerLayout then ns.OnViewerLayout(V.def.id) end
end

local pending = {}
function schedule(V)
	if pending[V] then return end
	pending[V] = true
	C_Timer.After(0, function()
		pending[V] = nil
		relayout(V)
	end)
end

local function applyAlpha(V)
	if not V.frame then return end
	local a = (V.blizzAlpha or 1) * ((active(V) and V.visAlpha) or 1)
	V.frame:SetAlpha(a)
end

----------------------------------------------------------------------
-- Posición propia (solo con «Rheizor lo coloca»)
----------------------------------------------------------------------

local function ensureHolder(V)
	if V.holder then return V.holder end
	local db = V.mod.db
	local hf = CreateFrame("Frame", "RheizorCDM" .. V.def.id, UIParent)
	hf:SetSize(NS(V.frame:GetWidth()) or 40, NS(V.frame:GetHeight()) or 40)
	-- Empieza donde estaba el visor
	if not db.point then ns.SavePoint(V.frame, db, "point", growthPoint(V)) end
	V.holder = hf
	hf.mover = R:CreateMover(hf, V.def.title, db, "point", db.point or { "CENTER", "CENTER", 0, -150 })
	-- El mover guarda el punto que da WoW; se cambia por el de crecimiento
	hf.mover:HookScript("OnDragStop", function()
		ns.SavePoint(hf, db, "point", growthPoint(V))
		hf.mover:Place()
	end)
	return hf
end

local function applyPosition(V)
	local db = V.mod.db
	if db.move and active(V) then
		ensureHolder(V)
		V.holder.mover:Place()
		V.holder.mover:SetShown(not db.locked)
		anchorViewer(V)
	elseif V.holder then
		V.holder.mover:Hide()
	end
end

----------------------------------------------------------------------
-- Enganchar un visor (cuando Blizzard_CooldownViewer está cargado)
----------------------------------------------------------------------

local function install(V)
	local v = _G[V.def.frame]
	if V.frame or type(v) ~= "table" or not v.Layout then return end
	V.frame = v
	byFrame[v] = V
	V.blizzAlpha = NS(v:GetAlpha()) or 1

	-- GridLayoutFrameMixin:Layout (Blizzard_SharedXML/LayoutFrame.lua); lo
	-- llama RefreshLayout al final y LayoutMixin.OnShow al mostrarse
	hooksecurefunc(v, "Layout", function() relayout(V) end)
	-- CooldownViewerMixin:OnAcquireItemFrame (CooldownViewer.lua)
	if v.OnAcquireItemFrame then
		hooksecurefunc(v, "OnAcquireItemFrame", function(_, item)
			if active(V) then styleItem(V, item) end
		end)
	end
	-- La opacidad del Modo edición (EditModeSystemTemplates.lua)
	if v.UpdateSystemSettingOpacity then
		hooksecurefunc(v, "UpdateSystemSettingOpacity", function(self)
			V.blizzAlpha = NS(self:GetAlpha()) or 1
			applyAlpha(V)
		end)
	end
	-- Si Rheizor lo coloca, cualquier otro SetPoint (Modo edición, marcos
	-- gestionados de abajo) se corrige al momento
	hooksecurefunc(v, "SetPoint", function()
		if not guard and V.mod.db.move and V.holder and active(V) then anchorViewer(V) end
	end)

	ns.RegisterVisibility(v, function() return active(V) and V.mod.db or nil end, function(a)
		V.visAlpha = a
		applyAlpha(V)
	end)
	ns.viewerFrames[V.def.id] = v
	applyPosition(V)
	relayout(V)
end

----------------------------------------------------------------------
-- Módulos (uno por visor, cada uno con su página)
----------------------------------------------------------------------

ns.viewerFrames = {}
local keyTimer

for _, def in ipairs(VIEWERS) do
	local V = { def = def }
	def.V = V
	local mod = R:RegisterModule(def.key, {
		title = def.title,
		defaults = viewerDefaults(def),
		options = viewerOptions(def),
	})
	V.mod = mod

	function mod:OnEnable()
		ns.StartVisibility()
		if EventUtil and EventUtil.ContinueOnAddOnLoaded then
			EventUtil.ContinueOnAddOnLoaded("Blizzard_CooldownViewer", function() install(V) end)
		else
			install(V)
		end
	end

	function mod:ResetPosition()
		self.db.point = nil
		if V.holder and V.frame then
			-- Vuelve a donde lo tenga el Modo edición
			R:NeedReload()
		end
	end

	function mod:OnOptionChanged(key, value)
		if not V.frame then return end
		if key == "enabled" then
			if value then relayout(V) else R:NeedReload() end
			ns.RefreshVisibility()
		elseif key == "move" then
			if value then applyPosition(V) else
				if V.holder then V.holder.mover:Hide() end
				R:NeedReload()
			end
		elseif key == "locked" then
			applyPosition(V)
		elseif key == "layout" and not value then
			R:NeedReload()
		elseif key == "show" or key == "where" or key == "group" or key == "hoverShow" or key == "hideMounted"
			or key == "oocAlpha" or key == "hiddenAlpha" then
			ns.RefreshVisibility()
		else
			relayout(V)
		end
	end
end

-- Recolocar un visor desde fuera (anclajes de las barras propias)
function ns.ViewerRelayout(id)
	for _, def in ipairs(VIEWERS) do
		if def.id == id then relayout(def.V) end
	end
end

-- Teclas: al cambiar las barras de acción o las asignaciones
local keyEvents = CreateFrame("Frame")
keyEvents:RegisterEvent("UPDATE_BINDINGS")
keyEvents:RegisterEvent("ACTIONBAR_SLOT_CHANGED")
keyEvents:SetScript("OnEvent", function()
	ns.InvalidateKeys()
	if keyTimer then return end
	keyTimer = C_Timer.NewTimer(0.5, function()
		keyTimer = nil
		for _, def in ipairs(VIEWERS) do
			if def.cd and def.V.frame and def.V.mod.db.keybind then relayout(def.V) end
		end
		if ns.OnKeysChanged then ns.OnKeysChanged() end
	end)
end)
