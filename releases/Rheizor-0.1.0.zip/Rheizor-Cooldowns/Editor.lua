-- Editor de barras propias (/rzcd, /rz cd o el botón de las opciones):
--   Izquierda: las barras (crear, borrar).
--   Centro:    lo que lleva la barra elegida (añadir por número o nombre,
--              arrastrando un hechizo u objeto, abalorios y racial; subir,
--              bajar y quitar).
--   Derecha:   nombre, estilo, tamaño, distribución, anclaje, visibilidad
--              y estados de la barra.
-- Mientras está abierto se ven todas las barras y todo lo que llevan (lo
-- que no tienes sale en gris) para poder colocarlas.

local ADDON, ns = ...
local R = Rheizor:Namespace(ADDON)
local L = R.L
local NS = R.NotSecret
local M = ns.bars
local UI = R.UI or {}

local W, H = 800, 560
local LIST_W, ENTRY_W, SET_W = 170, 290, 300
local ROW_H = 26
local WHITE = ns.WHITE

local win, barList, entryList, settings
local barRows, entryRows, controls = {}, {}, {}
local selected            -- id de la barra elegida
local armed = false       -- "Borrar" pide un segundo clic
local nameBox, typeDrop, inputBox, statusText, deleteButton
local addType = "spell"

local function backdrop(f, alpha)
	if UI.SetBackdrop then return UI.SetBackdrop(f, alpha) end
	f:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	f:SetBackdropColor(0.05, 0.05, 0.07, alpha or 0.95)
	f:SetBackdropBorderColor(0.2, 0.8, 1, 0.9)
end

local function setStatus(text, r, g, b)
	statusText:SetText(text or "")
	statusText:SetTextColor(r or 1, g or 1, b or 1)
end

local function button(parent, text, width, height)
	local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
	b:SetSize(width or 100, height or 22)
	b:SetText(text)
	return b
end

local function scroll(parent)
	local sf
	if UI.MakeScroll then
		sf = UI.MakeScroll(parent)
	else
		sf = CreateFrame("ScrollFrame", nil, parent, "UIPanelScrollFrameTemplate")
		sf.child = CreateFrame("Frame", nil, sf)
		sf:SetScrollChild(sf.child)
	end
	return sf
end

-- Lista desplegable (la del gestor de Rheizor; sin él, pasa al siguiente valor)
local function dropdown(parent, width)
	local b = CreateFrame("Button", nil, parent, "BackdropTemplate")
	b:SetSize(width, 22)
	b:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	b:SetBackdropColor(0, 0, 0, 0.6)
	b:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	local hl = b:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	b.text:SetPoint("LEFT", 6, 0)
	b.text:SetPoint("RIGHT", -18, 0)
	b.text:SetJustifyH("LEFT")
	b.text:SetWordWrap(false)
	local arrow = b:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	arrow:SetPoint("RIGHT", -6, 0)
	arrow:SetText("v")
	function b:SetValues(values, current, onPick)
		self.values, self.current, self.onPick = values, current, onPick
		self.text:SetText(ns.ValueText(values, current))
	end
	b:SetScript("OnClick", function(self)
		if not self.values then return end
		local shown = {}
		for i, v in ipairs(self.values) do shown[i] = { v[1], L[v[2]] } end
		if UI.OpenPopup then
			UI.OpenPopup(self, shown, self.current, self.onPick)
		else
			local nextIndex = 1
			for i, v in ipairs(shown) do
				if v[1] == self.current then nextIndex = i % #shown + 1 end
			end
			self.onPick(shown[nextIndex][1])
		end
	end)
	return b
end

----------------------------------------------------------------------
-- Barra elegida
----------------------------------------------------------------------

local function current()
	return selected and M:FindConf(selected)
end

-- Rebuild vuelve a colocar las barras y redibuja esta ventana
local function changed()
	M:Rebuild()
end

----------------------------------------------------------------------
-- Columna izquierda: barras
----------------------------------------------------------------------

local selectBar   -- se define más abajo

local function barRow(i)
	local row = barRows[i]
	if row then return row end
	row = CreateFrame("Button", nil, barList.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", barList.child, "RIGHT")
	row.sel = row:CreateTexture(nil, "BACKGROUND")
	row.sel:SetAllPoints()
	row.sel:SetColorTexture(0.2, 0.8, 1, 0.22)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(0.2, 0.8, 1, 0.12)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.text:SetPoint("LEFT", 6, 0)
	row.text:SetPoint("RIGHT", -4, 0)
	row.text:SetJustifyH("LEFT")
	row.text:SetWordWrap(false)
	row:SetScript("OnClick", function(self) selectBar(self.id) end)
	barRows[i] = row
	return row
end

local function drawBars()
	local confs = M:GetBarConfs()
	for i, c in ipairs(confs) do
		local row = barRow(i)
		row.id = c.id
		row.text:SetText(string.format("%s |cff888888(%d)|r", c.name ~= "" and c.name or "?", #c.entries))
		row.sel:SetShown(c.id == selected)
		row:Show()
	end
	for i = #confs + 1, #barRows do barRows[i]:Hide() end
	barList.child:SetHeight(math.max(1, #confs * ROW_H))
	if barList.UpdateBar then barList:UpdateBar() end
	deleteButton:SetEnabled(selected ~= nil)
	deleteButton:SetText(armed and L["|cffff5555¿Seguro? Pulsa otra vez|r"] or L["Borrar"])
end

----------------------------------------------------------------------
-- Columna central: entradas
----------------------------------------------------------------------

local function typeName(t)
	return ns.ValueText(M.TYPES, t)
end

local function moveEntry(index, delta)
	local conf = current()
	if not conf then return end
	local other = index + delta
	if other < 1 or other > #conf.entries then return end
	conf.entries[index], conf.entries[other] = conf.entries[other], conf.entries[index]
	changed()
end

local function removeEntry(index)
	local conf = current()
	if not conf then return end
	table.remove(conf.entries, index)
	changed()
end

local function smallButton(parent, text, onClick)
	local b = button(parent, text, 22, 20)
	b:SetScript("OnClick", onClick)
	return b
end

local function entryRow(i)
	local row = entryRows[i]
	if row then return row end
	row = CreateFrame("Frame", nil, entryList.child)
	row:SetHeight(ROW_H)
	row:SetPoint("TOPLEFT", 0, -(i - 1) * ROW_H)
	row:SetPoint("RIGHT", entryList.child, "RIGHT")
	row:EnableMouse(true)
	local hl = row:CreateTexture(nil, "HIGHLIGHT")
	hl:SetAllPoints()
	hl:SetColorTexture(1, 1, 1, 0.06)
	row.icon = row:CreateTexture(nil, "ARTWORK")
	row.icon:SetSize(20, 20)
	row.icon:SetPoint("LEFT", 4, 0)
	row.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
	row.del = smallButton(row, "x", function() removeEntry(row.index) end)
	row.del:SetPoint("RIGHT", -2, 0)
	row.down = smallButton(row, "v", function() moveEntry(row.index, 1) end)
	row.down:SetPoint("RIGHT", row.del, "LEFT", -2, 0)
	row.up = smallButton(row, "^", function() moveEntry(row.index, -1) end)
	row.up:SetPoint("RIGHT", row.down, "LEFT", -2, 0)
	row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	row.text:SetPoint("TOPLEFT", row.icon, "TOPRIGHT", 6, 1)
	row.text:SetPoint("RIGHT", row.up, "LEFT", -4, 0)
	row.text:SetJustifyH("LEFT")
	row.text:SetWordWrap(false)
	row.sub = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	row.sub:SetPoint("BOTTOMLEFT", row.icon, "BOTTOMRIGHT", 6, -1)
	row.sub:SetPoint("RIGHT", row.up, "LEFT", -4, 0)
	row.sub:SetJustifyH("LEFT")
	row.sub:SetWordWrap(false)
	row:SetScript("OnEnter", function(self)
		local e = self.entry
		if not e then return end
		GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
		if (e.t == "spell" or e.t == "aura") and e.id then
			GameTooltip:SetSpellByID(e.id)
		elseif e.t == "item" and e.id then
			GameTooltip:SetItemByID(e.id)
		else
			GameTooltip:SetText((M:EntryInfo(e)), 1, 1, 1)
		end
		GameTooltip:Show()
	end)
	row:SetScript("OnLeave", GameTooltip_Hide)
	entryRows[i] = row
	return row
end

local function drawEntries()
	local conf = current()
	local entries = conf and conf.entries or {}
	for i, e in ipairs(entries) do
		local row = entryRow(i)
		row.index, row.entry = i, e
		local name, icon = M:EntryInfo(e)
		row.icon:SetTexture(icon)
		row.text:SetText(name)
		local sub = typeName(e.t)
		if e.id and e.t ~= "slot" then sub = sub .. "  |cff666666#" .. e.id .. "|r" end
		row.sub:SetText(sub)
		row.up:SetEnabled(i > 1)
		row.down:SetEnabled(i < #entries)
		row:Show()
	end
	for i = #entries + 1, #entryRows do entryRows[i]:Hide() end
	entryList.child:SetHeight(math.max(1, #entries * ROW_H))
	if entryList.UpdateBar then entryList:UpdateBar() end
end

-- Añadir: lo escrito en la casilla, según el tipo elegido
local function parseEntry(t, text)
	text = strtrim(text or "")
	if t == "racial" then return { t = "racial" } end
	if text == "" then return nil, L["Escribe un número o un nombre."] end
	local n = tonumber(text)
	if t == "spell" or t == "aura" then
		local id = n
		if not id then
			local link = text:match("spell:(%d+)")
			id = link and tonumber(link)
		end
		if not id and C_Spell.GetSpellIDForSpellIdentifier then
			local ok, found = pcall(C_Spell.GetSpellIDForSpellIdentifier, text)
			id = ok and NS(found) or nil
		end
		local name = id and ns.SpellName(id)
		if not name then return nil, L["No se encuentra ese hechizo."] end
		return { t = t, id = id, name = name }
	elseif t == "item" then
		local id = n or tonumber(text:match("item:(%d+)") or "")
		if not id and C_Item and C_Item.GetItemInfoInstant then
			local ok, found = pcall(C_Item.GetItemInfoInstant, text)
			id = ok and NS(found) or nil
		end
		if not id then return nil, L["No se encuentra ese objeto (prueba con su número)."] end
		return { t = "item", id = id, name = ns.ItemName(id) }
	elseif t == "slot" then
		if not n or n < 1 or n > 19 then return nil, L["Las casillas van del 1 al 19 (abalorios: 13 y 14)."] end
		return { t = "slot", id = n }
	end
end

local function addEntry(e)
	local conf = current()
	if not conf then
		setStatus(L["Crea o elige antes una barra."], 1, 0.33, 0.33)
		return
	end
	table.insert(conf.entries, e)
	setStatus(L["Añadido: %s"]:format((M:EntryInfo(e))), 0.2, 1, 0.2)
	changed()
end

local function onAdd()
	local e, err = parseEntry(addType, inputBox:GetText())
	if e then
		addEntry(e)
		inputBox:SetText("")
		inputBox:ClearFocus()
	else
		setStatus(err, 1, 0.33, 0.33)
	end
end

-- Arrastrar un hechizo (libro de hechizos) o un objeto (bolsas)
local function onDrop()
	local kind, a, _, c = GetCursorInfo()
	if kind == "spell" then
		local id = NS(c) or NS(a)
		if type(id) == "number" and ns.SpellName(id) then
			addEntry({ t = "spell", id = id, name = ns.SpellName(id) })
		end
	elseif kind == "item" then
		local id = NS(a)
		if type(id) == "number" then addEntry({ t = "item", id = id, name = ns.ItemName(id) }) end
	elseif kind then
		setStatus(L["Solo se pueden añadir hechizos y objetos."], 1, 0.33, 0.33)
	end
	ClearCursor()
end

----------------------------------------------------------------------
-- Columna derecha: ajustes de la barra
----------------------------------------------------------------------

local function pct(v) return string.format("%d%%", v * 100 + 0.5) end
local function int(v) return string.format("%d", v) end

local SETTINGS = {
	{ kind = "header", text = "Barra" },
	{ kind = "choice", key = "style", name = "Estilo", values = M.STYLES },
	{ kind = "choice", key = "fill", name = "Barra de tiempo", values = M.FILLS },
	{ kind = "choice", key = "iconPos", name = "Icono (barras)", values = M.ICONPOS },
	{ kind = "num", key = "iconSize", name = "Tamaño del icono (barras)", min = 0, max = 120, step = 1,
	  fmt = function(v) return v == 0 and L["Automático"] or string.format("%d", v) end },
	{ kind = "num", key = "width", name = "Ancho", min = 8, max = 400, step = 1, fmt = int },
	{ kind = "num", key = "height", name = "Alto", min = 8, max = 400, step = 1, fmt = int },
	{ kind = "num", key = "spacing", name = "Separación", min = 0, max = 30, step = 1, fmt = int },
	{ kind = "num", key = "perRow", name = "Por fila o columna", min = 1, max = 40, step = 1, fmt = int },
	{ kind = "choice", key = "grow", name = "Dirección", values = ns.GROW },
	{ kind = "choice", key = "rowGrow", name = "Filas nuevas", values = ns.ROWS },
	{ kind = "choice", key = "align", name = "Filas incompletas", values = ns.ALIGN },
	{ kind = "header", text = "Anclaje" },
	{ kind = "choice", key = "anchorTo", name = "Anclar a", values = "anchors" },
	{ kind = "choice", key = "anchorPoint", name = "Punto de esta barra", values = ns.POINTS },
	{ kind = "choice", key = "anchorRel", name = "Punto del otro marco", values = ns.POINTS },
	{ kind = "num", key = "x", name = "Desplazamiento X", min = -500, max = 500, step = 1, fmt = int },
	{ kind = "num", key = "y", name = "Desplazamiento Y", min = -500, max = 500, step = 1, fmt = int },
	{ kind = "check", key = "matchWidth", name = "Igualar la anchura del otro marco" },
	{ kind = "header", text = "Visibilidad" },
	{ kind = "choice", key = "show", name = "Mostrar", values = ns.SHOW },
	{ kind = "choice", key = "where", name = "Dónde", values = ns.WHERE },
	{ kind = "choice", key = "group", name = "Con quién", values = ns.GROUP },
	{ kind = "check", key = "hideMounted", name = "Ocultar al ir montado" },
	{ kind = "check", key = "hoverShow", name = "Mostrar también al pasar el ratón" },
	{ kind = "num", key = "oocAlpha", name = "Opacidad fuera de combate", min = 0, max = 1, step = 0.05, fmt = pct },
	{ kind = "num", key = "hiddenAlpha", name = "Opacidad cuando está oculta", min = 0, max = 1, step = 0.05, fmt = pct },
	{ kind = "header", text = "Estados" },
	{ kind = "check", key = "desaturate", name = "En gris mientras está en reutilización" },
	{ kind = "num", key = "cdAlpha", name = "Opacidad en reutilización", min = 0.1, max = 1, step = 0.05, fmt = pct },
	{ kind = "check", key = "hideGCD", name = "Sin reutilización global (GCD)" },
	{ kind = "check", key = "glow", name = "Brillo cuando se activa (proc)" },
	{ kind = "check", key = "hideUnknown", name = "Ocultar lo que no tienes" },
	{ kind = "check", key = "hideReady", name = "Ocultar lo que está disponible" },
	{ kind = "check", key = "hideOnCD", name = "Ocultar lo que está en reutilización" },
	{ kind = "check", key = "keepGap", name = "Dejar su hueco al ocultarlo" },
	{ kind = "check", key = "showCount", name = "Cargas, acumulaciones y número de objetos" },
	{ kind = "check", key = "keybind", name = "Mostrar la tecla" },
	{ kind = "check", key = "tint", name = "Color si no se puede usar (sin maná…)" },
	{ kind = "check", key = "tooltip", name = "Tooltip al pasar el ratón" },
	{ kind = "check", key = "showName", name = "Nombre (estilo de barras)" },
}

local GROWTH_KEYS = { grow = true, rowGrow = true, align = true }

-- Destinos de anclaje: pantalla, visores de Blizzard y las demás barras
local function anchorValues(conf)
	local values = {
		{ "screen", "Pantalla" },
		{ "viewer:essential", "Blizzard: esenciales" },
		{ "viewer:utility", "Blizzard: utilidades" },
		{ "viewer:bufficon", "Blizzard: beneficios en iconos" },
		{ "viewer:buffbar", "Blizzard: beneficios en barras" },
	}
	for _, c in ipairs(M:GetBarConfs()) do
		if c.id ~= conf.id and not M:WouldLoop(conf, "bar:" .. c.id) then
			values[#values + 1] = { "bar:" .. c.id, L["Barra: %s"]:format(c.name ~= "" and c.name or "?") }
		end
	end
	return values
end

local function setValue(key, value)
	local conf = current()
	if not conf then return end
	local frame = M:BarFrame(conf.id)
	if key == "anchorTo" and value == "screen" and conf.anchorTo ~= "screen" and frame then
		-- Se queda donde está, ahora anclada a la pantalla
		ns.SavePoint(frame, conf, "point", ns.GrowthPoint(conf))
	end
	conf[key] = value
	if GROWTH_KEYS[key] and conf.anchorTo == "screen" and frame then
		ns.SavePoint(frame, conf, "point", ns.GrowthPoint(conf))
	end
	changed()
end

local function makeControls(parent)
	local y = 0
	local labelW = 150
	for _, s in ipairs(SETTINGS) do
		local kind = s.kind
		local c
		if kind == "header" then
			c = CreateFrame("Frame", nil, parent)
			c:SetHeight(24)
			c.text = c:CreateFontString(nil, "OVERLAY", "GameFontNormal")
			c.text:SetPoint("BOTTOMLEFT", 2, 3)
			c.text:SetText(L[s.text])
			local line = c:CreateTexture(nil, "ARTWORK")
			line:SetColorTexture(0.2, 0.8, 1, 0.3)
			line:SetHeight(1)
			line:SetPoint("BOTTOMLEFT", 0, 0)
			line:SetPoint("BOTTOMRIGHT", 0, 0)
		elseif kind == "choice" then
			c = CreateFrame("Frame", nil, parent)
			c:SetHeight(ROW_H)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetWidth(labelW - 6)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.drop = dropdown(c, SET_W - labelW - 24)
			c.drop:SetPoint("LEFT", labelW, 0)
			function c:Refresh(conf)
				local values = s.values == "anchors" and anchorValues(conf) or s.values
				self.drop:SetValues(values, conf[s.key], function(value) setValue(s.key, value) end)
			end
		elseif kind == "num" then
			c = CreateFrame("Frame", nil, parent)
			c:SetHeight(ROW_H)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", 2, 0)
			c.label:SetWidth(labelW - 6)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			local minus = button(c, "-", 24, 20)
			minus:SetPoint("LEFT", labelW, 0)
			c.value = c:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
			c.value:SetPoint("LEFT", minus, "RIGHT", 4, 0)
			c.value:SetWidth(52)
			local plus = button(c, "+", 24, 20)
			plus:SetPoint("LEFT", c.value, "RIGHT", 4, 0)
			local function step(dir)
				local conf = current()
				if not conf then return end
				local amount = s.step * (IsShiftKeyDown() and 10 or 1) * dir
				local v = (conf[s.key] or 0) + amount
				v = math.max(s.min, math.min(s.max, v))
				v = math.floor(v / s.step + 0.5) * s.step
				setValue(s.key, v)
			end
			minus:SetScript("OnClick", function() step(-1) end)
			plus:SetScript("OnClick", function() step(1) end)
			function c:Refresh(conf)
				self.value:SetText(s.fmt(conf[s.key] or 0))
			end
		elseif kind == "check" then
			c = CreateFrame("Frame", nil, parent)
			c:SetHeight(ROW_H - 2)
			c.check = CreateFrame("CheckButton", nil, c, "UICheckButtonTemplate")
			c.check:SetSize(22, 22)
			c.check:SetPoint("LEFT", 0, 0)
			c.label = c:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
			c.label:SetPoint("LEFT", c.check, "RIGHT", 4, 0)
			c.label:SetPoint("RIGHT", 0, 0)
			c.label:SetJustifyH("LEFT")
			c.label:SetText(L[s.name])
			c.check:SetScript("OnClick", function(self) setValue(s.key, self:GetChecked() and true or false) end)
			function c:Refresh(conf)
				self.check:SetChecked(conf[s.key] and true or false)
			end
		end
		c:SetPoint("TOPLEFT", 0, -y)
		c:SetPoint("RIGHT", parent, "RIGHT", -8, 0)
		y = y + c:GetHeight()
		controls[#controls + 1] = c
	end
	return y
end

local function drawSettings()
	local conf = current()
	settings:SetShown(conf ~= nil)
	nameBox:SetShown(conf ~= nil)
	if not conf then return end
	if not nameBox:HasFocus() then nameBox:SetText(conf.name or "") end
	for _, c in ipairs(controls) do
		if c.Refresh then c:Refresh(conf) end
	end
end

----------------------------------------------------------------------
-- Ventana
----------------------------------------------------------------------

function M:RefreshEditor()
	if not win or not win:IsShown() then return end
	if selected and not current() then selected = nil end
	drawBars()
	drawEntries()
	drawSettings()
end

function selectBar(id)
	selected = id
	armed = false
	setStatus("")
	M:RefreshEditor()
end

local function column(x, width, title)
	local f = CreateFrame("Frame", nil, win, "BackdropTemplate")
	f:SetPoint("TOPLEFT", x, -58)
	f:SetPoint("BOTTOMLEFT", x, 12)
	f:SetWidth(width)
	backdrop(f, 0.45)
	f:SetBackdropBorderColor(1, 1, 1, 0.08)
	local t = win:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	t:SetPoint("BOTTOMLEFT", f, "TOPLEFT", 2, 4)
	t:SetText(title)
	return f
end

local function createWindow()
	win = CreateFrame("Frame", "RheizorCooldownsEditor", UIParent, "BackdropTemplate")
	win:SetSize(W, H)
	win:SetFrameStrata("DIALOG")
	win:SetToplevel(true)
	win:SetClampedToScreen(true)
	win:SetMovable(true)
	win:EnableMouse(true)
	backdrop(win, 0.94)
	win:Hide()
	table.insert(UISpecialFrames, "RheizorCooldownsEditor")   -- se cierra con Esc

	local drag = CreateFrame("Frame", nil, win)
	drag:SetPoint("TOPLEFT")
	drag:SetPoint("TOPRIGHT", -30, 0)
	drag:SetHeight(30)
	drag:EnableMouse(true)
	drag:RegisterForDrag("LeftButton")
	drag:SetScript("OnDragStart", function() win:StartMoving() end)
	drag:SetScript("OnDragStop", function()
		win:StopMovingOrSizing()
		win:SetUserPlaced(false)
		local point, _, relPoint, px, py = win:GetPoint()
		M.db.winPoint = { point, relPoint, px, py }
	end)

	local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 14, -9)
	title:SetText("|cff33ccffRheizor|r · " .. L["Barras de reutilización"])

	local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 2, 2)
	close:SetScript("OnClick", function() win:Hide() end)

	local blizz = button(win, L["Gestor de Blizzard"], 150)
	blizz:SetPoint("RIGHT", close, "LEFT", -6, 0)
	blizz:SetScript("OnClick", function() ns.OpenBlizzardSettings() end)

	-- Izquierda: barras
	local left = column(10, LIST_W, L["Barras"])
	barList = scroll(left)
	barList:SetPoint("TOPLEFT", 2, -2)
	barList:SetPoint("BOTTOMRIGHT", -4, 34)
	barList.child:SetSize(LIST_W - 8, 1)
	local new = button(left, L["Nueva"], (LIST_W - 12) / 2)
	new:SetPoint("BOTTOMLEFT", 4, 6)
	new:SetScript("OnClick", function()
		local conf = M:NewBar()
		selectBar(conf.id)
		nameBox:SetFocus()
		nameBox:HighlightText()
	end)
	deleteButton = button(left, L["Borrar"], (LIST_W - 12) / 2)
	deleteButton:SetPoint("LEFT", new, "RIGHT", 4, 0)
	deleteButton:SetScript("OnClick", function()
		if not selected then return end
		if not armed then
			armed = true
			drawBars()
			return
		end
		armed = false
		M:DeleteBar(selected)
		selected = nil
		M:RefreshEditor()
	end)

	-- Centro: lo que lleva la barra
	local mid = column(10 + LIST_W + 10, ENTRY_W, L["Contenido"])
	entryList = scroll(mid)
	entryList:SetPoint("TOPLEFT", 2, -2)
	entryList:SetPoint("BOTTOMRIGHT", -4, 150)
	entryList.child:SetSize(ENTRY_W - 8, 1)

	typeDrop = dropdown(mid, 110)
	typeDrop:SetPoint("BOTTOMLEFT", 6, 120)
	local function pickType(value)
		addType = value
		typeDrop:SetValues(M.TYPES, addType, pickType)
		inputBox:SetShown(addType ~= "racial")
	end
	inputBox = CreateFrame("EditBox", nil, mid, "BackdropTemplate")
	inputBox:SetSize(ENTRY_W - 110 - 70 - 20, 22)
	inputBox:SetPoint("LEFT", typeDrop, "RIGHT", 4, 0)
	inputBox:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	inputBox:SetBackdropColor(0, 0, 0, 0.6)
	inputBox:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	inputBox:SetFontObject(GameFontHighlightSmall)
	inputBox:SetTextInsets(6, 6, 0, 0)
	inputBox:SetAutoFocus(false)
	inputBox:SetScript("OnEscapePressed", inputBox.ClearFocus)
	inputBox:SetScript("OnEnterPressed", onAdd)
	inputBox:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(L["Número o nombre"], 1, 1, 1)
		GameTooltip:AddLine(L["Hechizo o aura: su número o su nombre. Objeto: su número (o su nombre si lo llevas). Casilla: 13 y 14 son los abalorios."], nil, nil, nil, true)
		GameTooltip:Show()
	end)
	inputBox:SetScript("OnLeave", GameTooltip_Hide)
	local add = button(mid, L["Añadir"], 64)
	add:SetPoint("LEFT", inputBox, "RIGHT", 4, 0)
	add:SetScript("OnClick", onAdd)
	typeDrop:SetValues(M.TYPES, addType, pickType)

	local t1 = button(mid, L["Abalorio 1"], 88)
	t1:SetPoint("BOTTOMLEFT", 6, 92)
	t1:SetScript("OnClick", function() addEntry({ t = "slot", id = 13 }) end)
	local t2 = button(mid, L["Abalorio 2"], 88)
	t2:SetPoint("LEFT", t1, "RIGHT", 4, 0)
	t2:SetScript("OnClick", function() addEntry({ t = "slot", id = 14 }) end)
	local rc = button(mid, L["Racial"], 88)
	rc:SetPoint("LEFT", t2, "RIGHT", 4, 0)
	rc:SetScript("OnClick", function() addEntry({ t = "racial" }) end)

	local drop = CreateFrame("Button", nil, mid, "BackdropTemplate")
	drop:SetPoint("BOTTOMLEFT", 6, 36)
	drop:SetPoint("RIGHT", mid, "RIGHT", -6, 0)
	drop:SetHeight(48)
	drop:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	drop:SetBackdropColor(0.2, 0.8, 1, 0.06)
	drop:SetBackdropBorderColor(0.2, 0.8, 1, 0.5)
	drop.text = drop:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	drop.text:SetPoint("LEFT", 8, 0)
	drop.text:SetPoint("RIGHT", -8, 0)
	drop.text:SetText(L["Arrastra aquí un hechizo del libro o un objeto de las bolsas"])
	drop:RegisterForClicks("LeftButtonUp")
	drop:SetScript("OnReceiveDrag", onDrop)
	drop:SetScript("OnClick", onDrop)

	statusText = mid:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	statusText:SetPoint("BOTTOMLEFT", 6, 12)
	statusText:SetPoint("RIGHT", mid, "RIGHT", -6, 0)
	statusText:SetJustifyH("LEFT")
	statusText:SetWordWrap(false)

	-- Derecha: ajustes
	local right = column(10 + LIST_W + 10 + ENTRY_W + 10, SET_W, L["Ajustes de la barra"])
	local nameLabel = right:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	nameLabel:SetPoint("TOPLEFT", 8, -12)
	nameLabel:SetText(L["Nombre"])
	nameBox = CreateFrame("EditBox", nil, right, "BackdropTemplate")
	nameBox:SetPoint("LEFT", nameLabel, "RIGHT", 8, 0)
	nameBox:SetPoint("RIGHT", right, "RIGHT", -10, 0)
	nameBox:SetHeight(22)
	nameBox:SetBackdrop({ bgFile = WHITE, edgeFile = WHITE, edgeSize = 1 })
	nameBox:SetBackdropColor(0, 0, 0, 0.6)
	nameBox:SetBackdropBorderColor(0.35, 0.35, 0.35, 1)
	nameBox:SetFontObject(GameFontHighlightSmall)
	nameBox:SetTextInsets(6, 6, 0, 0)
	nameBox:SetAutoFocus(false)
	nameBox:SetMaxLetters(40)
	local function saveName(self)
		local conf = current()
		if conf then
			local text = strtrim(self:GetText() or "")
			if text ~= "" and text ~= conf.name then
				conf.name = text
				changed()
			end
		end
		self:ClearFocus()
	end
	nameBox:SetScript("OnEnterPressed", saveName)
	nameBox:SetScript("OnEditFocusLost", function(self)
		local conf = current()
		local text = strtrim(self:GetText() or "")
		if conf and text ~= "" and text ~= conf.name then
			conf.name = text
			changed()
		end
	end)
	nameBox:SetScript("OnEscapePressed", function(self)
		local conf = current()
		self:SetText(conf and conf.name or "")
		self:ClearFocus()
	end)

	settings = scroll(right)
	settings:SetPoint("TOPLEFT", 6, -42)
	settings:SetPoint("BOTTOMRIGHT", -4, 4)
	settings.child:SetSize(SET_W - 14, 1)
	local height = makeControls(settings.child)
	settings.child:SetHeight(height + 10)

	local hint = win:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -4)
	hint:SetText(L["Mayús + clic en - o + cambia de 10 en 10. Mientras esta ventana está abierta se ven todas las barras."])

	win:SetScript("OnShow", function()
		M:SetEditorOpen(true)
		if not selected or not current() then
			local first = M:GetBarConfs()[1]
			selected = first and first.id
		end
		M:RefreshEditor()
	end)
	win:SetScript("OnHide", function()
		armed = false
		if nameBox then nameBox:ClearFocus() end
		if inputBox then inputBox:ClearFocus() end
		M:SetEditorOpen(false)
	end)

	local p = M.db.winPoint
	if p then win:SetPoint(p[1], UIParent, p[2], p[3], p[4]) else win:SetPoint("CENTER") end
end

function M:ToggleEditor()
	if not win then createWindow() end
	win:SetShown(not win:IsShown())
end

-- Abre el editor con esa barra elegida (el engranaje de su recuadro de mover)
function M:OpenEditorAt(id)
	if not win then createWindow() end
	selected = id
	if win:IsShown() then selectBar(id) else win:Show() end
end
